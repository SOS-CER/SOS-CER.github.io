package edu.ncsu.csc.realsearch.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class JUnitTestReader {

	public ArrayList<String> parseFile(String file, String version,
			String project) {
		ArrayList<String> testFiles = new ArrayList<String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line = in.readLine();
			while (line != null) {
				if (line.contains(") test")) {
					//1) test0(org.jdom.output.XMLOutputterTest1)java.lang.ArrayIndexOutOfBoundsException: -1000000
					String path = line.substring(line.indexOf("(")+1, line.lastIndexOf(")"));
//					System.out.println(path);
					testFiles.add(path.substring(path.lastIndexOf(".")+1) + ".java");
				}
				
				line = in.readLine();
			}
		} catch (IOException e) {
			
		}
		return testFiles;
	}

}
