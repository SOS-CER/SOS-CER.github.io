package edu.ncsu.csc.realsearch.main;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.io.AlertComparitor;
import edu.ncsu.csc.realsearch.io.AlertReader;
import edu.ncsu.csc.realsearch.io.ChurnReader;
import edu.ncsu.csc.realsearch.io.CnCAlertComparitor;
import edu.ncsu.csc.realsearch.io.HistoryReader;
import edu.ncsu.csc.realsearch.io.JavaNCSSMetricsXMLReader;
import edu.ncsu.csc.realsearch.io.MetricsXmlReader;
import edu.ncsu.csc.realsearch.io.PMDAlertComparitor;
import edu.ncsu.csc.realsearch.io.StatusReader;
import edu.ncsu.csc.realsearch.io.db.AlertDB;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.HistoryDB;

import edu.ncsu.csc.realsearch.parser.main.CVSParser;
import edu.ncsu.csc.realsearch.parser.main.SVNDiffParser;
import edu.ncsu.csc.realsearch.parser.main.SVNLogParser;

public class BenchmarkHistoryMain {
	
	public static String PROJECT = "";
	
		
	public static void main(String [] args) {
		long startTime = System.currentTimeMillis();
		if (args.length == 1) {
			PROJECT = args[0];
		} else {
//			PROJECT = "jdom";
			PROJECT = "eclipse";
		}
//		CreateDBTables.destroyAlertsTable(DBConnection.getInstance(false).getConnection());
//		CreateDBTables.destroyCommitsTable(DBConnection.getInstance(false).getConnection());
		//Create listing of alerts by version that includes all associated 
		//alert characteristic information
		BenchmarkHistoryMain bhm = new BenchmarkHistoryMain(PROJECT);
				
		//Steps:
		//0. Parse generated build status info
//		bhm.parseStatus();
		//1. Parse metrics files and store in hash table
//		bhm.parseMetrics();
		//2. Parse or hard code history info (revision, date, fix type)
//		bhm.parseHistory();
//		bhm.parseCommits();
		//3. Parse churn info
//		bhm.parseChurn();
		//4. Parse alert info - have to do individually
		bhm.parseAlerts();
//		bhm.parsePMDAlerts();
//		bhm.parseCnCAlerts();
		//5. Generate the rest of the alert characteristic info and write to db
		bhm.generateAlertCharacteristics();
		
		long endTime = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("Total Time (ms): " + totalTime);
	}
	
	public BenchmarkHistoryMain(String project) {
		PROJECT = project;
		CreateDBTables.createAlertsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createChurnTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createHistoryTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createMetricsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createMetricsNCSSPackageTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createMetricsNCSSObjectTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createMetricsNCSSFunctionTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createCommitsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createRuntimeCommitsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createJdomCommitsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.createVersionStatusTable(DBConnection.getInstance(false).getConnection());
		
		createMethodSignatureHashMap();
	}
	
	private void createMethodSignatureHashMap() {
		Constants.primitatives = new HashMap<String, String>();
		Constants.primitatives.put("Z", "boolean");
		Constants.primitatives.put("B", "byte");
		Constants.primitatives.put("C", "char");
		Constants.primitatives.put("D", "double");
		Constants.primitatives.put("F", "float");
		Constants.primitatives.put("I", "int");
		Constants.primitatives.put("J", "long");
		Constants.primitatives.put("L", "object");
		Constants.primitatives.put("S", "short");
		Constants.primitatives.put("V", "void");
		Constants.primitatives.put("[", "array");
	}
	
	
	private void generateAlertCharacteristics() {
		System.out.println("generating ACs");
		ArrayList<Alert> alerts = Alerts.getInstance().getAlerts();
		for (int i = 0; i < alerts.size(); i++) {
			alerts.get(i).generateAlertData();
			AlertDB.writeAlerts(DBConnection.getInstance(false).getConnection(), alerts.get(i));
		}
		System.out.println("Ending ACs");
	}
	
	private void parseAlerts() {
		System.out.println("Starting FB");
		File dir = null;
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + Constants.FB_ROOT);
			String [] files = dir.list(new AlertsFilter());
			AlertComparitor comp = new AlertComparitor();
			for (int i = 0; i < files.length; i++) {
				int dash = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + Constants.FB_ROOT + files[i], "\\|", false, files[i].substring(0, dash), files[i].substring(dash+1, lastDash));
			}
		} else if (Constants.ECLIPSE.equals(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.ALERTS_ROOT + Constants.FB_ROOT);
			String [] files = dir.list(new AlertsFilter());
			AlertComparitor comp = new AlertComparitor();
			for (int i = 0; i < files.length; i++) {
				int dash = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.ALERTS_ROOT + Constants.FB_ROOT + files[i], "\\|", false, files[i].substring(0, dash), files[i].substring(dash+1, lastDash));
			}
		} else if (Constants.LOGGING.equals(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.LOGGING_ROOT + Constants.ALERTS_ROOT + Constants.FB_ROOT);
			String [] files = dir.list(new AlertsFilter());
			AlertComparitor comp = new AlertComparitor();
			for (int i = 0; i < files.length; i++) {
				int dash = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.LOGGING_ROOT + Constants.ALERTS_ROOT + Constants.FB_ROOT + files[i], "\\|", false, files[i].substring(0, dash), files[i].substring(dash+1, lastDash));
			}
		}
		
		Alerts.getInstance().writeToDB();
		System.out.println("Ending FB");
	}
	
	private void parsePMDAlerts() {
		System.out.println("Starting PMD");
		File dir = null;
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + Constants.PMD_ROOT);
			String [] files = dir.list(new AlertsFilter());
			PMDAlertComparitor comp = new PMDAlertComparitor();
			for (int i = 0; i < files.length; i++) {
				int dash = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + Constants.PMD_ROOT + files[i], "\\|", false, files[i].substring(0, dash), files[i].substring(dash+1, lastDash));
			}
		} else if (Constants.ECLIPSE.equals(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.ALERTS_ROOT);
			String [] files = dir.list(new AlertsFilter());
			AlertComparitor comp = new AlertComparitor();
			for (int i = 0; i < files.length; i++) {
				int dash = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.ALERTS_ROOT + files[i], "\\|", false, files[i].substring(0, dash), files[i].substring(dash+1, lastDash));
			}
		} 
		
		Alerts.getInstance().writeToDB();
		System.out.println("Ending PMD");
	}
	
	private void parseCnCAlerts() {
		
		System.out.println("Starting CnC");
		File dir = null;
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + Constants.CNC_ROOT);
			String [] files = dir.list();
			CnCAlertComparitor comp = new CnCAlertComparitor();
			for (int i = 0; i < files.length; i++) {
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + Constants.CNC_ROOT + files[i], "\\|", false,  files[i], "jdom");
			}
		} else if (Constants.ECLIPSE.equals(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.ALERTS_ROOT);
			String [] files = dir.list();
			CnCAlertComparitor comp = new CnCAlertComparitor();
			for (int i = 0; i < files.length; i++) {
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.ALERTS_ROOT + files[i], "\\|", false, files[i], "org.eclipse.core.runtime");
			}
		} else if (Constants.LOGGING.equals(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.LOGGING_ROOT + Constants.ALERTS_ROOT + Constants.CNC_ROOT);
			String [] files = dir.list();
			CnCAlertComparitor comp = new CnCAlertComparitor();
			for (int i = 0; i < files.length; i++) {
				comp.compareAlerts(Constants.PROJECT_ROOT + Constants.LOGGING_ROOT + Constants.ALERTS_ROOT + Constants.CNC_ROOT + files[i], "\\|", false,  files[i], "logging");
			}
		}
		
		Alerts.getInstance().writeToDB();
		System.out.println("Ending CnC");
	}
	
	private void parseChurn() {
		//Not needed for this version
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
//			ChurnReader reader = new ChurnReader();
//			reader.gatherChurnData();
		}
	}
	
	protected void parseHistory() {
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
			CVSParser parser = new CVSParser();
			parser.parse("jdom", Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.HISTORY_ROOT + "jdom.log", DBConnection.getInstance(false).getConnection());
			
		} else if (Constants.ECLIPSE.equals(PROJECT)) {
			CVSParser parser = new CVSParser();
			parser.parse("org.eclipse.core.runtime", Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.HISTORY_ROOT + "org.eclipse.core.runtime.log", DBConnection.getInstance(false).getConnection());
			
		} else if (Constants.LOGGING.equals(PROJECT)) {
			SVNLogParser parser = new SVNLogParser("logging", Constants.PROJECT_ROOT + Constants.LOGGING_ROOT + Constants.HISTORY_ROOT + "logging-log.out", DBConnection.getInstance(false).getConnection());
//			parser.parse();
			File file = new File(Constants.PROJECT_ROOT + Constants.LOGGING_ROOT + Constants.HISTORY_ROOT);
			File [] fileList = file.listFiles(new SVNDiffFilter());
			SVNDiffParser diffParser = new SVNDiffParser("logging", DBConnection.getInstance(false).getConnection());
			for (int i = 0; i < fileList.length; i++) {
				diffParser.parse(fileList[i].getAbsolutePath());
			}
		}
		
	}
	
	protected void parseCommits() {
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
			HistoryDB.addDatesToJdomCommitsTable(DBConnection.getInstance(false).getConnection(), "jdom");
		} else if (Constants.ECLIPSE.equals(PROJECT)) {
			HistoryDB.addDatesToRuntimeCommitsTable(DBConnection.getInstance(false).getConnection(), "org.eclipse.core.runtime");
		} else if (Constants.LOGGING.equals(PROJECT)) {
			//don'e use for SVN projects
		}
		
	}
	
	protected void parseMetrics() {
		File dir = null;
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT);
			String [] files = dir.list(new MetricsFilter());
			JavaNCSSMetricsXMLReader reader = new JavaNCSSMetricsXMLReader();
			for (int i = 0; i < files.length; i++) {
				int dash1 = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
				reader.parseFile(dir.getAbsolutePath() + "/" + files[i], files[i].substring(0, dash1), files[i].substring(dash1+1, lastDash));
			}
		} else if (Constants.ECLIPSE.equals(PROJECT)) {
//			System.out.println(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_JDOM_ROOT);
			dir = new File(Constants.PROJECT_ROOT + Constants.ECLIPSE_ROOT + Constants.METRICS_ROOT);
			String [] files = dir.list(new MetricsFilter());
			JavaNCSSMetricsXMLReader reader = new JavaNCSSMetricsXMLReader();
			for (int i = 0; i < files.length; i++) {
				int dash1 = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
//				System.out.println(dir.getAbsolutePath() + "/" + files[i]);
				System.out.println(files[i]);
				reader.parseFile(dir.getAbsolutePath() + "/" + files[i], files[i].substring(0, dash1), files[i].substring(dash1+1, lastDash));
			}
		} else if (Constants.LOGGING.equals(PROJECT)) {
			dir = new File(Constants.PROJECT_ROOT + Constants.LOGGING_ROOT + Constants.METRICS_ROOT);
			String [] files = dir.list(new MetricsFilter());
			JavaNCSSMetricsXMLReader reader = new JavaNCSSMetricsXMLReader();
			for (int i = 0; i < files.length; i++) {
				int dash1 = files[i].indexOf("-");
				int lastDash = files[i].lastIndexOf("-");
				reader.parseFile(dir.getAbsolutePath() + "/" + files[i], files[i].substring(0, dash1), files[i].substring(dash1+1, lastDash));
			}
		} else {
			System.out.println("Nothing");
		}
		
		
	}
	
	private void parseStatus() {
		if (Constants.JDOM_ROOT.startsWith(PROJECT)) {
			StatusReader reader = new StatusReader();
			reader.readStatus("jdom", new File(Constants.WORKSPACE_ROOT + "/" + Constants.JDOM_ROOT + "/collector.txt"));
		} else if (Constants.ECLIPSE.equals(PROJECT)) {
			StatusReader reader = new StatusReader();
			reader.readStatus("runtime", new File(Constants.WORKSPACE_ROOT + "/" + Constants.ECLIPSE_ROOT + "/collector-eclipse.txt"));
		} else if (Constants.LOGGING.equals(PROJECT)) {
			StatusReader reader = new StatusReader();
			reader.readStatus("logging", new File(Constants.WORKSPACE_ROOT + "/" + Constants.LOGGING_ROOT + "/collector.txt"));
		}
	}
	
	private class MetricsFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.contains("metrics"));
		}
	}
	
	private class AlertsFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.contains("alerts"));
		}
	}
	
	private class ChurnFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.startsWith("diff-") && name.endsWith(".txt"));
		}
	}
	
	private class SVNDiffFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.contains("_diff_"));
		}
	}

}

