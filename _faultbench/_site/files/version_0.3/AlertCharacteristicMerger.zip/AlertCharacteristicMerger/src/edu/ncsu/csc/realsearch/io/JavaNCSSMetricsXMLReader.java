package edu.ncsu.csc.realsearch.io;

import java.io.IOException;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import edu.ncsu.csc.realsearch.data.MetricsFunction;
import edu.ncsu.csc.realsearch.data.MetricsObject;
import edu.ncsu.csc.realsearch.data.MetricsPackage;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.MetricsDB;

public class JavaNCSSMetricsXMLReader extends DefaultHandler {
	
	private SAXParserFactory factory;
	private SAXParser parser;
	private String version;
	private String projectName;
	
	public JavaNCSSMetricsXMLReader() {
		super();
	}
	
	private void makeParser() {
		try {
			factory = SAXParserFactory.newInstance();
			factory.setNamespaceAware(true);
			parser = factory.newSAXParser();
		} catch (FactoryConfigurationError e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} finally {
			
		}
	}
	
	public void parseFile(String file, String version, String projectName) {
		makeParser();
		try {
			this.version = version;
			this.projectName = projectName;
			parser.parse(file, this);
			
		} catch (SAXException e) {
//			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	
	public void startDocument() throws SAXException {
		
	}
	
	public void endDocument() throws SAXException {
		
	}
	
	MetricsPackage metricsPackage;
	MetricsObject metricsObject;
	MetricsFunction metricsFunction;
	String flag;
	String temp;
	
	public void startElement(String namespaceURI, String lName, String qName, Attributes attrs) throws SAXException {
		temp = "";
		if (lName.equals("package")) { 
			metricsPackage = new MetricsPackage(projectName, version);
			flag = "package";
		} 
		if (lName.equals("object")) { 
			metricsObject = new MetricsObject(projectName, version);
			flag = "object";
		} 
		if (lName.equals("function")) { 
			metricsFunction = new MetricsFunction(projectName, version);
			flag = "function";
		} 
		if (lName.equals("averages") || lName.equals("total") || lName.equals("function_averages")) {
			flag = "average";
		}
	}
	
	public void characters(char ch[], int start, int length) {
		temp += new String(ch, start, length);
	}
	
	public void endElement(String namespaceURI, String sName, String qName) throws SAXException {
		if (sName.equals("package")) {
			MetricsDB.writeNCSSMetricPackage(DBConnection.getInstance(false).getConnection(), metricsPackage);
			temp = "";
		} 
		if (sName.equals("object")) { 
			MetricsDB.writeNCSSMetricObject(DBConnection.getInstance(false).getConnection(), metricsObject);
			temp = "";
		} 
		if (sName.equals("function")) { 
			MetricsDB.writeNCSSMetricFunction(DBConnection.getInstance(false).getConnection(), metricsFunction);
			temp = "";
		}
		if (sName.equals("name")) {
			if (flag.equals("package")) {
				metricsPackage.setName(temp);
			}
			if (flag.equals("object")) {
				metricsObject.setName(temp);
			}
			if (flag.equals("function")) {
				metricsFunction.setName(temp);
			}
			temp = "";
		} 
		if (sName.equals("classes")) {
			if (flag.equals("package")) {
				metricsPackage.setClasses(Integer.parseInt(temp));
			}
			if (flag.equals("object")) {
				metricsObject.setClasses(Integer.parseInt(temp));
			}
			temp = "";
		}
		if (sName.equals("functions")) {
			if (flag.equals("package")) {
				metricsPackage.setFunctions(Integer.parseInt(temp));
			}
			if (flag.equals("object")) {
				metricsObject.setFunctions(Integer.parseInt(temp));
			}
			temp = "";
		}
		if (sName.equals("ncss")) {
			if (flag.equals("package")) {
				metricsPackage.setNcss(Integer.parseInt(temp));
			}
			if (flag.equals("object")) {
				metricsObject.setNcss(Integer.parseInt(temp));
			}
			if (flag.equals("function")) {
				metricsFunction.setNcss(Integer.parseInt(temp));
			}
			temp = "";
		}
		if (sName.equals("javadocs")) {
			if (flag.equals("package")) {
				metricsPackage.setJavadocs(Integer.parseInt(temp));
			}
			if (flag.equals("object")) {
				metricsObject.setJavadocs(Integer.parseInt(temp));
			}
			if (flag.equals("function")) {
				metricsFunction.setJavadocs(Integer.parseInt(temp));
			}
			temp = "";
		}
		if (sName.equals("javadoc_lines")) {
			if (flag.equals("package")) {
				metricsPackage.setJavadocLines(Integer.parseInt(temp));
			}
			temp = "";
		}
		if (sName.equals("single_comment_lines")) {
			if (flag.equals("package")) {
				metricsPackage.setSingleCommentLines(Integer.parseInt(temp));
			}
			temp = "";
		}
		if (sName.equals("multi_comment_lines")) {
			if (flag.equals("package")) {
				metricsPackage.setMultiCommentLines(Integer.parseInt(temp));
			}
			temp = "";
		}
		if (sName.equals("ccn")) {
			if (flag.equals("function")) {
				metricsFunction.setCcn(Integer.parseInt(temp));
			}
			temp = "";
		}
	}

}
