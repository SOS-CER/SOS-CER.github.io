package edu.ncsu.csc.realsearch.data;

import java.util.Hashtable;

public class ChurnHash {
	
	private Hashtable<String, Churn> hash;
	public static ChurnHash instance;
	
	private ChurnHash() {
		hash = new Hashtable<String, Churn>();
	}
	
	public static ChurnHash getInstance() {
		if (instance == null) {
			instance = new ChurnHash();
		}
		return instance;
	}
	
	public void addToHash(String key, Churn value) {
		instance.hash.put(key, value);
	}
	
	public Churn getFromHash(String key) {
		return instance.hash.get(key);
	}

}
