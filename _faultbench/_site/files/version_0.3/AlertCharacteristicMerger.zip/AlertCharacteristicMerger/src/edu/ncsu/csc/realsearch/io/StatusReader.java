package edu.ncsu.csc.realsearch.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.StatusDB;

public class StatusReader {
	
	public void readStatus(String projectName, File statusFile) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(statusFile));
			String line = in.readLine();
			while (line != null) {
				String [] contents = line.split(" ");
				String version = contents[3];
				int revision = Integer.parseInt(version);
				String status = contents[4];
				StatusDB.writeToDatabase(DBConnection.getInstance(false).getConnection(), projectName, version, revision, status);
				line = in.readLine();
			}
		} catch (IOException e) {
			
		}
	}

}
