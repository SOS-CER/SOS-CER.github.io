package edu.ncsu.csc.realsearch.io.db;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class CreateDBTables {
	
	public static void createVersionStatusTable(DerbyConnection conn) {
		try {
			String query = "create table version_status ( " +
					"projectName varchar(50), " +
					"version varchar(20), " +
					"revision int, " +
					"status varchar(4))";
			PreparedStatement stmt = conn.getStatement(query);	
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void createCommitsTable(DerbyConnection conn) {
		try {
			String query = "create table commits ( " +
					"commitNum int not null generated always as identity (start with 1, increment by 1), " +
					"projectName varchar(50), " +
					"date varchar(20), " +
					"revisionNotes varchar(7500))";
			PreparedStatement stmt = conn.getStatement(query);	
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void createRuntimeCommitsTable(DerbyConnection conn) {
		try {
			String query = "create table commits_runtime ( " +
					"commitNum int not null generated always as identity (start with 1, increment by 1), " +
					"projectName varchar(50), " +
					"date varchar(20), " +
					"revisionNotes varchar(7500))";
			PreparedStatement stmt = conn.getStatement(query);	
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void createJdomCommitsTable(DerbyConnection conn) {
		try {
			String query = "create table commits_jdom ( " +
					"commitNum int not null generated always as identity (start with 1, increment by 1), " +
					"projectName varchar(50), " +
					"date varchar(20), " +
					"revisionNotes varchar(7500))";
			PreparedStatement stmt = conn.getStatement(query);	
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static boolean createAlertBenchmarkTable(DerbyConnection conn) {
		try {	
			String query = "create table alerts_benchmark (" +
					"id int, " +
					"classification varchar(2), " +
					"notes varchar(1000), " +
					"description varchar(500), " +
					"projectName varchar(100), " +
					"packageName varchar(100), " +
					"fileName varchar(100), " +
					"methodName varchar(100), " +
					"dups int, " +
					"sourceHash varchar(64), " +
					"markerType varchar(100), " +
					"lineNumber int, " +
					"isFiltered varchar(5), " +
					"isDefected varchar(5), " +
					"isClosed varchar(5), " +
					"testFile varchar(50), " +
					"severity int, " +
					"bugType varchar(100))";
			PreparedStatement stmt = conn.getStatement(query);
			
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean createAlertsTable(DerbyConnection conn) {
		try {	
			String query = "create table alerts (" +
					"id int, " +
					"classification varchar(2), " +
					"description varchar(500), " +
					"projectName varchar(100), " +
					"packageName varchar(100), " +
					"fileName varchar(100), " +
					"methodName varchar(100), " +
					"dups int, " +
					"sourceHash varchar(64), " +
					"markerType varchar(100), " +
					"lineNumber int, " +
					"isFiltered varchar(5), " +
					"isDefected varchar(5), " +
					"isClosed varchar(5), " +
					"testFile varchar(50), " +
					"severity int, " +
					"bugType varchar(100), " +
					"alertCategory varchar(50), " +
					"priority varchar(2), " +
					"fileExtension varchar(10), " +
					"numAlertModifications int , " +
					"version varchar(25), " +
					"revision int, " +
					//Metrics
					"methodSize int, " +
					"fileSize int, " +
					"cyclomaticComplexity int, " +
					"depthOfInheritanceTree int, " +
					"numAttributes int, " +
					"numParameters int, " + 
					"numberOfFunctionsInFile int , " +
					"numberOfClassesInFile int, " +
					"numberOfFunctionsInPackage int, " +
					"numberOfClassesInPackage int, " +
					"packageSize int, " +
					//History
					"openRevision int, " +
					"closeRevision int, " +
					"developer varchar(150), " +
					"closeRevisionType varchar(50), " +
					"openRevisionType varchar(50), " +
					"fileCreationRevision int, " +
					"fileDeletionRevision int, " +
					"latestFileModification int, " +
					"latestPackageModification int, " +
					"latestProjectModification int, " +
					//Churn
					"fileAddedLines int, " +
					"fileDeletedLines int, " +
					"fileModifiedLines int, " +
					"fileGrowthLines int, " +
					"fileTotalModifiedLines int, " +
					"filePercentModifiedLines double, " +
					"packageAddedLines int, " +
					"packageDeletedLines int, " +
					"packageModifiedLines int, " +
					"packageGrowthLines int, " +
					"packageTotalModifiedLines int, " +
					"packagePercentModifiedLines double, " +
					"projectAddedLines int, " +
					"projectDeletedLines int, " +
					"projectModifiedLines int, " +
					"projectGrowthLines int, " +
					"projectTotalModifiedLines int, " +
					"projectPercentModifiedLines double, " +
					//Aggregate Alert Info
					"totalAlertsForRevision int, " +
					"totalOpenAlertsForRevision int, " +
					"alertLifetime int, " +
					"fileAge int, " +
					"alertsInMethod int, " +
					"alertsInFile int," +
					"alertsInPackage int, " +
					"alertsInProject int, " +
					"fileStaleness int, " +
					"packageStaleness int, " +
					"projectStaleness int, " + 
					"alertDepthInFile double " +
					")";
			PreparedStatement stmt = conn.getStatement(query);
			
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean createChurnTable(DerbyConnection conn) {
		try {
			String query = "create table churn (" +
					"file varchar(500), " +
					"inserted int, " +
					"deleted int, " +
					"modified int, " +
					"startVersion varchar(20), " +
					"endVersion varchar(20))";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean createHistoryTable(DerbyConnection conn) {
		try {
			String query = "create table history (" +
					"version varchar(20), " +
					"revision int, " +
					"date varchar(25), " +
					"revisionType varchar(50), " +
					"developer varchar(50))";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean createMetricsTable(DerbyConnection conn) {
		try {
			String query = "create table metrics (" +
					"name varchar(500), " +
					"handle varchar(500), " +
					"version varchar(20), " +
					"id varchar(500), " +
					"value double, " +
					"avgValue double, " +
					"stddev double, " +
					"points int, " +
					"maxValue double, " +
					"per varchar(20), " +
					"maxhandle varchar(500))";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean createMetricsNCSSPackageTable(DerbyConnection conn) {
		try {
			String query = "create table metrics_javancss_package (" +
					"projectName varchar(50), " +
					"version varchar(20), " + 
					"name varchar(500), " +
					"classes int, " +
					"functions int, " +
					"ncss int, " +
					"javadocs int, " +
					"javadoc_lines int, " +
					"single_comment_lines int, " +
					"multi_comment_lines int)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean createMetricsNCSSObjectTable(DerbyConnection conn) {
		try {
			String query = "create table metrics_javancss_object (" +
					"projectName varchar(50), " +
					"version varchar(20), " + 
					"name varchar(500), " +
					"ncss int, " +
					"functions int, " +
					"classes int, " +
					"javadocs int)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean createMetricsNCSSFunctionTable(DerbyConnection conn) {
		try {
			String query = "create table metrics_javancss_function (" +
					"projectName varchar(50), " +
					"version varchar(20), " + 
					"name varchar(500), " +
					"ncss int, " +
					"ccn int, " +
					"javadocs int)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public static boolean destroyHistoryTable(DerbyConnection conn) {
		try {
			String query = "drop table history";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyChurnTable(DerbyConnection conn) {
		try {
			String query = "drop table churn";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyMetricsTable(DerbyConnection conn) {
		try {
			String query = "drop table metrics";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyMetricsNCSSPackageTable(DerbyConnection conn) {
		try {
			String query = "drop table metrics_javancss_package";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public static boolean destroyMetricsNCSSObjectTable(DerbyConnection conn) {
		try {
			String query = "drop table metrics_javancss_object";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	public static boolean destroyMetricsNCSSFunctionTable(DerbyConnection conn) {
		try {
			String query = "drop table metrics_javancss_function";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyAlertsTable(DerbyConnection conn) {
		try {
			String query = "drop table alerts";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyCommitsTable(DerbyConnection conn) {
		try {
			String query = "drop table commits";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyRuntimeCommitsTable(DerbyConnection conn) {
		try {
			String query = "drop table commits_runtime";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyJdomCommitsTable(DerbyConnection conn) {
		try {
			String query = "drop table commits_jdom";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyLoggingCommitsTable(DerbyConnection conn) {
		try {
			String query = "drop table commits_logging";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyCVSRevisionTable(DerbyConnection conn) {
		try {
			String query = "drop table cvs_revision";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean destroyCVSFilesTable(DerbyConnection conn) {
		try {
			String query = "drop table cvs_files";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public static boolean destroyStatusTable(DerbyConnection conn) {
		try {
			String query = "drop table version_status";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
			return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}


}
