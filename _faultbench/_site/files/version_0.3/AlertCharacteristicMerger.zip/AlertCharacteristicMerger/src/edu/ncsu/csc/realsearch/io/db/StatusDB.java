package edu.ncsu.csc.realsearch.io.db;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class StatusDB {
	
	public static boolean writeToDatabase(DerbyConnection conn, String projectName, String version, int revision, String status) {
		try {
			String query = "insert into version_status values(?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setString(2, version);
			stmt.setInt(3, revision);
			stmt.setString(4, status);
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

}
