package edu.ncsu.csc.realsearch.io.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Churn;
import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class ChurnDB {
	
	public static boolean writeToDatabase(DerbyConnection conn, Churn c) {
		try {
					
			String query = "insert into churn values(?,?,?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, c.getFile());
			stmt.setInt(2, c.getInserted());
			stmt.setInt(3, c.getDeleted());
			stmt.setInt(4, c.getModified());	
			stmt.setString(5, c.getStartVersion());
			stmt.setString(6, c.getEndVersion());
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	//XXX: FIX!
	public static int getInsertedFromFile(DerbyConnection conn, String file, int currentRevision) {
		int inserted = -1;
		try {
			
//			String query = "select sum(inserted) as inserted from churn, history where file like ? and file like '%.java' and churn.endVersion=history.version and history.revision<=?";
			String query = "select sum(addedLines) as inserted from cvs_revision where file like ? and file like '%.java' and date <= ? and date > ?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, file);
			stmt.setInt(2, currentRevision);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				inserted = rs.getInt("inserted");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return inserted;
	}

	public static int getDeletedFromFile(DerbyConnection conn, String file, String currentRevision, String previousRevision) {
		int deleted = -1;
		try {
			
//			String query = "select sum(deleted) as deleted from churn, history where file like ? and file like '%.java' and churn.endVersion=history.version and history.revision<=?";
			String query = "select sum(deletedLines) as deleted from cvs_revision where file like ? and file like '%.java' and date <= ? and date > ?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, file);
			stmt.setString(2, currentRevision);
			stmt.setString(3, previousRevision);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				deleted = rs.getInt("deleted");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deleted;
	}
	
	public static int getModifiedFromFile(DerbyConnection conn, String file, int closeRevision) {
		int modified = -1;
		try {
			
			String query = "select sum(modified) as modified from churn, history where file like ? and file like '%.java' and churn.endVersion=history.version and history.revision<=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, file);
			stmt.setInt(2, closeRevision);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				modified = rs.getInt("modified");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return modified;
	}

	public static int getFileCreationRevision(DerbyConnection conn,
			String file) {
		int revision = 0;
		try {
			
			String query = "select history.revision as rev from churn, history where churn.endVersion=history.version and churn.file like ? and inserted=0 and deleted=0 and modified=0";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, file);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("rev");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return revision;
	}

	public static int getFileDeletionRevision(DerbyConnection conn,
			String file, int closeRevision) {
		int revision = -1;
		try {
			
			String query = "select history.revision as rev from churn, history where history.revision=? and churn.startVersion=history.version and churn.file like ? and inserted=0 and deleted=0 and modified=0";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setInt(1, closeRevision);
			stmt.setString(2, file);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("rev");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return revision;
	}

	public static int getLatestFileModificationRevision(
			DerbyConnection conn, String file) {
		int revision = -1;
		try {
			
			String query = "select max(history.revision) as rev from churn, history where churn.endVersion=history.version and churn.file like ?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, file);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("rev");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return revision;
	}
	
	public static int getLatestPackageModificationRevision(DerbyConnection conn, 
			String packageName) {
		int revision = -1;
		try {
			
			String query = "select max(history.revision) as rev from churn, history where churn.endVersion=history.version and churn.file like ?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, packageName);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("rev");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return revision;
	}

	/**
	 * Returns the amount of total churn on or before the specified revision.
	 * This is used in the denominator of a fraction, and therefore, cannot be
	 * 0.
	 * @param conn
	 * @param openRevision
	 * @return
	 */
	public static double getTotalChurnBeforeRevision(DerbyConnection conn,
			int openRevision) {
		int revision = 0;
		try {
			
			String query = "select sum(inserted) as inserted, sum(deleted) as deleted, sum(modified) as modified from churn, history where churn.endVersion=history.version and history.revision<=? and file like '%.java'";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setInt(1, openRevision);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("inserted") + rs.getInt("deleted") + rs.getInt("modified");
			}
			
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		if (revision == 0) {
			revision = 1;
		}
		return revision;
	}

	public static ArrayList<Churn> getChurn(DerbyConnection conn) {
		ArrayList<Churn> churn = new ArrayList<Churn>();
		try {
			String query = "select ";
			PreparedStatement stmt = conn.getStatement(query);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return churn;
	}

	

}
