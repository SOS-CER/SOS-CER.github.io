package edu.ncsu.csc.realsearch.data;

public class Churn {
	
	private String file;
	private int inserted;
	private int deleted;
	private int modified;
	private String startVersion;
	private String endVersion;
	private int startRevision;
	private int endRevision;
	
	public Churn(String line, String delimitor, String startVersion, String endVersion) {
		String [] contents = line.split(delimitor);
		this.inserted = Integer.parseInt(contents[0]);
		this.deleted = Integer.parseInt(contents[1]);
		this.modified = Integer.parseInt(contents[2]);
		this.file = contents[3];
		this.startVersion = startVersion;
		this.endVersion = endVersion;
//		this.startRevision = HistoryHash.getInstance().getFromHash(startVersion).getRevision();
//		this.endRevision = HistoryHash.getInstance().getFromHash(endVersion).getRevision();
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public int getInserted() {
		return inserted;
	}
	public void setInserted(int inserted) {
		this.inserted = inserted;
	}
	public int getDeleted() {
		return deleted;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}
	public int getModified() {
		return modified;
	}
	public void setModified(int modified) {
		this.modified = modified;
	}
	public String getStartVersion() {
		return startVersion;
	}
	public void setStartVersion(String startVersion) {
		this.startVersion = startVersion;
	}
	public String getEndVersion() {
		return endVersion;
	}
	public void setEndVersion(String endVersion) {
		this.endVersion = endVersion;
	}
	public String getChurnKey() {
		return file + "-" + startVersion + "-" + endVersion;
	}
	public int getStartRevision() {
		return startRevision;
	}
	public void setStartRevision(int startRevision) {
		this.startRevision = startRevision;
	}
	public int getEndRevision() {
		return endRevision;
	}
	public void setEndRevision(int endRevision) {
		this.endRevision = endRevision;
	}
	public boolean isEmptyChange() {
		if (inserted == 0 && deleted == 0 && modified ==0) {
			return true;
		}
		return false;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + deleted;
		result = prime * result + endRevision;
		result = prime * result
				+ ((endVersion == null) ? 0 : endVersion.hashCode());
		result = prime * result + ((file == null) ? 0 : file.hashCode());
		result = prime * result + inserted;
		result = prime * result + modified;
		result = prime * result + startRevision;
		result = prime * result
				+ ((startVersion == null) ? 0 : startVersion.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Churn other = (Churn) obj;
		if (deleted != other.deleted)
			return false;
		if (endRevision != other.endRevision)
			return false;
		if (endVersion == null) {
			if (other.endVersion != null)
				return false;
		} else if (!endVersion.equals(other.endVersion))
			return false;
		if (file == null) {
			if (other.file != null)
				return false;
		} else if (!file.equals(other.file))
			return false;
		if (inserted != other.inserted)
			return false;
		if (modified != other.modified)
			return false;
		if (startRevision != other.startRevision)
			return false;
		if (startVersion == null) {
			if (other.startVersion != null)
				return false;
		} else if (!startVersion.equals(other.startVersion))
			return false;
		return true;
	}

}
