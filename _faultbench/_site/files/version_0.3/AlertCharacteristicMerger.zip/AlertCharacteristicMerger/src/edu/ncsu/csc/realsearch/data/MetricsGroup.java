package edu.ncsu.csc.realsearch.data;

import java.util.Hashtable;

import edu.ncsu.csc.realsearch.main.Constants;

public class MetricsGroup {

	private String name;
	private String handle;
	private String version;
	private Hashtable<String, Metric> metrics;
	
	public MetricsGroup() {
		metrics = new Hashtable<String, Metric>();
	}
	
	public MetricsGroup(String name, String handle, String version) {
		this.name = name;
		this.version = version;
		this.handle = parseHandle(handle, version);
		metrics = new Hashtable<String, Metric>();
	}
	
	private static String parseHandle(String handle, String version) {
		handle = handle.replace("\\", "");
		handle = handle.replace("&lt;","/");
		handle = handle.replace("<", "/");
		handle = handle.replaceAll("\\.", "/");
		handle = handle.replace("{", "/");
		handle = handle.replaceAll("/java", ".java");
		String newhandle = handle;
		if (handle.indexOf("[") != -1) {
			newhandle = handle.substring(0,handle.indexOf("[")) + ".";
		}
		if (handle.indexOf("~") != -1) {
			if (handle.indexOf("~")==handle.lastIndexOf("~")) {
				//no parameters to the method
				newhandle = newhandle + handle.substring(handle.indexOf("~")+1) + "()";
			} else {
				//one or more parameters
				int firstTilde = handle.indexOf("~");
				int secondTilde = handle.indexOf("~", firstTilde + 1);
				String methodName = handle.substring(firstTilde + 1, secondTilde);
				newhandle = newhandle + methodName;
				//Process parameters ~ separates parameters
				String parameters = handle.substring(secondTilde + 1);
				String [] paramContents = parameters.split("~");
				parameters = "";
				for (int i = 0; i < paramContents.length ; i++) {
					boolean isArray = false;
					if (paramContents[i].contains("[")) {
						paramContents[i] = paramContents[i].substring(paramContents[i].indexOf("[") + 1);
						isArray = true;
					}
					if (paramContents[i].length() == 1) {
						parameters += Constants.primitatives.get(paramContents[i]);
					} else if (paramContents[i].startsWith("Q") && paramContents[i].endsWith(";")) {
						//is an object
						parameters += paramContents[i].substring(1, paramContents[i].length()-1);
					} 
					if (isArray) {
						parameters += "[]";
					}
					parameters += ",";
				}
				if (parameters.endsWith(",")) {
					parameters = parameters.substring(0, parameters.length()-1);
				}
				newhandle += "(" + parameters + ")";
				
			}
		}
		return newhandle;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHandle() {
		return handle;
	}

	public void setHandle(String handle) {
		this.handle = handle;
	}

	public Hashtable<String, Metric> getMetrics() {
		return metrics;
	}

	public void setMetrics(Hashtable<String, Metric> metrics) {
		this.metrics = metrics;
	}
	
	public void addMetric(String key, Metric value) {
		this.metrics.put(key, value);
	}

	public Metric getMetric(String key) {
		return this.metrics.get(key);
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((handle == null) ? 0 : handle.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final MetricsGroup other = (MetricsGroup) obj;
		if (handle == null) {
			if (other.handle != null)
				return false;
		} else if (!handle.equals(other.handle))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}

	public String getMetricsGroupKey() {
		return handle;
	}
	

}
