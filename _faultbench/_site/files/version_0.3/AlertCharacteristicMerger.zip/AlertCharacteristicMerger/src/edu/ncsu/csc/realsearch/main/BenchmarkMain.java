package edu.ncsu.csc.realsearch.main;

import java.io.File;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.io.AlertReader;
import edu.ncsu.csc.realsearch.io.db.AlertDB;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class BenchmarkMain {
	
	public static final String DB_NAME = "jdbc:derby:C:/Documents and Settings/Sarah Smith/My Documents/Research/Experiments/2009_ICSE/AlertsDatabase/alert_db;create=true";
	public static final String DIR_NAME = "C:/Documents and Settings/Sarah Smith/My Documents/Research/Experiments/2009_ICSE/Benchmark_2008-06-10";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			DerbyConnection conn = new DerbyConnection();
			conn.connect(DB_NAME);
			CreateDBTables.createAlertBenchmarkTable(conn);
			
			AlertReader reader = new AlertReader();
			AlertDB db = new AlertDB();
			
			File dir = new File(DIR_NAME);
			
			File [] files = dir.listFiles();
			
			for (int j = 0; j < files.length; j++) {
				ArrayList<Alert> alerts = reader.readAlertsFromTabDelimitedFile(files[j].getAbsolutePath(), true);
					
				for (int i = 0; i < alerts.size(); i++) {
//					db.writeToDatabase(conn, alerts.get(i));
				}
			}
			conn.disconnect();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		}
	}

}
