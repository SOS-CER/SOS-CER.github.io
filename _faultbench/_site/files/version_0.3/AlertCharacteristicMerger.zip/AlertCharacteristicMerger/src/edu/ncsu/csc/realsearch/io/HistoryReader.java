package edu.ncsu.csc.realsearch.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import edu.ncsu.csc.realsearch.data.History;
import edu.ncsu.csc.realsearch.data.HistoryHash;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.HistoryDB;

public class HistoryReader {
	
	public void readHistoryFromDelimitedFile(String fileName, String delimitor, boolean isHeader) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String line = in.readLine();
			if (isHeader)	//Skip the first line
				line = in.readLine();
			while (line != null) {
				History h = new History(line, delimitor);
				HistoryHash.getInstance().addToHash(h.getVersion(), h);
				HistoryDB.writeToDatabase(DBConnection.getInstance(false).getConnection(), h);
				line = in.readLine();
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
