package edu.ncsu.csc.realsearch.io.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class AlertDB {
	
	public boolean writeBasicAlertToDatabase(DerbyConnection conn, Alert a) {
		try {
					
			String query = "insert into alerts(id, classification, description, projectName, packageName, fileName, methodName, dups, sourceHash, markerType, lineNumber, isFiltered, isDefected, isClosed, testFile, severity, bugType, version, openRevision, closeRevision) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setInt(1, a.getId());
			stmt.setString(2, a.getClassification());
			stmt.setString(3, a.getDescription());
			stmt.setString(4, a.getProjectName());
			stmt.setString(5, a.getPackageName());
			stmt.setString(6, a.getFileName());
			stmt.setString(7, a.getMethodName());
			stmt.setInt(8, a.getDups());
			stmt.setString(9, a.getSourceHash());
			stmt.setString(10, a.getMarkerType());
			stmt.setInt(11, a.getLineNumber());
			if (a.isFiltered()) 
				stmt.setString(12, "true");
			else
				stmt.setString(12, "false");
			if (a.isDefected()) 
				stmt.setString(13, "true");
			else
				stmt.setString(13, "false");
			if (a.isClosed()) 
				stmt.setString(14, "true");
			else
				stmt.setString(14, "false");
			stmt.setString(15, a.getTestFile());
			stmt.setInt(16, a.getSeverity());
			stmt.setString(17, a.getBugType());
			stmt.setString(18, a.getVersion());
			stmt.setInt(19, a.getOpenRevision());
			stmt.setInt(20, a.getCloseRevision());
			
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	public static int getTotalAlertsForRevision(DerbyConnection conn,
			String projectName, int openRevision) {
		int totalAlertsForRevision = -1;
		try {
			String query = "select count(*) as count from alerts where projectName=? and openRevision<=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setInt(2, openRevision);	
			ResultSet rs = stmt.executeQuery();
			rs.next();
			totalAlertsForRevision = rs.getInt("count");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return totalAlertsForRevision;
	}

	public static int getTotalOpenAlertsForRevision(DerbyConnection conn,
			String projectName, int openRevision) {
		int totalOpenAlertsForRevision = -1;
		try {
			String query = "select count(*) as count from alerts where projectName=? and openRevision<=? and closeRevision=-1";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setInt(2, openRevision);	
			ResultSet rs = stmt.executeQuery();
			rs.next();
			totalOpenAlertsForRevision = rs.getInt("count");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return totalOpenAlertsForRevision;
	}

	public static int getAlertsInProject(DerbyConnection conn, String projectName) {
		int alertsInProject = -1;
		try {
			String query = "select count(*) as count from alerts where projectName=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			alertsInProject = rs.getInt("count");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return alertsInProject;
	}
	
	public static int getAlertsForPackage(DerbyConnection conn, String projectName, 
			String packageName) {
		int alertsInFile = -1;
		try {
			String query = "select count(*) as count from alerts where projectName=? and packageName=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setString(2, packageName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			alertsInFile = rs.getInt("count");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return alertsInFile;
	}
	
	public static int getAlertsForMethod(DerbyConnection conn, String projectName, 
			String packageName, String fileName, String methodName) {
		int alertsInFile = -1;
		try {
			String query = "select count(*) as count from alerts where projectName=? and packageName=? and fileName=? and methodName=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setString(2, packageName);
			stmt.setString(3, fileName);
			stmt.setString(4, methodName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			alertsInFile = rs.getInt("count");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return alertsInFile;
	}

	public static int getAlertsForFile(DerbyConnection conn, String projectName, 
			String packageName, String fileName) {
		int alertsInFile = -1;
		try {
			String query = "select count(*) as count from alerts where projectName=? and packageName=? and fileName=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setString(2, packageName);
			stmt.setString(3, fileName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			alertsInFile = rs.getInt("count");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return alertsInFile;
	}

	public static boolean writeAlerts(DerbyConnection conn, Alert a) {
		int ret = -1;
		try {
			
			String query = "update alerts set " +
					"alertCategory=?, " +
					"priority=?, " +
					"fileExtension=?, " +
					"numAlertModifications=?, " +
					"revision=?, " +
					//Metrics
					"methodSize=?, " +
					"fileSize=?, " +
					"cyclomaticComplexity=?, " +
					"depthOfInheritanceTree=?, " +
					"numAttributes=?, " +
					"numParameters=?, " +
					"numberOfFunctionsInFile=?, " +
					"numberOfClassesInFile=?, " +
					"numberOfFunctionsInPackage=?, " +
					"numberOfClassesInPackage=?, " +
					"packageSize=?, " +
					//History
					"developer=?, " +
					"closeRevisionType=?, " +
					"openRevisionType=?, " +
					"fileCreationRevision=?, " +
					"fileDeletionRevision=?, " +
					"latestFileModification=?, " +
					"latestPackageModification=?, " +
					"latestProjectModification=?, " +
					//Churn
					"fileAddedLines=?, " +
					"fileDeletedLines=?, " +
					"fileModifiedLines=?, " +
					"fileGrowthLines=?, " +
					"fileTotalModifiedLines=?, " +
					"filePercentModifiedLines=?, " +
					"packageAddedLines=?, " +
					"packageDeletedLines=?, " +
					"packageModifiedLines=?, " +
					"packageGrowthLines=?, " +
					"packageTotalModifiedLines=?, " +
					"packagePercentModifiedLines=?, " +
					"projectAddedLines=?, " +
					"projectDeletedLines=?, " +
					"projectModifiedLines=?, " +
					"projectGrowthLines=?," +
					"projectTotalModifiedLines=?, " +
					"projectPercentModifiedLines=?, " +
					//Aggregate
					"totalAlertsForRevision=?, " +
					"totalOpenAlertsForRevision=?, " +
					"alertLifetime=?, " +
					"fileAge=?, " +
					"alertsInMethod=?, " +
					"alertsInFile=?, " +
					"alertsInPackage=?, " +
					"alertsInProject=?, " +
					"fileStaleness=?, " +
					"packageStaleness=?, " +
					"projectStaleness=?, " +
					"alertDepthInFile=? " +
					//Alert ID
					"where description=? and " +
					"projectName=? and " +
					"packageName=? and " +
					"fileName=? and " +
					"methodName=? and " +
					"sourceHash=? and " +
					"lineNumber=? and " +
					"bugType=? and " +
					"version=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, a.getAlertCategory());
			stmt.setString(2, a.getPriority());
			stmt.setString(3, a.getFileExtension());
			stmt.setInt(4, a.getNumAlertModifications());
			stmt.setInt(5, a.getRevision());
			//Metrics
			stmt.setInt(6, a.getMethodSize());
			stmt.setInt(7, a.getFileSize());
			stmt.setInt(8, a.getCyclomaticComplexity());
			stmt.setInt(9, a.getDepthOfInheritanceTree());
			stmt.setInt(10, a.getNumAttributes());
			stmt.setInt(11, a.getNumParameters());
			stmt.setInt(12, a.getNumberOfFunctionsInFile());
			stmt.setInt(13, a.getNumberOfClassesInFile());
			stmt.setInt(14, a.getNumberOfFunctionsInPackage());
			stmt.setInt(15, a.getNumberOfClassesInPackage());
			stmt.setInt(16, a.getPackageSize());
			//History
			stmt.setString(17, a.getDeveloper());
			stmt.setString(18, a.getCloseRevisionType());
			stmt.setString(19, a.getOpenRevisionType());
			stmt.setInt(20, a.getFileCreationRevision());
			stmt.setInt(21, a.getFileDeletionRevision());
			stmt.setInt(22, a.getLatestFileModficationRevision());
			stmt.setInt(23, a.getLatestPackageModificationRevision());
			stmt.setInt(24, a.getLatestProjectModficiationRevision());
			//Churn
			stmt.setInt(25, a.getFileAddedLines());
			stmt.setInt(26, a.getFileDeletedLines());
			stmt.setInt(27, a.getFileModifiedLines());
			stmt.setInt(28, a.getFileGrowthLines());
			stmt.setInt(29, a.getFileTotalModifiedLines());
			stmt.setDouble(30, a.getFilePercentModifiedLines());
			stmt.setInt(31, a.getPackageAddedLines());
			stmt.setInt(32, a.getPackageDeletedLines());
			stmt.setInt(33, a.getPackageModifiedLines());
			stmt.setInt(34, a.getPackageGrowthLines());
			stmt.setInt(35, a.getPackageTotalModifiedLines());
			stmt.setDouble(36, a.getPackagePercentModifiedLines());
			stmt.setInt(37, a.getProjectAddedLines());
			stmt.setInt(38, a.getProjectDeletedLines());
			stmt.setInt(39, a.getProjectModifiedLines());
			stmt.setInt(40, a.getProjectGrowthLines());
			stmt.setInt(41, a.getProjectTotalModifiedLines());
			stmt.setDouble(42, a.getProjectPercentModifiedLines());
			//Aggregate
			stmt.setInt(43, a.getTotalAlertsForRevision());
			stmt.setInt(44, a.getTotalOpenAlertsForRevision());
			stmt.setInt(45, a.getAlertLifetime());
			stmt.setInt(46, a.getFileAge());
			stmt.setInt(47, a.getAlertsInMethod());
			stmt.setInt(48, a.getAlertsInFile());
			stmt.setInt(49, a.getAlertsInPackage());
			stmt.setInt(50, a.getAlertsInProject());
			stmt.setInt(51, a.getFileStaleness());
			stmt.setInt(52, a.getPackageStaleness());
			stmt.setInt(53, a.getProjectStaleness());
			stmt.setDouble(54, a.getAlertDepthInFile());
			
			
			stmt.setString(55, a.getDescription());
			stmt.setString(56, a.getProjectName());
			stmt.setString(57, a.getPackageName());
			stmt.setString(58, a.getFileName());
			stmt.setString(59, a.getMethodName());
			stmt.setString(60, a.getSourceHash());
			stmt.setInt(61, a.getLineNumber());
			stmt.setString(62, a.getBugType());
			stmt.setString(63, a.getVersion());
			
			ret = stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
//		System.out.println(ret);
		return true;
	}

}
