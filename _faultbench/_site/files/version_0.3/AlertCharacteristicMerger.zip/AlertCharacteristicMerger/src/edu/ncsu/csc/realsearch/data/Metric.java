package edu.ncsu.csc.realsearch.data;

import org.xml.sax.Attributes;

public class Metric {
	
	private String id;
	private double value;
	private double avg;
	private double stddev;
	private int points;
	private double max;
	private String per;
	private String maxhandle;
	
	public Metric(Attributes attrs) {
		this.id = attrs.getValue("id");
		if (attrs.getValue("value") != null && !attrs.getValue("value").equals("?"))
			this.value = Double.parseDouble(attrs.getValue("value"));
		else 
			this.value = -1;
		if (attrs.getValue("avg") != null)
			this.avg = Double.parseDouble(attrs.getValue("avg"));
		else 
			this.avg = 0;
		if (attrs.getValue("stddev") != null) 
			this.stddev = Double.parseDouble(attrs.getValue("stddev"));
		else 
			this.stddev = 0;
		if (attrs.getValue("points") != null)
			this.points = Integer.parseInt(attrs.getValue("points"));
		else 
			this.points = 0;
		if (attrs.getValue("max") != null)
			this.max = Double.parseDouble(attrs.getValue("max"));
		else 
			this.max = 0;
		if (attrs.getValue("per") != null)
			this.per = attrs.getValue("per");
		else 
			this.per = "";
		if (attrs.getValue("maxhandle") != null)
			this.maxhandle = attrs.getValue("maxhandle");
		else 
			this.maxhandle = "";
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	public double getAvg() {
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	public double getStddev() {
		return stddev;
	}
	public void setStddev(double stddev) {
		this.stddev = stddev;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public String getPer() {
		return per;
	}
	public void setPer(String per) {
		this.per = per;
	}
	public String getMaxhandle() {
		return maxhandle;
	}
	public void setMaxhandle(String maxhandle) {
		this.maxhandle = maxhandle;
	}
	
}
