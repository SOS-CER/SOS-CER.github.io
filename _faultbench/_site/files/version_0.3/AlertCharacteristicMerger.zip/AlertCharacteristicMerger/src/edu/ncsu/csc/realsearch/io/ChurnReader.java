package edu.ncsu.csc.realsearch.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Churn;
import edu.ncsu.csc.realsearch.data.ChurnHash;
import edu.ncsu.csc.realsearch.io.db.ChurnDB;
import edu.ncsu.csc.realsearch.io.db.DBConnection;

public class ChurnReader {
	
	public void readChurnFromDelimitedFile(String fileName, String delimitor, boolean isHeader, String startVersion, String endVersion) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String line = in.readLine();
			if (isHeader)	//Skip the first line
				line = in.readLine();
			while (line != null) {
				Churn c = new Churn(line, delimitor, startVersion, endVersion);
				ChurnHash.getInstance().addToHash(c.getChurnKey(), c);
				
				ChurnDB.writeToDatabase(DBConnection.getInstance(false).getConnection(), c);
				line = in.readLine();
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void gatherChurnData() {
		ArrayList<Churn> churn = ChurnDB.getChurn(DBConnection.getInstance(false).getConnection());
		for (int i = 0; i < churn.size(); i++) {
			ChurnHash.getInstance().addToHash(churn.get(i).getChurnKey(), churn.get(i));
			ChurnDB.writeToDatabase(DBConnection.getInstance(false).getConnection(), churn.get(i));
		}
		
	}

}
