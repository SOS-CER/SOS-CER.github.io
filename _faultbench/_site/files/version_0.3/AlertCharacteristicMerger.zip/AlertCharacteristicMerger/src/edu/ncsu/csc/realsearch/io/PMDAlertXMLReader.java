package edu.ncsu.csc.realsearch.io;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.main.Constants;

public class PMDAlertXMLReader extends DefaultHandler{
	//Code for reading simple elements from http://www.onjava.com/pub/a/onjava/2002/06/26/xml.html?page=2
	
	private SAXParserFactory factory;
	private SAXParser parser;
	private String version;
	private String key;
	private ArrayList<Alert> alerts;
	private Alert a;
	String temp;
	String flag;
	private String file;
	private String srcFolder = "build\\src\\";
	private String project;
	
	public PMDAlertXMLReader() {
		super();
		alerts = new ArrayList<Alert>();
	}
	
	private void makeParser() {
		try {
			factory = SAXParserFactory.newInstance();
			factory.setNamespaceAware(true);
			parser = factory.newSAXParser();
		} catch (FactoryConfigurationError e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} finally {
			
		}
	}
	
	public ArrayList<Alert> parseFile(String file, String version, String project) {
		makeParser();
		try {
			this.version = version;
			this.project = project;
//			System.out.println(file);
			parser.parse(file, this);
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return alerts;
	}
	
	public void startDocument() throws SAXException {
		
	}
	
	public void endDocument() throws SAXException {
		
	}
//	<violation beginline="96" endline="96" begincolumn="21" endcolumn="35" rule="MethodArgumentCouldBeFinal" ruleset="Optimization Rules" package="org.jdom.contrib.xpath.impl" class="Step" method="apply" externalInfoUrl="http://pmd.sourceforge.net/rules/optimizations.html#MethodArgumentCouldBeFinal" priority="3">
//	Parameter 'nodeset' is not assigned and could be declared final
//	</violation>
	public void startElement(String namespaceURI, String lName, String qName, Attributes attrs) throws SAXException {
		if (lName.equals("file")) { // flag = 0
			file = attrs.getValue("name");
		} else if (lName.equals("violation")) {
			a = new Alert();
			temp = "";
			a.setProjectName(project);
			if (attrs.getValue("package") != null) {
				a.setPackageName(attrs.getValue("package"));
			} else {
				a.setPackageName("");
			}
			if (attrs.getValue("class") != null) {
				a.setFileName(attrs.getValue("class") + ".java");
			} else {
				a.setFileName("");
			}
			if (attrs.getValue("method") != null) {
				a.setMethodName(attrs.getValue("method"));
			} else {
				a.setMethodName("");
			}
			a.setBugType(attrs.getValue("rule"));
			a.setAlertCategory(attrs.getValue("ruleset"));
			a.setLineNumber(Integer.parseInt(attrs.getValue("beginline")));
			a.setPriority(attrs.getValue("priority"));
			if (project.contains(Constants.JDOM) || project.contains(Constants.ECLIPSE)) {
				a.setRepository("cvs");
			} 
			if (project.equals(Constants.LOGGING)) {
				a.setRepository("svn");
			}
			a.setMarkerType("pmd");
			a.setSourceHash("");
			a.setSeverity(2);
		} 		
	}
	
	public void endElement(String namespaceURI, String sName, String qName) throws SAXException {
		if (sName.equals("file")) {
			
		} else if (sName.equals("violation")) {
				a.setDescription(temp);
				alerts.add(a);
		}
		temp = "";
	}
	
	public void characters(char ch[], int start, int length) {
		temp += new String(ch, start, length);
	}
}

