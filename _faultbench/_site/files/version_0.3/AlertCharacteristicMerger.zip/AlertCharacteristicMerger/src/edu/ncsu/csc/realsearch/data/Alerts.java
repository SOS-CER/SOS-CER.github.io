package edu.ncsu.csc.realsearch.data;

import java.util.ArrayList;

import edu.ncsu.csc.realsearch.io.db.AlertDB;
import edu.ncsu.csc.realsearch.io.db.DBConnection;

public final class Alerts {
	
	private ArrayList<Alert> alerts;
	private static Alerts instance;
	
	private Alerts() {
		alerts = new ArrayList<Alert>();
	}
	
	public static Alerts getInstance() {
		if (instance == null) {
			instance = new Alerts();
		}
		return instance;
	}
	
	public ArrayList<Alert> getAlerts() {
		return alerts;
	}

	public void writeToDB() {
		AlertDB db = new AlertDB();
		for (int i = 0; i < alerts.size(); i++) {
			db.writeBasicAlertToDatabase(DBConnection.getInstance(false).getConnection(), alerts.get(i));
		}
	}

	public void clearAlerts() {
		instance = new Alerts();
	}

}
