package edu.ncsu.csc.realsearch.io;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.HistoryDB;
import edu.ncsu.csc.realsearch.main.Constants;

public class CnCAlertComparitor {
public void compareAlerts(String file, String delimitor, boolean isHeader, String version, String project) {
		
		CnCAlertReader reader = new CnCAlertReader();
		JUnitTestReader junitReader = new JUnitTestReader();
		ArrayList<Alert> newAlerts = new ArrayList<Alert>();
		ArrayList<Alert> oldAlerts = Alerts.getInstance().getAlerts();
		if (project.contains(Constants.JDOM)) {
			File f = new File(file);
			File [] files = f.listFiles(new CnCFilter());
			if (files.length >= 1) {
				newAlerts = reader.parseFile(files[0].getAbsolutePath(), version, project);
				files = f.listFiles(new JUnitFilter());
				if (files.length >= 1) {
					ArrayList<String> testFiles = junitReader.parseFile(files[0].getAbsolutePath(), version, project);
					for (int i = 0; i < newAlerts.size(); i++) {
						if (testFiles.contains(newAlerts.get(i).getTestFile())) {
							newAlerts.get(i).setSeverity(1);
						} else {
							newAlerts.get(i).setSeverity(3);
						}
					}
				} else {
					for (int i = 0; i < newAlerts.size(); i++) {
						newAlerts.get(i).setSeverity(2);
					}
				}	 
			}
		} else if (project.contains(Constants.ECLIPSE)) {
			newAlerts = reader.parseFile(file, version, project);
		} else if (project.contains(Constants.LOGGING)) {
			File f = new File(file);
			File [] files = f.listFiles(new CnCFilter());
			if (files.length >= 1) {
				newAlerts = reader.parseFile(files[0].getAbsolutePath(), version, project);
				files = f.listFiles(new JUnitFilter());
				if (files.length >= 1) {
					ArrayList<String> testFiles = junitReader.parseFile(files[0].getAbsolutePath(), version, project);
					for (int i = 0; i < newAlerts.size(); i++) {
						if (testFiles.contains(newAlerts.get(i).getTestFile())) {
							newAlerts.get(i).setSeverity(1);
						} else {
							newAlerts.get(i).setSeverity(3);
						}
					}
				} else {
					for (int i = 0; i < newAlerts.size(); i++) {
						newAlerts.get(i).setSeverity(2);
					}
				}	 
			}
		}
//		System.out.println(version);
		int revision = 0; 
		try {
			revision = Integer.parseInt(version);
		} catch (NumberFormatException e) {
			revision = HistoryDB.getRevisionFromVersion(DBConnection.getInstance(false).getConnection(), project, version);
		}
		
		//JDOM && ECLIPSE
		for (int i = 0; i < oldAlerts.size(); i++) {
			if (oldAlerts.get(i).getMarkerType().equals("cnc")) {
				if (newAlerts.contains(oldAlerts.get(i))) {
					//Only want to check for modification once
					int index = newAlerts.indexOf(oldAlerts.get(i));
					oldAlerts.get(i).isModified(newAlerts.get(index));
					
				} else if (oldAlerts.get(i).getProjectName().equals(project) && oldAlerts.get(i).getCloseRevision() == -1){
					//Old alert has been closed
					oldAlerts.get(i).setCloseRevision(revision);
					oldAlerts.get(i).setClosed(true);
				}
			}
		}
		for (int i = 0; i < newAlerts.size(); i++) {
			if (oldAlerts.contains(newAlerts.get(i))) {
				
				int oldAlertsIndex = oldAlerts.indexOf(newAlerts.get(i));
				if (oldAlerts.get(oldAlertsIndex).isClosed() && oldAlerts.get(oldAlertsIndex).getCloseRevision() != -1) {
//					System.out.println("Alert reopened: " + version + " " + oldAlerts.get(oldAlertsIndex).getCloseRevision() + " " + oldAlerts.get(oldAlertsIndex).getPackageName() + " " + oldAlerts.get(oldAlertsIndex).getFileName() + " " + oldAlerts.get(oldAlertsIndex).getMethodName() + " " + oldAlerts.get(oldAlertsIndex).getBugType() + " " + oldAlerts.get(oldAlertsIndex).getLineNumber());
					oldAlerts.get(oldAlertsIndex).setClosed(false);
					oldAlerts.get(oldAlertsIndex).setCloseRevision(-1);
				}
				
				if (version.equals("1324")) {
					System.out.print("In old set: " + i);
					System.out.print(" closed: " + oldAlerts.get(oldAlertsIndex).isClosed());
					System.out.println(" close revision: " + oldAlerts.get(oldAlertsIndex).getCloseRevision());
				}
			} else {
				if (version.equals("1324")) {
					System.out.println("New: " + i);
				}
				newAlerts.get(i).setOpenRevision(revision);
				newAlerts.get(i).setVersion(version);
				newAlerts.get(i).setRevision(revision);
				oldAlerts.add(newAlerts.get(i));
			}
		}
		
//		for (int i = 0; i < newAlerts.size(); i++) {
//			int dups = 0;
//			for (int j = 0; j < newAlerts.size(); j++) {
//				if (newAlerts.get(i).equals(newAlerts.get(j))) {
//					dups++;
//				}
//			}
//			if (dups > 1) {
//				System.out.println(version + " " + i + " " + dups);
//			}
//		}
				
	}

	private class CnCFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.endsWith("cnc.txt"));
		}
	}
	
	private class JUnitFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			return (name.endsWith("junit.txt"));
		}
	}
}
