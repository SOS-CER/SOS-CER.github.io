package edu.ncsu.csc.realsearch.data;

import java.util.Vector;

public class SvnChangeRecord {
	
	private String revision;
	private String user;
	private String date;
	private String linesChanged;
	private Vector<String> paths;
	private Vector<String> pathChanges;
	private String description;
	
	public SvnChangeRecord() {
		paths = new Vector<String>();
		pathChanges = new Vector<String>();
	}
	
	public String getRevision() {
		return revision;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getLinesChanged() {
		return linesChanged;
	}
	public void setLinesChanged(String linesChanged) {
		this.linesChanged = linesChanged;
	}
	public Vector<String> getPaths() {
		return paths;
	}
	public void setPaths(Vector<String> paths) {
		this.paths = paths;
	}
	public void addPath(String path) {
		paths.add(path);
	}
	public Vector<String> getPathChanges() {
		return pathChanges;
	}
	public void setPathChanges(Vector<String> pathChanges) {
		this.pathChanges = pathChanges;
	}
	public void addPathChange(String pathChange) {
		pathChanges.add(pathChange);
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String toString() {
		String toReturn = revision + " | " + user + " | " + date.toString() + " | " + linesChanged + " | " + description + "\n";
		for(int i = 0; i < paths.size(); i++) {
			toReturn += "\t" + pathChanges.get(i) + " " + paths.get(i) + "\n";
		}
		return toReturn;
	}

}
