package edu.ncsu.csc.realsearch.main;

import java.util.HashMap;

public class Constants {
	
	public static final String PROJECT_ROOT = "C:/sarah_workspace/Subjects/";
	public static final String WORKSPACE_ROOT = "C:/sarah_workspace/RepositoryDataCollector/";
	
	public static final String ECLIPSE_ROOT = "runtime/";
	public static final String ECLIPSE = "runtime";
	public static final String JDOM_ROOT = "jdom/";
	public static final String JDOM = "jdom";
	public static final String LOGGING_ROOT = "logging/";
	public static final String LOGGING = "logging";
	
	public static final String METRICS_ROOT = "metrics/";
	public static final String COVERAGE_ROOT = "test-coverage/";
	public static final String ALERTS_ROOT = "alerts/";
	public static final String HISTORY_ROOT = "history/";
	public static final String FB_ROOT = "fb/";
	public static final String PMD_ROOT = "pmd/";
	public static final String CNC_ROOT = "cnc/";
	
	public static final String DB_NAME = "jdbc:derby:C:/sarah_workspace/databases/alert_db;create=true";
	public static final String DB_NAME_TEST = "jdbc:derby:C:/sarah_workspace/databases/alert_db_test;create=true";
	

	public static HashMap<String, String> primitatives;
}
