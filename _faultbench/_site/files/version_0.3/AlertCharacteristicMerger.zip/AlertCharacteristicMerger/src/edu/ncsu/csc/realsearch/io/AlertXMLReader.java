package edu.ncsu.csc.realsearch.io;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.main.Constants;

public class AlertXMLReader extends DefaultHandler{
	//Code for reading simple elements from http://www.onjava.com/pub/a/onjava/2002/06/26/xml.html?page=2
	
	private SAXParserFactory factory;
	private SAXParser parser;
	private String version;
	private String key;
	private ArrayList<Alert> alerts;
	private Alert a;
	String temp;
	String flag;
	private String project;
	
	public AlertXMLReader() {
		super();
		alerts = new ArrayList<Alert>();
	}
	
	private void makeParser() {
		try {
			factory = SAXParserFactory.newInstance();
			factory.setNamespaceAware(true);
			parser = factory.newSAXParser();
		} catch (FactoryConfigurationError e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} finally {
			
		}
	}
	
	public ArrayList<Alert> parseFile(String file, String version, String project) {
		makeParser();
		try {
			this.version = version;
			this.project = project;
//			System.out.println(file);
			parser.parse(file, this);
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return alerts;
	}
	
	public void startDocument() throws SAXException {
		
	}
	
	public void endDocument() throws SAXException {
		
	}
	
	public void startElement(String namespaceURI, String lName, String qName, Attributes attrs) throws SAXException {
		if (lName.equals("BugCollection")) { // flag = 0
			//skip
		} else if (lName.equals("Project")) {
			//skip
		} else if (lName.equals("Jar")) {
			//skip
		} else if (lName.equals("AuxClasspathEntry")) {
			//skip
		} else if (lName.equals("BugInstance")) {
			a = new Alert();
			if (project.contains(Constants.JDOM) || project.contains(Constants.ECLIPSE)) {
				a.setRepository("cvs");
			} else if (project.contains(Constants.LOGGING)) {
				a.setRepository("svn");
			}
			a.setBugType(attrs.getValue("type"));
			a.setPriority(attrs.getValue("priority"));
			a.setAlertCategory(attrs.getValue("category"));
			a.setSourceHash(attrs.getValue("instanceHash"));
			a.setMethodName("");//Required for no null pointer exceptions
			a.setMarkerType("fb");
		} else if (lName.equals("ShortMessage")) {
			//ignore
		} else if (lName.equals("LongMessage")) {
			//characters will be read
		} else if (lName.equals("Class")) {
			flag = "class";
			if (attrs.getValue("role") != null && attrs.getValue("role").equals("INTERFACE_TYPE")) {
				flag += "_interface";
			}
		} else if (lName.equals("SourceLine")) {
			if (flag.equals("")) {
				if (attrs.getValue("start") != null) { 
					a.setLineNumber(Integer.parseInt(attrs.getValue("start")));
				} else {
					a.setLineNumber(-1);
				}
			} else if (flag.equals("class")) {
				a.setProjectName(project);
				a.setFileName(attrs.getValue("sourcefile"));
				a.setPackageName(attrs.getValue("sourcepath").substring(0, attrs.getValue("sourcepath").indexOf(a.getFileName())));
				flag = "";
			} else if (flag.equals("class_interface")) {
				flag = "";
			} else if (flag.equals("method")) {
				flag = "";
			} else if (flag.equals("field")) {
				flag = "";
			}
		} else if (lName.equals("Method")) {
			flag = "method";
			String methodName = attrs.getValue("name");
			String methodSig = attrs.getValue("signature");
			a.setMethodName(makeMethodSignature(methodName, methodSig));
		} else if (lName.equals("Field")) {
			flag = "field";
		}
		
	}
	
	public String makeMethodSignature(String methodName, String methodSig) {
		String paramContent = methodSig.substring(methodSig.indexOf("(")+1, methodSig.indexOf(")"));
		String parameters = "";
//		System.out.println(methodName + " " + methodSig + " " + paramContent);
		if (!paramContent.contains(";") && paramContent.length() > 0) {
			//go through each letter and expand.
			for (int i = 0; i < paramContent.length(); i++) {
				parameters += Constants.primitatives.get(paramContent.substring(i, i+1)) + ",";
			}
		} else {
			String [] params = paramContent.split(";");
			for (int i = 0; i < params.length; i++) {
				if (params[i].startsWith("L")) {
					parameters += params[i].substring(params[i].lastIndexOf("/")+1) + ",";
				} else {
					int firstL = params[i].indexOf("L");
					for (int j = 0; j < firstL; j++) {
						parameters += Constants.primitatives.get(params[i].substring(j, j+1)) + ",";
					}
					parameters += params[i].substring(params[i].lastIndexOf("/")+1) + ",";
				} 
			}				
		}
		if (parameters.startsWith(",")) {
			parameters.substring(1);
		}
		if (parameters.endsWith(",")) {
			parameters = parameters.substring(0, parameters.length() - 1);
		}
		return methodName + "(" + parameters + ")";
	}
	
	public void endElement(String namespaceURI, String sName, String qName) throws SAXException {
		if (sName.equals("BugInstance")) {
			alerts.add(a);
		} else if (sName.equals("LongMessage")) {
			a.setDescription(temp);
			
		}
		temp = "";
	}
	
	public void characters(char ch[], int start, int length) {
		temp += new String(ch, start, length);
	}
}
