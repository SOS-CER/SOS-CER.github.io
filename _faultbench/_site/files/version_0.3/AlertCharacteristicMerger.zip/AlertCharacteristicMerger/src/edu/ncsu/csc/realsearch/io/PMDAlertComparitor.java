package edu.ncsu.csc.realsearch.io;

import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.HistoryDB;
import edu.ncsu.csc.realsearch.main.Constants;

public class PMDAlertComparitor {
	public void compareAlerts(String file, String delimitor, boolean isHeader, String version, String project) {
		
		PMDAlertXMLReader xmlReader = new PMDAlertXMLReader();
		ArrayList<Alert> newAlerts = null;
		ArrayList<Alert> oldAlerts = Alerts.getInstance().getAlerts();
		if (project.contains(Constants.JDOM)) {
			newAlerts = xmlReader.parseFile(file, version, project);
		} else if (project.contains(Constants.ECLIPSE)) {
			newAlerts = xmlReader.parseFile(file, version, project);
		}
//		System.out.println(version);
		int revision = 0; 
		try {
			revision = Integer.parseInt(version);
		} catch (NumberFormatException e) {
			revision = HistoryDB.getRevisionFromVersion(DBConnection.getInstance(false).getConnection(), project, version);
		}
		
		//JDOM && ECLIPSE
		for (int i = 0; i < oldAlerts.size(); i++) {
			if (newAlerts.contains(oldAlerts.get(i))) {
				//Only want to check for modification once
				int index = newAlerts.indexOf(oldAlerts.get(i));
				oldAlerts.get(i).isModified(newAlerts.get(index));
				
			} else if (oldAlerts.get(i).getProjectName().equals(project) && oldAlerts.get(i).getCloseRevision() == -1){
				//Old alert has been closed
				oldAlerts.get(i).setCloseRevision(revision);
				oldAlerts.get(i).setClosed(true);
			}
		}
		for (int i = 0; i < newAlerts.size(); i++) {
			if (oldAlerts.contains(newAlerts.get(i))) {
				
				int oldAlertsIndex = oldAlerts.indexOf(newAlerts.get(i));
				if (oldAlerts.get(oldAlertsIndex).isClosed() && oldAlerts.get(oldAlertsIndex).getCloseRevision() != -1) {
//					System.out.println("Alert reopened: " + version + " " + oldAlerts.get(oldAlertsIndex).getCloseRevision() + " " + oldAlerts.get(oldAlertsIndex).getPackageName() + " " + oldAlerts.get(oldAlertsIndex).getFileName() + " " + oldAlerts.get(oldAlertsIndex).getMethodName() + " " + oldAlerts.get(oldAlertsIndex).getBugType() + " " + oldAlerts.get(oldAlertsIndex).getLineNumber());
					oldAlerts.get(oldAlertsIndex).setClosed(false);
					oldAlerts.get(oldAlertsIndex).setCloseRevision(-1);
				}
				
				if (version.equals("1324")) {
					System.out.print("In old set: " + i);
					System.out.print(" closed: " + oldAlerts.get(oldAlertsIndex).isClosed());
					System.out.println(" close revision: " + oldAlerts.get(oldAlertsIndex).getCloseRevision());
				}
			} else {
				if (version.equals("1324")) {
					System.out.println("New: " + i);
				}
				newAlerts.get(i).setOpenRevision(revision);
				newAlerts.get(i).setVersion(version);
				newAlerts.get(i).setRevision(revision);
				oldAlerts.add(newAlerts.get(i));
			}
		}
		
//		for (int i = 0; i < newAlerts.size(); i++) {
//			int dups = 0;
//			for (int j = 0; j < newAlerts.size(); j++) {
//				if (newAlerts.get(i).equals(newAlerts.get(j))) {
//					dups++;
//				}
//			}
//			if (dups > 1) {
//				System.out.println(version + " " + i + " " + dups);
//			}
//		}
				
	}
}
