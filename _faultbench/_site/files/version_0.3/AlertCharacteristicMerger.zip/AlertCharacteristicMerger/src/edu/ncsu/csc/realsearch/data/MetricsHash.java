package edu.ncsu.csc.realsearch.data;

import java.util.Hashtable;

public class MetricsHash {
	
	private Hashtable<String, MetricsGroup> hash;
	public static MetricsHash instance;
	
	private MetricsHash() {
		hash = new Hashtable<String, MetricsGroup>();
	}
	
	public static MetricsHash getInstance() {
		if (instance == null) {
			instance = new MetricsHash();
		}
		return instance;
	}
	
	public void addToHash(String key, MetricsGroup value) {
		instance.hash.put(key, value);
	}
	
	public MetricsGroup getFromHash(String key) {
		return instance.hash.get(key);
	}

	public Hashtable<String, MetricsGroup> getHashtable() {
		return hash;
	}

}
