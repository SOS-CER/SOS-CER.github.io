package edu.ncsu.csc.realsearch.io.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.History;
import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class HistoryDB {
	
	public static boolean writeToDatabase(DerbyConnection conn, History h) {
		try {
					
			String query = "insert into history values(?,?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, h.getVersion());
			stmt.setInt(2, h.getRevision());
			stmt.setString(3, h.getDate());
			stmt.setString(4, h.getRevisionType());	
			stmt.setString(5, h.getDeveloper());
			stmt.executeUpdate();
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public static int getRevisionFromVersion(DerbyConnection conn, String projectName, String version) {
		int revision = -1;
		try {
			String query = "select revision from history where project=? and version=?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setString(2, version);	
			ResultSet rs = stmt.executeQuery();
			rs.next();
			revision = rs.getInt("revision");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return revision;
	}

	public static String getDeveloper(DerbyConnection conn, String projectName, int openRevision) {
		String developer = "";
		try {
			String query = "select developer from history where projectName=? and revision=?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setInt(2, openRevision);	
			ResultSet rs = stmt.executeQuery();
			rs.next();
			developer = rs.getString("developer");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return developer;
	}

	public static String getRevisionType(DerbyConnection conn,
			String projectName, int closeRevision) {
		String revisionType = "";
		try {
			String query = "select revisionType from history where projectName=? and revision=?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setInt(2, closeRevision);	
			ResultSet rs = stmt.executeQuery();
			rs.next();
			revisionType = rs.getString("revisionType");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return revisionType;
	}

	public static int getMaxRevision(DerbyConnection conn, String projectName) {
		int maxRevision = -1;
		try {
			String query = "select max(revision) as maxRevision from history where projectName=?";
			PreparedStatement stmt = conn.getStatement(query);	
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			maxRevision = rs.getInt("maxRevision");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return maxRevision;
	}

	public static void addDatesToCommitsTable(DerbyConnection conn, String projectName) {
		try {
			String query = "select distinct date, revisionNotes from cvs_revision where projectName=? order by date";
			PreparedStatement stmt = conn.getStatement(query);	
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				query = "insert into commits(projectName, date, revisionNotes) values(?,?,?)";
				stmt = conn.getStatement(query);
				stmt.setString(1, projectName);
				stmt.setString(2, rs.getString("date"));
				stmt.setString(3, rs.getString("revisionNotes"));
				stmt.executeUpdate();
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static String getCommitDateFromCommitNumber(
			DerbyConnection conn, String projectName, int revision) {
		String commitDate = "";
		try {
			String query = "select date from commits where projectName=? and commitNum=?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setInt(2, revision);	
			ResultSet rs = stmt.executeQuery();
			rs.next();
			commitDate = rs.getString("date");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return commitDate;
	}

	public static String getPreviousCommitDateFromCommitNumber(
			DerbyConnection conn, String projectName, int revision) {
		String commitDate = "";
		try {
			String query = "select date from commits where projectName=? and commitNum<?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setInt(2, revision);	
			ResultSet rs = stmt.executeQuery();
			rs.next();
			commitDate = rs.getString("date");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return commitDate;
	}

	public static int getMaxCommit(DerbyConnection conn, String projectName) {
		int maxRevision = -1;
		try {
			String tableName = "";
			if (projectName.startsWith("jdom")) {
				tableName = "commits_jdom";
				
			} else if (projectName.contains("runtime")) {
				tableName = "commits_runtime";
			}
			String query = "select max(commitNum) as maxRevision from "+tableName+" where projectName=?";
			PreparedStatement stmt = conn.getStatement(query);	
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			maxRevision = rs.getInt("maxRevision");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return maxRevision;
	}
	
	public static int getMaxCommitSVN(DerbyConnection conn, String projectName) {
		int maxRevision = -1;
		try {
			String query = "select max(revision) as maxRevision from svn_revision where projectName=?";
			PreparedStatement stmt = conn.getStatement(query);	
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			maxRevision = Integer.parseInt(rs.getString("maxRevision"));
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return maxRevision;
	}

	public static String getCommitType(DerbyConnection conn, String projectName,
			int revision) {
		String commitType = "change";
		try {
			int previousRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
			String query = "select count(*) as count from commits where commitNum <= ? and commitnum > ? and (revisionNotes like ? or revisionNotes like ? or revisionNotes like ? or revisionNotes like ?) ";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setInt(1, revision);
			stmt.setInt(2, previousRevision);
			stmt.setString(3, "% bug%");
			stmt.setString(4, "% patch%");
			stmt.setString(5, "% fix%");
			stmt.setString(6, "% bugfix%");
			ResultSet rs = stmt.executeQuery();
			rs.next();
			if (rs.getInt("count") > 0) {
				commitType = "bug";
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return commitType;
	}
	
	public static String getCommitTypeSVN(DerbyConnection conn, String projectName,
			int revision) {
		String commitType = "change";
		try {
			int previousRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
			String query = "select count(*) as count from svn_revision where revision <= ? and revision > ? and (comments like ? or comments like ? or comments like ? or comments like ?) ";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "" + revision);
			stmt.setString(2, "" + previousRevision);
			stmt.setString(3, "% bug%");
			stmt.setString(4, "% patch%");
			stmt.setString(5, "% fix%");
			stmt.setString(6, "% bugfix%");
			ResultSet rs = stmt.executeQuery();
			rs.next();
			if (rs.getInt("count") > 0) {
				commitType = "bug";
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return commitType;
	}

	public static String getCommitDeveloper(DerbyConnection conn,
			String projectName, int revision) {
		String developer = "";
		try {
			String query = "select author as developer from cvs_revision, commits where commits.commitNum=? and cvs_revsion.date = commits.date and cvs_revision.revisionNotes=commits.revisionNotes and projectName=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setInt(1, revision);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(2, projectName);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			developer = rs.getString("developer");
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return developer;
	}
	
	public static String getLastPassingVersionFromRevision(DerbyConnection conn, String projectName, int revision) {
		String version = "";
		try {
			String query = "select version from version_status where projectName=? and revision < ? and status='PASS'";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setInt(2, revision);	
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				version = rs.getString("version");
			} else {
				version = "0001";
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return version;
	}
	
	public static int getLastPassingRevisionFromRevision(DerbyConnection conn, String projectName, int revision) {
		int lastRevision = 1;
		try {
			String query = "select max(revision) as  revision from version_status where projectName=? and revision < ? and status=?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setInt(2, revision);	
			stmt.setString(3, "PASS");
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				lastRevision = rs.getInt("revision");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return lastRevision;
	}
	
	public static String getDateForRevision(DerbyConnection conn, String projectName, int revision) {
		String date = "";
		try {
			String query = "";
			if (projectName.startsWith("jdom")) {
				query = "select date from commits_jdom where projectName=? and commitnum=?";
			} else if (projectName.contains("runtime")) {
				query = "select date from commits_runtime where projectName=? and commitnum=?";
			}
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setInt(2, revision);	
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				date = rs.getString("date");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public static ArrayList<String> getDevelopersForFileInRevision(DerbyConnection conn, int revision, String projectName, String file) {
		ArrayList<String> developers = new ArrayList<String>();
		String currentDate = getDateForRevision(conn, projectName, revision);
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		String previousPassingRevisionDate = getDateForRevision(conn, projectName, previousPassingRevision);
		try {
			String query = "select distinct author from cvs_revision where projectName=? and date <= ? and date > ? and workingFile like ?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setString(2, currentDate);
			stmt.setString(3, previousPassingRevisionDate);
			stmt.setString(4, projectName + "%" + file);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				developers.add(rs.getString("author"));
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
//		if (developers.size() == 0) {
//			System.out.println(projectName + " " + file + " " + revision + " " + currentDate + " " + previousPassingRevision + " " + previousPassingRevisionDate);
//		}
		return developers;
	}
	
	public static ArrayList<String> getDevelopersForFileInRevisionSVN(DerbyConnection conn, int revision, String projectName, String file) {
		ArrayList<String> developers = new ArrayList<String>();
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		try {
			String query = "select distinct author from svn_revision where projectName=? and revision <= ? and revision > ? and path like ?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setString(2, "" + revision);
			stmt.setString(3, "" + previousPassingRevision);
			stmt.setString(4, "%" + projectName + "%" + file);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				developers.add(rs.getString("author"));
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
//		if (developers.size() == 0) {
//			System.out.println(projectName + " " + file + " " + revision + " " + currentDate + " " + previousPassingRevision + " " + previousPassingRevisionDate);
//		}
		return developers;
	}
	
	

	public static int getFileCreationRevision(DerbyConnection conn, String projectName,
			String file) {
		int revision = -1;
		try {
			String query = "";
			if (projectName.startsWith("jdom")) {
				query = "select commitNum from commits_jdom, (select date, revisionNotes from cvs_revision where revision=? and workingFile like ?) as dates where commits_jdom.date=dates.date and commits_jdom.revisionNotes=dates.revisionNotes";
			} else if (projectName.contains("runtime")) {
				query = "select commitNum from commits_runtime, (select date, revisionNotes from cvs_revision where revision=? and workingFile like ?) as dates where commits_runtime.date=dates.date and commits_runtime.revisionNotes=dates.revisionNotes";
			}
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "1.1");
			stmt.setString(2, projectName + "%" + file);	
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("commitNum");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return revision;
	}
	
	public static int getFileCreationRevisionSVN(DerbyConnection conn, String projectName, 
			String file) {
		int revision = -1;
		try {
			String query = "select min(revision) as commitNum from svn_revision where path like ? and change='A' or change='M'";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "%" + file);	
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("commitNum");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return revision;
	}

	public static int getFileDeletionRevision(DerbyConnection conn,
			String projectName, String file) {
		int revision = -1;
		try {
			String query = "";
			if (projectName.startsWith("jdom")) { 
				query = "select commitNum from commits_jdom, (select date, revisionNotes from cvs_revision where state=? and workingFile like ? and date=(select max(date) from cvs_revision where workingFile like ?)) as dates where commits_jdom.date=dates.date and commits_jdom.revisionNotes=dates.revisionNotes";
			} else if (projectName.contains("runtime")) {
				query = "select commitNum from commits_runtime, (select date, revisionNotes from cvs_revision where state=? and workingFile like ? and date=(select max(date) from cvs_revision where workingFile like ?)) as dates where commits_runtime.date=dates.date and commits_runtime.revisionNotes=dates.revisionNotes";
			}
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "dead");
			stmt.setString(2, projectName + "%" + file);
			stmt.setString(3, projectName + "%" + file);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("commitNum");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return revision;
	}
	
	public static int getFileDeletionRevisionSVN(DerbyConnection conn,
			String projectName, String file) {
		int revision = -1;
		try {
			String query = "select max(revision) as maxDeletedRevision from svn_revision where path like ? and change='D'";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "%" + file);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				revision = rs.getInt("maxDeletedRevision");
			} 
			
			query = "select max(revision) as maxAddedRevision from svn_revision where path like ? and change='A'";
			stmt = conn.getStatement(query);
			stmt.setString(1, "%" + file);
			rs = stmt.executeQuery();
			int maxAddedRevision = 0;
			if (rs.next()) {
				maxAddedRevision = rs.getInt("maxAddedRevision");
			} 
			
			if (maxAddedRevision >= revision) {
				revision = -1;
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return revision;
	}

	public static int getFileModificationBeforeCurrentRevision(
			DerbyConnection conn, String projectName, String file,
			int revision) {
		int modRevision = -1;
		String currentDate = getDateForRevision(conn, projectName, revision);
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		String previousPassingRevisionDate = getDateForRevision(conn, projectName, previousPassingRevision);
		try {
			String tableName = "";
			if (projectName.startsWith("jdom")) {
				tableName = "commits_jdom";
			} else if (projectName.contains("runtime")) {
				tableName = "commits_runtime";
			}
			String query = "select commitNum from " + tableName + " , (select max(date) as date from cvs_revision where date <= ? and date > ? and workingFile like ?) as dates where " + tableName + ".date=dates.date";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, currentDate);
			stmt.setString(2, previousPassingRevisionDate);
			stmt.setString(3, projectName + "%" + file);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				modRevision = rs.getInt("commitNum");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return modRevision;
	}
	
	public static int getLatestFileModificationRevision(
			DerbyConnection conn, String projectName, String file,
			int revision) {
		int modRevision = -1;
		try {
			
			String tableName = "";
			if (projectName.startsWith("jdom")) {
				tableName = "commits_jdom";
//				projectName = "jdom";
			} else if (projectName.contains("runtime")) {
				tableName = "commits_runtime";
			}
			String query = "select commitNum from " + tableName + ", (select max(date) as date from cvs_revision where workingFile like ? and projectName like ?) as dates where " + tableName + ".date=dates.date";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName + "%" + file);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(2, "%" + projectName + "%");
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				modRevision = rs.getInt("commitNum");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return modRevision;
	}
	
	public static int getLatestFileModificationRevisionSVN(
			DerbyConnection conn, String projectName, String file,
			int revision) {
		int modRevision = -1;
		try {
			String query = "select max(revision) as commitNum from svn_revision where path like ? and projectName=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "%" + file);
			stmt.setString(2, projectName);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				modRevision = rs.getInt("commitNum");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return modRevision;
	}
	
	public static int getAddedLines(DerbyConnection conn, String projectName, 
			String file, int revision) {
		int addedLines = -1;
		String currentDate = getDateForRevision(conn, projectName, revision);
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		String previousPassingRevisionDate = getDateForRevision(conn, projectName, previousPassingRevision);
		try {
			String query = "select sum(addedLines) as added from cvs_revision where date <= ? and date > ? and workingFile like ? and projectName like ?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, currentDate);
			stmt.setString(2, previousPassingRevisionDate);
			stmt.setString(3, "%" + file);
			stmt.setString(4, "%" + projectName + "%");
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				addedLines = rs.getInt("added");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return addedLines;
	}
	
	public static int getAddedLinesSVN(DerbyConnection conn, String projectName, 
			String file, int revision) {
		int addedLines = -1;
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		try {
			String query = "select sum(addedLines) as added from svn_churn_info where revision <= ? and revision > ? and path like ? and projectName=? and addedLines >= 0";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "" + revision);
			stmt.setString(2, "" + previousPassingRevision);
			stmt.setString(3, "%" + file);
			stmt.setString(4, projectName);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				addedLines = rs.getInt("added");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return addedLines;
	}
	
	public static int getDeletedLines(DerbyConnection conn, String projectName, 
			String file, int revision) {
		int deletedLines = -1;
		String currentDate = getDateForRevision(conn, projectName, revision);
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		String previousPassingRevisionDate = getDateForRevision(conn, projectName, previousPassingRevision);
		try {
			String query = "select sum(deletedLines) as deleted from cvs_revision where date <= ? and date > ? and workingFile like ? and projectName like ?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, currentDate);
			stmt.setString(2, previousPassingRevisionDate);
			stmt.setString(3, "%" + file);
			stmt.setString(4, "%" + projectName + "%");
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				deletedLines = rs.getInt("deleted");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deletedLines;
	}
	
	public static int getDeletedLinesSVN(DerbyConnection conn, String projectName, 
			String file, int revision) {
		int deletedLines = -1;
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		try {
			String query = "select sum(deletedLines) as deleted from svn_churn_info where revision <= ? and revision > ? and path like ? and projectName=? and deletedLines >= 0";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "" + revision);
			stmt.setString(2, "" + previousPassingRevision);
			stmt.setString(3, "%" + file);
			stmt.setString(4, projectName);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				deletedLines = rs.getInt("deleted");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deletedLines;
	}

	public static double getAllChurnedLines(DerbyConnection conn, String projectName, int revision) {
		double churnedLines = -1;
		String currentDate = getDateForRevision(conn, projectName, revision);
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		String previousPassingRevisionDate = getDateForRevision(conn, projectName, previousPassingRevision);
		try {
			String query = "select sum(addedLines) as added, sum(deletedLines) as deleted from cvs_revision where projectName=? and date <= ? and date > ?";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setString(2, currentDate);
			stmt.setString(3, previousPassingRevisionDate);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				churnedLines = rs.getInt("added");
				churnedLines += rs.getInt("deleted");
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (churnedLines == 0) {
//			System.out.println(projectName + " " + revision + " " + currentDate + " " + previousPassingRevision + " " + previousPassingRevisionDate);
		}
		return churnedLines;
	}
	
	public static double getAllChurnedLinesSVN(DerbyConnection conn, String projectName, int revision) {
		double churnedLines = -1;
		int previousPassingRevision = getLastPassingRevisionFromRevision(conn, projectName, revision);
		try {
			//TODO: check - Need to check that values are -1 for comparisons of jar files.
			String query = "select sum(addedLines) as added, sum(deletedLines) as deleted from svn_churn_info where projectName=? and revision <= ? and revision > ? and addedLines >= 0 and deletedLines >= 0";
			PreparedStatement stmt = conn.getStatement(query);
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			stmt.setString(2, "" + revision);
			stmt.setString(3, "" + previousPassingRevision);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				churnedLines = rs.getInt("added");
				churnedLines += rs.getInt("deleted");
//				System.out.println(churnedLines + " = " + rs.getInt("added") + " + " + rs.getInt("deleted"));
				
			} 
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (churnedLines == 0) {
//			System.out.println(projectName + " " + revision + " " + currentDate + " " + previousPassingRevision + " " + previousPassingRevisionDate);
		}
		return churnedLines;
	}

	public static void addDatesToRuntimeCommitsTable(
			DerbyConnection conn, String projectName) {
		try {
			String query = "select distinct date, revisionNotes from cvs_revision where projectName=? order by date";
			PreparedStatement stmt = conn.getStatement(query);	
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				query = "insert into commits_runtime(projectName, date, revisionNotes) values(?,?,?)";
				stmt = conn.getStatement(query);
				stmt.setString(1, projectName);
				stmt.setString(2, rs.getString("date"));
				stmt.setString(3, rs.getString("revisionNotes"));
				stmt.executeUpdate();
			}
			
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void addDatesToJdomCommitsTable(DerbyConnection conn,
			String projectName) {
		try {
			String query = "select distinct date, revisionNotes from cvs_revision where projectName like ? order by date";
			PreparedStatement stmt = conn.getStatement(query);	
			if (projectName.startsWith("jdom")) {
				projectName = "jdom";
			}
			stmt.setString(1, projectName);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				query = "insert into commits_jdom(projectName, date, revisionNotes) values(?,?,?)";
				stmt = conn.getStatement(query);
				stmt.setString(1, projectName);
				stmt.setString(2, rs.getString("date"));
				stmt.setString(3, rs.getString("revisionNotes"));
				stmt.executeUpdate();
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

}
