package edu.ncsu.csc.realsearch.data;

public class History {
	
	
	private String version;
	private int revision;
	private String date;
	private String revisionType;
	private String developer;
	
	public History(String line, String delimitor) {
		String [] contents = line.split(delimitor);
		this.revision = Integer.parseInt(contents[0]);
		this.version = contents[1];
		this.date = contents[2];
		this.revisionType = contents[3];
		this.developer = contents[4];
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final History other = (History) obj;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (revision != other.revision)
			return false;
		if (revisionType == null) {
			if (other.revisionType != null)
				return false;
		} else if (!revisionType.equals(other.revisionType))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}
	public String getDate() {
		return date;
	}
	public String getDeveloper() {
		return developer;
	}
	public int getRevision() {
		return revision;
	}
	public String getRevisionType() {
		return revisionType;
	}
	public String getVersion() {
		return version;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + revision;
		result = prime * result
				+ ((revisionType == null) ? 0 : revisionType.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public void setDeveloper(String developer) {
		this.developer = developer;
	}
	public void setRevision(int revision) {
		this.revision = revision;
	}
	public void setRevisionType(String revisionType) {
		this.revisionType = revisionType;
	}
	public void setVersion(String version) {
		this.version = version;
	}
		
}
