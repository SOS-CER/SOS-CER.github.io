package edu.ncsu.csc.realsearch.data;

public class MetricsPackage {
	
	private String projectName;
	private String version;
	private String name;
	private int classes;
	private int functions;
	private int ncss;
	private int javadocs;
	private int javadocLines;
	private int singleCommentLines;
	private int multiCommentLines;
	
	public MetricsPackage(String projectName, String version) {
		this.projectName = projectName;
		this.version = version;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getClasses() {
		return classes;
	}

	public void setClasses(int classes) {
		this.classes = classes;
	}

	public int getFunctions() {
		return functions;
	}

	public void setFunctions(int functions) {
		this.functions = functions;
	}

	public int getNcss() {
		return ncss;
	}

	public void setNcss(int ncss) {
		this.ncss = ncss;
	}

	public int getJavadocs() {
		return javadocs;
	}

	public void setJavadocs(int javadocs) {
		this.javadocs = javadocs;
	}

	public int getJavadocLines() {
		return javadocLines;
	}

	public void setJavadocLines(int javadocLines) {
		this.javadocLines = javadocLines;
	}

	public int getSingleCommentLines() {
		return singleCommentLines;
	}

	public void setSingleCommentLines(int singleCommentLines) {
		this.singleCommentLines = singleCommentLines;
	}

	public int getMultiCommentLines() {
		return multiCommentLines;
	}

	public void setMultiCommentLines(int multiCommentLines) {
		this.multiCommentLines = multiCommentLines;
	}

}
