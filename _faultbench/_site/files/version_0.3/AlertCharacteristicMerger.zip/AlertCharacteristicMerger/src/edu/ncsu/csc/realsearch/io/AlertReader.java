package edu.ncsu.csc.realsearch.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;

public class AlertReader {
	
	public ArrayList<Alert> readAlertsFromTabDelimitedFile(String fileName, boolean isHeader) {
		ArrayList<Alert> alerts = new ArrayList<Alert>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String line = in.readLine();
			if (isHeader)	//Skip the first line
				line = in.readLine();
			while (line != null) {
				Alert alert = new Alert(line);
				alerts.add(alert);
				line = in.readLine();
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return alerts;
	}
	
	public ArrayList<Alert> readAlertsFromDelimitedFile(String fileName, String delimitor, boolean isHeader, String version) {
		ArrayList<Alert> alerts = new ArrayList<Alert>();
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String line = in.readLine();
			if (isHeader)	//Skip the first line
				line = in.readLine();
			while (line != null) {
				Alert alert = new Alert(line, delimitor, version);
				alerts.add(alert);
				line = in.readLine();
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return alerts;
	}

}
