package edu.ncsu.csc.realsearch.io.db;

import edu.ncsu.csc.realsearch.main.Constants;
import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class DBConnection {
		
	private static DerbyConnection conn;
	private static DBConnection instance;
	
	public DBConnection (boolean isTest) {
		try {
			conn = new DerbyConnection();
			if (isTest) {
				conn.connect(Constants.DB_NAME_TEST);
			} else {
				conn.connect(Constants.DB_NAME);
			}
		} catch (DBConnectionException e) {
			
		}
	}
	
	public static DBConnection getInstance(boolean isTest) {
		if (instance == null) {
			instance = new DBConnection(isTest);
		}
		return instance;
	}
	
	public DerbyConnection getConnection() {
		return conn;
	}
	
}
