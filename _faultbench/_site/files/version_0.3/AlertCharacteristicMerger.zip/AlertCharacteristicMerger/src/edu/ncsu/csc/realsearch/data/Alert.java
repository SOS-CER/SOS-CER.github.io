package edu.ncsu.csc.realsearch.data;

import java.text.DecimalFormat;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.io.db.AlertDB;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.HistoryDB;
import edu.ncsu.csc.realsearch.io.db.MetricsDB;

public class Alert {
	
	private DecimalFormat formatter;
	
	private int id;
	private String classification;
	private String notes;
	/*================Alert Info==================*/
	private String description;
	private String projectName;
	private String packageName;
	private String fileName;
	private String methodName;
	private int dups; //not used 
	private String sourceHash; //not used
	private String markerType; 
	private int lineNumber; //not used
	private boolean isFiltered; //not used
	private boolean isDefected; //not used
	private boolean isClosed; //not used
	private String testFile; //not used
	private int severity; //Eclipse level severity
	private String bugType;
	private String alertCategory;
	private String priority;
	private String fileExtension;
	private int numAlertModifications;
	private String version;
	private int revision;
	private String repository;
	
	/*=============Metrics=============*/
	private int methodSize;
	private int fileSize;
	private int cyclomaticComplexity;
	private int depthOfInheritanceTree;
	private int numAttributes;
	private int numParameters;
	private int numberOfFunctionsInFile;
	private int numberOfClassesInFile;
	private int numberOfFunctionsInPackage;
	private int numberOfClassesInPackage;
	private int packageSize;
	
	/*=============History=============*/
	private int openRevision;
	private int closeRevision;
	private String developer;
	private ArrayList<String> developers;
	private String closeRevisionType;
	private String openRevisionType;
	private int fileCreationRevision;
	private int fileDeletionRevision;
	private int latestFileModficationRevision;
	private int latestPackageModificationRevision;
	private int latestProjectModficiationRevision;
		
	/*=============Churn===============*/
	private int fileAddedLines;
	private int fileDeletedLines;
	private int fileModifiedLines;
	private int fileGrowthLines;
	private int fileTotalModifiedLines;
	private double filePercentModifiedLines;
	private int packageAddedLines;
	private int packageDeletedLines;
	private int packageModifiedLines;
	private int packageGrowthLines;
	private int packageTotalModifiedLines;
	private double packagePercentModifiedLines;
	private int projectAddedLines;
	private int projectDeletedLines;
	private int projectModifiedLines;
	private int projectGrowthLines;
	private int projectTotalModifiedLines;
	private double projectPercentModifiedLines;
	
	
	/*============Aggregate Alert Info======*/
	private int totalAlertsForRevision;
	private int totalOpenAlertsForRevision;
	private int alertLifetime; //in # of revisions
	private int fileAge; //in # of revisions
	private int alertsInMethod;
	private int alertsInFile;
	private int alertsInPackage;
	private int alertsInProject;
	private int fileStaleness; //in # of revisions
	private int packageStaleness; //in # of revisions
	private int projectStaleness;
	private double alertDepthInFile;
	
	
	private static final int ALERT_LINE_LENGTH = 18; 
	
	public Alert() {
		super();
		this.closeRevision = -1;
		formatter = new DecimalFormat("###.#####");
	}
	
	public Alert(String alertLine) {
		String [] contents = alertLine.split("\t");
		this.closeRevision = -1;
		formatter = new DecimalFormat("###.#####");
		if (contents.length == ALERT_LINE_LENGTH) {
			this.id = Integer.parseInt(contents[0]);
			this.classification = contents[1];
			this.notes = contents[2];
			this.description = contents[3];
			this.projectName = contents[4];
			this.packageName = contents[5];
			this.fileName = contents[6];
			this.methodName = contents[7];
			this.dups = Integer.parseInt(contents[8]);
			this.sourceHash = contents[9];
			this.markerType = contents[10];
			this.lineNumber = Integer.parseInt(contents[11]);
			if ("true".equals(contents[12]))
				this.isFiltered = Boolean.valueOf(true);
			else
				this.isFiltered = Boolean.valueOf(false);
			if ("true".equals(contents[13]))
				this.isDefected = Boolean.valueOf(true);
			else
				this.isDefected = Boolean.valueOf(false);
			if ("true".equals(contents[14]))
				this.isClosed = Boolean.valueOf(true);
			else
				this.isClosed = Boolean.valueOf(false);
			this.testFile = contents[15];
			this.severity = Integer.parseInt(contents[16]);
			this.bugType = contents[17];
			
		} else {
			System.err.println("Alert " + alertLine + " cannot be parsed");
		}
	}	
	
	public Alert(String alertLine, String delimitor, String version) {
		String [] contents = alertLine.split(delimitor);
		this.closeRevision = -1;
		formatter = new DecimalFormat("###.#####");
		if (contents.length == ALERT_LINE_LENGTH-2) {
			//Skip the ranking
			this.description = contents[1];
			this.projectName = contents[2].toLowerCase();
			this.packageName = contents[3] + "/";
			this.fileName = contents[4];
			if (contents[5].startsWith("static")) {
				contents[5] = contents[5].substring(contents[5].indexOf(" ") + 1);
			}
			contents[5] = contents[5].substring(contents[5].indexOf(" ") + 1);
			this.methodName = contents[5].replace(" ", "");
			this.dups = Integer.parseInt(contents[6]);
			this.sourceHash = contents[7];
			this.markerType = contents[8];
			this.lineNumber = Integer.parseInt(contents[9]);
			if ("true".equals(contents[10]))
				this.isFiltered = Boolean.valueOf(true);
			else
				this.isFiltered = Boolean.valueOf(false);
			if ("true".equals(contents[11]))
				this.isDefected = Boolean.valueOf(true);
			else
				this.isDefected = Boolean.valueOf(false);
			if ("true".equals(contents[12]))
				this.isClosed = Boolean.valueOf(true);
			else
				this.isClosed = Boolean.valueOf(false);
			//Skip the fourth true/false
//			this.testFile = contents[14];
			this.severity = Integer.parseInt(contents[14]);
			this.bugType = contents[15];
			this.version = version;
			this.repository = "svn";
		} else {
			System.err.println("Alert " + alertLine + " cannot be parsed");
		}
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getPackageName() {
		return packageName;
	}
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMethodName() {
		return methodName;
	}
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	public int getDups() {
		return dups;
	}
	public void setDups(int dups) {
		this.dups = dups;
	}
	public String getSourceHash() {
		return sourceHash;
	}
	public void setSourceHash(String sourceHash) {
		this.sourceHash = sourceHash;
	}
	public String getMarkerType() {
		return markerType;
	}
	public void setMarkerType(String markerType) {
		this.markerType = markerType;
	}
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public boolean isFiltered() {
		return isFiltered;
	}
	public void setFiltered(boolean isFiltered) {
		this.isFiltered = isFiltered;
	}
	public boolean isDefected() {
		return isDefected;
	}
	public void setDefected(boolean isDefected) {
		this.isDefected = isDefected;
	}
	public boolean isClosed() {
		return isClosed;
	}
	public void setClosed(boolean isClosed) {
		this.isClosed = isClosed;
	}
	public String getTestFile() {
		return testFile;
	}
	public void setTestFile(String testFile) {
		this.testFile = testFile;
	}
	public int getSeverity() {
		return severity;
	}
	public void setSeverity(int severity) {
		this.severity = severity;
	}
	public String getBugType() {
		return bugType;
	}
	public void setBugType(String bugType) {
		this.bugType = bugType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getDeveloper() {
		return developer;
	}

	public void setDeveloper(String developer) {
		this.developer = developer;
	}
	
	public ArrayList<String> getDevelopers() {
		return developers;
	}

	public void setDevelopers(ArrayList<String> developers) {
		this.developers = developers;
	}
	
	/* Total alerts for revision is all alerts including closed alerts */
	public int getTotalAlertsForRevision() {
		return totalAlertsForRevision;
	}

	public void setTotalAlertsForRevision(int totalAlertsForRevision) {
		this.totalAlertsForRevision = totalAlertsForRevision;
	}

	public int getOpenRevision() {
		return openRevision;
	}

	public void setOpenRevision(int openRevision) {
		this.openRevision = openRevision;
	}

	public int getCloseRevision() {
		return closeRevision;
	}

	public void setCloseRevision(int closeRevision) {
		this.closeRevision = closeRevision;
	}

	public int getAlertLifetime() {
		return alertLifetime;
	}

	public void setAlertLifetime(int alertLifetime) {
		this.alertLifetime = alertLifetime;
	}

	public String getAlertCategory() {
		return alertCategory;
	}

	public void setAlertCategory(String alertCategory) {
		this.alertCategory = alertCategory;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public int getFileCreationRevision() {
		return fileCreationRevision;
	}

	public void setFileCreationRevision(int fileCreationRevision) {
		this.fileCreationRevision = fileCreationRevision;
	}

	public int getFileAge() {
		return fileAge;
	}

	public void setFileAge(int fileAge) {
		this.fileAge = fileAge;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public int getAlertsInFile() {
		return alertsInFile;
	}

	public void setAlertsInFile(int alertsInFile) {
		this.alertsInFile = alertsInFile;
	}

	public int getLatestFileModficationRevision() {
		return latestFileModficationRevision;
	}

	public void setLatestFileModficationRevision(int latestFileModficationRevision) {
		this.latestFileModficationRevision = latestFileModficationRevision;
	}

	public int getFileStaleness() {
		return fileStaleness;
	}

	public void setFileStaleness(int fileStaleness) {
		this.fileStaleness = fileStaleness;
	}

	public int getLatestPackageModificationRevision() {
		return latestPackageModificationRevision;
	}

	public void setLatestPackageModificationRevision(
			int latestPackageModificationRevision) {
		this.latestPackageModificationRevision = latestPackageModificationRevision;
	}

	public int getPackageStaleness() {
		return packageStaleness;
	}

	public void setPackageStaleness(int packageStaleness) {
		this.packageStaleness = packageStaleness;
	}

	public int getAlertsInProject() {
		return alertsInProject;
	}

	public void setAlertsInProject(int alertsInProject) {
		this.alertsInProject = alertsInProject;
	}

	public int getLatestProjectModficiationRevision() {
		return latestProjectModficiationRevision;
	}

	public void setLatestProjectModficiationRevision(
			int latestProjectModficiationRevision) {
		this.latestProjectModficiationRevision = latestProjectModficiationRevision;
	}

	public int getProjectStaleness() {
		return projectStaleness;
	}

	public void setProjectStaleness(int projectStaleness) {
		this.projectStaleness = projectStaleness;
	}

	public int getFileSize() {
		return fileSize;
	}

	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}

	public double getAlertDepthInFile() {
		return alertDepthInFile;
	}

	public void setAlertDepthInFile(double alertDepthInFile) {
		this.alertDepthInFile = alertDepthInFile;
	}

	public int getCyclomaticComplexity() {
		return cyclomaticComplexity;
	}

	public void setCyclomaticComplexity(int cyclomaticComplexity) {
		this.cyclomaticComplexity = cyclomaticComplexity;
	}

	public int getFileAddedLines() {
		return fileAddedLines;
	}

	public void setFileAddedLines(int fileAddedLines) {
		this.fileAddedLines = fileAddedLines;
	}

	public int getFileDeletedLines() {
		return fileDeletedLines;
	}

	public void setFileDeletedLines(int fileDeletedLines) {
		this.fileDeletedLines = fileDeletedLines;
	}

	public int getFileModifiedLines() {
		return fileModifiedLines;
	}

	public void setFileModifiedLines(int fileModifiedLines) {
		this.fileModifiedLines = fileModifiedLines;
	}

	public int getFileGrowthLines() {
		return fileGrowthLines;
	}

	public void setFileGrowthLines(int fileGrowthLines) {
		this.fileGrowthLines = fileGrowthLines;
	}

	public int getFileTotalModifiedLines() {
		return fileTotalModifiedLines;
	}

	public void setFileTotalModifiedLines(int fileTotalModifiedLines) {
		this.fileTotalModifiedLines = fileTotalModifiedLines;
	}

	public double getFilePercentModifiedLines() {
		return Double.valueOf(formatter.format(filePercentModifiedLines));
	}

	public void setFilePercentModifiedLines(double filePercentModifiedLines) {
		this.filePercentModifiedLines = filePercentModifiedLines;
	}

	public int getPackageAddedLines() {
		return packageAddedLines;
	}

	public void setPackageAddedLines(int packageAddedLines) {
		this.packageAddedLines = packageAddedLines;
	}

	public int getPackageDeletedLines() {
		return packageDeletedLines;
	}

	public void setPackageDeletedLines(int packageDeletedLines) {
		this.packageDeletedLines = packageDeletedLines;
	}

	public int getPackageModifiedLines() {
		return packageModifiedLines;
	}

	public void setPackageModifiedLines(int packageModifiedLines) {
		this.packageModifiedLines = packageModifiedLines;
	}

	public int getPackageGrowthLines() {
		return packageGrowthLines;
	}

	public void setPackageGrowthLines(int packageGrowthLines) {
		this.packageGrowthLines = packageGrowthLines;
	}

	public int getPackageTotalModifiedLines() {
		return packageTotalModifiedLines;
	}

	public void setPackageTotalModifiedLines(int packageTotalModifiedLines) {
		this.packageTotalModifiedLines = packageTotalModifiedLines;
	}

	public double getPackagePercentModifiedLines() {
		return Double.valueOf(formatter.format(packagePercentModifiedLines));
	}

	public void setPackagePercentModifiedLines(double packagePercentModifiedLines) {
		this.packagePercentModifiedLines = packagePercentModifiedLines;
	}

	public int getProjectAddedLines() {
		return projectAddedLines;
	}

	public void setProjectAddedLines(int projectAddedLines) {
		this.projectAddedLines = projectAddedLines;
	}

	public int getProjectDeletedLines() {
		return projectDeletedLines;
	}

	public void setProjectDeletedLines(int projectDeletedLines) {
		this.projectDeletedLines = projectDeletedLines;
	}

	public int getProjectModifiedLines() {
		return projectModifiedLines;
	}

	public void setProjectModifiedLines(int projectModifiedLines) {
		this.projectModifiedLines = projectModifiedLines;
	}

	public int getProjectGrowthLines() {
		return projectGrowthLines;
	}

	public void setProjectGrowthLines(int projectGrowthLines) {
		this.projectGrowthLines = projectGrowthLines;
	}

	public int getProjectTotalModifiedLines() {
		return projectTotalModifiedLines;
	}

	public void setProjectTotalModifiedLines(int projectTotalModifiedLines) {
		this.projectTotalModifiedLines = projectTotalModifiedLines;
	}

	public double getProjectPercentModifiedLines() {
		return Double.valueOf(formatter.format(projectPercentModifiedLines));
	}

	public void setProjectPercentModifiedLines(double projectPercentModifiedLines) {
		this.projectPercentModifiedLines = projectPercentModifiedLines;
	}

	public int getNumAlertModifications() {
		return numAlertModifications;
	}

	public void setNumAlertModifications(int numAlertModifications) {
		this.numAlertModifications = numAlertModifications;
	}

	public int getDepthOfInheritanceTree() {
		return depthOfInheritanceTree;
	}

	public void setDepthOfInheritanceTree(int depthOfInheritanceTree) {
		this.depthOfInheritanceTree = depthOfInheritanceTree;
	}

	public int getNumAttributes() {
		return numAttributes;
	}

	public void setNumAttributes(int numAttributes) {
		this.numAttributes = numAttributes;
	}

	public int getNumParameters() {
		return numParameters;
	}

	public void setNumParameters(int numParameters) {
		this.numParameters = numParameters;
	}

	public String getOnlyMethodName() {
		int paren = methodName.indexOf("(");
		if (paren == -1) {
			return methodName;
		}
		int spaceBeforeMethodName = methodName.lastIndexOf(" ", paren);
		return methodName.substring(spaceBeforeMethodName+1, paren);
	}
	
	public int getMethodSize() {
		return methodSize;
	}

	public void setMethodSize(int methodSize) {
		this.methodSize = methodSize;
	}
	
	public String makeMetricsKeyMethod(String type) {
		StringBuffer key = new StringBuffer();
		if (type.equals("package") || type.equals("file") || type.equals("method")) {
			if (projectName.equals("paireval")) {
				key.append(getPackageName().replaceAll("/", ".").substring(4));
			} else {
				key.append(getPackageName().replaceAll("/", "."));
			}
			if (key.length()> 0 && key.toString().endsWith(".")) {
				key.deleteCharAt(key.length()-1);
			}
			if (type.equals("file") || type.equals("method")) {
				
				if (fileName.contains(".")) {
					if (fileName.contains("$")) {
						//don't append anything b/c the inner class info isn't available
					} else {
						key.append(".");
						key.append(getFileName().substring(0, getFileName().indexOf(".")));
					}
				} 
				if (type.equals("method") && methodName.length() > 0) {
					key.append(".");
					if (markerType.equals("cnc")) {
						key.append(getMethodName().substring(0, getMethodName().indexOf("(")));
					} else {
						key.append(getMethodName());
					}
				}
			}
		}
//		key.append("_");
//		key.append(getVersion());
		return key.toString();
	}
	
	public String makeChurnKey() {
		StringBuffer key = new StringBuffer();
		if (projectName.equals("importscrubbers")) {
			key.append("importscrubber-");
			key.append(version);
			key.append("/");
		} else {
			key.append(projectName);
		}
		key.append(packageName);
		key.append("/");
		key.append(fileName);
		key.append("-");
		key.append(revision);
		key.append("-");
		key.append(revision);
		return key.toString();
	}
	
	public String makeDeletedChurnKey() {
		StringBuffer key = new StringBuffer();
		if (projectName.equals("importscrubbers")) {
			key.append("importscrubber-");
			key.append(version);
			key.append("/");
		} else {
			key.append(projectName);
		}
		key.append(packageName);
		key.append("/");
		key.append(fileName);
		key.append("-");
		key.append(revision);
		key.append("-");
		key.append(revision+1);
		return key.toString();
	}

	public int getRevision() {
		return revision;
	}

	public void setRevision(int revision) {
		this.revision = revision;
	}

	public int getFileDeletionRevision() {
		return fileDeletionRevision;
	}

	public void setFileDeletionRevision(int fileDeletionRevision) {
		this.fileDeletionRevision = fileDeletionRevision;
	}
	
	public boolean equals(Object o) {
		boolean isEqual = false;
		if (o != null && o instanceof Alert) {
			Alert f = (Alert) o;
			
			if (f.getProjectName().equals(getProjectName())
					&& f.getPackageName().equals(getPackageName())
					&& f.getFileName().equals(getFileName())
					&& f.getMethodName().equals(getMethodName())
					&& (f.getSourceHash().equals(getSourceHash()) 
							|| f.getLineNumber() == getLineNumber())  //XXX: issue when exact same alert is moved onto the line 
					&& f.getBugType().equals(getBugType())
					&& f.getMarkerType().equals(getMarkerType())) {

					isEqual = true;
			}
		}
		return isEqual;
	}

	public int getTotalOpenAlertsForRevision() {
		return totalOpenAlertsForRevision;
	}

	public void setTotalOpenAlertsForRevision(int totalOpenAlertsForRevision) {
		this.totalOpenAlertsForRevision = totalOpenAlertsForRevision;
	}
	
	public int getNumberOfFunctionsInFile() {
		return numberOfFunctionsInFile;
	}

	public void setNumberOfFunctionsInFile(int numberOfFunctionsInFile) {
		this.numberOfFunctionsInFile = numberOfFunctionsInFile;
	}

	public int getNumberOfClassesInFile() {
		return numberOfClassesInFile;
	}

	public void setNumberOfClassesInFile(int numberOfClassesInFile) {
		this.numberOfClassesInFile = numberOfClassesInFile;
	}

	public int getNumberOfFunctionsInPackage() {
		return numberOfFunctionsInPackage;
	}

	public void setNumberOfFunctionsInPackage(int numberOfFunctionsInPackage) {
		this.numberOfFunctionsInPackage = numberOfFunctionsInPackage;
	}

	public int getNumberOfClassesInPackage() {
		return numberOfClassesInPackage;
	}

	public void setNumberOfClassesInPackage(int numberOfClassesInPackage) {
		this.numberOfClassesInPackage = numberOfClassesInPackage;
	}

	public int getPackageSize() {
		return packageSize;
	}

	public void setPackageSize(int packageSize) {
		this.packageSize = packageSize;
	}

	/** 
	 * We're generating alert data from the assumption that we're using alert
	 * data from the first n-1 revisions to predict the alerts in the nth revision.
	 * Therefore, stalenss, etc will be counted from the maximum revision.
	 */
	public void generateAlertData() {
		//General
		generateFileExtension();
		generateAlertCategory();
		generateAlertPriority();
		
		//Metrics
		generateMethodSize();
		generateFileSize();
		generatePackageSize();
		generateCyclomaticComplexity();
		generateNumberOfFunctionsInFile();
		generateNumberOfFunctionsInPackage();
		generateNumberOfClassesInFile();
		generateNumberOfClassesInPackage();
		
		//History
		generateDevelopers();
		generateDeveloper();
		generateFileCreationRevision();
		generateFileDeletionRevision();
		generateLatestFileModification();
		generateLatestPackageModification();
		generateLatestProjectModification();
		generateOpenRevisionType();
		generateCloseRevisionType();
		
		//Churn
		generateFileAddedLines();
		generateFileDeletedLines();
		generateFileModifiedLines();
		generateFileGrowthLines();
		generateFileTotalModifiedLines();
		generateFilePercentModifiedLines();
		generatePackageAddedLines();
		generatePackageDeletedLines();
		generatePackageModifiedLines();
		generatePackageGrowthLines();
		generatePackageTotalModifiedLines();
		generatePackagePercentModifiedLines();
		generateProjectAddedLines();
		generateProjectDeletedLines();
		generateProjectModifiedLines();
		generateProjectGrowthLines();
		generateProjectTotalModifiedLines();
		generateProjectPercentModifiedLines();
		
		//Aggregate
		generateTotalAlertsForRevision();
		generateTotalOpenAlertsForRevision();
		generateAlertLifetime();
		generateFileAge();
		generateAlertsInMethod();
		generateAlertsInFile();
		generateAlertsInPackage();
		generateAlertsInProject();
		generateFileStaleness();
		generatePackageStaleness();
		generateProjectStaleness();
		generateAlertsInProject();
	}
	
	protected void generateNumParameters() {
//		this.numParameters = MetricsDB.getValueForHandleVersionMetric(DBConnection.getInstance(false).getConnection(), makeMetricsKeyMethod("method"), version, "PAR");
		this.numParameters = -1;
	}
	
	protected void generateNumAttributes() {
//		this.numAttributes = MetricsDB.getValueForHandleVersionMetric(DBConnection.getInstance(false).getConnection(), makeMetricsKeyMethod("file"), version, "NOF");
		this.numAttributes = -1;
	}
	
	protected void generateDepthOfInheritanceTree() {
//		this.depthOfInheritanceTree = MetricsDB.getValueForHandleVersionMetric(DBConnection.getInstance(false).getConnection(), makeMetricsKeyMethod("file"), version, "DIT");
		this.depthOfInheritanceTree = -1;
	}
		
	protected void generateProjectPercentModifiedLines() {
	 	if (repository.equals("cvs")) {
	 		if (this.projectTotalModifiedLines > 0 ) {
	 			this.projectPercentModifiedLines = this.projectTotalModifiedLines / HistoryDB.getAllChurnedLines(DBConnection.getInstance(false).getConnection(), projectName, revision);
	 		} else {
	 			this.projectPercentModifiedLines = 0;
	 		}
		} else if (repository.equals("svn")) {
			if (projectTotalModifiedLines > 0) {
//				System.out.println(this.projectTotalModifiedLines);
				this.projectPercentModifiedLines = this.projectTotalModifiedLines / HistoryDB.getAllChurnedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, revision);
//				System.out.println(this.projectPercentModifiedLines);
			} else {
				this.projectPercentModifiedLines = 0;
			}
		}
	 	this.projectPercentModifiedLines = this.projectPercentModifiedLines * 100;
	}
	
	protected void generateProjectTotalModifiedLines() {
		this.projectTotalModifiedLines = this.projectAddedLines + this.projectDeletedLines + this.projectModifiedLines;
	}
	
	protected void generateProjectGrowthLines() {
		this.projectGrowthLines = this.projectAddedLines - this.projectDeletedLines;
	}
	
	protected void generateProjectModifiedLines() {
		//Just for importscrubbers
		this.projectModifiedLines = 0;
	}
	
	protected void generateProjectDeletedLines() {
		if (repository.equals("cvs")) {
			this.projectDeletedLines = HistoryDB.getDeletedLines(DBConnection.getInstance(false).getConnection(), projectName, "", revision);
		} else if (repository.equals("svn")) {
			this.projectDeletedLines = HistoryDB.getDeletedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, "", revision);
		}
	}
	
	protected void generateProjectAddedLines() {
		if (repository.equals("cvs")) {
			this.projectAddedLines = HistoryDB.getAddedLines(DBConnection.getInstance(false).getConnection(), projectName, "", revision);
		} else if (repository.equals("svn")) {
			this.projectAddedLines = HistoryDB.getAddedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, "", revision);
		}
	}
	
	protected void generatePackagePercentModifiedLines() {
		if (repository.equals("cvs")) {
			if (this.packageTotalModifiedLines > 0 ) {
			this.packagePercentModifiedLines = this.packageTotalModifiedLines / HistoryDB.getAllChurnedLines(DBConnection.getInstance(false).getConnection(), projectName, revision);
			} else {
				this.packagePercentModifiedLines = 0;
			}
		} else if (repository.equals("svn")) {
			if (this.packageTotalModifiedLines > 0 ) {
				this.packagePercentModifiedLines = this.packageTotalModifiedLines / HistoryDB.getAllChurnedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, revision);
			} else {
				this.packagePercentModifiedLines = 0;
			}
		}
		this.packagePercentModifiedLines = this.packagePercentModifiedLines * 100;
	}
	
	protected void generatePackageTotalModifiedLines() {
		this.packageTotalModifiedLines = this.packageAddedLines + this.packageDeletedLines + this.packageModifiedLines;
	}
	
	protected void generatePackageGrowthLines() {
		this.packageGrowthLines = this.packageAddedLines - this.packageDeletedLines;
	}
	
	protected void generatePackageModifiedLines() {
		this.packageModifiedLines = 0;
	}
	
	protected void generatePackageDeletedLines() {
		if (repository.equals("cvs")) {
			this.packageDeletedLines = HistoryDB.getDeletedLines(DBConnection.getInstance(false).getConnection(), projectName , packageName + "%", revision);
		} else if (repository.equals("svn")) {
			this.packageDeletedLines = HistoryDB.getDeletedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, packageName + "%", revision);
		}
	}
	
	/**
	 * Top level packages also contain the added/deleted lines of the 
	 * subpackages.  The relationship is inclusive, not distinct.
	 */
	protected void generatePackageAddedLines() {
		if (repository.equals("cvs")) {
			this.packageAddedLines = HistoryDB.getAddedLines(DBConnection.getInstance(false).getConnection(), projectName, packageName + "%", revision);
		} else if (repository.equals("svn")) {
			this.packageAddedLines = HistoryDB.getAddedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, packageName + "%", revision);
		}
	}
	
	/**
	 * From RAF08 paper, this metric considers the percentage of churned lines.  
	 * From there, I speculate that this means the percentage of churned lines
	 * out of all lines churned during the revisions before the openRevision.
	 */
	protected void generateFilePercentModifiedLines() {
		if (repository.equals("cvs")) {
			if (this.fileTotalModifiedLines > 0) {
				this.filePercentModifiedLines = this.fileTotalModifiedLines / HistoryDB.getAllChurnedLines(DBConnection.getInstance(false).getConnection(), projectName, revision);
			} else {
				this.filePercentModifiedLines = 0;
			}
		} else if (repository.equals("svn")) {
			if (this.fileTotalModifiedLines > 0) {
//				System.out.println(this.fileTotalModifiedLines);
//				System.out.println(this.bugType + " " + this.openReision + " " + this.fileName);
				this.filePercentModifiedLines = this.fileTotalModifiedLines / HistoryDB.getAllChurnedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, revision);
//				System.out.println(filePercentModifiedLines);
			} else {
				this.filePercentModifiedLines = 0;
			}
		}
		this.filePercentModifiedLines = this.filePercentModifiedLines * 100;
	}
	
	protected void generateFileTotalModifiedLines() {
		this.fileTotalModifiedLines = this.fileAddedLines + this.fileDeletedLines + this.fileModifiedLines;
	}
	
	protected void generateFileGrowthLines() {
		this.fileGrowthLines = this.fileAddedLines - this.fileDeletedLines;
	}
	
	protected void generateFileModifiedLines() {
		this.fileModifiedLines = 0;
	}
	
	protected void generateFileDeletedLines() {
		if (repository.equals("cvs")) {
			this.fileDeletedLines = HistoryDB.getDeletedLines(DBConnection.getInstance(false).getConnection(), projectName , packageName + fileName, revision);
		} else if (repository.equals("svn")) {
			this.fileDeletedLines = HistoryDB.getDeletedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName , packageName + fileName, revision);
		}
	}
	
	/**
	 * From RAF08 paper, the file added lines are the sum of the number of lines added 
	 * to the file in the three months prior to when the alert was opened.  For now,
	 * we'll stick to all added lines prior to the openRevision for the alert.
	 * 
	 * XXX: Revision for JDOM that will need to be done for importscrubbers.
	 * - Define churn as the changes made between the previous version and current version that caused
	 *   an alert to open or close.  Since we're really only interested in predicting which alerts close
	 *   we will actually only look at the churn that caused an alert to open.
	 * @param currentRevision
	 */
	protected void generateFileAddedLines() {
		if (repository.equals("cvs")) {
			this.fileAddedLines = HistoryDB.getAddedLines(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName, revision);
		} else if (repository.equals("svn")) {
			this.fileAddedLines = HistoryDB.getAddedLinesSVN(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName, revision);
		}
	}
	
	protected void generateCyclomaticComplexity() {
		this.cyclomaticComplexity = MetricsDB.getMetricsFunction(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("method")).getCcn();
	}
	
	protected void generateAlertDepthInFile() {
//		this.alertDepthInFile = lineNumber / fileSize;
		this.alertDepthInFile = -1;
	}
	
	protected void generateFileSize() {
		this.fileSize = MetricsDB.getMetricsObject(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("file")).getNcss();
	}
	
	/**
	 * Sets the number of LOC of the method.
	 */
	protected void generateMethodSize() {
//		System.out.println("Metrics Key" + makeMetricsKeyMethod("method"));
		this.methodSize = MetricsDB.getMetricsFunction(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("method")).getNcss();
//		System.out.println(methodSize);
	}
	
	/**
	 * Returns the number of alerts in the project: open, closed, all revisions.
	 */
	protected void generateAlertsInProject() {
		this.alertsInProject = AlertDB.getAlertsInProject(DBConnection.getInstance(false).getConnection(), projectName);
	}
	
	/**
	 * Not currently implemented because this will be the same for all projects
	 * and the churn data isn't set up to handle finding things on project names properly.
	 */
	protected void generateLatestProjectModification() {
		
		if (repository.equals("cvs")) {
			this.latestProjectModficiationRevision = HistoryDB.getLatestFileModificationRevision(DBConnection.getInstance(false).getConnection(), projectName, "", revision);
		} else if (repository.equals("svn")) {
			this.latestProjectModficiationRevision = HistoryDB.getLatestFileModificationRevisionSVN(DBConnection.getInstance(false).getConnection(), projectName, "", revision);
		}
	}
	
	/**
	 * Returns the difference between the max revision and the latest project 
	 * revision to determine how many revision since the last revision to 
	 * a file in the package.
	 */
	protected void generateProjectStaleness() {
		if (repository.equals("cvs")) {
			this.projectStaleness = HistoryDB.getMaxCommit(DBConnection.getInstance(false).getConnection(), projectName) 
				- latestProjectModficiationRevision;
		} else if (repository.equals("svn")) {
			this.projectStaleness = HistoryDB.getMaxCommitSVN(DBConnection.getInstance(false).getConnection(), projectName) 
				- latestProjectModficiationRevision;
		}
	}
	
	/**
	 * Returns the difference between the max revision and the latest package 
	 * revision to determine how many revision since the last revision to 
	 * a file in the package.
	 */
	protected void generatePackageStaleness() {
		if (repository.equals("cvs")) {
			this.packageStaleness = HistoryDB.getMaxCommit(DBConnection.getInstance(false).getConnection(), projectName) 
				- latestPackageModificationRevision;
		} else if (repository.equals("svn")) {
			this.packageStaleness = HistoryDB.getMaxCommitSVN(DBConnection.getInstance(false).getConnection(), projectName) 
			- latestPackageModificationRevision;
		}
	}
	/**
	 * Returns the revision of the latest package modification. This can be when
	 * *any* file in the package was last modified.  Eventually, the churn will only
	 * contain .java files, therefore, the package modification will only be on java 
	 * files.
	 */
	protected void generateLatestPackageModification() {
		
		if (repository.equals("cvs")) {
			this.latestPackageModificationRevision = HistoryDB.getLatestFileModificationRevision(DBConnection.getInstance(false).getConnection(), projectName, packageName + "%", revision);
		} else if (repository.equals("svn")) {
			this.latestPackageModificationRevision = HistoryDB.getLatestFileModificationRevisionSVN(DBConnection.getInstance(false).getConnection(), projectName, packageName + "%", revision);
		}
	}
	
	/**
	 * Returns the difference between the max file revision and the latest
	 * file revision to determine how many revisions since the last 
	 * revision to the file
	 */
	protected void generateFileStaleness() {
		if (repository.equals("cvs")) {
			this.fileStaleness = HistoryDB.getMaxCommit(DBConnection.getInstance(false).getConnection(), projectName) 
				- latestFileModficationRevision;
		} else if (repository.equals("svn")) {
			this.fileStaleness = HistoryDB.getMaxCommitSVN(DBConnection.getInstance(false).getConnection(), projectName) 
				- latestFileModficationRevision;
		}
//		System.out.println(latestFileModficationRevision);
	}
		
	/**
	 * Returns the revision of the latest file modification.  This can be when
	 * the file was last modified or when the file is closed.  It's a simple db
	 * check on the max endVersion
	 */
	protected void generateLatestFileModification() {
		if (repository.equals("cvs")) {
			this.latestFileModficationRevision = HistoryDB.getLatestFileModificationRevision(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName, revision);
		} else if (repository.equals("svn")) {
			this.latestFileModficationRevision = HistoryDB.getLatestFileModificationRevisionSVN(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName, revision);
		}
	}
	
	/**
	 * The alerts in the file at the latest revision.  Maybe should be the 
	 * n-1 revision for the model building set of alerts and n for the test set, 
	 * but for now I'm going to have the alerts for n and use those not in the 
	 * nth revision for modelbuilding... therefore everything that's closed.
	 */
	protected void generateAlertsInFile() {
		this.alertsInFile = AlertDB.getAlertsForFile(DBConnection.getInstance(false).getConnection(), projectName, packageName, fileName);
	}
	
	/**
	 * The alerts in the method at the latest revision.  Maybe should be the 
	 * n-1 revision for the model building set of alerts and n for the test set, 
	 * but for now I'm going to have the alerts for n and use those not in the 
	 * nth revision for modelbuilding... therefore everything that's closed.
	 */
	protected void generateAlertsInMethod() {
		this.alertsInMethod = AlertDB.getAlertsForMethod(DBConnection.getInstance(false).getConnection(), projectName, packageName, fileName, methodName);
	}
	
	/**
	 * The alerts in the package at the latest revision.  Maybe should be the 
	 * n-1 revision for the model building set of alerts and n for the test set, 
	 * but for now I'm going to have the alerts for n and use those not in the 
	 * nth revision for modelbuilding... therefore everything that's closed.
	 */
	protected void generateAlertsInPackage() {
		this.alertsInPackage = AlertDB.getAlertsForPackage(DBConnection.getInstance(false).getConnection(), projectName, packageName);
	}
	
	/**
	 * Returns the file extension including the .
	 */
	protected void generateFileExtension() {
		if (fileName.contains(".")) {
			this.fileExtension = fileName.substring(fileName.indexOf("."));
		} else {
			this.fileExtension = "";
		}
	}
	
	protected void generateFileAge() {
		if (fileDeletionRevision != -1) {
			this.fileAge = fileDeletionRevision - fileCreationRevision;
		} else {
			if (repository.equals("cvs")) {
				this.fileAge = HistoryDB.getMaxCommit(DBConnection.getInstance(false).getConnection(), projectName)
					- fileCreationRevision;
			} else if (repository.equals("svn")) {
				this.fileAge = HistoryDB.getMaxCommitSVN(DBConnection.getInstance(false).getConnection(), projectName)
					- fileCreationRevision;
			}
		}
	}
	/**
	 * Returns the revision when a file is deleted.  This is identified by a file where
	 * the state of the cvs revision is 'dead'.
	 * Really should only happen if the alert is closed, and is used to determine if the 
	 * alert is really associated with a fix or just the side effect of a larger change.
	 */
	protected void generateFileDeletionRevision() {
		if (repository.equals("cvs")) {
			this.fileDeletionRevision = HistoryDB.getFileDeletionRevision(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName);
		} else if (repository.equals("svn")) {
			this.fileDeletionRevision = HistoryDB.getFileDeletionRevisionSVN(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName);
		}
	}
	/**
	 * Returns the revision when the file was created.  This is identified by a file
	 * at cvs revision 1.1
	 * 
	 */
	protected void generateFileCreationRevision() {
		if (repository.equals("cvs")) {
			this.fileCreationRevision = HistoryDB.getFileCreationRevision(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName);
		} else if (repository.equals("svn")) {
			this.fileCreationRevision = HistoryDB.getFileCreationRevisionSVN(DBConnection.getInstance(false).getConnection(), projectName, packageName + fileName);
		}
	}
	
	/**
	 * Alert priority if the first character in the alert description.  
	 * The alert priority is different from the alert's severity (which is almost 
	 * always one in the Eclipse workbench).
	 */
	protected void generateAlertPriority() {
		if (projectName.equals("paireval")) {
			this.priority = description.substring(0,1);
		}
		
	}
	
	/**
	 * Alert category is the second non-whitespace character in the alert description.
	 * This character is offset by the first and second space characters
	 */
	protected void generateAlertCategory() {
		if (projectName.equals("paireval")) {
			this.alertCategory = description.substring(2,3);
		}
	}
	
	/**
	 * Alert lifetime is measured in the number of revisions between
	 * when an alert is opened and closed.  Otherwise, the alert lifetime 
	 * is the difference between the final revision and the open revision.
	 * For this analysis, the final revision can be the max open revision
	 * in the database (after a check to ensure there was at least one new 
	 * alert in the last revision).  
	 */
	protected void generateAlertLifetime() {
		if (closeRevision != -1) {
			this.alertLifetime = closeRevision - openRevision;
		} else {
			if (repository.equals("cvs")) {
				this.alertLifetime = HistoryDB.getMaxCommit(DBConnection.getInstance(false).getConnection(), projectName)
					- openRevision;
			} else if (repository.equals("svn")) {
				this.alertLifetime = HistoryDB.getMaxCommitSVN(DBConnection.getInstance(false).getConnection(), projectName)
					- openRevision;
			}
//			this.alertLifetime = 5000 - openRevision;
		}
	}
	
	/**
	 * The number of open alerts for the revision after all revisions have 
	 * been analyzed.  Therefore, an open alert for a revision is still open
	 * in the nth revision.
	 */
	protected void generateTotalOpenAlertsForRevision() {
		this.totalOpenAlertsForRevision = AlertDB.getTotalOpenAlertsForRevision(DBConnection.getInstance(false).getConnection(), projectName, openRevision);
	}
	
	/**
	 * The number of alerts (opened and closed) for the revision.
	 */
	protected void generateTotalAlertsForRevision() {
		this.totalAlertsForRevision = AlertDB.getTotalAlertsForRevision(DBConnection.getInstance(false).getConnection(), projectName, openRevision);
	}
	
	/**
	 * The type of revision that closed the alert.  Therefore,
	 * open alerts will not a have a revision type.
	 */
	protected void generateCloseRevisionType() {
		if (closeRevision != -1) {
			//Currently returns an empty string b/c need to aggregate the revision type over
			//all revisions between current and previous
			if (repository.equals("cvs")) {
				this.closeRevisionType = HistoryDB.getCommitType(DBConnection.getInstance(false).getConnection(), projectName, closeRevision);
			} else if (repository.equals("svn")) {
				this.closeRevisionType = HistoryDB.getCommitTypeSVN(DBConnection.getInstance(false).getConnection(), projectName, closeRevision);
			}
		} else {
			this.closeRevisionType = "";
		}
	}
	
	/**
	 * The type of revision that opened the alert.  
	 */
	protected void generateOpenRevisionType() {
		//Currently returns an empty string b/c need to aggregate the revision type over
		//all revisions between current and previous
		if (repository.equals("cvs")) {
			this.openRevisionType = HistoryDB.getCommitType(DBConnection.getInstance(false).getConnection(), projectName, openRevision);
		} else if (repository.equals("svn")) {
			this.openRevisionType = HistoryDB.getCommitTypeSVN(DBConnection.getInstance(false).getConnection(), projectName, openRevision);
		}
	}
	
	/**
	 * A comma seperated list of developers who made changes on the file
	 * between the current revision and the last passing revision that 
	 * could have caused the alert to be created.
	 * 
	 * With jdom, it is possible to have no developers make changes to a file
	 * if the file was generated during the build process.  For example see:
	 * 0226 jdom-contrib org/jdom/contrib/xpath/parser/ XPathLexer.java.  The file 
	 * was probably generated from xpath_lexer.g, but we can't know for sure.
	 * 
	 * @pre call generateDevelopers() first
	 */
	protected void generateDeveloper() {
		this.developer = "";
		for (int i = 0; i < this.developers.size(); i++) {
			developer += this.developers.get(i) + ",";
		}
		if (this.developer.length() > 0) {
			this.developer = this.developer.substring(0, this.developer.length()-1);
		}
	}
	
	/**
	 * The list of developers who made changes on the file between the current
	 * revision and the last passing revision that could have caused
	 * the alert to be created.
	 */
	protected void generateDevelopers() {
		if (repository.equals("cvs")) {
			this.developers = HistoryDB.getDevelopersForFileInRevision(DBConnection.getInstance(false).getConnection(), revision, projectName, packageName + fileName);
		} else if (repository.equals("svn")) {
			this.developers = HistoryDB.getDevelopersForFileInRevisionSVN(DBConnection.getInstance(false).getConnection(), revision, projectName, packageName + fileName);
		}
	}

	/**
	 * The revision number for the alert is the revision the alert is opened
	 * in.  Therefore, the openRevision is the better metric to use
	 * but this attribute remains for legacy reasons.
	 */
	protected void generateRevision() {
		this.revision = openRevision;
	}

	public String getCloseRevisionType() {
		return closeRevisionType;
	}

	public void setCloseRevisionType(String closeRevisionType) {
		this.closeRevisionType = closeRevisionType;
	}

	public String getOpenRevisionType() {
		return openRevisionType;
	}

	public void setOpenRevisionType(String openRevisionType) {
		this.openRevisionType = openRevisionType;
	}

	public void isModified(Alert a) {
		if (this.equals(a)) {
			if (a.getSourceHash().equals(getSourceHash()) 
					&& a.getLineNumber() == getLineNumber()) {
				if (!a.getPriority().equals(getPriority())) {
					numAlertModifications++;
				}
			} else {
				numAlertModifications++;
			}
		}
	}

	public void generatePackageSize() {
		this.packageSize = MetricsDB.getMetricsPackage(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("package")).getNcss();
	}

	public void generateNumberOfFunctionsInFile() {
		this.numberOfFunctionsInFile = MetricsDB.getMetricsObject(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("file")).getFunctions();
	}

	public void generateNumberOfClassesInFile() {
		this.numberOfClassesInFile = MetricsDB.getMetricsObject(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("file")).getClasses();
	}

	public void generateNumberOfClassesInPackage() {
		this.numberOfClassesInPackage = MetricsDB.getMetricsPackage(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("package")).getClasses();
	}
	public void generateNumberOfFunctionsInPackage() {
		this.numberOfFunctionsInPackage = MetricsDB.getMetricsPackage(DBConnection.getInstance(false).getConnection(), projectName, version, makeMetricsKeyMethod("package")).getFunctions();
	}

	public int getAlertsInMethod() {
		return alertsInMethod;
	}

	public void setAlertsInMethod(int alertsInMethod) {
		this.alertsInMethod = alertsInMethod;
	}

	public int getAlertsInPackage() {
		return alertsInPackage;
	}

	public void setAlertsInPackage(int alertsInPackage) {
		this.alertsInPackage = alertsInPackage;
	}

	public String getRepository() {
		return repository;
	}

	public void setRepository(String repository) {
		this.repository = repository;
	}

}
