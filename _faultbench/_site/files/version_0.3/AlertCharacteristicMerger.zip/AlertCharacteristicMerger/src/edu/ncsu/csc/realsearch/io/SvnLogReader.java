package edu.ncsu.csc.realsearch.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

import edu.ncsu.csc.realsearch.data.SvnChangeRecord;

public class SvnLogReader {
	
	public static void main(String [] args) {
		Vector<SvnChangeRecord> changeRecords = parseFile("C:/Documents and Settings/Sarah Smith/My Documents/Research/Experiments/ExperimentalSubjects/Columba/ChangeHistory/columba_trunk_log_verbose.txt");
		for(int i = 0; i < changeRecords.size(); i++) {
//			System.out.println(changeRecords.get(i).toString());
		}
	}

	public static Vector<SvnChangeRecord> parseFile(String fileName) {
		Vector<SvnChangeRecord> changeRecords = new Vector<SvnChangeRecord>();
		
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String line = in.readLine();
			while (line != null) {
				while (line.startsWith("------")) {
					SvnChangeRecord changeRecord = new SvnChangeRecord();
					//get record line
					line = in.readLine();
					if(line == null) {
						//at end
						return changeRecords;
					}
					String [] contents = line.split(" \\| ");
					changeRecord.setRevision(contents[0]);
					changeRecord.setUser(contents[1]);
					changeRecord.setDate(contents[2]);
					changeRecord.setLinesChanged(contents[3]);
					
					line = in.readLine();
					
					if(line.equals("Changed paths:")) {
						line = in.readLine();
						while (line.length() != 0) {
							line = line.trim();
							String [] pathInfo = line.split(" ");
							changeRecord.addPathChange(pathInfo[0]);
							changeRecord.addPath(pathInfo[1]);
							line = in.readLine();
						}
					}
					
					line = in.readLine();
					changeRecord.setDescription(line);
					changeRecords.add(changeRecord);
				}
				line = in.readLine();
			}
		} catch (IOException e) {
			
		}
		
		return changeRecords;
	}

}
