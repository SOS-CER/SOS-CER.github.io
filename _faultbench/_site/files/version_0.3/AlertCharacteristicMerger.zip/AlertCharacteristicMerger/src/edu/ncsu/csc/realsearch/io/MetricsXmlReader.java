package edu.ncsu.csc.realsearch.io;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import edu.ncsu.csc.realsearch.data.Metric;
import edu.ncsu.csc.realsearch.data.MetricsHash;
import edu.ncsu.csc.realsearch.data.MetricsGroup;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.MetricsDB;

public class MetricsXmlReader extends DefaultHandler {
	
	private SAXParserFactory factory;
	private SAXParser parser;
	private String version;
	private String key;
	
	public MetricsXmlReader() {
		super();
	}
	
	private void makeParser() {
		try {
			factory = SAXParserFactory.newInstance();
			factory.setNamespaceAware(true);
			parser = factory.newSAXParser();
		} catch (FactoryConfigurationError e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} finally {
			
		}
	}
	
	public void parseFile(String file, String version) {
		makeParser();
		try {
			this.version = version;
			parser.parse(file, this);
			
			Hashtable<String, MetricsGroup> hash = MetricsHash.getInstance().getHashtable();
			Set<Entry<String, MetricsGroup>> entrySet = hash.entrySet();
			Iterator<Entry<String, MetricsGroup>> i = entrySet.iterator();
			MetricsDB db = new MetricsDB();
			while (i.hasNext()) {
				Map.Entry<String, MetricsGroup> entry = (Map.Entry<String, MetricsGroup>) i.next();
				db.writeToDatabase(DBConnection.getInstance(false).getConnection(), entry.getValue());
			}
		} catch (SAXException e) {
//			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
//			e.printStackTrace();
		}
	}
	
	public void startDocument() throws SAXException {
		
	}
	
	public void endDocument() throws SAXException {
		
	}
	
	public void startElement(String namespaceURI, String lName, String qName, Attributes attrs) throws SAXException {
		if (lName.equals("MetricDescription")) { // flag = 0
			//skip
		} else if (lName.equals("Project") || /*lName.equals("PackageRoot") ||*/
				lName.equals("Package") || lName.equals("CompilationUnit") ||
				/*lName.equals("Type") || */ lName.equals("Method")) {
			MetricsGroup value = new MetricsGroup(attrs.getValue("name"), attrs.getValue("handle"), version);
			key = value.getMetricsGroupKey();
			MetricsHash.getInstance().addToHash(key, value);
		} else if (lName.equals("Metrics")) {
			//ignore
		} else if (lName.equals("Metric")) {
			MetricsGroup value = MetricsHash.getInstance().getFromHash(key);
			value.addMetric(attrs.getValue("id"), new Metric(attrs));
		}
	}
	
	public void endElement(String namespaceURI, String sName, String qName) throws SAXException {
		
	}

}
