package edu.ncsu.csc.realsearch.io.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import edu.ncsu.csc.realsearch.data.Metric;
import edu.ncsu.csc.realsearch.data.MetricsFunction;
import edu.ncsu.csc.realsearch.data.MetricsGroup;
import edu.ncsu.csc.realsearch.data.MetricsObject;
import edu.ncsu.csc.realsearch.data.MetricsPackage;
import edu.ncsu.csc.realsearch.util.io.derby.DBConnectionException;
import edu.ncsu.csc.realsearch.util.io.derby.DerbyConnection;

public class MetricsDB {
	
	public boolean writeToDatabase(DerbyConnection conn, MetricsGroup mg) {
		try {
					
			String query = "insert into metrics values(?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, mg.getName());
			stmt.setString(2, mg.getHandle());
			stmt.setString(3, mg.getVersion());
			Set<Entry<String, Metric>> entrySet = mg.getMetrics().entrySet();
			Iterator<Entry<String, Metric>> i = entrySet.iterator();
			while (i.hasNext()) {
				Map.Entry<String, Metric> entry = (Map.Entry<String, Metric>) i.next();
				Metric m = entry.getValue();
				stmt.setString(4, m.getId());
				stmt.setDouble(5, m.getValue());
				stmt.setDouble(6, m.getAvg());
				stmt.setDouble(7, m.getStddev());
				stmt.setInt(8, m.getPoints());
				stmt.setDouble(9, m.getMax());
				stmt.setString(10, m.getPer());
				stmt.setString(11, m.getMaxhandle());
				stmt.executeUpdate();
			}
					
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	public static double getValueForHandleVersionMetric(DerbyConnection conn, String handle, String version,
			String metric) {
		double value = -1;
		try {
			String query = "select value from metrics where handle like ? and version=? and id=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, "%" + handle);
			stmt.setString(2, version);
			stmt.setString(3, metric);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				value = rs.getDouble("value");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return value;
	}

	public static double getAvgForHandleVersionMetric(DerbyConnection conn,
			String handle, String version, String metric) {
		double avg = -1;
		try {
			String query = "select avgValue from metrics where handle=? and version=? and id=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, handle);
			stmt.setString(2, version);
			stmt.setString(3, metric);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				avg = rs.getDouble("avgValue");
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return avg;
	}

	public static void writeNCSSMetricPackage(DerbyConnection conn, MetricsPackage metricsPackage) {
		try {
			
			String query = "insert into metrics_javancss_package values(?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, metricsPackage.getProjectName());
			stmt.setString(2, metricsPackage.getVersion());
			stmt.setString(3, metricsPackage.getName());
			stmt.setInt(4, metricsPackage.getClasses());
			stmt.setInt(5, metricsPackage.getFunctions());
			stmt.setInt(6, metricsPackage.getNcss());
			stmt.setInt(7, metricsPackage.getJavadocs());
			stmt.setInt(8, metricsPackage.getJavadocLines());
			stmt.setInt(9, metricsPackage.getSingleCommentLines());
			stmt.setInt(10, metricsPackage.getMultiCommentLines());
			stmt.executeUpdate();
					
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void writeNCSSMetricObject(DerbyConnection conn, MetricsObject metricsObject) {
		try {
			
			String query = "insert into metrics_javancss_object values(?,?,?,?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, metricsObject.getProjectName());
			stmt.setString(2, metricsObject.getVersion());
			stmt.setString(3, metricsObject.getName());
			stmt.setInt(4, metricsObject.getNcss());
			stmt.setInt(5, metricsObject.getFunctions());
			stmt.setInt(6, metricsObject.getClasses());
			stmt.setInt(7, metricsObject.getJavadocs());
			stmt.executeUpdate();
					
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void writeNCSSMetricFunction(DerbyConnection conn, MetricsFunction metricsFunction) {
		try {
			
			String query = "insert into metrics_javancss_function values(?,?,?,?,?,?)";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, metricsFunction.getProjectName());
			stmt.setString(2, metricsFunction.getVersion());
			stmt.setString(3, metricsFunction.getName());
			stmt.setInt(4, metricsFunction.getNcss());
			stmt.setInt(5, metricsFunction.getCcn());
			stmt.setInt(6, metricsFunction.getJavadocs());
			stmt.executeUpdate();
					
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static MetricsPackage getMetricsPackage(DerbyConnection conn, String projectName, String version, String name) {
		MetricsPackage metricsPackage = new MetricsPackage(projectName, version);
		metricsPackage.setName(name);
		try {
			String query = "select * from metrics_javancss_package where projectName=? and version=? and name=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setString(2, version);
			stmt.setString(3, name);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				metricsPackage.setClasses(rs.getInt("classes"));
				metricsPackage.setFunctions(rs.getInt("functions"));
				metricsPackage.setNcss(rs.getInt("ncss"));
				metricsPackage.setJavadocs(rs.getInt("javadocs"));
				metricsPackage.setJavadocLines(rs.getInt("javadoc_lines"));
				metricsPackage.setSingleCommentLines(rs.getInt("single_comment_lines"));
				metricsPackage.setMultiCommentLines(rs.getInt("multi_comment_lines"));
			} else {
				metricsPackage.setClasses(-1);
				metricsPackage.setFunctions(-1);
				metricsPackage.setNcss(-1);
				metricsPackage.setJavadocs(-1);
				metricsPackage.setJavadocLines(-1);
				metricsPackage.setSingleCommentLines(-1);
				metricsPackage.setMultiCommentLines(-1);
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return metricsPackage;
	}
	
	public static MetricsObject getMetricsObject(DerbyConnection conn, String projectName, String version, String name) {
		MetricsObject metricsObject = new MetricsObject(projectName, version);
		metricsObject.setName(name);
		try {
			String query = "select * from metrics_javancss_object where projectName=? and version=? and name=?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setString(2, version);
			stmt.setString(3, name);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				metricsObject.setNcss(rs.getInt("ncss"));
				metricsObject.setFunctions(rs.getInt("functions"));
				metricsObject.setClasses(rs.getInt("classes"));
				metricsObject.setJavadocs(rs.getInt("javadocs"));
			} else {
				metricsObject.setNcss(-1);
				metricsObject.setFunctions(-1);
				metricsObject.setClasses(-1);
				metricsObject.setJavadocs(-1);
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return metricsObject;
	}
	
	public static MetricsFunction getMetricsFunction(DerbyConnection conn, String projectName, String version, String name) {
		MetricsFunction metricsFunction = new MetricsFunction(projectName, version);
		metricsFunction.setName(name);
		try {
			String query = "select * from metrics_javancss_function where projectName=? and version=? and name like ?";
			PreparedStatement stmt = conn.getStatement(query);
			stmt.setString(1, projectName);
			stmt.setString(2, version);
			stmt.setString(3, name + "%");
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				metricsFunction.setNcss(rs.getInt("ncss"));
				metricsFunction.setCcn(rs.getInt("ccn"));
				metricsFunction.setJavadocs(rs.getInt("javadocs"));
			} else {
				metricsFunction.setNcss(-1);
				metricsFunction.setCcn(-1);
				metricsFunction.setJavadocs(-1);
			}
		} catch (DBConnectionException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return metricsFunction;
	}

}
