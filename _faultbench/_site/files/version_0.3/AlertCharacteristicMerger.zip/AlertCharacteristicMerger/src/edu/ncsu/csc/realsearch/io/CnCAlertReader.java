package edu.ncsu.csc.realsearch.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.main.Constants;

public class CnCAlertReader {
	
	public ArrayList<Alert> parseFile(String file, String version, String project) {
		ArrayList<Alert> alerts = new ArrayList<Alert>();
		boolean alertStarted = false;
		String previousLine = "";
		Alert a = new Alert();
		String fileName = "";
		int count = 0;
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line = in.readLine();
			while (line != null) {
				if (alertStarted && line.startsWith("-----")) {
					alerts.add(a);
					alertStarted = false;
				} else if (alertStarted && line.contains("(aborted)")) {
					alerts.add(a);
					alertStarted = false;
				} else if (!alertStarted && line.startsWith("-----")) {
					a = new Alert();
					alertStarted = true;
					//Add method name to new alert
					//org.jdom.Element: getNamespace(java.lang.String) ...
					int colon = previousLine.indexOf(":");
					int rightPar = previousLine.indexOf(")");
					a.setMethodName(previousLine.substring(colon+1, rightPar+1).trim());
					count ++;
					String currentName = previousLine.substring(0, previousLine.indexOf(":"));
					if (fileName.equals("")) {
						fileName = currentName;
						a.setTestFile(fileName.substring(fileName.lastIndexOf(".") +1, fileName.length()) + "Test" + count + ".java");
					} else if (fileName.equals(currentName)) {
						a.setTestFile(fileName.substring(fileName.lastIndexOf(".") +1, fileName.length()) + "Test" + count + ".java");
					} else {
						fileName = currentName;
						count = 1;
						a.setTestFile(fileName.substring(fileName.lastIndexOf(".") +1, fileName.length()) + "Test" + count + ".java");
					}
				} else if (alertStarted && line.startsWith("org")) {
					//org\jdom\Element.java:308: Warning: Possible type cast error (Cast)
					a.setProjectName(project);
					a.setPackageName(line.substring(0,line.lastIndexOf("\\")+1).replace("\\", "/"));
					a.setFileName(line.substring(line.lastIndexOf("\\") + 1, line.indexOf(":")));
					int colon = line.indexOf(":");
					int colon2 = line.indexOf(":", colon +1);
					a.setLineNumber(Integer.parseInt(line.substring(colon+1, colon2)));
					a.setBugType(line.substring(line.indexOf("(") + 1, line.indexOf(")")));
					a.setDescription(line.substring(line.lastIndexOf(":") + 1, line.indexOf("(")).trim());
					a.setAlertCategory("");
					a.setPriority("");
					if (project.startsWith(Constants.JDOM)) {
						a.setRepository("cvs");
					} else if (project.equals(Constants.LOGGING)) {
						a.setRepository("svn");
					}
					a.setSourceHash("");
					a.setMarkerType("cnc");
				}
				if (line.endsWith("...")) {
					previousLine = line;
				}
				line = in.readLine();
			}
		} catch (IOException e) {
			
		}
		return alerts;
	}

}
