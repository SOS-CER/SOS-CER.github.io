package edu.ncsu.csc.realsearch.data;

public class MetricsFunction {
	
	private String projectName;
	private String version;
	private String name;
	private int ncss;
	private int ccn;
	private int javadocs;
	
	public MetricsFunction(String projectName, String version) {
		this.projectName = projectName;
		this.version = version;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNcss() {
		return ncss;
	}

	public void setNcss(int ncss) {
		this.ncss = ncss;
	}

	public int getCcn() {
		return ccn;
	}

	public void setCcn(int ccn) {
		this.ccn = ccn;
	}

	public int getJavadocs() {
		return javadocs;
	}

	public void setJavadocs(int javadocs) {
		this.javadocs = javadocs;
	}

}
