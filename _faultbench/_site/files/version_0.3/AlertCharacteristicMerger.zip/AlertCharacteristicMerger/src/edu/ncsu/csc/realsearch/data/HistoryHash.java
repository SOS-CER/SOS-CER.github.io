package edu.ncsu.csc.realsearch.data;

import java.util.Hashtable;

public class HistoryHash {
	
	private Hashtable<String, History> hash;
	public static HistoryHash instance;
	
	private HistoryHash() {
		hash = new Hashtable<String, History>();
	}
	
	public static HistoryHash getInstance() {
		if (instance == null) {
			instance = new HistoryHash();
		}
		return instance;
	}
	
	public void addToHash(String key, History value) {
		instance.hash.put(key, value);
	}
	
	public History getFromHash(String key) {
		return instance.hash.get(key);
	}

}
