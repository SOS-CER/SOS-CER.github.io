package edu.ncsu.csc.realsearch.io;

import java.util.HashMap;

import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.main.Constants;
import junit.framework.TestCase;

public class AlertComparitorJdomTest extends TestCase {
	
	AlertComparitor comp;
	
	protected void setUp() throws Exception {
		super.setUp();
		comp = new AlertComparitor();
		createMethodSignatureHashMap();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		Alerts.getInstance().clearAlerts();
	}
	
	private void createMethodSignatureHashMap() {
		Constants.primitatives = new HashMap<String, String>();
		Constants.primitatives.put("Z", "boolean");
		Constants.primitatives.put("B", "byte");
		Constants.primitatives.put("C", "char");
		Constants.primitatives.put("D", "double");
		Constants.primitatives.put("F", "float");
		Constants.primitatives.put("I", "int");
		Constants.primitatives.put("J", "long");
		Constants.primitatives.put("L", "object");
		Constants.primitatives.put("S", "short");
		Constants.primitatives.put("V", "void");
		Constants.primitatives.put("[", "array");
	}
	
	public void testForOpenAlerts() {
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0226-jdom-alerts.xml", "\\|", false, "0226", "jdom");
		assertEquals(26, Alerts.getInstance().getAlerts().size());
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0251-jdom-alerts.xml", "\\|", false, "0251", "jdom");
		assertEquals(28, Alerts.getInstance().getAlerts().size());
		assertEquals(176, Alerts.getInstance().getAlerts().get(0).getOpenRevision());
		assertEquals(176, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size()-3).getOpenRevision());
		assertEquals(201, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size()-2).getOpenRevision());
		assertEquals(201, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size()-1).getOpenRevision());
		assertEquals(1, Alerts.getInstance().getAlerts().get(10).getNumAlertModifications());
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0226-jdom-contrib-alerts.xml", "\\|", false, "0226", "jdom-contrib");
		assertEquals(129, Alerts.getInstance().getAlerts().size());
	}
	
	public void testForClosedAlerts() {
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0226-jdom-alerts.xml", "\\|", false, "0226", "jdom");
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0251-jdom-alerts.xml", "\\|", false, "0251", "jdom");
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0276-jdom-alerts.xml", "\\|", false, "0276", "jdom");
		assertEquals(30, Alerts.getInstance().getAlerts().size());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 9).getCloseRevision());
		assertEquals(176, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 9).getOpenRevision());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 4).getCloseRevision());
		assertEquals(-1, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 3).getCloseRevision());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 2).getOpenRevision());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 1).getOpenRevision());
		assertEquals(2, Alerts.getInstance().getAlerts().get(10).getNumAlertModifications());
		assertEquals(1, Alerts.getInstance().getAlerts().get(20).getNumAlertModifications());
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0301-jdom-alerts.xml", "\\|", false, "0301", "jdom");
		assertEquals(32, Alerts.getInstance().getAlerts().size());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 11).getCloseRevision());
		assertEquals(176, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 11).getOpenRevision());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 6).getCloseRevision());
		assertEquals(-1, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 5).getCloseRevision());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 4).getOpenRevision());
		assertEquals(226, Alerts.getInstance().getAlerts().get(Alerts.getInstance().getAlerts().size() - 3).getOpenRevision());
		
	}

}
