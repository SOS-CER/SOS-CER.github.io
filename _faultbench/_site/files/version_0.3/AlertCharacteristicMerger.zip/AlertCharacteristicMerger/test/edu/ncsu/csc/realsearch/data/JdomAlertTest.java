package edu.ncsu.csc.realsearch.data;

import java.io.File;
import java.util.HashMap;

import edu.ncsu.csc.realsearch.io.AlertComparitor;
import edu.ncsu.csc.realsearch.io.JavaNCSSMetricsXMLReader;
import edu.ncsu.csc.realsearch.io.MetricsXmlReader;
import edu.ncsu.csc.realsearch.io.StatusReader;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.HistoryDB;
import edu.ncsu.csc.realsearch.main.BenchmarkHistoryMain;
import edu.ncsu.csc.realsearch.main.Constants;
import edu.ncsu.csc.realsearch.parser.main.CVSParser;
import junit.framework.TestCase;

public class JdomAlertTest extends TestCase {
	
	Alert jdomA1, jdomA2, jdomA3, jdomA4;
	
	protected void setUp() throws Exception {
		super.setUp();
		
		new BenchmarkHistoryMain("jdom");
		
		StatusReader reader = new StatusReader();
		reader.readStatus("jdom", new File(Constants.PROJECT_ROOT + "/" + Constants.JDOM_ROOT + "/collector.txt"));
		
		JavaNCSSMetricsXMLReader metricsReader = new JavaNCSSMetricsXMLReader();
		metricsReader.parseFile(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT + "0176-jdom-metrics.xml", "0176", "jdom");
		metricsReader.parseFile(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT + "0176-jdom-contrib-metrics.xml", "0176", "jdom-contrib");
		
		metricsReader.parseFile(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT + "0201-jdom-metrics.xml", "0201", "jdom");
		metricsReader.parseFile(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT + "0201-jdom-contrib-metrics.xml", "0201", "jdom-contrib");
		
		CVSParser parser = new CVSParser();
		parser.parse("jdom", Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.HISTORY_ROOT + "jdom-all.log", DBConnection.getInstance(false).getConnection());
		HistoryDB.addDatesToCommitsTable(DBConnection.getInstance(false).getConnection(), "jdom");
		
		
		AlertComparitor comp = new AlertComparitor();
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0176-jdom-alerts.xml", "\\|", false, "0176", "jdom");
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0176-jdom-contrib-alerts.xml", "\\|", false, "0176", "jdom-contrib");
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0201-jdom-alerts.xml", "\\|", false, "0201", "jdom");
		comp.compareAlerts(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.ALERTS_ROOT + "0201-jdom-contrib-alerts.xml", "\\|", false, "0201", "jdom-contrib");
		Alerts.getInstance().writeToDB();
			
		//jdom 176 - 26 alerts
		//jdom-contrib 176 - 103 alerts
		//jdom 201 - 28 alerts - 2 new

		/* Alert 0 */
		jdomA1 = Alerts.getInstance().getAlerts().get(0);
		/* Alert 14: */
		jdomA2 = Alerts.getInstance().getAlerts().get(14);
		//Alert 26 + 8 = 34 -1 = 33 - ResultSetBuilder.java.setAsAttribute(String,String)
		jdomA3 = Alerts.getInstance().getAlerts().get(33);
		//First new jdom alert in 201
		jdomA4 = Alerts.getInstance().getAlerts().get(127);
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		CreateDBTables.destroyChurnTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyHistoryTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyMetricsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyMetricsNCSSPackageTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyMetricsNCSSObjectTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyMetricsNCSSFunctionTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyAlertsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyCommitsTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyStatusTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyCVSFilesTable(DBConnection.getInstance(false).getConnection());
		CreateDBTables.destroyCVSRevisionTable(DBConnection.getInstance(false).getConnection());
		Alerts.getInstance().clearAlerts();
	}

//	public void testAlertJdom() {
//		assertEquals("jdom", jdomA1.getProjectName());
//		assertEquals("org/jdom/", jdomA1.getPackageName());
//		assertEquals("Attribute.java", jdomA1.getFileName());
//		assertEquals("clone()", jdomA1.getMethodName());
//		assertEquals("cd2aa7c18ce14506fabc735751db6bd1", jdomA1.getSourceHash());
//		assertEquals(353, jdomA1.getLineNumber());
//		assertEquals("CN_IDIOM_NO_SUPER_CALL", jdomA1.getBugType());
//		assertEquals("2", jdomA1.getPriority());
//		assertEquals("BAD_PRACTICE", jdomA1.getAlertCategory());
//		
//		assertEquals("jdom", jdomA2.getProjectName());
//		assertEquals("org/jdom/", jdomA2.getPackageName());
//		assertEquals("PartialList.java", jdomA2.getFileName());
//		assertEquals("", jdomA2.getMethodName());
//		assertEquals("508f1d975925e3a09112f7b1e806b2b2", jdomA2.getSourceHash());
//		assertEquals(91, jdomA2.getLineNumber());
//		assertEquals("SE_NO_SERIALVERSIONID", jdomA2.getBugType());
//		assertEquals("3", jdomA2.getPriority());
//		assertEquals("BAD_PRACTICE", jdomA2.getAlertCategory());
//		
//		assertEquals("jdom-contrib", jdomA3.getProjectName());
//		assertEquals("org/jdom/contrib/input/", jdomA3.getPackageName());
//		assertEquals("ResultSetBuilder.java", jdomA3.getFileName());
//		assertEquals("setAsAttribute(String,String)", jdomA3.getMethodName());
//		assertEquals("2108beca1117185e8cf5c9d736f66401", jdomA3.getSourceHash());
//		assertEquals(183, jdomA3.getLineNumber());
//		assertEquals("DM_CONVERT_CASE", jdomA3.getBugType());
//		assertEquals("3", jdomA3.getPriority());
//		assertEquals("I18N", jdomA3.getAlertCategory());
//		
//		assertEquals("jdom", jdomA4.getProjectName());
//		assertEquals("org/jdom/", jdomA4.getPackageName());
//		assertEquals("Element.java", jdomA4.getFileName());
//		assertEquals("getText()", jdomA4.getMethodName());
//		assertEquals("5ab5c4a1fa55ca450dc22364de52e783", jdomA4.getSourceHash());
//		assertEquals(409, jdomA4.getLineNumber());
//		assertEquals("NP_NULL_ON_SOME_PATH", jdomA4.getBugType());
//		assertEquals("2", jdomA4.getPriority());
//		assertEquals("CORRECTNESS", jdomA4.getAlertCategory());
//	}

//	public void testMakeMetricsKeyMethod() {
//		assertEquals("org.jdom", jdomA1.makeMetricsKeyMethod("package"));
//		assertEquals("org.jdom.PartialList", jdomA2.makeMetricsKeyMethod("file"));
//		assertEquals("org.jdom.contrib.input.ResultSetBuilder.setAsAttribute(String,String)", jdomA3.makeMetricsKeyMethod("method"));
//	}
	
//	public void testGenerateRevision() {
//		a1.generateRevision();
//		assertEquals(0, a1.getRevision());
//		
//		a2.generateRevision();
//		assertEquals(0, a2.getRevision());
//		
//		a3.generateRevision();
//		assertEquals(1, a3.getRevision());
//	}
//	
//	public void testGenerateDeveloper() {
//		jdomA1.generateDevelopers();
//		assertEquals("bmclaugh", jdomA1.getDevelopers().get(0));
//		assertEquals("jhunter", jdomA1.getDevelopers().get(1));
//		jdomA1.generateDeveloper();
//		assertEquals("bmclaugh,jhunter", jdomA1.getDeveloper());
//		
//		jdomA2.generateDevelopers();
//		assertEquals("bmclaugh", jdomA2.getDevelopers().get(0));
//		assertEquals("jhunter", jdomA2.getDevelopers().get(1));
//		jdomA2.generateDeveloper();
//		assertEquals("bmclaugh,jhunter", jdomA2.getDeveloper());
//		
//		jdomA3.generateDevelopers();
//		assertEquals("jhunter", jdomA3.getDevelopers().get(0));
//		jdomA3.generateDeveloper();
//		assertEquals("jhunter", jdomA3.getDeveloper());
//		
//		jdomA4.generateDevelopers();
//		assertEquals("jhunter", jdomA4.getDevelopers().get(0));
//		jdomA4.generateDeveloper();
//		assertEquals("jhunter", jdomA4.getDeveloper());
//	}
//	
//	public void testGenerateCloseRevisionType() {
//		a1.generateCloseRevisionType();
//		assertEquals("", a1.getCloseRevisionType());
//		
//		a2.generateCloseRevisionType();
//		assertEquals("functionality", a2.getCloseRevisionType());
//		
//		a3.generateCloseRevisionType();
//		assertEquals("", a3.getCloseRevisionType());
//	}
//	
//	public void testGenerateOpenRevisionType() {
//		a1.generateOpenRevisionType();
//		assertEquals("functionality", a1.getOpenRevisionType());
//		
//		a2.generateOpenRevisionType();
//		assertEquals("functionality", a2.getOpenRevisionType());
//		
//		a3.generateOpenRevisionType();
//		assertEquals("functionality", a3.getOpenRevisionType());
//	}
//	
//	public void testTotalAlertsForRevision() {
//		jdomA1.generateTotalAlertsForRevision();
//		assertEquals(127, jdomA1.getTotalAlertsForRevision());
//		
//		jdomA2.generateTotalAlertsForRevision();
//		assertEquals(127, jdomA2.getTotalAlertsForRevision());
//		
//		jdomA3.generateTotalAlertsForRevision();
//		assertEquals(127, jdomA3.getTotalAlertsForRevision());
//		
//		jdomA4.generateTotalAlertsForRevision();
//		assertEquals(129, jdomA4.getTotalAlertsForRevision());
//	}
//	
//	public void testTotalOpenAlertsForRevision() {
//		jdomA1.generateTotalOpenAlertsForRevision();
//		assertEquals(127, jdomA1.getTotalOpenAlertsForRevision());
//		
//		jdomA2.generateTotalOpenAlertsForRevision();
//		assertEquals(127, jdomA2.getTotalOpenAlertsForRevision());
//		
//		jdomA3.generateTotalOpenAlertsForRevision();
//		assertEquals(127, jdomA3.getTotalOpenAlertsForRevision());
//		
//		jdomA4.generateTotalOpenAlertsForRevision();
//		assertEquals(129, jdomA4.getTotalOpenAlertsForRevision());
//	}
//
//	public void testAlertLifetime() {
//		jdomA1.generateAlertLifetime();
//		assertEquals(989, jdomA1.getAlertLifetime());
//		
//		jdomA2.generateAlertLifetime();
//		assertEquals(989, jdomA2.getAlertLifetime());
//		
//		jdomA3.generateAlertLifetime();
//		assertEquals(989, jdomA3.getAlertLifetime());
//		
//		jdomA4.generateAlertLifetime();
//		assertEquals(964, jdomA4.getAlertLifetime());
//	}
//
//	
//	public void testGenerateAlertCategory() {
//		a1.generateAlertCategory();
//		assertEquals("B", a1.getAlertCategory());
//		
//		a2.generateAlertCategory();
//		assertEquals("D", a2.getAlertCategory());
//		
//		a3.generateAlertCategory();
//		assertEquals("D", a3.getAlertCategory());
//	}
//	
//	public void testGenerateAlertPriority() {
//		a1.generateAlertPriority();
//		assertEquals("L", a1.getPriority());
//		
//		a2.generateAlertPriority();
//		assertEquals("H", a2.getPriority());
//		
//		a3.generateAlertPriority();
//		assertEquals("M", a3.getPriority());
//	}
//	
//	public void testGenerateFileCreationRevision() {
//		jdomA1.generateFileCreationRevision();
//		assertEquals(4, jdomA1.getFileCreationRevision());
//		
//		jdomA2.generateFileCreationRevision();
//		assertEquals(4, jdomA2.getFileCreationRevision());
//		
//		jdomA3.generateFileCreationRevision();
//		assertEquals(52, jdomA3.getFileCreationRevision());
//		
//		jdomA4.generateFileCreationRevision();
//		assertEquals(4, jdomA4.getFileCreationRevision());
//		
//	}
//	
//	public void testGenerateFileDeletionRevision() {
//		jdomA1.generateFileDeletionRevision();
//		assertEquals(-1, jdomA1.getFileDeletionRevision());
//		
//		jdomA2.generateFileDeletionRevision();
//		assertEquals(636, jdomA2.getFileDeletionRevision());
//		
//		jdomA3.generateFileDeletionRevision();
//		assertEquals(-1, jdomA3.getFileDeletionRevision());
//		
//		jdomA4.generateFileDeletionRevision();
//		assertEquals(-1, jdomA4.getFileDeletionRevision());
//	}
//	
//	//NOTE: remember that the full history is loaded!
//	public void testGenerateFileAge() {
//		jdomA1.generateFileCreationRevision();
//		jdomA2.generateFileCreationRevision();
//		jdomA3.generateFileCreationRevision();
//		jdomA4.generateFileCreationRevision();
//		
//		jdomA1.generateFileDeletionRevision();
//		jdomA2.generateFileDeletionRevision();
//		jdomA3.generateFileDeletionRevision();
//		jdomA4.generateFileDeletionRevision();
//		
//		jdomA1.generateFileAge();
//		assertEquals(1161, jdomA1.getFileAge());
//		
//		jdomA2.generateFileAge();
//		assertEquals(632, jdomA2.getFileAge());
//		
//		jdomA3.generateFileAge();
//		assertEquals(1113, jdomA3.getFileAge());
//		
//		jdomA4.generateFileAge();
//		assertEquals(1113, jdomA3.getFileAge());
//	}
//	
//	public void testGenerateFileExtension() {
//		a1.generateFileExtension();
//		assertEquals(".java", a1.getFileExtension());
//		
//		a2.generateFileExtension();
//		assertEquals(".java", a2.getFileExtension());
//		
//		a3.generateFileExtension();
//		assertEquals(".java", a3.getFileExtension());	
//	}
//	
//	public void testGenerateAlertsInFile() {
//		jdomA1.generateAlertsInFile();
//		assertEquals(2, jdomA1.getAlertsInFile());
//		
//		jdomA2.generateAlertsInFile();
//		assertEquals(1, jdomA2.getAlertsInFile());
//		
//		jdomA3.generateAlertsInFile();
//		assertEquals(9, jdomA3.getAlertsInFile());
//		
//		jdomA4.generateAlertsInFile();
//		assertEquals(3, jdomA4.getAlertsInFile());
//	}
//	
//	public void testGenerateLatestFileModification() {
//		jdomA1.generateLatestFileModification();
//		assertEquals(1154, jdomA1.getLatestFileModficationRevision());
//		
//		jdomA2.generateLatestFileModification();
//		assertEquals(636, jdomA2.getLatestFileModficationRevision());
//		
//		jdomA3.generateLatestFileModification();
//		assertEquals(1115, jdomA3.getLatestFileModficationRevision());
//		
//		jdomA4.generateLatestFileModification();
//		assertEquals(1162, jdomA4.getLatestFileModficationRevision());
//	}
//	
//	public void testGenerateFileStaleness() {
//		jdomA1.generateLatestFileModification();
//		jdomA2.generateLatestFileModification();
//		jdomA3.generateLatestFileModification();
//		jdomA4.generateLatestFileModification();
//		
//		jdomA1.generateFileStaleness();
//		assertEquals(11, jdomA1.getFileStaleness());
//		
//		jdomA2.generateFileStaleness();
//		assertEquals(529, jdomA2.getFileStaleness());
//		
//		jdomA3.generateFileStaleness();
//		assertEquals(50, jdomA3.getFileStaleness());
//		
//		jdomA4.generateFileStaleness();
//		assertEquals(3, jdomA4.getFileStaleness());
//	}
//	
//	public void testGenerateLatestPackageModification() {
//		jdomA1.generateLatestPackageModification();
//		assertEquals(1164, jdomA1.getLatestPackageModificationRevision());
//		
//		jdomA2.generateLatestPackageModification();
//		assertEquals(1164, jdomA2.getLatestPackageModificationRevision());
//		
//		jdomA3.generateLatestPackageModification();
//		assertEquals(1160, jdomA3.getLatestPackageModificationRevision());
//		
//		jdomA4.generateLatestPackageModification();
//		assertEquals(1164, jdomA4.getLatestPackageModificationRevision());
//	}
//	
//	public void testGenerateLatestProjectModification() {
//		jdomA1.generateLatestProjectModification();
//		assertEquals(1164, jdomA1.getLatestProjectModficiationRevision());
//		
//		jdomA2.generateLatestProjectModification();
//		assertEquals(1164, jdomA2.getLatestProjectModficiationRevision());
//		
//		jdomA3.generateLatestProjectModification();
//		assertEquals(1160, jdomA3.getLatestProjectModficiationRevision());
//		
//		jdomA4.generateLatestProjectModification();
//		assertEquals(1164, jdomA4.getLatestProjectModficiationRevision());
//	}
//	
//	public void testGeneratePackageStaleness() {
//		jdomA1.generateLatestPackageModification();
//		jdomA2.generateLatestPackageModification();
//		jdomA3.generateLatestPackageModification();
//		jdomA4.generateLatestPackageModification();
//		
//		jdomA1.generatePackageStaleness();
//		assertEquals(1, jdomA1.getPackageStaleness());
//		
//		jdomA2.generatePackageStaleness();
//		assertEquals(1, jdomA2.getPackageStaleness());
//		
//		jdomA3.generatePackageStaleness();
//		assertEquals(5, jdomA3.getPackageStaleness());
//		
//		jdomA4.generatePackageStaleness();
//		assertEquals(1, jdomA4.getPackageStaleness());
//	}
//	
//	public void testGenerateProjectStaleness() {
//		jdomA1.generateLatestProjectModification();
//		jdomA2.generateLatestProjectModification();
//		jdomA3.generateLatestProjectModification();
//		jdomA4.generateLatestProjectModification();
//		
//		jdomA1.generateProjectStaleness();
//		assertEquals(1, jdomA1.getProjectStaleness());
//		
//		jdomA2.generateProjectStaleness();
//		assertEquals(1, jdomA2.getProjectStaleness());
//		
//		jdomA3.generateProjectStaleness();
//		assertEquals(5, jdomA3.getProjectStaleness());
//		
//		jdomA4.generateProjectStaleness();
//		assertEquals(1, jdomA4.getProjectStaleness());
//	}
	
	public void testGenerateAlertsInProject() {
		jdomA1.generateAlertsInProject();
		assertEquals(28, jdomA1.getAlertsInProject());
		
		jdomA2.generateAlertsInProject();
		assertEquals(28, jdomA2.getAlertsInProject());
		
		jdomA3.generateAlertsInProject();
		assertEquals(101, jdomA3.getAlertsInProject());
		
		jdomA4.generateAlertsInProject();
		assertEquals(28, jdomA4.getAlertsInProject());
	}
	
//	public void testGenerateMethodSize() {
//		jdomA1.generateMethodSize();
//		assertEquals(3, jdomA1.getMethodSize());
//		
//		jdomA2.generateMethodSize();
//		assertEquals(-1, jdomA2.getMethodSize());
//		
//		jdomA3.generateMethodSize();
//		assertEquals(3, jdomA3.getMethodSize());
//		
//		jdomA4.generateMethodSize();
//		assertEquals(23, jdomA4.getMethodSize());
//	}
//	
//	public void testGenerateCyclomaticComplexity() {
//		jdomA1.generateCyclomaticComplexity();
//		assertEquals(1, jdomA1.getCyclomaticComplexity());
//		
//		jdomA2.generateCyclomaticComplexity();
//		assertEquals(-1, jdomA2.getCyclomaticComplexity());
//		
//		jdomA3.generateCyclomaticComplexity();
//		assertEquals(1, jdomA3.getCyclomaticComplexity());
//		
//		jdomA4.generateCyclomaticComplexity();
//		assertEquals(12, jdomA4.getCyclomaticComplexity());
//	}
//	
//	public void testGenerateNumParameters() {
//		jdomA1.generateNumParameters();
//		assertEquals(-1, jdomA1.getNumParameters());
//		
//		jdomA2.generateNumParameters();
//		assertEquals(-1, jdomA2.getNumParameters());
//		
//		jdomA3.generateNumParameters();
//		assertEquals(-1, jdomA3.getNumParameters());
//		
//		jdomA4.generateNumParameters();
//		assertEquals(-1, jdomA4.getNumParameters());
//	}
//	
//	public void testGenerateFileSize() {
//		jdomA1.generateFileSize();
//		assertEquals(80, jdomA1.getFileSize());
//		
//		jdomA2.generateFileSize();
//		assertEquals(132, jdomA2.getFileSize());
//		
//		jdomA3.generateFileSize();
//		assertEquals(86, jdomA3.getFileSize());
//		
//		jdomA4.generateFileSize();
//		assertEquals(432, jdomA4.getFileSize());
//	}
//	
//	public void testGenerateNumberOfFunctionInFile() {
//		jdomA1.generateNumberOfFunctionsInFile();
//		assertEquals(23, jdomA1.getNumberOfFunctionsInFile());
//		
//		jdomA2.generateNumberOfFunctionsInFile();
//		assertEquals(16, jdomA2.getNumberOfFunctionsInFile());
//		
//		jdomA3.generateNumberOfFunctionsInFile();
//		assertEquals(14, jdomA3.getNumberOfFunctionsInFile());
//		
//		jdomA4.generateNumberOfFunctionsInFile();
//		assertEquals(79, jdomA4.getNumberOfFunctionsInFile());
//	}
//	
//	public void testGenerateNumberOfClassesInFile() {
//		jdomA1.generateNumberOfClassesInFile();
//		assertEquals(0, jdomA1.getNumberOfClassesInFile());
//		
//		jdomA2.generateNumberOfClassesInFile();
//		assertEquals(0, jdomA2.getNumberOfClassesInFile());
//		
//		jdomA3.generateNumberOfClassesInFile();
//		assertEquals(0, jdomA3.getNumberOfClassesInFile());
//		
//		jdomA4.generateNumberOfClassesInFile();
//		assertEquals(0, jdomA4.getNumberOfClassesInFile());
//	}
//	
//	public void testDepthOfInheritanceTree() {
//		jdomA1.generateDepthOfInheritanceTree();
//		assertEquals(-1, jdomA1.getDepthOfInheritanceTree());
//		
//		jdomA2.generateDepthOfInheritanceTree();
//		assertEquals(-1, jdomA2.getDepthOfInheritanceTree());
//		
//		jdomA3.generateDepthOfInheritanceTree();
//		assertEquals(-1, jdomA3.getDepthOfInheritanceTree());
//		
//		jdomA4.generateDepthOfInheritanceTree();
//		assertEquals(-1, jdomA4.getDepthOfInheritanceTree());
//	}
//	
//	public void testGenerateNumAttributes() {
//		jdomA1.generateNumAttributes();
//		assertEquals(-1, jdomA1.getNumAttributes());
//		
//		jdomA2.generateNumAttributes();
//		assertEquals(-1, jdomA2.getNumAttributes());
//		
//		jdomA3.generateNumAttributes();
//		assertEquals(-1, jdomA3.getNumAttributes());
//		
//		jdomA4.generateNumAttributes();
//		assertEquals(-1, jdomA4.getNumAttributes());
//	}
//	
//	public void testGenerateNumberOfClassesInPackage() {
//		jdomA1.generateNumberOfClassesInPackage();
//		assertEquals(17, jdomA1.getNumberOfClassesInPackage());
//		
//		jdomA2.generateNumberOfClassesInPackage();
//		assertEquals(17, jdomA2.getNumberOfClassesInPackage());
//		
//		jdomA3.generateNumberOfClassesInPackage();
//		assertEquals(2, jdomA3.getNumberOfClassesInPackage());
//		
//		jdomA4.generateNumberOfClassesInPackage();
//		assertEquals(17, jdomA4.getNumberOfClassesInPackage());
//	}
//	
//	public void testGenerateNumberOfFunctionsInPackage() {
//		jdomA1.generateNumberOfFunctionsInPackage();
//		assertEquals(258, jdomA1.getNumberOfFunctionsInPackage());
//		
//		jdomA2.generateNumberOfFunctionsInPackage();
//		assertEquals(258, jdomA2.getNumberOfFunctionsInPackage());
//		
//		jdomA3.generateNumberOfFunctionsInPackage();
//		assertEquals(20, jdomA3.getNumberOfFunctionsInPackage());
//		
//		jdomA4.generateNumberOfFunctionsInPackage();
//		assertEquals(258, jdomA4.getNumberOfFunctionsInPackage());
//	}
//	
//	public void testGeneratePackageSize() {
//		jdomA1.generatePackageSize();
//		assertEquals(1983, jdomA1.getPackageSize());
//		
//		jdomA2.generatePackageSize();
//		assertEquals(1983, jdomA2.getPackageSize());
//		
//		jdomA3.generatePackageSize();
//		assertEquals(110, jdomA3.getPackageSize());
//		
//		jdomA4.generatePackageSize();
//		assertEquals(1959, jdomA4.getPackageSize());
//	}
	
//	public void testGenerateAlertDepthInFile() {
//		a1.generateFileSize();
//		a2.generateFileSize();
//		a3.generateFileSize();
//		
//		a1.generateAlertDepthInFile();
//		assertEquals(32 / 97.0, a1.getAlertDepthInFile());
//		
//		a2.generateAlertDepthInFile();
//		assertEquals(30 / 156.0, a2.getAlertDepthInFile());
//		
//		a3.generateAlertDepthInFile();
//		assertEquals(25 / 29.0, a3.getAlertDepthInFile());
//	}
//	
//	public void testFileChurn() {
//		jdomA1.generateFileAddedLines();
//		jdomA1.generateFileDeletedLines();
//		jdomA1.generateFileModifiedLines();
//		jdomA1.generateFileGrowthLines();
//		jdomA1.generateFileTotalModifiedLines();
//		jdomA1.generateFilePercentModifiedLines();
//		assertEquals(103, jdomA1.getFileAddedLines());
//		assertEquals(283, jdomA1.getFileDeletedLines());
//		assertEquals(0, jdomA1.getFileModifiedLines());
//		assertEquals(-180, jdomA1.getFileGrowthLines());
//		assertEquals(386, jdomA1.getFileTotalModifiedLines());
//		assertEquals(0.032, jdomA1.getFilePercentModifiedLines(), 0.001);
//		
//		jdomA2.generateFileAddedLines();
//		jdomA2.generateFileDeletedLines();
//		jdomA2.generateFileModifiedLines();
//		jdomA2.generateFileGrowthLines();
//		jdomA2.generateFileTotalModifiedLines();
//		jdomA2.generateFilePercentModifiedLines();
//		assertEquals(112, jdomA2.getFileAddedLines());
//		assertEquals(81, jdomA2.getFileDeletedLines());
//		assertEquals(0, jdomA2.getFileModifiedLines());
//		assertEquals(31, jdomA2.getFileGrowthLines());
//		assertEquals(193, jdomA2.getFileTotalModifiedLines());
//		assertEquals(0.016, jdomA2.getFilePercentModifiedLines(), 0.001);
//		
//		jdomA3.generateFileAddedLines();
//		jdomA3.generateFileDeletedLines();
//		jdomA3.generateFileModifiedLines();
//		jdomA3.generateFileGrowthLines();
//		jdomA3.generateFileTotalModifiedLines();
//		jdomA3.generateFilePercentModifiedLines();
//		assertEquals(3, jdomA3.getFileAddedLines());
//		assertEquals(3, jdomA3.getFileDeletedLines());
//		assertEquals(0, jdomA3.getFileModifiedLines());
//		assertEquals(0, jdomA3.getFileGrowthLines());
//		assertEquals(6, jdomA3.getFileTotalModifiedLines());
//		assertEquals(0.0005, jdomA3.getFilePercentModifiedLines(), 0.001);
//		
//		jdomA4.generateFileAddedLines();
//		jdomA4.generateFileDeletedLines();
//		jdomA4.generateFileModifiedLines();
//		jdomA4.generateFileGrowthLines();
//		jdomA4.generateFileTotalModifiedLines();
//		jdomA4.generateFilePercentModifiedLines();
//		assertEquals(5, jdomA4.getFileAddedLines());
//		assertEquals(0, jdomA4.getFileDeletedLines());
//		assertEquals(0, jdomA4.getFileModifiedLines());
//		assertEquals(5, jdomA4.getFileGrowthLines());
//		assertEquals(5, jdomA4.getFileTotalModifiedLines());
//		assertEquals(0.0004, jdomA4.getFilePercentModifiedLines(), 0.001); //out of 887
//	}
//	
//	public void testPackageChurn() {
//		jdomA1.generatePackageAddedLines();
//		jdomA1.generatePackageDeletedLines();
//		jdomA1.generatePackageModifiedLines();
//		jdomA1.generatePackageGrowthLines();
//		jdomA1.generatePackageTotalModifiedLines();
//		jdomA1.generatePackagePercentModifiedLines();
//		assertEquals(4993, jdomA1.getPackageAddedLines());
//		assertEquals(3484, jdomA1.getPackageDeletedLines());
//		assertEquals(0, jdomA1.getPackageModifiedLines());
//		assertEquals(1509, jdomA1.getPackageGrowthLines());
//		assertEquals(8477, jdomA1.getPackageTotalModifiedLines());
//		assertEquals(0.705, jdomA1.getPackagePercentModifiedLines(), 0.001);
//		
//		jdomA2.generatePackageAddedLines();
//		jdomA2.generatePackageDeletedLines();
//		jdomA2.generatePackageModifiedLines();
//		jdomA2.generatePackageGrowthLines();
//		jdomA2.generatePackageTotalModifiedLines();
//		jdomA2.generatePackagePercentModifiedLines();
//		assertEquals(4993, jdomA2.getPackageAddedLines());
//		assertEquals(3484, jdomA2.getPackageDeletedLines());
//		assertEquals(0, jdomA2.getPackageModifiedLines());
//		assertEquals(1509, jdomA2.getPackageGrowthLines());
//		assertEquals(8477, jdomA2.getPackageTotalModifiedLines());
//		assertEquals(0.705, jdomA2.getPackagePercentModifiedLines(), 0.001);
//		
//		jdomA3.generatePackageAddedLines();
//		jdomA3.generatePackageDeletedLines();
//		jdomA3.generatePackageModifiedLines();
//		jdomA3.generatePackageGrowthLines();
//		jdomA3.generatePackageTotalModifiedLines();
//		jdomA3.generatePackagePercentModifiedLines();
//		assertEquals(3, jdomA3.getPackageAddedLines());
//		assertEquals(3, jdomA3.getPackageDeletedLines());
//		assertEquals(0, jdomA3.getPackageModifiedLines());
//		assertEquals(0, jdomA3.getPackageGrowthLines());
//		assertEquals(6, jdomA3.getPackageTotalModifiedLines());
//		assertEquals(0.0005, jdomA3.getPackagePercentModifiedLines(), 0.001);
//		
//		jdomA4.generatePackageAddedLines();
//		jdomA4.generatePackageDeletedLines();
//		jdomA4.generatePackageModifiedLines();
//		jdomA4.generatePackageGrowthLines();
//		jdomA4.generatePackageTotalModifiedLines();
//		jdomA4.generatePackagePercentModifiedLines();
//		assertEquals(25, jdomA4.getPackageAddedLines());
//		assertEquals(8, jdomA4.getPackageDeletedLines());
//		assertEquals(0, jdomA4.getPackageModifiedLines());
//		assertEquals(17, jdomA4.getPackageGrowthLines());
//		assertEquals(33, jdomA4.getPackageTotalModifiedLines());
//		assertEquals(0.002, jdomA4.getPackagePercentModifiedLines(), 0.001);
//	}
//	
//	public void testProjectChurn() {
//		jdomA1.generateProjectAddedLines();
//		jdomA1.generateProjectDeletedLines();
//		jdomA1.generateProjectModifiedLines();
//		jdomA1.generateProjectGrowthLines();
//		jdomA1.generateProjectTotalModifiedLines();
//		jdomA1.generateProjectPercentModifiedLines();
//		assertEquals(5651, jdomA1.getProjectAddedLines());
//		assertEquals(3936, jdomA1.getProjectDeletedLines());
//		assertEquals(0, jdomA1.getProjectModifiedLines());
//		assertEquals(1715, jdomA1.getProjectGrowthLines());
//		assertEquals(9587, jdomA1.getProjectTotalModifiedLines());
//		assertEquals(0.797, jdomA1.getProjectPercentModifiedLines(), 0.001);
//		
//		jdomA2.generateProjectAddedLines();
//		jdomA2.generateProjectDeletedLines();
//		jdomA2.generateProjectModifiedLines();
//		jdomA2.generateProjectGrowthLines();
//		jdomA2.generateProjectTotalModifiedLines();
//		jdomA2.generateProjectPercentModifiedLines();
//		assertEquals(5651, jdomA2.getProjectAddedLines());
//		assertEquals(3936, jdomA2.getProjectDeletedLines());
//		assertEquals(0, jdomA2.getProjectModifiedLines());
//		assertEquals(1715, jdomA2.getProjectGrowthLines());
//		assertEquals(9587, jdomA2.getProjectTotalModifiedLines());
//		assertEquals(0.797, jdomA2.getProjectPercentModifiedLines(), 0.001);
//		
//		jdomA3.generateProjectAddedLines();
//		jdomA3.generateProjectDeletedLines();
//		jdomA3.generateProjectModifiedLines();
//		jdomA3.generateProjectGrowthLines();
//		jdomA3.generateProjectTotalModifiedLines();
//		jdomA3.generateProjectPercentModifiedLines();
//		assertEquals(656, jdomA3.getProjectAddedLines());
//		assertEquals(386, jdomA3.getProjectDeletedLines());
//		assertEquals(0, jdomA3.getProjectModifiedLines());
//		assertEquals(270, jdomA3.getProjectGrowthLines());
//		assertEquals(1042, jdomA3.getProjectTotalModifiedLines());
//		assertEquals(0.087, jdomA3.getProjectPercentModifiedLines(), 0.001);
//		
//		jdomA4.generateProjectAddedLines();
//		jdomA4.generateProjectDeletedLines();
//		jdomA4.generateProjectModifiedLines();
//		jdomA4.generateProjectGrowthLines();
//		jdomA4.generateProjectTotalModifiedLines();
//		jdomA4.generateProjectPercentModifiedLines();
//		assertEquals(32, jdomA4.getProjectAddedLines());
//		assertEquals(18, jdomA4.getProjectDeletedLines());
//		assertEquals(0, jdomA4.getProjectModifiedLines());
//		assertEquals(14, jdomA4.getProjectGrowthLines());
//		assertEquals(50, jdomA4.getProjectTotalModifiedLines());
//		assertEquals(0.003, jdomA4.getProjectPercentModifiedLines(), 0.001);
//	}

}
