package edu.ncsu.csc.realsearch.io;

import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.data.History;
import edu.ncsu.csc.realsearch.data.HistoryHash;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.HistoryDB;
import edu.ncsu.csc.realsearch.main.Constants;
import junit.framework.TestCase;

public class HistoryReaderTest extends TestCase {
	
	private HistoryReader reader;
	private String testHistory = "18,1.3.2,9/11/2001,functionality,30,1530,27,29";

	protected void setUp() throws Exception {
		super.setUp();
		CreateDBTables.createHistoryTable(DBConnection.getInstance(true).getConnection());
		reader = new HistoryReader();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		CreateDBTables.destroyHistoryTable(DBConnection.getInstance(true).getConnection());
		Alerts.getInstance().clearAlerts();
	}

	public void testReadHistoryFromDelimitedFile() {
//		reader.readHistoryFromDelimitedFile(Constants.PROJECT_ROOT + Constants.IMPORTSCRUBBER_ROOT + "history.csv", ",", true);
//		assertEquals(18,HistoryDB.getRevisionFromVersion(DBConnection.getInstance(true).getConnection(), "importscrubbers", "1.3.2"));
//		assertEquals(new History(testHistory,","), HistoryHash.getInstance().getFromHash("1.3.2"));
	}

}
