package edu.ncsu.csc.realsearch.data;

import java.util.HashMap;

import edu.ncsu.csc.realsearch.main.Constants;
import junit.framework.TestCase;

public class MetricsGroupTest extends TestCase {
	
	public void setUp() throws Exception {
		createMethodSignatureHashMap();
	}

	public void tearDown() throws Exception {
		super.tearDown();
		Alerts.getInstance().clearAlerts();
	}
	
	private void createMethodSignatureHashMap() {
		Constants.primitatives = new HashMap<String, String>();
		Constants.primitatives.put("Z", "boolean");
		Constants.primitatives.put("B", "byte");
		Constants.primitatives.put("C", "char");
		Constants.primitatives.put("D", "double");
		Constants.primitatives.put("F", "float");
		Constants.primitatives.put("I", "int");
		Constants.primitatives.put("J", "long");
		Constants.primitatives.put("L", "object");
		Constants.primitatives.put("S", "short");
		Constants.primitatives.put("V", "void");
		Constants.primitatives.put("[", "array");
	}
	
	public void testParseHandle1() {
		MetricsGroup group = new MetricsGroup("setFormat", "=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber{ImportScrubberTask.java[ImportScrubberTask~setFormat~QString;","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber/ImportScrubberTask.java.setFormat(String)", group.getHandle());
	}
	
	public void testParseHandle2() {
		MetricsGroup group = new MetricsGroup("setVerbose", "=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber{ImportScrubberTask.java[ImportScrubberTask~setVerbose~Z","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber/ImportScrubberTask.java.setVerbose(boolean)", group.getHandle());
	}
	public void testParseHandle3() {
		MetricsGroup group = new MetricsGroup("execute","=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber{ImportScrubberTask.java[ImportScrubberTask~execute","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber/ImportScrubberTask.java.execute()", group.getHandle());
	}
	public void testParseHandle4() {
		MetricsGroup group = new MetricsGroup("setRoot","=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber{ImportScrubberTask.java[ImportScrubberTask~setRoot~QString;","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber/ImportScrubberTask.java.setRoot(String)", group.getHandle());
	}
	public void testParseHandle5() {
		MetricsGroup group = new MetricsGroup("setRecurse","=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber{ImportScrubberTask.java[ImportScrubberTask~setRecurse~Z","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber/ImportScrubberTask.java.setRecurse(boolean)", group.getHandle());
	}
	public void testParseHandle6() {
		MetricsGroup group = new MetricsGroup("RecursiveFileChooserTest","=importscrubbers/importscrubber\\/src&lt;test.net.sourceforge.importscrubber{RecursiveFileChooserTest.java[RecursiveFileChooserTest~RecursiveFileChooserTest~QString;","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/test/net/sourceforge/importscrubber/RecursiveFileChooserTest.java.RecursiveFileChooserTest(String)", group.getHandle());
	}
	public void testParseHandle7() {
		MetricsGroup group = new MetricsGroup("main","=importscrubbers/importscrubber\\/src&lt;test.net.sourceforge.importscrubber{TestDriver.java[TestDriver~main~\\[QString;","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/test/net/sourceforge/importscrubber/TestDriver.java.main(String[])", group.getHandle());
	}
	public void testParseHandle8() {
		MetricsGroup group = new MetricsGroup("org.apache.tools.ant.taskdefs.optional.importscrubber","=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber", group.getHandle());
	}
	public void testParseHandle9() {
		MetricsGroup group = new MetricsGroup("ImportScrubberTask.java","=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber{ImportScrubberTask.java","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber/ImportScrubberTask.java", group.getHandle());
	}
	public void testParseHandle10() {
		MetricsGroup group = new MetricsGroup("importscrubbers","=importscrubbers","1.4.3");
		assertEquals("=importscrubbers", group.getHandle());
	}
	public void testParseHandle11() {
		MetricsGroup group = new MetricsGroup("org.apache.tools.ant.taskdefs.optional.importscrubber","=importscrubbers/importscrubber\\/src&lt;org.apache.tools.ant.taskdefs.optional.importscrubber","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber", group.getHandle());
	}
	public void testParseHandle12() {
		MetricsGroup group = new MetricsGroup("setAsAttribute","=jdom-contrib/build\\/src<org.jdom.contrib.input{ResultSetBuilder.java[ResultSetBuilder~setAsAttribute~QString;~QString;","0176");
		assertEquals("=jdom-contrib/build/src/org/jdom/contrib/input/ResultSetBuilder.java.setAsAttribute(String,String)", group.getHandle());
	}
	public void testParseHandle13() {
		MetricsGroup group = new MetricsGroup("setAsAttribute","=jdom-contrib/build\\/src<org.jdom.contrib.input{ResultSetBuilder.java[ResultSetBuilder~setAsAttribute~I","0176");
		assertEquals("=jdom-contrib/build/src/org/jdom/contrib/input/ResultSetBuilder.java.setAsAttribute(int)", group.getHandle());
	}
	public void testParseHandle14() {
		MetricsGroup group = new MetricsGroup("setAsAttribute","=jdom-contrib/build\\/src<org.jdom.contrib.input{ResultSetBuilder.java[ResultSetBuilder~setAsAttribute~QString;","0176");
		assertEquals("=jdom-contrib/build/src/org/jdom/contrib/input/ResultSetBuilder.java.setAsAttribute(String)", group.getHandle());
	}
	public void testParseHandle15() {
		MetricsGroup group = new MetricsGroup("setAsAttribute","=jdom-contrib/build\\/src<org.jdom.contrib.input{ResultSetBuilder.java[ResultSetBuilder~setAsAttribute~I~QString;","0176");
		assertEquals("=jdom-contrib/build/src/org/jdom/contrib/input/ResultSetBuilder.java.setAsAttribute(int,String)", group.getHandle());
	}
	public void testCompareWithAlertKey1() {
		MetricsGroup group = new MetricsGroup("setVerbose","=importscrubbers/importscrubber\\/src&lt;net.sourceforge.importscrubber.ant{ImportScrubberTask.java[ImportScrubberTask~setVerbose~Z","1.4.3");
		assertEquals("=importscrubbers/importscrubber/src/net/sourceforge/importscrubber/ant/ImportScrubberTask.java.setVerbose(boolean)", group.getHandle());
		String alert = "2|0.5166573033707865|M P UrF: Unread field: net.sourceforge.importscrubber.ant.ImportScrubberTask.verbose|importscrubbers|importscrubber/src/net/sourceforge/importscrubber/ant|ImportScrubberTask.java|void setVerbose(boolean)|1|5db8f2e7cc6ebed2f746b2f45ec59bc2|edu.umd.cs.findbugs.plugin.eclipse.findbugsMarker|28|false|false|false||1|URF_UNREAD_FIELD";
		Alert a = new Alert(alert, "\\|", "1.4.3");
		assertTrue(group.getMetricsGroupKey().contains(a.makeMetricsKeyMethod("method")));
	}
	
	public void testSlashes() {
		String testString = "ber\\/src";
		assertEquals("ber/src",testString.replace("\\", ""));
	}
	
	public void testUnicode() {
		String testString = "src&lt;org";
		assertEquals("src/org",testString.replace("&lt;", "/"));
	}

}
