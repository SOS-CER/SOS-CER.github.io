package edu.ncsu.csc.realsearch.main;

import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import junit.framework.TestCase;

public class BenchmarkHistoryMainTest extends TestCase {
	
	BenchmarkHistoryMain main;
	
	protected void setUp() throws Exception {
		super.setUp();
		
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
//	public void testParseMetricsJdom() {
//		main = new BenchmarkHistoryMain("jdom");
//		main.parseMetrics();
//	}
//	
//	public void testParseMetricsImportScrubbers() {
//		main = new BenchmarkHistoryMain("importscrubbers");
//		main.parseMetrics();
//	}
	
	public void testParseHistoryJdom() {
		main = new BenchmarkHistoryMain("jdom");
		main.parseHistory();
	}
	
}
