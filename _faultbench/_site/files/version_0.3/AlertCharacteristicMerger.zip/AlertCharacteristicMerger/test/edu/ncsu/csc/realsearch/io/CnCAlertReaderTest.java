package edu.ncsu.csc.realsearch.io;

import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;

import junit.framework.TestCase;

public class CnCAlertReaderTest extends TestCase {
	
	CnCAlertReader reader;
	JUnitTestReader junitReader;

	protected void setUp() throws Exception {
		super.setUp();
		reader = new CnCAlertReader();
		junitReader = new JUnitTestReader();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testParseFile() {
		ArrayList<Alert> alerts = reader.parseFile("C:\\sarah_workspace\\Subjects\\jdom\\alerts\\cnc\\0351\\jdom-cnc-0.8.6-2009-04-13-1214.cnc.txt", "0351", "jdom");
		assertEquals(24, alerts.size());
		//org\jdom\Element.java:308: Warning: Possible type cast error (Cast)
		//org.jdom.Element: getNamespace(java.lang.String) ...
		Alert a = alerts.get(0);
		assertEquals("jdom", a.getProjectName());
		assertEquals("org/jdom/", a.getPackageName());
		assertEquals("Element.java", a.getFileName());
		assertEquals("getNamespace(java.lang.String)", a.getMethodName());
		assertEquals("Cast", a.getBugType());
		assertEquals("", a.getAlertCategory());
		assertEquals(308, a.getLineNumber());
		assertEquals("", a.getPriority());
		assertEquals("cvs", a.getRepository());
		assertEquals("", a.getSourceHash());
		assertEquals("cnc", a.getMarkerType());
		assertEquals("ElementTest1.java", a.getTestFile());
		
		ArrayList<String> testFiles = junitReader.parseFile("C:\\sarah_workspace\\Subjects\\jdom\\alerts\\cnc\\0351\\jdom-cnc-0.8.6-2009-04-13-1214.junit.txt", "0351", "jdom");
		assertEquals(1, testFiles.size());
		assertEquals("XMLOutputterTest1.java", testFiles.get(0));
	}

}
