package edu.ncsu.csc.realsearch.io;

import edu.ncsu.csc.realsearch.data.MetricsFunction;
import edu.ncsu.csc.realsearch.data.MetricsObject;
import edu.ncsu.csc.realsearch.data.MetricsPackage;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.MetricsDB;
import edu.ncsu.csc.realsearch.main.Constants;
import junit.framework.TestCase;

public class JavaNCSSMetricsXMLReaderTest extends TestCase {
	
	JavaNCSSMetricsXMLReader reader;

	protected void setUp() throws Exception {
		super.setUp();
		CreateDBTables.createMetricsNCSSPackageTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.createMetricsNCSSObjectTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.createMetricsNCSSFunctionTable(DBConnection.getInstance(true).getConnection());
		reader = new JavaNCSSMetricsXMLReader();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		CreateDBTables.destroyMetricsNCSSPackageTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.destroyMetricsNCSSObjectTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.destroyMetricsNCSSFunctionTable(DBConnection.getInstance(true).getConnection());
	}

	public void testParseFile() {
		reader.parseFile(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT + "0176-jdom-contrib-metrics.xml", "0176", "jdom-contrib");
		MetricsPackage metricsPackage = MetricsDB.getMetricsPackage(DBConnection.getInstance(true).getConnection(), "jdom-contrib", "0176", "org.jdom.contrib.output");
		assertEquals("jdom-contrib", metricsPackage.getProjectName());
		assertEquals("0176", metricsPackage.getVersion());
		assertEquals("org.jdom.contrib.output", metricsPackage.getName());
		assertEquals(2, metricsPackage.getClasses());
		assertEquals(8, metricsPackage.getFunctions());
		assertEquals(77, metricsPackage.getNcss());
		assertEquals(1, metricsPackage.getJavadocs());
		assertEquals(8, metricsPackage.getJavadocLines());
		assertEquals(6, metricsPackage.getSingleCommentLines());
		assertEquals(42, metricsPackage.getMultiCommentLines());
		
		MetricsObject metricsObject = MetricsDB.getMetricsObject(DBConnection.getInstance(true).getConnection(), "jdom-contrib", "0176", "org.jdom.contrib.xpath.a.XPathPredicateHandler");
		assertEquals("jdom-contrib", metricsObject.getProjectName());
		assertEquals("0176", metricsObject.getVersion());
		assertEquals("org.jdom.contrib.xpath.a.XPathPredicateHandler", metricsObject.getName());
		assertEquals(22, metricsObject.getNcss());
		assertEquals(7, metricsObject.getFunctions());
		assertEquals(0, metricsObject.getClasses());
		assertEquals(4, metricsObject.getJavadocs());
		
		MetricsFunction metricsFunction = MetricsDB.getMetricsFunction(DBConnection.getInstance(true).getConnection(), "jdom-contrib", "0176", "org.jdom.contrib.beans.JDOMBean.main(String[])");
		assertEquals("jdom-contrib", metricsFunction.getProjectName());
		assertEquals("0176", metricsFunction.getVersion());
		assertEquals("org.jdom.contrib.beans.JDOMBean.main(String[])", metricsFunction.getName());
		assertEquals(14, metricsFunction.getNcss());
		assertEquals(3, metricsFunction.getCcn());
		assertEquals(0, metricsFunction.getJavadocs());
	}
	
	public void testParseFile1() {
		reader.parseFile("test/metrics_ncss_test1.xml", "0176", "jdom-contrib");
		
		MetricsObject metricsObject = MetricsDB.getMetricsObject(DBConnection.getInstance(true).getConnection(), "jdom-contrib", "0176", "org.jdom.contrib.xpath.a.XPathPredicateHandler");
		assertEquals("jdom-contrib", metricsObject.getProjectName());
		assertEquals("0176", metricsObject.getVersion());
		assertEquals("org.jdom.contrib.xpath.a.XPathPredicateHandler", metricsObject.getName());
		assertEquals(22, metricsObject.getNcss());
		assertEquals(7, metricsObject.getFunctions());
		assertEquals(0, metricsObject.getClasses());
		assertEquals(4, metricsObject.getJavadocs());
		
		MetricsFunction metricsFunction = MetricsDB.getMetricsFunction(DBConnection.getInstance(true).getConnection(), "jdom-contrib", "0176", "org.jdom.contrib.beans.JDOMBean.main(String[])");
		assertEquals("jdom-contrib", metricsFunction.getProjectName());
		assertEquals("0176", metricsFunction.getVersion());
		assertEquals("org.jdom.contrib.beans.JDOMBean.main(String[])", metricsFunction.getName());
		assertEquals(14, metricsFunction.getNcss());
		assertEquals(3, metricsFunction.getCcn());
		assertEquals(0, metricsFunction.getJavadocs());
	}

}
