package edu.ncsu.csc.realsearch.io;

import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import junit.framework.TestCase;

public class ChurnReaderTest extends TestCase {
	
	protected void setUp() throws Exception {
		super.setUp();
		CreateDBTables.createChurnTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.createHistoryTable(DBConnection.getInstance(true).getConnection());
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		CreateDBTables.destroyChurnTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.destroyChurnTable(DBConnection.getInstance(true).getConnection());
		Alerts.getInstance().clearAlerts();
	}

	public void testReadChurnFromDelimitedFile() {
//		HistoryReader hReader = new HistoryReader();
//		hReader.readHistoryFromDelimitedFile(projectRoot + "history.csv", ",", true);
//		reader.readChurnFromDelimitedFile(projectRoot + "diff-0.1.0-1.0.0.txt", ",", true, "0.1.0", "1.0.0");
//		assertEquals(31,ChurnDB.getInsertedFromFile(DBConnection.getInstance(true).getConnection(), "importscrubber-1.0.0/importscrubber/etc/FunctionalTest.java", 1));
//		assertEquals(10,ChurnDB.getDeletedFromFile(DBConnection.getInstance(true).getConnection(), "importscrubber-1.0.0/importscrubber/etc/FunctionalTest.java", 1));
//		assertEquals(0,ChurnDB.getModifiedFromFile(DBConnection.getInstance(true).getConnection(), "importscrubber-1.0.0/importscrubber/etc/FunctionalTest.java", 1));
//		assertEquals(new Churn(testChurn, ",", "0.1.0", "1.0.0"), ChurnHash.getInstance().getFromHash("importscrubber-1.0.0/importscrubber/etc/FunctionalTest.java-0.1.0-1.0.0"));
	}

}
