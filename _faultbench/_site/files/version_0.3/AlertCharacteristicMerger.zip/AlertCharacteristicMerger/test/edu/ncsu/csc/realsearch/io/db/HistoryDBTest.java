package edu.ncsu.csc.realsearch.io.db;

import java.io.File;
import java.util.ArrayList;

import edu.ncsu.csc.realsearch.io.StatusReader;
import edu.ncsu.csc.realsearch.main.Constants;
import edu.ncsu.csc.realsearch.parser.main.CVSParser;
import junit.framework.TestCase;

public class HistoryDBTest extends TestCase {
	
	protected void setUp() throws Exception {
		super.setUp();
		CreateDBTables.createHistoryTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.createCommitsTable(DBConnection.getInstance(true).getConnection());
		CreateDBTables.createVersionStatusTable(DBConnection.getInstance(true).getConnection());
		CVSParser parser = new CVSParser();
		parser.parse("jdom", Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.HISTORY_ROOT + "jdom-all.log", DBConnection.getInstance(false).getConnection());
		StatusReader reader = new StatusReader();
		reader.readStatus("jdom", new File(Constants.PROJECT_ROOT + "/" + Constants.JDOM_ROOT + "/collector.txt"));
		HistoryDB.addDatesToCommitsTable(DBConnection.getInstance(true).getConnection(), "jdom");
	}

	protected void tearDown() throws Exception {
		super.tearDown();
//		CreateDBTables.destroyHistoryTable(DBConnection.getInstance(true).getConnection());
//		CreateDBTables.destroyCommitsTable(DBConnection.getInstance(true).getConnection());
//		CreateDBTables.destroyStatusTable(DBConnection.getInstance(true).getConnection());
//		CreateDBTables.destroyCVSFilesTable(DBConnection.getInstance(true).getConnection());
//		CreateDBTables.destroyCVSRevisionTable(DBConnection.getInstance(true).getConnection());
	}

	public void testAddDatesToCommitsTable() {
		assertEquals("2000/05/27 22:33", HistoryDB.getCommitDateFromCommitNumber(DBConnection.getInstance(true).getConnection(), "jdom", 2));
	}
	
	public void testGetLastPassingRevisionFromRevision() {
		assertEquals(1, HistoryDB.getLastPassingRevisionFromRevision(DBConnection.getInstance(true).getConnection(), "jdom", 226));
		assertEquals(226, HistoryDB.getLastPassingRevisionFromRevision(DBConnection.getInstance(true).getConnection(), "jdom", 251));
	}
	
	public void testGetDateForRevision() {
		assertEquals("2000/08/20 00:25", HistoryDB.getDateForRevision(DBConnection.getInstance(true).getConnection(), "jdom", 176));
		assertEquals("2000/08/29 18:03", HistoryDB.getDateForRevision(DBConnection.getInstance(true).getConnection(), "jdom", 201));
	}
	
	public void testGetDeveloperForFileInRevision() {
		ArrayList<String> developers = HistoryDB.getDevelopersForFileInRevision(DBConnection.getInstance(true).getConnection(), 176, "jdom", "org/jdom/Attribute.java");
		assertEquals(5, developers.size());
		assertEquals("bmclaugh", developers.get(0));
		assertEquals("jhunter", developers.get(1));
		
		developers = HistoryDB.getDevelopersForFileInRevision(DBConnection.getInstance(true).getConnection(), 201, "jdom", "org/jdom/Element.java");
		assertEquals(1, developers.size());
		assertEquals("jhunter", developers.get(0));
	}
	
	public void testGetFileCreationRevision() {
		assertEquals(4, HistoryDB.getFileCreationRevision(DBConnection.getInstance(true).getConnection(), "jdom", "org/jdom/Attribute.java"));
		assertEquals(52, HistoryDB.getFileCreationRevision(DBConnection.getInstance(true).getConnection(), "jdom-contrib", "org/jdom/contrib/input/ResultSetBuilder.java"));
	}

	public void testGetFileDeletionRevision() {
		assertEquals(825, HistoryDB.getFileDeletionRevision(DBConnection.getInstance(false).getConnection(), "jdom-contrib", "org/jdom/contrib/input/SpitfireBuilder.java"));
	}
	
	public void testGetLatestFileModificationRevision() {
		assertEquals(175, HistoryDB.getLatestFileModificationRevision(DBConnection.getInstance(false).getConnection(), "jdom", "org/jdom/Attribute.java", 176));
		assertEquals(185, HistoryDB.getLatestFileModificationRevision(DBConnection.getInstance(false).getConnection(), "jdom", "org/jdom/Element.java", 201));
	}
	
	public void testGetFileAddedLines() {
		assertEquals(103, HistoryDB.getAddedLines(DBConnection.getInstance(true).getConnection(), "jdom", "org/jdom/Attribute.java", 176));
		assertEquals(5, HistoryDB.getAddedLines(DBConnection.getInstance(true).getConnection(), "jdom", "org/jdom/Element.java", 201));
	}
	
	public void testGetFileDeletedLines() {
		assertEquals(283, HistoryDB.getDeletedLines(DBConnection.getInstance(true).getConnection(), "jdom", "org/jdom/Attribute.java", 176));
		assertEquals(0, HistoryDB.getDeletedLines(DBConnection.getInstance(true).getConnection(), "jdom", "org/jdom/Element.java", 201));
	}
	
	public void testGetAllChurnedLines() {
		assertEquals(12023, HistoryDB.getAllChurnedLines(DBConnection.getInstance(false).getConnection(), "jdom", 176));
	}

}
