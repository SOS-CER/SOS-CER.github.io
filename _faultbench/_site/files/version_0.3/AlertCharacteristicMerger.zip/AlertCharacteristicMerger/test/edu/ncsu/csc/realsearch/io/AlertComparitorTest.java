package edu.ncsu.csc.realsearch.io;

import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.main.Constants;
import junit.framework.TestCase;

public class AlertComparitorTest extends TestCase {

	AlertComparitor comp;
		
	protected void setUp() throws Exception {
		super.setUp();
		comp = new AlertComparitor();
		CreateDBTables.createHistoryTable(DBConnection.getInstance(false).getConnection());
		HistoryReader reader = new HistoryReader();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		CreateDBTables.destroyHistoryTable(DBConnection.getInstance(false).getConnection());
		Alerts.getInstance().clearAlerts();
	}

	public void testCompareAlerts() {
		ArrayList<Alert> alerts = Alerts.getInstance().getAlerts();
		assertEquals(0, alerts.size());
		comp.compareAlerts("test/alerts_test1.csv", "\\|", false, "0.1.0","");
		alerts = Alerts.getInstance().getAlerts();
		assertEquals(2, alerts.size());
		assertEquals(0,alerts.get(0).getOpenRevision());
		
		comp.compareAlerts("test/alerts_test2.csv", "\\|", false, "1.0.0","");
		alerts = Alerts.getInstance().getAlerts();
		assertEquals(2, alerts.size());
		assertEquals(0,alerts.get(0).getOpenRevision());
		assertEquals(-1, alerts.get(0).getCloseRevision());
		assertEquals(0,alerts.get(1).getOpenRevision());
		assertEquals(1, alerts.get(1).getCloseRevision());
		assertEquals(1, alerts.get(0).getNumAlertModifications());
	}
	
	

}
