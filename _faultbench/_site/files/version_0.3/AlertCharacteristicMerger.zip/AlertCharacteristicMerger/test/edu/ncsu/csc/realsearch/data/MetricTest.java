package edu.ncsu.csc.realsearch.data;

import junit.framework.TestCase;

public class MetricTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		Alerts.getInstance().clearAlerts();
	}

//	public void testMetric() {
//		fail("Not yet implemented");
//	}

}
