package edu.ncsu.csc.realsearch.io;

import java.util.HashMap;

import junit.framework.TestCase;
import edu.ncsu.csc.realsearch.data.Alerts;
import edu.ncsu.csc.realsearch.io.db.CreateDBTables;
import edu.ncsu.csc.realsearch.io.db.DBConnection;
import edu.ncsu.csc.realsearch.io.db.MetricsDB;
import edu.ncsu.csc.realsearch.main.Constants;

public class MetricsReaderTest extends TestCase {
	
	private MetricsXmlReader reader;

	protected void setUp() throws Exception {
		super.setUp();
		CreateDBTables.createMetricsTable(DBConnection.getInstance(true).getConnection());
		reader = new MetricsXmlReader();
		createMethodSignatureHashMap();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
		CreateDBTables.destroyMetricsTable(DBConnection.getInstance(true).getConnection());
		Alerts.getInstance().clearAlerts();
	}
	
	private void createMethodSignatureHashMap() {
		Constants.primitatives = new HashMap<String, String>();
		Constants.primitatives.put("Z", "boolean");
		Constants.primitatives.put("B", "byte");
		Constants.primitatives.put("C", "char");
		Constants.primitatives.put("D", "double");
		Constants.primitatives.put("F", "float");
		Constants.primitatives.put("I", "int");
		Constants.primitatives.put("J", "long");
		Constants.primitatives.put("L", "object");
		Constants.primitatives.put("S", "short");
		Constants.primitatives.put("V", "void");
		Constants.primitatives.put("[", "array");
	}

	public void testReadChurnFromDelimitedFile() {
//		reader.parseFile(Constants.PROJECT_ROOT + "/" + Constants.IMPORTSCRUBBER_ROOT + "/" + "importscrubber-1.4.3-metrics.xml","1.4.3");
//		assertEquals(5.0, MetricsDB.getValueForHandleVersionMetric(DBConnection.getInstance(true).getConnection(),"=importscrubbers", "1.4.3", "NORM"));
	}
	
	public void testReadChurnFromDelimitedFile2() {
		reader.parseFile("./test/metrics_test1.xml", "1.4.3");
		assertEquals(0.812, MetricsDB.getAvgForHandleVersionMetric(DBConnection.getInstance(false).getConnection(),"=importscrubbers/importscrubber/src/org/apache/tools/ant/taskdefs/optional/importscrubber", "1.4.3", "LCOM"));
	}
	
	public void testReadChurnFromDelimitedFile3() {
		reader.parseFile("./test/metrics_test2.xml", "1.4.3");
		assertEquals(-1.0, MetricsDB.getValueForHandleVersionMetric(DBConnection.getInstance(false).getConnection(),"=importscrubbers/", "1.4.3", "RMD"));
	}
	
	public void testReadChurnFromDelimitedFile4() {
		System.out.println(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT + "0176-jdom-metrics.xml");
		reader.parseFile(Constants.PROJECT_ROOT + Constants.JDOM_ROOT + Constants.METRICS_ROOT + "0176-jdom-metrics.xml", "0179");
		assertEquals(62.0, MetricsDB.getValueForHandleVersionMetric(DBConnection.getInstance(false).getConnection(),"=jdom", "0179", "NORM"));
	}
	

}
