package edu.ncsu.csc.realsearch.io;

import java.util.ArrayList;

import edu.ncsu.csc.realsearch.data.Alert;

import junit.framework.TestCase;

public class PMDAlertXMLReaderTest extends TestCase {
	
	PMDAlertXMLReader reader;

	protected void setUp() throws Exception {
		super.setUp();
		reader = new PMDAlertXMLReader();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

//	<violation beginline="46" endline="46" begincolumn="1" endcolumn="27" rule="UnusedImports" ruleset="Import Statement Rules" package="org.jdom.contrib.beans" externalInfoUrl="http://pmd.sourceforge.net/rules/imports.html#UnusedImports" priority="4">
//	Avoid unused imports such as 'java.io.PrintStream'
//	</violation>
	public void testParseFile() {
		ArrayList<Alert> alerts = reader.parseFile("C:/sarah_workspace/Subjects/jdom/alerts/pmd/0226-jdom-contrib-pmd-alerts.xml", "0226", "jdom-contrib");
		assertEquals(2083, alerts.size());
		Alert a = alerts.get(0);
		assertEquals(46, a.getLineNumber());
		assertEquals("\nAvoid unused imports such as \'java.io.PrintStream\'\n", a.getDescription());
		assertEquals("UnusedImports", a.getBugType());
		assertEquals("Import Statement Rules", a.getAlertCategory());
		assertEquals("org.jdom.contrib.beans", a.getPackageName());
		assertNull(a.getFileName());
		assertNull(a.getMethodName());
		assertEquals("4", a.getPriority());
	}

}
