package edu.ncsu.csc.realsearch.io;

import java.util.ArrayList;
import java.util.HashMap;

import edu.ncsu.csc.realsearch.data.Alert;
import edu.ncsu.csc.realsearch.main.Constants;
import junit.framework.TestCase;

public class AlertXMLReaderTest extends TestCase {
	
	AlertXMLReader reader;

	protected void setUp() throws Exception {
		super.setUp();
		reader = new AlertXMLReader();
		createMethodSignatureHashMap();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	private void createMethodSignatureHashMap() {
		Constants.primitatives = new HashMap<String, String>();
		Constants.primitatives.put("Z", "boolean");
		Constants.primitatives.put("B", "byte");
		Constants.primitatives.put("C", "char");
		Constants.primitatives.put("D", "double");
		Constants.primitatives.put("F", "float");
		Constants.primitatives.put("I", "int");
		Constants.primitatives.put("J", "long");
		Constants.primitatives.put("L", "object");
		Constants.primitatives.put("S", "short");
		Constants.primitatives.put("V", "void");
		Constants.primitatives.put("[", "array");
	}

	public void testParseFile() {
		ArrayList<Alert> alerts = reader.parseFile("./test/alerts_test1.xml", "0179", "jdom");
		assertEquals(3, alerts.size());
		assertEquals("CN_IDIOM_NO_SUPER_CALL", alerts.get(0).getBugType());
		assertEquals("BAD_PRACTICE", alerts.get(0).getAlertCategory());
		assertEquals("cd2aa7c18ce14506fabc735751db6bd1", alerts.get(0).getSourceHash());
		assertEquals("org.jdom.Attribute.clone() does not call super.clone()", alerts.get(0).getDescription());
		assertEquals("Attribute.java", alerts.get(0).getFileName());
		assertEquals("jdom", alerts.get(0).getProjectName());
		assertEquals("org/jdom/", alerts.get(0).getPackageName());
		assertEquals("clone()", alerts.get(0).getMethodName());
		assertEquals(353, alerts.get(0).getLineNumber());
		
		assertEquals("DM_CONVERT_CASE", alerts.get(1).getBugType());
		assertEquals("I18N", alerts.get(1).getAlertCategory());
		assertEquals("2108beca1117185e8cf5c9d736f66401", alerts.get(1).getSourceHash());
		assertEquals("Use of non-localized String.toUpperCase() or String.toLowerCase", alerts.get(1).getDescription());
		assertEquals("ResultSetBuilder.java", alerts.get(1).getFileName());
		assertEquals("jdom", alerts.get(1).getProjectName());
		assertEquals("org/jdom/contrib/input/", alerts.get(1).getPackageName());
		assertEquals("setAsAttribute(String,String)", alerts.get(1).getMethodName());
		assertEquals(183, alerts.get(1).getLineNumber());
	}
	
	public void testParseFile2() {
		ArrayList<Alert> alerts = reader.parseFile("C:/Documents and Settings/Sarah Smith/My Documents/Research/Experiments/2009_ICSE/BenchmarkHistory/jdom/alerts/0176-jdom-alerts.xml", "0179", "jdom");
		assertEquals(26, alerts.size());
		assertEquals("CN_IDIOM_NO_SUPER_CALL", alerts.get(0).getBugType());
		assertEquals("BAD_PRACTICE", alerts.get(0).getAlertCategory());
		assertEquals("cd2aa7c18ce14506fabc735751db6bd1", alerts.get(0).getSourceHash());
		assertEquals("org.jdom.Attribute.clone() does not call super.clone()", alerts.get(0).getDescription());
		assertEquals("Attribute.java", alerts.get(0).getFileName());
		assertEquals("jdom", alerts.get(0).getProjectName());
		assertEquals("org/jdom/", alerts.get(0).getPackageName());
		assertEquals("clone()", alerts.get(0).getMethodName());
		assertEquals(353, alerts.get(0).getLineNumber());
	}

	public void testMakeMethodSignature1() {
		//name="clone" signature="()Ljava/lang/Object;"
		assertEquals("clone()",reader.makeMethodSignature("clone", "()Ljava/lang/Object;"));
	}
	
	public void testMakeMethodSignature2() {
		//name="setAsAttribute" signature="(Ljava/lang/String;Ljava/lang/String;)V"
		assertEquals("setAsAttribute(String,String)",reader.makeMethodSignature("setAsAttribute", "(Ljava/lang/String;Ljava/lang/String;)V"));
	}
	
	public void testMakeMethodSignature3() {
		//name="setAsAttribute" signature="(Ljava/lang/String;)V"
		assertEquals("setAsAttribute(String)",reader.makeMethodSignature("setAsAttribute", "(Ljava/lang/String;)V"));
	}
	
	public void testMakeMethodSignature4() {
		//name="setAsAttribute" signature="(ILjava/lang/String;)V" 
		assertEquals("setAsAttribute(int,String)",reader.makeMethodSignature("setAsAttribute", "(ILjava/lang/String;)V"));
	}

}
