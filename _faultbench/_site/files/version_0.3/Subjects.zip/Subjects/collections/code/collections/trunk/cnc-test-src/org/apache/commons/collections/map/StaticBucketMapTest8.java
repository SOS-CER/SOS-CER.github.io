package org.apache.commons.collections.map;

public class StaticBucketMapTest8 extends edu.gatech.cc.junit.FilteringTestCase {

	protected String getNameOfTestedMeth() {
		return "org.apache.commons.collections.map.StaticBucketMap.hashCode";
	}

	public StaticBucketMapTest8(String pName) {
		super(pName);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(StaticBucketMapTest8.class);
	}

	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(StaticBucketMapTest8.class);
	}

	/**
	 * Executed before each testX().
	 * Resets static fields of each user class (except this).
	 */
	protected void setUp() {
		edu.gatech.cc.junit.reinit.ClassRegistry.resetClasses();	//re-initialize static fields of previously loaded classes
		//my setUp() code goes here..
	}

	/**
	 * Executed after each testX()
	 */
	protected void tearDown() {
		//my tearDown() code goes here..
	}



	/********** Generated testcases **********/

	public void test0() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test1() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test2() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test3() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test4() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test5() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test6() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test7() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test8() throws Throwable {
		try {
			StaticBucketMap s1 = (StaticBucketMap)null;
			int i2 = s1.hashCode();
		}
		catch (Exception e) {dispatchException(e);}
	}

}