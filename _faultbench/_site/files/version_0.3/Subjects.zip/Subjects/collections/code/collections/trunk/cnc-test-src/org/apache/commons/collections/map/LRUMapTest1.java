package org.apache.commons.collections.map;

public class LRUMapTest1 extends edu.gatech.cc.junit.FilteringTestCase {

	protected String getNameOfTestedMeth() {
		return "org.apache.commons.collections.map.LRUMap.get";
	}

	public LRUMapTest1(String pName) {
		super(pName);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(LRUMapTest1.class);
	}

	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(LRUMapTest1.class);
	}

	/**
	 * Executed before each testX().
	 * Resets static fields of each user class (except this).
	 */
	protected void setUp() {
		edu.gatech.cc.junit.reinit.ClassRegistry.resetClasses();	//re-initialize static fields of previously loaded classes
		//my setUp() code goes here..
	}

	/**
	 * Executed after each testX()
	 */
	protected void tearDown() {
		//my tearDown() code goes here..
	}



	/********** Generated testcases **********/

	public void test0() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test1() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test2() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test3() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test4() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test5() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test6() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test7() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test8() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test9() throws Throwable {
		try {
			java.lang.Object o4 = (java.lang.Object)null;
			LRUMap l2 = (LRUMap)null;
			java.lang.Object o3 = l2.get(o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

}