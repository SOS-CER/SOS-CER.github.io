package org.apache.commons.collections.comparators;

public class FixedOrderComparatorTest extends junit.framework.TestCase {

	public FixedOrderComparatorTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(FixedOrderComparatorTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(FixedOrderComparatorTest1.class);
		suite.addTestSuite(FixedOrderComparatorTest2.class);
		return suite;
	}

}