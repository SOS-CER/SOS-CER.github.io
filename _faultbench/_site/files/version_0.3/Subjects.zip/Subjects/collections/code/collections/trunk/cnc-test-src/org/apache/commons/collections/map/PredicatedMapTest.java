package org.apache.commons.collections.map;

public class PredicatedMapTest extends junit.framework.TestCase {

	public PredicatedMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(PredicatedMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(PredicatedMapTest1.class);
		return suite;
	}

}