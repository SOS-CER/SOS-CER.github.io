package org.apache.commons.collections.map;

public class AbstractHashedMapTest extends junit.framework.TestCase {

	public AbstractHashedMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AbstractHashedMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(AbstractHashedMapTest1.class);
		suite.addTestSuite(AbstractHashedMapTest2.class);
		suite.addTestSuite(AbstractHashedMapTest3.class);
		suite.addTestSuite(AbstractHashedMapTest4.class);
		suite.addTestSuite(AbstractHashedMapTest5.class);
		return suite;
	}

}