package org.apache.commons.collections.map;

public class StaticBucketMapTest extends junit.framework.TestCase {

	public StaticBucketMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(StaticBucketMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(StaticBucketMapTest1.class);
		suite.addTestSuite(StaticBucketMapTest2.class);
		suite.addTestSuite(StaticBucketMapTest3.class);
		suite.addTestSuite(StaticBucketMapTest4.class);
		suite.addTestSuite(StaticBucketMapTest5.class);
		suite.addTestSuite(StaticBucketMapTest6.class);
		suite.addTestSuite(StaticBucketMapTest7.class);
		suite.addTestSuite(StaticBucketMapTest8.class);
		return suite;
	}

}