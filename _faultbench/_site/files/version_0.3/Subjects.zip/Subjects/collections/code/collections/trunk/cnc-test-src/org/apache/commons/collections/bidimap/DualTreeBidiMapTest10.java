package org.apache.commons.collections.bidimap;

public class DualTreeBidiMapTest10 extends edu.gatech.cc.junit.FilteringTestCase {

	protected String getNameOfTestedMeth() {
		return "org.apache.commons.collections.bidimap.DualTreeBidiMap.subMap";
	}

	public DualTreeBidiMapTest10(String pName) {
		super(pName);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(DualTreeBidiMapTest10.class);
	}

	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(DualTreeBidiMapTest10.class);
	}

	/**
	 * Executed before each testX().
	 * Resets static fields of each user class (except this).
	 */
	protected void setUp() {
		edu.gatech.cc.junit.reinit.ClassRegistry.resetClasses();	//re-initialize static fields of previously loaded classes
		//my setUp() code goes here..
	}

	/**
	 * Executed after each testX()
	 */
	protected void tearDown() {
		//my tearDown() code goes here..
	}



	/********** Generated testcases **********/

	public void test0() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			char[] c7 = "".toCharArray();
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, c7);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test1() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			byte[] b7 = "".getBytes("`'@#$%^&/({<[|\n:.,;");
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, b7);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test2() throws Throwable {
		try {
			byte[] b7 = "".getBytes("`'@#$%^&/({<[|\n:.,;");
			byte[] b8 = "".getBytes("");
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(b7, b8);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test3() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			java.lang.Object o4 = new java.lang.Object();
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test4() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			byte[] b7 = "`'@#$%^&/({<[|\n:.,;".getBytes("`'@#$%^&/({<[|\n:.,;");
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, b7);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test5() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			java.lang.Object o4 = new java.lang.Object();
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test6() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			java.lang.Object o4 = new java.lang.Object();
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test7() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			java.lang.Object o4 = new java.lang.Object();
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test8() throws Throwable {
		try {
			byte[] b7 = "`'@#$%^&/({<[|\n:.,;".getBytes("`'@#$%^&/({<[|\n:.,;");
			java.lang.Object o4 = new java.lang.Object();
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(b7, o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test9() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			java.lang.Object o4 = new java.lang.Object();
			DualTreeBidiMap d5 = (DualTreeBidiMap)null;
			java.util.SortedMap s6 = d5.subMap(o2, o4);
		}
		catch (Exception e) {dispatchException(e);}
	}

}