package org.apache.commons.collections.buffer;

public class PriorityBufferTest extends junit.framework.TestCase {

	public PriorityBufferTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(PriorityBufferTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(PriorityBufferTest1.class);
		suite.addTestSuite(PriorityBufferTest2.class);
		suite.addTestSuite(PriorityBufferTest3.class);
		return suite;
	}

}