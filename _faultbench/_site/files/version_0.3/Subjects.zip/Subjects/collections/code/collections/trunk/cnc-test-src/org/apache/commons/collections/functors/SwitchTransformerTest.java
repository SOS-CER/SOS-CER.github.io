package org.apache.commons.collections.functors;

public class SwitchTransformerTest extends junit.framework.TestCase {

	public SwitchTransformerTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(SwitchTransformerTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(SwitchTransformerTest1.class);
		suite.addTestSuite(SwitchTransformerTest2.class);
		return suite;
	}

}