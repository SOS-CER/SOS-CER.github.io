package org.apache.commons.collections.bag;

public class TreeBagTest extends junit.framework.TestCase {

	public TreeBagTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(TreeBagTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(TreeBagTest1.class);
		suite.addTestSuite(TreeBagTest2.class);
		suite.addTestSuite(TreeBagTest3.class);
		return suite;
	}

}