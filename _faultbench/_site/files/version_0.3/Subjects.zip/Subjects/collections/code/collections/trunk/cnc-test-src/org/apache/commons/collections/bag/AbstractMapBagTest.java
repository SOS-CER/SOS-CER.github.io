package org.apache.commons.collections.bag;

public class AbstractMapBagTest extends junit.framework.TestCase {

	public AbstractMapBagTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AbstractMapBagTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(AbstractMapBagTest1.class);
		suite.addTestSuite(AbstractMapBagTest2.class);
		suite.addTestSuite(AbstractMapBagTest3.class);
		suite.addTestSuite(AbstractMapBagTest4.class);
		suite.addTestSuite(AbstractMapBagTest5.class);
		suite.addTestSuite(AbstractMapBagTest6.class);
		suite.addTestSuite(AbstractMapBagTest7.class);
		return suite;
	}

}