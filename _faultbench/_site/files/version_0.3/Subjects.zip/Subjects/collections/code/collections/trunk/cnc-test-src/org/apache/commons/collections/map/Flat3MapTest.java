package org.apache.commons.collections.map;

public class Flat3MapTest extends junit.framework.TestCase {

	public Flat3MapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(Flat3MapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(Flat3MapTest1.class);
		suite.addTestSuite(Flat3MapTest2.class);
		return suite;
	}

}