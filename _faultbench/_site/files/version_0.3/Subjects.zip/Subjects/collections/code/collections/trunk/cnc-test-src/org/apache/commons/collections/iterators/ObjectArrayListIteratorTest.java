package org.apache.commons.collections.iterators;

public class ObjectArrayListIteratorTest extends junit.framework.TestCase {

	public ObjectArrayListIteratorTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ObjectArrayListIteratorTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(ObjectArrayListIteratorTest1.class);
		suite.addTestSuite(ObjectArrayListIteratorTest2.class);
		suite.addTestSuite(ObjectArrayListIteratorTest3.class);
		return suite;
	}

}