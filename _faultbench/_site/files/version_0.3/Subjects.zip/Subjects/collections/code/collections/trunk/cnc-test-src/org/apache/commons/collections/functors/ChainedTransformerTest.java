package org.apache.commons.collections.functors;

public class ChainedTransformerTest extends junit.framework.TestCase {

	public ChainedTransformerTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ChainedTransformerTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(ChainedTransformerTest1.class);
		return suite;
	}

}