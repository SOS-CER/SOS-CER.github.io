package org.apache.commons.collections.iterators;

public class ObjectArrayListIteratorTest3 extends edu.gatech.cc.junit.FilteringTestCase {

	protected String getNameOfTestedMeth() {
		return "org.apache.commons.collections.iterators.ObjectArrayListIterator.set";
	}

	public ObjectArrayListIteratorTest3(String pName) {
		super(pName);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ObjectArrayListIteratorTest3.class);
	}

	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(ObjectArrayListIteratorTest3.class);
	}

	/**
	 * Executed before each testX().
	 * Resets static fields of each user class (except this).
	 */
	protected void setUp() {
		edu.gatech.cc.junit.reinit.ClassRegistry.resetClasses();	//re-initialize static fields of previously loaded classes
		//my setUp() code goes here..
	}

	/**
	 * Executed after each testX()
	 */
	protected void tearDown() {
		//my tearDown() code goes here..
	}



	/********** Generated testcases **********/

	public void test0() throws Throwable {
		try {
			byte[] b5 = "".getBytes("`'@#$%^&/({<[|\n:.,;");
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(b5);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test1() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test2() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test3() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test4() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test5() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test6() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test7() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test8() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

	public void test9() throws Throwable {
		try {
			java.lang.Object o2 = new java.lang.Object();
			ObjectArrayListIterator o3 = (ObjectArrayListIterator)null;
			o3.set(o2);
		}
		catch (Exception e) {dispatchException(e);}
	}

}