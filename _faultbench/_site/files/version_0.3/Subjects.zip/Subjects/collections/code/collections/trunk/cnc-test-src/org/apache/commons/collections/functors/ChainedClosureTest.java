package org.apache.commons.collections.functors;

public class ChainedClosureTest extends junit.framework.TestCase {

	public ChainedClosureTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ChainedClosureTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(ChainedClosureTest1.class);
		return suite;
	}

}