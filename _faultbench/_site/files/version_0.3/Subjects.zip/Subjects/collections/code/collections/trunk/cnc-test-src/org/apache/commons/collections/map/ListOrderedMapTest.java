package org.apache.commons.collections.map;

public class ListOrderedMapTest extends junit.framework.TestCase {

	public ListOrderedMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ListOrderedMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(ListOrderedMapTest1.class);
		suite.addTestSuite(ListOrderedMapTest2.class);
		suite.addTestSuite(ListOrderedMapTest3.class);
		return suite;
	}

}