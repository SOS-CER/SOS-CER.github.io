package org.apache.commons.collections.bidimap;

public class AbstractDualBidiMapTest extends junit.framework.TestCase {

	public AbstractDualBidiMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AbstractDualBidiMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(AbstractDualBidiMapTest1.class);
		return suite;
	}

}