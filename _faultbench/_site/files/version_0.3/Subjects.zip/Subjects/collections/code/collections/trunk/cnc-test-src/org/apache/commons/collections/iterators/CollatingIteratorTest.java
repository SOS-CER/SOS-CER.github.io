package org.apache.commons.collections.iterators;

public class CollatingIteratorTest extends junit.framework.TestCase {

	public CollatingIteratorTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(CollatingIteratorTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(CollatingIteratorTest1.class);
		suite.addTestSuite(CollatingIteratorTest2.class);
		return suite;
	}

}