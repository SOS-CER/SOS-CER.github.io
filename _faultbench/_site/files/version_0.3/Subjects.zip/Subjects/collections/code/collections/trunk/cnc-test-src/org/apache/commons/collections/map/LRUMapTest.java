package org.apache.commons.collections.map;

public class LRUMapTest extends junit.framework.TestCase {

	public LRUMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(LRUMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(LRUMapTest1.class);
		return suite;
	}

}