package org.apache.commons.collections.buffer;

public class BoundedFifoBufferTest extends junit.framework.TestCase {

	public BoundedFifoBufferTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(BoundedFifoBufferTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(BoundedFifoBufferTest1.class);
		suite.addTestSuite(BoundedFifoBufferTest2.class);
		suite.addTestSuite(BoundedFifoBufferTest3.class);
		return suite;
	}

}