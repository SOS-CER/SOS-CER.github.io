package org.apache.commons.collections.buffer;

public class UnboundedFifoBufferTest extends junit.framework.TestCase {

	public UnboundedFifoBufferTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(UnboundedFifoBufferTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(UnboundedFifoBufferTest1.class);
		suite.addTestSuite(UnboundedFifoBufferTest2.class);
		suite.addTestSuite(UnboundedFifoBufferTest3.class);
		return suite;
	}

}