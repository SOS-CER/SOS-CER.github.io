package org.apache.commons.collections.comparators;

public class ComparatorChainTest extends junit.framework.TestCase {

	public ComparatorChainTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ComparatorChainTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(ComparatorChainTest1.class);
		suite.addTestSuite(ComparatorChainTest2.class);
		return suite;
	}

}