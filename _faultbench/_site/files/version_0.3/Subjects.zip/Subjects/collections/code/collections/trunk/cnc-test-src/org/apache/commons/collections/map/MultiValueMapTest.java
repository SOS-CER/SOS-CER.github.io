package org.apache.commons.collections.map;

public class MultiValueMapTest extends junit.framework.TestCase {

	public MultiValueMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(MultiValueMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(MultiValueMapTest1.class);
		suite.addTestSuite(MultiValueMapTest2.class);
		suite.addTestSuite(MultiValueMapTest3.class);
		suite.addTestSuite(MultiValueMapTest4.class);
		return suite;
	}

}