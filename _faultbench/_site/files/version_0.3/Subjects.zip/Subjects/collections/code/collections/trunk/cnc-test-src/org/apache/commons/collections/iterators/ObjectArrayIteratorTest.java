package org.apache.commons.collections.iterators;

public class ObjectArrayIteratorTest extends junit.framework.TestCase {

	public ObjectArrayIteratorTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ObjectArrayIteratorTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(ObjectArrayIteratorTest1.class);
		return suite;
	}

}