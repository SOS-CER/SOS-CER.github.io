package org.apache.commons.collections.map;

public class SingletonMapTest extends junit.framework.TestCase {

	public SingletonMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(SingletonMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(SingletonMapTest1.class);
		suite.addTestSuite(SingletonMapTest2.class);
		suite.addTestSuite(SingletonMapTest3.class);
		return suite;
	}

}