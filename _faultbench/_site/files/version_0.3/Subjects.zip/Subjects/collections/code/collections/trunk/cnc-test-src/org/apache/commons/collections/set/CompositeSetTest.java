package org.apache.commons.collections.set;

public class CompositeSetTest extends junit.framework.TestCase {

	public CompositeSetTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(CompositeSetTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(CompositeSetTest1.class);
		suite.addTestSuite(CompositeSetTest2.class);
		return suite;
	}

}