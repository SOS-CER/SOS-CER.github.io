package org.apache.commons.collections.buffer;

public class BoundedFifoBufferTest1 extends edu.gatech.cc.junit.FilteringTestCase {

	public BoundedFifoBufferTest1(String pName) {
		super(pName);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(BoundedFifoBufferTest1.class);
	}

	public static junit.framework.Test suite() {
		return new junit.framework.TestSuite(BoundedFifoBufferTest1.class);
	}

	/**
	 * Executed before each testX().
	 * Resets static fields of each user class (except this).
	 */
	protected void setUp() {
		edu.gatech.cc.junit.reinit.ClassRegistry.resetClasses();	//re-initialize static fields of previously loaded classes
		//my setUp() code goes here..
	}

	/**
	 * Executed after each testX()
	 */
	protected void tearDown() {
		//my tearDown() code goes here..
	}



	/********** Generated testcases **********/

}