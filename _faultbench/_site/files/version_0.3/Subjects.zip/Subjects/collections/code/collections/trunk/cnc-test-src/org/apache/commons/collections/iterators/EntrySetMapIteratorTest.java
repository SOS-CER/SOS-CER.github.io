package org.apache.commons.collections.iterators;

public class EntrySetMapIteratorTest extends junit.framework.TestCase {

	public EntrySetMapIteratorTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(EntrySetMapIteratorTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(EntrySetMapIteratorTest1.class);
		return suite;
	}

}