package org.apache.commons.collections.map;

public class MultiKeyMapTest extends junit.framework.TestCase {

	public MultiKeyMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(MultiKeyMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(MultiKeyMapTest1.class);
		suite.addTestSuite(MultiKeyMapTest2.class);
		suite.addTestSuite(MultiKeyMapTest3.class);
		suite.addTestSuite(MultiKeyMapTest4.class);
		suite.addTestSuite(MultiKeyMapTest5.class);
		suite.addTestSuite(MultiKeyMapTest6.class);
		suite.addTestSuite(MultiKeyMapTest7.class);
		suite.addTestSuite(MultiKeyMapTest8.class);
		suite.addTestSuite(MultiKeyMapTest9.class);
		suite.addTestSuite(MultiKeyMapTest10.class);
		suite.addTestSuite(MultiKeyMapTest11.class);
		suite.addTestSuite(MultiKeyMapTest12.class);
		suite.addTestSuite(MultiKeyMapTest13.class);
		suite.addTestSuite(MultiKeyMapTest14.class);
		suite.addTestSuite(MultiKeyMapTest15.class);
		suite.addTestSuite(MultiKeyMapTest16.class);
		suite.addTestSuite(MultiKeyMapTest17.class);
		suite.addTestSuite(MultiKeyMapTest18.class);
		suite.addTestSuite(MultiKeyMapTest19.class);
		suite.addTestSuite(MultiKeyMapTest20.class);
		suite.addTestSuite(MultiKeyMapTest21.class);
		return suite;
	}

}