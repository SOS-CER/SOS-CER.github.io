package org.apache.commons.collections.list;

public class CursorableLinkedList$CursorTest extends junit.framework.TestCase {

	public CursorableLinkedList$CursorTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(CursorableLinkedList$CursorTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(CursorableLinkedList$CursorTest1.class);
		return suite;
	}

}