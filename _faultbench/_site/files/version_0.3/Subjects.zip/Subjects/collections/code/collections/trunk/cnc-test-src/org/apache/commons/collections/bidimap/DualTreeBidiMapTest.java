package org.apache.commons.collections.bidimap;

public class DualTreeBidiMapTest extends junit.framework.TestCase {

	public DualTreeBidiMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(DualTreeBidiMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(DualTreeBidiMapTest1.class);
		suite.addTestSuite(DualTreeBidiMapTest2.class);
		suite.addTestSuite(DualTreeBidiMapTest3.class);
		suite.addTestSuite(DualTreeBidiMapTest4.class);
		suite.addTestSuite(DualTreeBidiMapTest5.class);
		suite.addTestSuite(DualTreeBidiMapTest6.class);
		suite.addTestSuite(DualTreeBidiMapTest7.class);
		suite.addTestSuite(DualTreeBidiMapTest8.class);
		suite.addTestSuite(DualTreeBidiMapTest9.class);
		suite.addTestSuite(DualTreeBidiMapTest10.class);
		return suite;
	}

}