package org.apache.commons.collections.map;

public class AbstractLinkedMapTest extends junit.framework.TestCase {

	public AbstractLinkedMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AbstractLinkedMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(AbstractLinkedMapTest1.class);
		suite.addTestSuite(AbstractLinkedMapTest2.class);
		return suite;
	}

}