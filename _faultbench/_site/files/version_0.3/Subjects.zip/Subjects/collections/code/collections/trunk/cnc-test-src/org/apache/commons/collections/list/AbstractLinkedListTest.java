package org.apache.commons.collections.list;

public class AbstractLinkedListTest extends junit.framework.TestCase {

	public AbstractLinkedListTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AbstractLinkedListTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(AbstractLinkedListTest1.class);
		suite.addTestSuite(AbstractLinkedListTest2.class);
		return suite;
	}

}