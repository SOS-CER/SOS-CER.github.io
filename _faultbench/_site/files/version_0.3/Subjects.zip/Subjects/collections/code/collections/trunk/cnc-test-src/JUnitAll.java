import junit.framework.*;

/**
 * TestSuite that collects all testcases genereated for all JUnit classes.
 */
public class JUnitAll extends TestSuite {

	public JUnitAll(String pName) {
		super(pName);
	}

	public static Test suite() {
		TestSuite suite = new TestSuite();
		suite.addTest(org.apache.commons.collections.bag.AbstractMapBagTest.suite());
		suite.addTest(org.apache.commons.collections.bag.TreeBagTest.suite());
		suite.addTest(org.apache.commons.collections.bidimap.AbstractDualBidiMapTest.suite());
		suite.addTest(org.apache.commons.collections.bidimap.DualTreeBidiMapTest.suite());
		suite.addTest(org.apache.commons.collections.bidimap.TreeBidiMapTest.suite());
		suite.addTest(org.apache.commons.collections.buffer.BoundedFifoBufferTest.suite());
		suite.addTest(org.apache.commons.collections.buffer.PriorityBufferTest.suite());
		suite.addTest(org.apache.commons.collections.buffer.UnboundedFifoBufferTest.suite());
		suite.addTest(org.apache.commons.collections.collection.CompositeCollectionTest.suite());
		suite.addTest(org.apache.commons.collections.collection.UnmodifiableBoundedCollectionTest.suite());
		suite.addTest(org.apache.commons.collections.comparators.BooleanComparatorTest.suite());
		suite.addTest(org.apache.commons.collections.comparators.ComparableComparatorTest.suite());
		suite.addTest(org.apache.commons.collections.comparators.ComparatorChainTest.suite());
		suite.addTest(org.apache.commons.collections.comparators.FixedOrderComparatorTest.suite());
		suite.addTest(org.apache.commons.collections.comparators.NullComparatorTest.suite());
		suite.addTest(org.apache.commons.collections.comparators.ReverseComparatorTest.suite());
		suite.addTest(org.apache.commons.collections.functors.ChainedClosureTest.suite());
		suite.addTest(org.apache.commons.collections.functors.ChainedTransformerTest.suite());
		suite.addTest(org.apache.commons.collections.functors.SwitchClosureTest.suite());
		suite.addTest(org.apache.commons.collections.functors.SwitchTransformerTest.suite());
		suite.addTest(org.apache.commons.collections.iterators.CollatingIteratorTest.suite());
		suite.addTest(org.apache.commons.collections.iterators.EntrySetMapIteratorTest.suite());
		suite.addTest(org.apache.commons.collections.iterators.IteratorChainTest.suite());
		suite.addTest(org.apache.commons.collections.iterators.ObjectArrayIteratorTest.suite());
		suite.addTest(org.apache.commons.collections.iterators.ObjectArrayListIteratorTest.suite());
		suite.addTest(org.apache.commons.collections.keyvalue.MultiKeyTest.suite());
		suite.addTest(org.apache.commons.collections.list.AbstractLinkedListTest.suite());
		suite.addTest(org.apache.commons.collections.list.CursorableLinkedList$CursorTest.suite());
		suite.addTest(org.apache.commons.collections.map.AbstractHashedMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.AbstractLinkedMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.Flat3MapTest.suite());
		suite.addTest(org.apache.commons.collections.map.ListOrderedMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.LRUMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.MultiKeyMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.MultiValueMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.PredicatedMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.SingletonMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.StaticBucketMapTest.suite());
		suite.addTest(org.apache.commons.collections.map.UnmodifiableEntrySetTest.suite());
		suite.addTest(org.apache.commons.collections.set.CompositeSetTest.suite());
		return suite;
	}
}
