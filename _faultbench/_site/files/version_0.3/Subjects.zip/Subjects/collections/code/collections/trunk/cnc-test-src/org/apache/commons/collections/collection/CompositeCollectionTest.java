package org.apache.commons.collections.collection;

public class CompositeCollectionTest extends junit.framework.TestCase {

	public CompositeCollectionTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(CompositeCollectionTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(CompositeCollectionTest1.class);
		suite.addTestSuite(CompositeCollectionTest2.class);
		suite.addTestSuite(CompositeCollectionTest3.class);
		suite.addTestSuite(CompositeCollectionTest4.class);
		return suite;
	}

}