package org.apache.commons.collections.keyvalue;

public class MultiKeyTest extends junit.framework.TestCase {

	public MultiKeyTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(MultiKeyTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(MultiKeyTest1.class);
		return suite;
	}

}