package org.apache.commons.collections.iterators;

public class IteratorChainTest extends junit.framework.TestCase {

	public IteratorChainTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(IteratorChainTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(IteratorChainTest1.class);
		return suite;
	}

}