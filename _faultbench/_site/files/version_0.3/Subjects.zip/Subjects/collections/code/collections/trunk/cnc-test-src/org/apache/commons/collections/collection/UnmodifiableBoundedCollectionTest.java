package org.apache.commons.collections.collection;

public class UnmodifiableBoundedCollectionTest extends junit.framework.TestCase {

	public UnmodifiableBoundedCollectionTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(UnmodifiableBoundedCollectionTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(UnmodifiableBoundedCollectionTest1.class);
		suite.addTestSuite(UnmodifiableBoundedCollectionTest2.class);
		return suite;
	}

}