package org.apache.commons.collections.bidimap;

public class TreeBidiMapTest extends junit.framework.TestCase {

	public TreeBidiMapTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(TreeBidiMapTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(TreeBidiMapTest1.class);
		suite.addTestSuite(TreeBidiMapTest2.class);
		suite.addTestSuite(TreeBidiMapTest3.class);
		suite.addTestSuite(TreeBidiMapTest4.class);
		suite.addTestSuite(TreeBidiMapTest5.class);
		suite.addTestSuite(TreeBidiMapTest6.class);
		suite.addTestSuite(TreeBidiMapTest7.class);
		suite.addTestSuite(TreeBidiMapTest8.class);
		suite.addTestSuite(TreeBidiMapTest9.class);
		suite.addTestSuite(TreeBidiMapTest10.class);
		suite.addTestSuite(TreeBidiMapTest11.class);
		suite.addTestSuite(TreeBidiMapTest12.class);
		suite.addTestSuite(TreeBidiMapTest13.class);
		return suite;
	}

}