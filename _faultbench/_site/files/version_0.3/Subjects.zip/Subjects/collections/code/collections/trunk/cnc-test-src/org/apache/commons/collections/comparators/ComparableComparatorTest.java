package org.apache.commons.collections.comparators;

public class ComparableComparatorTest extends junit.framework.TestCase {

	public ComparableComparatorTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(ComparableComparatorTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(ComparableComparatorTest1.class);
		return suite;
	}

}