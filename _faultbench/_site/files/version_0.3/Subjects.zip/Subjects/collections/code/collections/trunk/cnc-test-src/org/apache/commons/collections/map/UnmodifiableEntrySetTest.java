package org.apache.commons.collections.map;

public class UnmodifiableEntrySetTest extends junit.framework.TestCase {

	public UnmodifiableEntrySetTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(UnmodifiableEntrySetTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(UnmodifiableEntrySetTest1.class);
		suite.addTestSuite(UnmodifiableEntrySetTest2.class);
		return suite;
	}

}