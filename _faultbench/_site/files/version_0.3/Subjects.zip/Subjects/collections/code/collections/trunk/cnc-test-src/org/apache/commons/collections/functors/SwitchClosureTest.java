package org.apache.commons.collections.functors;

public class SwitchClosureTest extends junit.framework.TestCase {

	public SwitchClosureTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(SwitchClosureTest.class);
	}


	public static junit.framework.Test suite() {
		junit.framework.TestSuite suite = new junit.framework.TestSuite();
		suite.addTestSuite(SwitchClosureTest1.class);
		suite.addTestSuite(SwitchClosureTest2.class);
		return suite;
	}

}