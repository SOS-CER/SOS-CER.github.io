DELETE FROM ICDCodes;
INSERT INTO ICDCodes(Code, Description) VALUES
('250.1','Diabetes with ketoacidosis'),
('250.3','Diabetes with other coma'),
('487','Influenza'),
('79.1','Echovirus'),
('79.3','Coxsackie');