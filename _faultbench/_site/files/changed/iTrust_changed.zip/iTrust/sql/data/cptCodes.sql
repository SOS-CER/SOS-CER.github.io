DELETE FROM CPTCodes;
INSERT INTO CPTCodes(Code, Description) VALUES('1270F','Injection procedure'),
											  ('87','Diagnostic Radiology');