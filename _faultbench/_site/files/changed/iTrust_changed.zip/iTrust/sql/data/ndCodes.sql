DELETE FROM NDCodes;
INSERT INTO NDCodes(Code, Description) VALUES
('009042407','Tetracycline'),
('081096','Aspirin');
