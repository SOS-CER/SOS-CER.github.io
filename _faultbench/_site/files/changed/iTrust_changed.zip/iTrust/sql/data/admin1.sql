DELETE FROM Users WHERE MID=9000000001;
DELETE FROM Personnel WHERE MID=9000000001;

INSERT INTO Personnel(
MID,
AMID,
role,
lastName, 
firstName, 
address1,
address2,
city,
state,
zip,
zip1,
zip2,
phone,
phone1,
phone2,
phone3,
hospitalID,
sQuestion,
sAnswer,
specialty) 
VALUES (
9000000001,
null,
'admin',
'Shifter',
'Shape',
'4321 My Road St',
'PO BOX 2',
'CityName',
'NY',
'12345-1234',
'12345',
'1234',
'999-888-7777',
'999',
'888',
'7777',
NULL,
'first letter?',
MD5('a'),
'administrator'
);

INSERT INTO Users(MID, password, role) VALUES(9000000001, 'pw', 'admin');
