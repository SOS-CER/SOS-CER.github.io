DELETE FROM Patients WHERE MID=1;
DELETE FROM Users WHERE MID=1;
DELETE FROM Allergies WHERE PatientID=1;
DELETE FROM PersonalHealthInformation WHERE PatientID=1;
DELETE FROM Representatives WHERE RepresenterMID=1;
DELETE FROM OVDiagnosis WHERE VisitID IN (SELECT ID FROM OfficeVisits WHERE PatientID=1);
DELETE FROM OfficeVisits WHERE PatientID=1 OR ID=11;
DELETE FROM DeclaredHCP WHERE PatientID=1;
DELETE FROM Representatives WHERE RepresenteeMID=1;
