DELETE FROM OfficeVisits WHERE id=2;

INSERT INTO OfficeVisits(
	id,
	visitDate,
	HCPID,
	notes,
	PatientID
)
VALUES (
2,
'2005-10-11',
9000000000,
'Additional Test OV (2005-10-11)',
1
);

DELETE FROM OfficeVisits WHERE id=99999;

INSERT INTO OfficeVisits(
	id,
	visitDate,
	HCPID,
	notes,
	PatientID
)
VALUES (
99999,
'2007-05-10',
9000000000,
'Additional Test OV (2007-05-10)',
1
);