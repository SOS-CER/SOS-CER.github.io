DELETE FROM Hospitals WHERE HospitalID IN ('9191919191','8181818181', '1');

INSERT INTO Hospitals(HospitalID, HospitalName) VALUES('9191919191','Test Hospital 9191919191');
INSERT INTO Hospitals(HospitalID, HospitalName) VALUES('8181818181','Test Hospital 8181818181');
INSERT INTO Hospitals(HospitalID, HospitalName) VALUES('1','Test Hospital 1');