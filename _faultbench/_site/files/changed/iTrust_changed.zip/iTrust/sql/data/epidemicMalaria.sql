DELETE FROM Patients WHERE MID=52;
DELETE FROM OVDiagnosis;
DELETE FROM OfficeVisits;

INSERT INTO Patients (MID,firstName,lastName,zip1,state) 
VALUES  (52,'Disease-Ridden', 'Person 52','27607', 'NC');

INSERT INTO OfficeVisits(id,visitDate,notes,PatientID)
VALUES 	(1,'2005-6-09','Office visit for malaria epidemic test.',52),
		(2,'2005-6-16','Office visit for malaria epidemic test.',52),
		(3,'2006-6-09','Office visit for malaria epidemic test.',52),
		(4,'2006-6-16','Office visit for malaria epidemic test.',52),
		(5,'2007-6-09','Office visit for malaria epidemic test.',52),
		(6,'2007-6-16','Office visit for malaria epidemic test.',52);

INSERT INTO OVDiagnosis(ICDCode, VisitID) 
VALUES 	(84, 1), (84, 1),
		(84, 2), (84, 2),
		(84, 3), (84, 3), (84, 3),
		(84, 4), (84, 4), (84, 4),
		(84, 5), (84, 5), (84, 5), (84, 5),
		(84, 6), (84, 6), (84, 6), (84, 6);
		