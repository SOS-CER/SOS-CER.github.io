DELETE FROM Patients;
DELETE FROM OVDiagnosis;
DELETE FROM OfficeVisits;
DELETE FROM OVDiagnosis;
DELETE FROM OVProcedure;