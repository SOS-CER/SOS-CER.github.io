This is the README for the READMEs you are required to submit with each assignment.

Please place a README file in the /iTrust/doc/readme folder for each submission.

*** This file is here to help the grading of your assignment ***
*** PLEASE fill this out to help your grade!! ***

Use the file format of assignment_X.txt, where X is the assignment number.

Please note the following in your readme:
+ Anything that you did not finish
+ Any major design decisions you made; interpretations of the assignment that you think the TA should know about
+ The tests you added (doesn't need to be detailed, just the package and a few classes would suffice)
+ Anything else you think the TA should know about before grading