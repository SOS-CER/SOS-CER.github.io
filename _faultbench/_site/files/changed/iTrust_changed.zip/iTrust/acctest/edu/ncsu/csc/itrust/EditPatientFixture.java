package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.EditPatientAction;
import edu.ncsu.csc.itrust.beans.PatientBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import fit.ColumnFixture;

public class EditPatientFixture extends ColumnFixture {
	public long loggedInMID;
	private boolean hadException = false;
	public String pid;
	public String bloodType;
	public String causeOfDeath = "";
	public String city;
	public String confirmPassword;
	public String dateOfBirthStr;
	public String dateOfDeathStr = "";
	public String email;
	public String emergencyName;
	public String emergencyPhone1;
	public String emergencyPhone2;
	public String emergencyPhone3;
	public String ethnicity;
	public long fatherMID;
	public String firstName;
	public String gender;
	public String icAddress1;
	public String icAddress2;
	public String icCity;
	public String icID;
	public String icName;
	public String icPhone1;
	public String icPhone2;
	public String icPhone3;
	public String icState;
	public String icZip1;
	public String icZip2;
	public String lastName;
	public long motherMID;
	public String password;
	public String phone1;
	public String phone2;
	public String phone3;
	public String securityAnswer;
	public String securityQuestion;
	public String state;
	public String streetAddress1;
	public String streetAddress2;
	public String topicalNotes;
	public String zip1;
	public String zip2;

	public EditPatientFixture() throws FileNotFoundException, IOException, SQLException {
		new TestDataGenerator().insertPatient1();
	}

	public String editPatient() throws iTrustException {
		hadException = false;
		EditPatientAction action = new EditPatientAction(DAOFactory.getTestInstance(), loggedInMID, pid);
		PatientBean p = new PatientBean();
		p.setBloodTypeStr(bloodType);;
		p.setCauseOfDeath(causeOfDeath);
		p.setCity(city);
		p.setConfirmPassword(confirmPassword);
		p.setDateOfBirthStr(dateOfBirthStr);
		p.setDateOfDeathStr(dateOfDeathStr);
		p.setEmail(email);
		p.setEmergencyName(emergencyName);
		p.setEmergencyPhone1(emergencyPhone1);
		p.setEmergencyPhone2(emergencyPhone2);
		p.setEmergencyPhone3(emergencyPhone3);
		p.setEthnicityStr(ethnicity);
		p.setFatherMID(fatherMID);
		p.setFirstName(firstName);
		p.setGenderStr(gender);
		p.setIcAddress1(icAddress1);
		p.setIcAddress2(icAddress2);
		p.setIcCity(icCity);
		p.setIcID(icID);
		p.setIcName(icName);
		p.setIcPhone1(icPhone1);
		p.setIcPhone2(icPhone2);
		p.setIcPhone3(icPhone3);
		p.setIcState(icState);
		p.setIcZip1(icZip1);
		p.setIcZip2(icZip2);
		p.setLastName(lastName);
		p.setMotherMID(motherMID);
		p.setPassword(password);
		p.setPhone1(phone1);
		p.setPhone2(phone2);
		p.setPhone3(phone3);
		p.setSecurityAnswer(securityAnswer);
		p.setSecurityQuestion(securityQuestion);
		p.setState(state);
		p.setStreetAddress1(streetAddress1);
		p.setStreetAddress2(streetAddress2);
		p.setTopicalNotes(topicalNotes);
		p.setZip1(zip1);
		p.setZip2(zip2);
		try {
			action.updateInformation(p);
		} catch (FormValidationException e) {
			hadException = true;
			return e.getMessage();
		}
		return "success";
	}

	public boolean hadException() {
		return hadException;
	}
}
