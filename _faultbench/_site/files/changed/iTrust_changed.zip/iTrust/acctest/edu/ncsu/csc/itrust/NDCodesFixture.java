package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.UpdateNDCodeListAction;
import edu.ncsu.csc.itrust.beans.MedicationBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import fit.ActionFixture;

public class NDCodesFixture extends ActionFixture {
	private UpdateNDCodeListAction action;
	private String exception = "";
	private String code;
	private String description;

	public NDCodesFixture() throws FileNotFoundException, IOException, SQLException {
		TestDataGenerator gen = new TestDataGenerator();
		gen.resetAllNDCodes();
	}

	public void adminMID(long adminMID) {
		action = new UpdateNDCodeListAction(DAOFactory.getTestInstance(), adminMID);
	}

	public void icd(String code) {
		this.code = code;
	}

	public void description(String description) {
		this.description = description;
	}

	public void addCode() {
		MedicationBean bean = new MedicationBean();
		bean.setNDCode(code);
		bean.setDescription(description);
		try {
			action.addNDCode(bean);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getCode() throws DBException {
		return DAOFactory.getTestInstance().getNDCodesDAO().getNDCode(code).getDescription();
	}

	public void updateCode() {
		MedicationBean bean = new MedicationBean();
		bean.setNDCode(code);
		bean.setDescription(description);
		try {
			action.updateInformation(bean);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getException() {
		return exception;
	}
}
