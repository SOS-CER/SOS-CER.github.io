package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.EpidemicDetectionAction;
import edu.ncsu.csc.itrust.beans.forms.EpidemicForm;
import edu.ncsu.csc.itrust.beans.forms.EpidemicReturnForm;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import fit.ColumnFixture;

public class EpidemicDetectionFixture extends ColumnFixture {
	public long loggedInMID;
	public String date;
	public String detector;
	public String icdLower;
	public String icdUpper;
	public String state;
	public String weeksBack;
	public String zip;
	public String useEpidemic;
	private boolean hadException = false;

	public String detectEpidemic() throws Exception {
		hadException = false;
		setUpTestData();
		EpidemicDetectionAction action = new EpidemicDetectionAction(DAOFactory.getTestInstance(), loggedInMID);
		EpidemicForm form = new EpidemicForm();
		form.setDate(date);
		form.setDetector(detector);
		form.setIcdLower(icdLower);
		form.setIcdUpper(icdUpper);
		form.setState(state);
		form.setUseEpidemic(useEpidemic);
		form.setWeeksBack(weeksBack);
		form.setZip(zip);
		try {
			EpidemicReturnForm returnForm = action.execute(form);
			return returnForm.getEpidemicMessage();
		} catch (DBException e) {
			hadException = true;
			return e.getMessage();
		} catch (FormValidationException e) {
			hadException = true;
			return e.getMessage();
		}
	}

	public boolean hadException() {
		return hadException;
	}

	private void setUpTestData() throws FileNotFoundException, SQLException, IOException {
		TestDataGenerator gen = new TestDataGenerator();
		if ("influenza".equals(detector))
			gen.resetEpidemicInfluenza();
		if ("malaria".equals(detector))
			gen.resetEpidemicMalaria();
	}
}
