package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.UpdateHospitalListAction;
import edu.ncsu.csc.itrust.beans.HospitalBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import fit.ActionFixture;

public class HospitalListingFixture extends ActionFixture {
	private UpdateHospitalListAction action;
	private String exception = "";
	private String hosID;
	private String hosName;

	public HospitalListingFixture() throws FileNotFoundException, IOException, SQLException {
		TestDataGenerator gen = new TestDataGenerator();
		gen.resetAllHospitals();
	}

	public void adminMID(long adminMID) {
		action = new UpdateHospitalListAction(DAOFactory.getTestInstance(), adminMID);
	}

	public void hospitalId(String hosID) {
		this.hosID = hosID;
	}

	public void hospitalName(String hosName) {
		this.hosName = hosName;
	}

	public void addHospital() {
		HospitalBean hosp = new HospitalBean();
		hosp.setHospitalID(hosID);
		hosp.setHospitalName(hosName);
		try {
			action.addHospital(hosp);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getHospital() throws DBException {
		return DAOFactory.getTestInstance().getHospitalsDAO().getHospital(hosID).getHospitalName();
	}

	public void updateHospital() {
		HospitalBean hosp = new HospitalBean();
		hosp.setHospitalID(hosID);
		hosp.setHospitalName(hosName);
		try {
			action.updateInformation(hosp);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getException() {
		return exception;
	}
}
