package edu.ncsu.csc.itrust.beans;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AllergyBean {
	private long id;
	private long patientID;
	private String description;
	private Date firstFound;

	public AllergyBean() {
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getFirstFound() {
		return new Date(firstFound.getTime());
	}

	public void setFirstFound(Date firstFound) {
		this.firstFound = firstFound;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPatientID() {
		return patientID;
	}

	public void setPatientID(long patientID) {
		this.patientID = patientID;
	}
	
	public String getFirstFoundStr(){
		try{
			return new SimpleDateFormat("MM/dd/yyyy").format(getFirstFound());
		}catch(Exception e){
			e.printStackTrace();
			return "";
		}
	}
}
