package edu.ncsu.csc.itrust.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.ncsu.csc.itrust.ParameterUtil;
import edu.ncsu.csc.itrust.action.base.OfficeVisitBaseAction;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class DiscretionaryAccessAction extends OfficeVisitBaseAction {
	private AccessDAO accessDAO;
	private OfficeVisitDAO ovDAO;
	private TransactionDAO transDAO;
	private long loggedInMID;

	public DiscretionaryAccessAction(DAOFactory factory, long loggedInMID, String pidString, String ovIDString)
			throws iTrustException {
		super(factory, pidString, ovIDString);
		this.ovDAO = factory.getOfficeVisitDAO();
		this.transDAO = factory.getTransactionDAO();
		this.accessDAO = factory.getAccessDAO();
		this.loggedInMID = loggedInMID;
		checkLoggedInOfficeVisit();
	}

	// Check that the logged in user is allowed to manage discretionary access
	private void checkLoggedInOfficeVisit() throws iTrustException {
		OfficeVisitBean ov = ovDAO.getOfficeVisit(ovID);
		if (ov.getHcpID() != loggedInMID) {
			throw new iTrustException("You are not authorized to manage discretionary access for office visit " + ovID);
		}
	}

	public List<OfficeVisitBean> getAllOfficeVisits() throws DBException {
		return ovDAO.getAllOfficeVisits(pid);
	}

	public List<DiagnosisBean> getDiagnoses() throws DBException {
		return ovDAO.getDiagnoses(ovID);
	}

	@SuppressWarnings("unchecked")
	public void updateInformation(Map params) throws DBException {
		HashMap<String, String> myMap = ParameterUtil.convertMap(params);
		updateInformation(myMap);
	}

	public void updateInformation(HashMap<String, String> myMap) throws DBException {
		List<DiagnosisBean> diagnoses = ovDAO.getDiagnoses(ovID);
		List<DiagnosisBean> updateDiagnoses = new ArrayList<DiagnosisBean>();
		for (DiagnosisBean d : diagnoses) {
			boolean hasAccess = Boolean.valueOf(myMap.get("ovdID" + d.getOvDiagnosisID()));
			if (hasAccess != d.isDiscretionaryAccess()) {
				DiagnosisBean newD = new DiagnosisBean();
				newD.setDiscretionaryAccess(hasAccess);
				newD.setOvDiagnosisID(d.getOvDiagnosisID());
				updateDiagnoses.add(newD);
			}
		}
		if (updateDiagnoses.size() > 0) {
			accessDAO.updateDiscretionaryAccess(updateDiagnoses);
			transDAO.logTransaction(TransactionType.ALLOW_DISALLOW_ACCESS, loggedInMID, pid,
					"changed the discretionary acccess for diagnoses");
		}
	}
}
