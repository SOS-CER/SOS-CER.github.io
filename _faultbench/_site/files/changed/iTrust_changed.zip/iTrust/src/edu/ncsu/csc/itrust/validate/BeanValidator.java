package edu.ncsu.csc.itrust.validate;

import edu.ncsu.csc.itrust.exception.FormValidationException;

abstract public class BeanValidator<T> {
	abstract public void validate(T bean) throws FormValidationException;

	protected String checkFormat(String name, String value, ValidationFormat format, boolean isNullable) {
		String errorMessage = name + ": " + format.getDescription();
		if (value == null || "".equals(value))
			return isNullable ? "" : errorMessage;
		if (format.getRegex().matcher(value).matches())
			return "";
		else
			return errorMessage;
	}

	protected String checkFormat(String name, Long longValue, ValidationFormat format, boolean isNullable) {
		String str = "";
		if (longValue != null)
			str = String.valueOf(longValue);
		return checkFormat(name, str, format, isNullable);
	}

	protected String checkFormat(String name, Double doubleValue, ValidationFormat format, boolean isNullable) {
		String str = "";
		if (doubleValue != null)
			str = String.valueOf(doubleValue);
		return checkFormat(name, str, format, isNullable);
	}

	protected String checkInt(String name, String value, int lower, int upper, boolean isNullable) {
		if (isNullable && (value == null || "".equals(value)))
			return "";
		try {
			int intValue = Integer.valueOf(value);
			if (lower <= intValue && intValue <= upper)
				return "";
		} catch (NumberFormatException e) {
			// just fall through to returning the error message
		}

		return name + " must be an integer in [" + lower + "," + upper + "]";
	}

	protected String checkDouble(String name, String value, double lower, double upper) {
		try {
			double doubleValue = Double.valueOf(value);
			if (lower <= doubleValue && doubleValue < upper)
				return "";
		} catch (NumberFormatException e) {
			// just fall through to returning the error message
		}
		return name + " must be a decimal in [" + lower + "," + upper + ")";
	}

	protected String checkBoolean(String name, String value) {
		if ("true".equals(value) || "false".equals(value))
			return "";
		else
			return name + " must be either 'true' or 'false'";
	}
}
