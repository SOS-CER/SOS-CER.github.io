package edu.ncsu.csc.itrust.action;

import java.util.List;

import edu.ncsu.csc.itrust.beans.PersonnelBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class DeclareHCPAction {
	private TransactionDAO transDAO;
	private PatientDAO patientDAO;
	private long loggedInMID;

	public DeclareHCPAction(DAOFactory factory, long loggedInMID) {
		this.loggedInMID = loggedInMID;
		this.transDAO = factory.getTransactionDAO();
		this.patientDAO = factory.getPatientDAO();
	}

	public List<PersonnelBean> getDeclaredHCPS() throws iTrustException {
		try {
			return patientDAO.getDeclaredHCPs(loggedInMID);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public String declareHCP(String input) throws iTrustException {
		try {
			long hcpID = Long.valueOf(input);
			boolean confirm = patientDAO.declareHCP(loggedInMID, hcpID);
			if (confirm) {
				transDAO.logTransaction(TransactionType.DECLARE_HCP, loggedInMID, hcpID, "patient declared hcp");
				return "HCP successfully declared";
			} else
				return "HCP not declared";
		} catch (NumberFormatException e) {
			throw new iTrustException("HCP's MID not a number");
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public String undeclareHCP(String input) throws iTrustException {
		try {
			long hcpID = Long.valueOf(input);
			boolean confirm = patientDAO.undeclareHCP(loggedInMID, hcpID);
			if (confirm) {
				transDAO.logTransaction(TransactionType.DECLARE_HCP, loggedInMID, hcpID, "patient undeclared hcp");
				return "HCP successfully undeclared";
			} else
				return "HCP not undeclared";
		} catch (NumberFormatException e) {
			throw new iTrustException("HCP's MID not a number");
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}
}
