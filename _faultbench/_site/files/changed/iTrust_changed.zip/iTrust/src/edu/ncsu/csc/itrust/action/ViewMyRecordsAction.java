package edu.ncsu.csc.itrust.action;

import java.util.ArrayList;
import java.util.List;

import edu.ncsu.csc.itrust.beans.AllergyBean;
import edu.ncsu.csc.itrust.beans.FamilyMemberBean;
import edu.ncsu.csc.itrust.beans.HealthRecord;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.beans.PatientBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AllergyDAO;
import edu.ncsu.csc.itrust.dao.mysql.FamilyDAO;
import edu.ncsu.csc.itrust.dao.mysql.HealthRecordsDAO;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class ViewMyRecordsAction {
	private PatientDAO patientDAO;
	private AllergyDAO allergyDAO;
	private FamilyDAO familyDAO;
	private HealthRecordsDAO hrDAO;
	private OfficeVisitDAO ovDAO;
	private long loggedInMID;

	public ViewMyRecordsAction(DAOFactory factory, long loggedInMID) {
		this.patientDAO = factory.getPatientDAO();
		this.allergyDAO = factory.getAllergyDAO();
		this.familyDAO = factory.getFamilyDAO();
		this.hrDAO = factory.getHealthRecordsDAO();
		this.ovDAO = factory.getOfficeVisitDAO();
		this.loggedInMID = loggedInMID;
	}

	public long representPatient(String input) throws iTrustException {
		try {
			long reppeeMID = Long.valueOf(input);
			if (patientDAO.represents(loggedInMID, reppeeMID)) {
				loggedInMID = reppeeMID;
				return reppeeMID;
			} else 
				throw new iTrustException("You do not represent patient " + reppeeMID);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		} catch(NumberFormatException e){
			throw new iTrustException("MID is not a number");
		}
	}

	public PatientBean getPatient() throws iTrustException {
		try {
			return patientDAO.getPatient(loggedInMID);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public List<AllergyBean> getAllergies() throws iTrustException {
		try {
			return allergyDAO.getAllergies(loggedInMID);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public List<FamilyMemberBean> getFamily() {
		List<FamilyMemberBean> fam = new ArrayList<FamilyMemberBean>();
		try {
			fam.addAll(familyDAO.getParents(loggedInMID));
			fam.addAll(familyDAO.getSiblings(loggedInMID));
			fam.addAll(familyDAO.getChildren(loggedInMID));
		} catch (DBException e) {
			e.printStackTrace();
		}
		return fam;
	}

	public List<HealthRecord> getAllHealthRecords() throws iTrustException {
		try {
			return hrDAO.getAllHealthRecords(loggedInMID);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public List<OfficeVisitBean> getAllOfficeVisits() throws iTrustException {
		try {
			return ovDAO.getAllOfficeVisits(loggedInMID);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public List<PatientBean> getRepresented() throws iTrustException {
		try {
			return patientDAO.getRepresented(loggedInMID);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}
}
