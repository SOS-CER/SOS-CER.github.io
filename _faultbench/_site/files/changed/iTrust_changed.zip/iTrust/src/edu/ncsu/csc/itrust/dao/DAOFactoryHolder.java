package edu.ncsu.csc.itrust.dao;

public class DAOFactoryHolder {
	
	public static DAOFactory factory = new DAOFactory(new ProductionConnectionDriver());

}
