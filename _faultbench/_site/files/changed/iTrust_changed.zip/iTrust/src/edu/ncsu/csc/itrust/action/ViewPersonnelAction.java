package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.beans.PersonnelBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class ViewPersonnelAction {
	private PersonnelDAO personnelDAO;
	private TransactionDAO transDAO;
	private long loggedInMID;

	public ViewPersonnelAction(DAOFactory factory, long loggedInMID) {
		this.personnelDAO = factory.getPersonnelDAO();
		this.transDAO = factory.getTransactionDAO();
	}

	public PersonnelBean getPersonnel(String input) throws iTrustException {
		try {
			long mid = Long.valueOf(input);
			PersonnelBean personnel = personnelDAO.getPersonnel(mid);
			if (personnel != null) {
				transDAO.logTransaction(TransactionType.ENTER_EDIT_DEMOGRAPHICS, loggedInMID, mid,
						"Patient viewed personnel " + mid);
				return personnel;
			} else
				throw new iTrustException("No personnel record exists for this MID");
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new iTrustException("MID not a number");
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}
}
