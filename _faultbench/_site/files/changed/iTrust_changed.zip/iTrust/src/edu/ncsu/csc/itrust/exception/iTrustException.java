package edu.ncsu.csc.itrust.exception;

public class iTrustException extends Exception {
	private static final long serialVersionUID = 1L;
	String message = null;

	public iTrustException(String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		if (message == null)
			return "An error has occurred. Please see log for details.";
		return message;
	}
}
