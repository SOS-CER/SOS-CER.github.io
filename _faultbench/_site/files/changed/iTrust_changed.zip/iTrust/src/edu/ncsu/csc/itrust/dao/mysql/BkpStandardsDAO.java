package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.beans.MedicationBean;
import edu.ncsu.csc.itrust.beans.ProcedureBean;
import edu.ncsu.csc.itrust.beans.loaders.BeanLoader;
import edu.ncsu.csc.itrust.beans.loaders.DiagnosisBeanLoader;
import edu.ncsu.csc.itrust.beans.loaders.MedicationBeanLoader;
import edu.ncsu.csc.itrust.beans.loaders.ProcedureBeanLoader;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;

public class BkpStandardsDAO {
	private DAOFactory factory;
	private DiagnosisBeanLoader diagnosisLoader = new DiagnosisBeanLoader();
	private MedicationBeanLoader medicationLoader = new MedicationBeanLoader();
	private ProcedureBeanLoader procedureBeanLoader = new ProcedureBeanLoader();

	public BkpStandardsDAO(DAOFactory factory) {
		this.factory = factory;
	}

	public List<DiagnosisBean> getAllICDCodes() throws DBException {
		return getAllGeneralCodes("ICDCodes", diagnosisLoader); 
	}

	public List<MedicationBean> getAllNDCodes() throws DBException {
		return getAllGeneralCodes("NDCodes", medicationLoader);
	}
	
	public List<ProcedureBean> getALLCPTCodes() throws DBException {
		return getAllGeneralCodes("CPTCodes", procedureBeanLoader);
	}

	private <T> List<T> getAllGeneralCodes(String tableName, BeanLoader<T> loader) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM " + tableName + " ORDER BY CODE ASC");
			ResultSet rs = ps.executeQuery();
			return loader.loadList(rs);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
}
