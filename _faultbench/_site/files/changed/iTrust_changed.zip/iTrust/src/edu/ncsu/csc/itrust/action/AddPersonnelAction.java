package edu.ncsu.csc.itrust.action;

import java.util.Random;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AuthDAO;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.enums.Role;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class AddPersonnelAction {
	private PersonnelDAO personnelDAO;
	private AuthDAO authDAO;
	private long loggedInMID;

	public AddPersonnelAction(DAOFactory factory, long loggedInMID) {
		this.personnelDAO = factory.getPersonnelDAO();
		this.authDAO = factory.getAuthDAO();
		this.loggedInMID = loggedInMID;
	}

	public long execute(Role role) throws DBException, iTrustException {
		long mid;
		switch (role) {
			case HCP :
				mid = personnelDAO.addEmptyPersonnel();
				break;
			case UAP :
				mid = personnelDAO.addEmptyPersonnel(loggedInMID);
				break;
			default :
				throw new iTrustException("Invalid role: " + role.getUserRolesString());
		}
		authDAO.addUser(mid, role, getRandomPassword());
		return mid;
	}

	/**
	 * @return random-ish password string
	 */
	private String getRandomPassword() {
		Random rand = new Random();
		String str = "";
		for (int i = 0; i < 10; i++) {
			str += (char) (rand.nextInt(26) + 'a');
		}
		return str;
	}
}
