package edu.ncsu.csc.itrust.dao.mysql;

import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.Calendar;
//import java.util.GregorianCalendar;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.beans.VisitFlag;
import edu.ncsu.csc.itrust.beans.forms.VisitReminderReturnForm;
import edu.ncsu.csc.itrust.beans.loaders.VisitReminderReturnFormLoader;
import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.DateUtil;

public class VisitRemindersDAO {
	private DAOFactory factory;

	public VisitRemindersDAO(DAOFactory factory) {
		this.factory = factory;
	}
	
	/**
	 * CURRENT SPEC:
	 * Alive patient, no office visit for > 1 yr, diagnosed:
	 * - Diabetes: 250.xx
	 * - Asthma:   493.xx
	 * - Circulatory-System Disease: [ 390.00 , 459.99 ]
	 * 
	 * @return
	 */
	public List<VisitReminderReturnForm> getDiagnosedVisitNeeders(long hcpid) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"SELECT DISTINCT "
						+ "? as hid, ov.patientid, p.lastname, p.firstname, "
						+ "p.phone1, p.phone2, p.phone3, ovd.icdcode, lastvisit "
					+ "FROM OVDiagnosis ovd, OfficeVisits ov, Patients p, "
						+ "(SELECT patientid, MAX(visitdate) as lastvisit "
							+ "FROM OfficeVisits GROUP BY patientid) as visits  "
					+ "WHERE ovd.visitID=ov.id "
						+ "AND ov.patientid=p.mid "
						+ "AND visits.patientid=ov.patientid "
						+ "AND p.dateofdeath IS NULL "
						+ "AND (ovd.DiscretionaryAccess=false "
							+ "OR (ovd.PrivacyLevel='Declared HCP Only' "
								+ "AND ? IN "
									+ "(SELECT HCPID FROM DeclaredHCP "
									+ "WHERE ov.patientid=DeclaredHCP.patientid)) "
							+ "OR  ovd.PrivacyLevel='All')"
						+ "AND ("
							+ "(ovd.icdcode BETWEEN 250.00 AND 250.99) "
							+ "OR (ovd.icdcode BETWEEN 493.00 AND 493.99) "
							+ "OR (ovd.icdcode BETWEEN 390.00 AND 459.99)) "
						+ "AND ov.patientid NOT IN "
							+ "(SELECT patientid "
							+ "FROM (SELECT patientid, MAX(visitdate) as last "
								+ "FROM OfficeVisits GROUP BY patientid "
								+ "HAVING last >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)) "
									+ "as somevisits) "
					+ "ORDER BY lastname, firstname, ov.patientid");
			ps.setLong(1, hcpid);
			ps.setLong(2, hcpid);
			//ps.setDate(3, DateArithmetic.getSQLdateXyearsAgoFromNow(1));
			rs = ps.executeQuery();
			List<VisitReminderReturnForm> patients = new ArrayList<VisitReminderReturnForm>();
			VisitReminderReturnForm temp;
			VisitReminderReturnFormLoader loader = new VisitReminderReturnFormLoader();
			while(rs.next()) {
				temp = loader.loadSingle(rs);
				temp.addVisitFlag(new VisitFlag(VisitFlag.DIAGNOSED, rs.getString(8)));
				temp.addVisitFlag(new VisitFlag(VisitFlag.LAST_VISIT, rs.getString(9)));
				patients.add(temp);
			}
			return patients;
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally{
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	
	/**
	 * CURRENT SPEC:
	 * Alive patient, over 50 years old, no flu shot
	 * - 90656, 90658, 90660
	 * a) during the months 09 - 12 of current calendar year if in 09 - 12
	 * b) during the months 09 - 12 of last calendar year if not in 09 - 12
	 * 
	 * Determines current date and calls one of two private methods
	 *   these methods return different sets of people
	 *   - a: people who haven't had a flu shot yet this year and need one
	 *   - b: people who missed last year's flu shot and need a check-up
	 * 
	 * @return
	 * @param hcpid
	 * @param patientBirthday
	 * @return
	 * @throws DBException
	 */
	public List<VisitReminderReturnForm> getFluShotDelinquents(long hcpid) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		boolean thisYear = DateUtil.currentlyInMonthRange(9, 12);
		
		String flagType = thisYear ? VisitFlag.MISSING_MEDICATION : VisitFlag.MISSED_MEDICATION;
		
		java.sql.Date september = new java.sql.Date(0l), december = new java.sql.Date(0l);
		DateUtil.setSQLMonthRange(september, 8, thisYear ? 0 : 1, december, 11, thisYear ? 0 : 1);
		
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"SELECT DISTINCT "
						+ "? as hid, ov.patientid, p.lastname, p.firstname, "
						+ "p.phone1, p.phone2, p.phone3 "
					+ "FROM OfficeVisits ov, Patients p "
					+ "WHERE ov.patientid=p.mid "
						+ "AND p.dateofdeath IS NULL "
						+ "AND p.dateofbirth < DATE_SUB(CURDATE(), INTERVAL 50 YEAR) "
						+ "AND patientid NOT IN "
							+ "(SELECT patientid FROM OfficeVisits ov, OVMedication om "
							+  "WHERE ov.id=om.visitid "
								+ "AND NDCode IN (90656, 90658, 90660) "
								+ "AND ((StartDate BETWEEN ? AND ?) "
									+ "OR (EndDate BETWEEN ? AND ?))) "
					+ "ORDER BY lastname, firstname, ov.patientid");
			ps.setLong(1, hcpid);
			ps.setDate(2, september);
			ps.setDate(3, december);
			ps.setDate(4, september);
			ps.setDate(5, december);
			rs = ps.executeQuery();
			List<VisitReminderReturnForm> patients = new ArrayList<VisitReminderReturnForm>();
			VisitReminderReturnForm temp;
			VisitReminderReturnFormLoader loader = new VisitReminderReturnFormLoader();
			while(rs.next()) {
				temp = loader.loadSingle(rs);
				temp.addVisitFlag(new VisitFlag(flagType, "Flu Shot"));
				patients.add(temp);
			}
			return patients;
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally{
			DBUtil.closeConnection(conn, ps);
		}
	}
}
