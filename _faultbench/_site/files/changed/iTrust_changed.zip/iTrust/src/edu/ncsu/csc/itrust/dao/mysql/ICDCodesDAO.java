package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.beans.loaders.DiagnosisBeanLoader;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class ICDCodesDAO {
	private DAOFactory factory;
	private DiagnosisBeanLoader diagnosisLoader = new DiagnosisBeanLoader();
	
	public ICDCodesDAO(DAOFactory factory) {
		this.factory = factory;
	}

	public List<DiagnosisBean> getAllICDCodes() throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM ICDCodes ORDER BY CODE");
			ResultSet rs = ps.executeQuery();
			return diagnosisLoader.loadList(rs);
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public DiagnosisBean getICDCode(double code) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"SELECT * FROM ICDCodes WHERE Code = ?");
			ps.setDouble(1, code);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) return diagnosisLoader.loadSingle(rs);
			return null;
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	/**
	 * NOTE: method should be passed non-null values for non-null fields
	 * @param diag
	 * @return
	 * @throws DBException
	 * @throws iTrustException
	 */
	public boolean addICDCode(DiagnosisBean diag)
			throws DBException, iTrustException
	{
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"INSERT INTO ICDCodes (Code, Description) " +
					"VALUES (?,?)");
			ps.setDouble(1, diag.getICDCode());
			ps.setString(2, diag.getDescription());
			return (1 == ps.executeUpdate());
		} catch (SQLException e) {
			e.printStackTrace();
			if(1062 == e.getErrorCode())
				throw new iTrustException("Error: Code already exists.");
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public int updateCode(DiagnosisBean diag) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"UPDATE ICDCodes SET Description = ? " +
					"WHERE Code = ?");
			/* ps.setStrint(1, ...) and diagnosisLoader.loadParameters
			 * accomplish the same thing
			 *  == BUT == 
			 *  loadParameters HAS NOT BEEN TESTED YET */
			ps.setString(1, diag.getDescription());
			// OR NEXT LINE
			//diagnosisLoader.loadParameters(ps, proc);
			ps.setDouble(2, diag.getICDCode());
			return ps.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
}
