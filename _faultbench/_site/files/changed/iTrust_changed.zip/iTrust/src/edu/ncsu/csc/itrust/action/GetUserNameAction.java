package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class GetUserNameAction {
	private DAOFactory factory;

	public GetUserNameAction(DAOFactory factory) {
		this.factory = factory;
	}

	public String getUserName(String inputMID) throws DBException,
			iTrustException {
		try {
			long mid = Long.valueOf(inputMID);
			return factory.getAuthDAO().getUserName(mid);
		} catch (NumberFormatException e) {
			throw new iTrustException("MID not in correct form");
		}
	}
}
