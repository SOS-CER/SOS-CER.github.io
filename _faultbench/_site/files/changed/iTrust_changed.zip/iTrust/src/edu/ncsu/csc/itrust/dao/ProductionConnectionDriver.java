package edu.ncsu.csc.itrust.dao;

import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class ProductionConnectionDriver implements IConnectionDriver {
	public Connection getConnection() throws SQLException {
		try {
			Object dataSource = ((Context) new InitialContext().lookup("java:comp/env")).lookup("jdbc/itrust");
			return ((DataSource) dataSource).getConnection();
		} catch (NamingException e) {
			throw new SQLException("Context Lookup Naming Exception: " + e.getMessage());
		}
	}
}
