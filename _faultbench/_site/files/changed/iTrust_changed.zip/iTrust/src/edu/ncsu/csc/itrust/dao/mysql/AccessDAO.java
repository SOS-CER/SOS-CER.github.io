package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;

public class AccessDAO {
	private DAOFactory factory;

	public AccessDAO(DAOFactory factory) {
		this.factory = factory;
	}

	public void updateDiscretionaryAccess(List<DiagnosisBean> updateDiagnoses) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("UPDATE OVDiagnosis SET DiscretionaryAccess=? WHERE ID=?");
			for (DiagnosisBean d : updateDiagnoses) {
				ps.setBoolean(1, d.isDiscretionaryAccess());
				ps.setLong(2, d.getOvDiagnosisID());
				ps.addBatch();
			}
			ps.executeBatch();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public String updatePrivacyLevels(List<DiagnosisBean> updateDiagnoses) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("UPDATE OVDiagnosis SET PrivacyLevel=? WHERE ID=? AND DiscretionaryAccess=true");
			for (DiagnosisBean d : updateDiagnoses) {
				ps.setString(1, d.getPrivacyLevel().getDBName());
				ps.setLong(2, d.getOvDiagnosisID());
				ps.addBatch();
			}
			int[] executionStats = ps.executeBatch();
			return processUpdateStats(executionStats, updateDiagnoses);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	private String processUpdateStats(int[] executionStats, List<DiagnosisBean> updateDiagnoses) {
		String str = "Privacy levels successfully set.  ";
		boolean first = true;
		for (int i = 0; i < executionStats.length; i++) {
			if (executionStats[i] == 0) {
				if (first) {
					first = false;
					str = "Could not update the following diagnoses: ";
				}
				str += updateDiagnoses.get(i).getFormattedDescription() + ", ";
			}
		}
		return str.substring(0, str.length() - 2);
	}

	public List<Long> getAllowableDiagnoses(long hcpid, long pid) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT ovd.ID FROM OVDiagnosis ovd, OfficeVisits ov "
					+ "WHERE ovd.VisitID=ov.ID AND ov.PatientID=? AND (ovd.DiscretionaryAccess=false "
					+ "OR (ovd.PrivacyLevel='Declared HCP Only' AND true=?) OR  ovd.PrivacyLevel='All') ");
			List<Long> ids = new ArrayList<Long>();
			ps.setLong(1, pid);
			ps.setBoolean(2, factory.getPatientDAO().checkDeclaredHCP(pid, hcpid));
			ResultSet rs = ps.executeQuery();
			while (rs.next())
				ids.add(rs.getLong("ID"));
			return ids;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public int getSessionTimeoutMins() throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ResultSet rs = conn.createStatement()
					.executeQuery("SELECT Value FROM GlobalVariables WHERE Name='Timeout'");
			if (rs.next())
				return rs.getInt("Value");
			else {
				insertDefaultTimeout(conn, 20);
				return 20;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public void setSessionTimeoutMins(int mins) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("UPDATE GlobalVariables SET Value=? WHERE Name='Timeout'");
			ps.setInt(1, mins);
			int numUpdated = ps.executeUpdate();
			if (numUpdated == 0) // no value in the table
				insertDefaultTimeout(conn, mins);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	private void insertDefaultTimeout(Connection conn, int mins) throws SQLException {
		conn.createStatement().executeUpdate(
				"INSERT INTO GlobalVariables(Name,Value) VALUES ('Timeout', '" + mins + " ')");
	}
}
