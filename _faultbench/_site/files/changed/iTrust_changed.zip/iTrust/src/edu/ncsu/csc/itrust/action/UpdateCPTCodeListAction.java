package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.CPTCodesDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.beans.ProcedureBean;
import edu.ncsu.csc.itrust.validate.ProcedureBeanValidator;
import edu.ncsu.csc.itrust.exception.FormValidationException;

public class UpdateCPTCodeListAction {
	private long loggedInMID;
	private TransactionDAO transDAO;
	private CPTCodesDAO cptDAO;
	private ProcedureBeanValidator validator = new ProcedureBeanValidator();

	public UpdateCPTCodeListAction(DAOFactory factory, long loggedInMID) {
		this.loggedInMID = loggedInMID;
		this.transDAO = factory.getTransactionDAO();
		this.cptDAO = factory.getCPTCodesDAO();
	}

	public String addCPTCode(ProcedureBean proc) throws FormValidationException {
		validator.validate(proc);
		try {
			if (cptDAO.addCPTCode(proc)) {
				transDAO.logTransaction(TransactionType.MANAGE_PROCEDURE_CODE, loggedInMID, 0L, "added CPT code "
						+ proc.getCPTCode());
				return "Success: " + proc.getCPTCode() + " - " + proc.getDescription() + " added";
			} else
				return "unexpected error"; // TODO: needs better error message
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		} catch (iTrustException e) {
			return e.getMessage();
		}
	}

	public String updateInformation(ProcedureBean proc) throws FormValidationException {
		validator.validate(proc);
		try {
			int rows = updateCode(proc);
			if(0 == rows) {
				return "Error: Code not found.";
			} else {
				transDAO.logTransaction(TransactionType.MANAGE_PROCEDURE_CODE, loggedInMID, 0L, "updated CPT code "
						+ proc.getCPTCode());
				return "Success: " + rows + " row(s) updated";
			}
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	private int updateCode(ProcedureBean proc) throws DBException {
		return cptDAO.updateCode(proc);
	}
}
