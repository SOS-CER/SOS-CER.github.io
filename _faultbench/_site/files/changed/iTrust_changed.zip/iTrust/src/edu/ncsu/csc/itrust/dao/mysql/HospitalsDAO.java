package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.beans.HospitalBean;
import edu.ncsu.csc.itrust.beans.loaders.HospitalBeanLoader;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class HospitalsDAO {
	private DAOFactory factory;
	private HospitalBeanLoader hospitalLoader = new HospitalBeanLoader();

	public HospitalsDAO(DAOFactory factory) {
		this.factory = factory;
	}

	public List<HospitalBean> getAllHospitals() throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM Hospitals ORDER BY HospitalName");
			ResultSet rs = ps.executeQuery();
			return hospitalLoader.loadList(rs);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public HospitalBean getHospital(String id) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM Hospitals WHERE HospitalID = ?");
			ps.setString(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				return hospitalLoader.loadSingle(rs);
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	/**
	 * NOTE: method should be passed non-null values for non-null fields
	 * 
	 * @param hosp
	 * @return
	 * @throws DBException
	 * @throws iTrustException
	 */
	public boolean addHospital(HospitalBean hosp) throws DBException, iTrustException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("INSERT INTO Hospitals (HospitalID, HospitalName) " + "VALUES (?,?)");
			ps.setString(1, hosp.getHospitalID());
			ps.setString(2, hosp.getHospitalName());
			return (1 == ps.executeUpdate());
		} catch (SQLException e) {
			e.printStackTrace();
			if (1062 == e.getErrorCode())
				throw new iTrustException("Error: Hospital already exists.");
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public int updateHospital(HospitalBean hosp) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("UPDATE Hospitals SET HospitalName = ? " + "WHERE HospitalID = ?");
			/* TODO: CHECK BOTH WAYS */
			/*
			 * ps.setStrint(1, ...) and hospitalLoader.loadParameters accomplish the same thing and
			 * both pass unit tests as of 2007-jun-05
			 */
			ps.setString(1, hosp.getHospitalName());
			// OR NEXT LINE
			// hospitalLoader.loadParameters(ps, hosp);
			ps.setString(2, hosp.getHospitalID());
			return ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public boolean assignHospital(long hcpID, String hospitalID) throws DBException, iTrustException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("INSERT INTO HCPAssignedHos (HCPID, HosID) VALUES (?,?)");
			ps.setLong(1, hcpID);
			ps.setString(2, hospitalID);
			return (1 == ps.executeUpdate());
		} catch (SQLException e) {
			if (1062 == e.getErrorCode())
				throw new iTrustException("HCP " + hcpID + " already assigned to hospital " + hospitalID);
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public boolean removeHospitalAssignment(long hcpID, String hospitalID)
			throws DBException
	{
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"DELETE FROM HCPAssignedHos WHERE HCPID = ? AND HosID = ?");
			ps.setLong(1, hcpID);
			ps.setString(2, hospitalID);
			return(1 == ps.executeUpdate());
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public int removeAllHospitalAssignmentsFrom(long hcpID) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"DELETE FROM HCPAssignedHos WHERE HCPID = ?");
			ps.setLong(1, hcpID);
			return ps.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
}
