package edu.ncsu.csc.itrust;

public class HtmlEncoder {
	public static String encode(String input) {
		String str = input.replaceAll("<", "&lt;");
		str = str.replaceAll(">", "&gt;");
		str = str.replaceAll("\n", "<br>");
		return str;
	}
}
