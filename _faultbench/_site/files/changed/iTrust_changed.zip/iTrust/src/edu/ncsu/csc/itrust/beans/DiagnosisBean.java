package edu.ncsu.csc.itrust.beans;

import edu.ncsu.csc.itrust.enums.PrivacyLevel;

public class DiagnosisBean {
	private long ovDiagnosisID = 0L; // optional
	private double icdCode;
	private String description;
	private boolean discretionaryAccess = true;
	private PrivacyLevel privacyLevel = PrivacyLevel.ALL_STAFF;

	public DiagnosisBean() {
	}

	public DiagnosisBean(double code) {
		icdCode = code;
	}

	public DiagnosisBean(double code, String description) {
		icdCode = code;
		this.description = description;
	}

	/**
	 * This functionality will be moved elsewhere.
	 * 
	 */
	public DiagnosisBean(String code, String description) {
		try {
			icdCode = Double.parseDouble(code);
		} catch (NumberFormatException e) {
			icdCode = 0.0;
			System.err.println("invalid code format, defaulting to 0.0");
		}
		this.description = description;
	}

	/**
	 * Gets the ICD Code for this procedure
	 * @return The ICD Code for this procedure
	 */
	public double getICDCode() {
		return icdCode;
	}

	/**
	 * Gets the ICD Description for this procedure
	 * @return The ICD Description for this procedure
	 */
	public String getDescription() {
		return description;
	}

	public void setICDCode(double code) {
		icdCode = code;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFormattedDescription() {
		return description + "(" + icdCode + ")";
	}

	/**
	 * Optional - for use with editing an office visit
	 * @return
	 */
	public long getOvDiagnosisID() {
		return ovDiagnosisID;
	}

	public void setOvDiagnosisID(long ovDiagnosisID) {
		this.ovDiagnosisID = ovDiagnosisID;
	}

	public boolean isDiscretionaryAccess() {
		return discretionaryAccess;
	}

	public void setDiscretionaryAccess(boolean discretionaryAccess) {
		this.discretionaryAccess = discretionaryAccess;
	}

	public PrivacyLevel getPrivacyLevel() {
		return privacyLevel;
	}

	public void setPrivacyLevel(PrivacyLevel privacyLevel) {
		this.privacyLevel = privacyLevel;
	}

	public void setPrivacyLevelStr(String privacyLevel) {
		this.privacyLevel = PrivacyLevel.parse(privacyLevel);
	}
}
