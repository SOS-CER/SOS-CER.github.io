package edu.ncsu.csc.itrust.validate;

import edu.ncsu.csc.itrust.beans.forms.EditOfficeVisitForm;
import edu.ncsu.csc.itrust.exception.ErrorList;
import edu.ncsu.csc.itrust.exception.FormValidationException;

public class EditOfficeVisitValidator extends BeanValidator<EditOfficeVisitForm> {
	private boolean validatePrescription = false;
	public EditOfficeVisitValidator() {
	}

	public EditOfficeVisitValidator(boolean validatePrescription) {
		this.validatePrescription = validatePrescription;
	}

	@Override
	public void validate(EditOfficeVisitForm form) throws FormValidationException {
		ErrorList errorList = new ErrorList();
		errorList.addIfNotNull(checkFormat("HCP ID", form.getHcpID(), ValidationFormat.MID, false));
		errorList.addIfNotNull(checkFormat("Hospital ID", form.getHospitalID(), ValidationFormat.HOSPITAL_ID, true));
		errorList.addIfNotNull(checkFormat("Notes", form.getNotes(), ValidationFormat.NOTES, true));
		errorList.addIfNotNull(checkFormat("Patient ID", form.getPatientID(), ValidationFormat.MID, false));
		errorList.addIfNotNull(checkFormat("Visit Date", form.getVisitDate(), ValidationFormat.DATE, false));
		if (validatePrescription) {
			errorList.addIfNotNull(checkFormat("Start Date", form.getStartDate(), ValidationFormat.DATE, false));
			errorList.addIfNotNull(checkFormat("End Date", form.getEndDate(), ValidationFormat.DATE, false));
			errorList.addIfNotNull(checkFormat("Instructions", form.getInstructions(), ValidationFormat.NOTES, true));
			errorList.addIfNotNull(checkInt("Dosage", form.getDosage(), 0, 9999, false));
		}
		if (errorList.hasErrors())
			throw new FormValidationException(errorList);
	}
}
