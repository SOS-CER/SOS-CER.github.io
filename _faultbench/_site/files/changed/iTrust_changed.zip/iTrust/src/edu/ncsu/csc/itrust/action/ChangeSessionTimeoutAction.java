package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;

public class ChangeSessionTimeoutAction {
	private AccessDAO accessDAO;

	public ChangeSessionTimeoutAction(DAOFactory factory) {
		this.accessDAO = factory.getAccessDAO();
	}

	public void changeSessionTimeout(String minuteString) throws FormValidationException, DBException {
		try {
			Integer minutes = Integer.valueOf(minuteString);
			if(minutes < 1)
				throw new FormValidationException("Must be a number greater than 0");
			accessDAO.setSessionTimeoutMins(minutes);
		} catch (NumberFormatException e) {
			throw new FormValidationException("That is not a number");
		}
	}
	
	public int getSessionTimeout() throws DBException{
		return accessDAO.getSessionTimeoutMins();
	}
}
