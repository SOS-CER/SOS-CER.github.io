package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.action.base.PersonnelBaseAction;
import edu.ncsu.csc.itrust.beans.PersonnelBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.validate.PersonnelValidator;

public class EditPersonnelAction extends PersonnelBaseAction {
	private long loggedInMID;
	private PersonnelDAO personnelDAO;
	private TransactionDAO transDAO;
	private PersonnelValidator validator = new PersonnelValidator();;
	
	public EditPersonnelAction(DAOFactory factory, long loggedInMID, String pidString)
			throws iTrustException
	{
		super(factory, pidString);
		this.personnelDAO = factory.getPersonnelDAO();
		this.transDAO = factory.getTransactionDAO();
		this.loggedInMID = loggedInMID;
	}

	public void updateInformation(PersonnelBean personnelForm)
			throws iTrustException, FormValidationException
	{
		personnelForm.setMID(pid);
		validator.validate(personnelForm);
		personnelDAO.editPersonnel(personnelForm);
		transDAO.logTransaction(TransactionType.CREATE_DISABLE_PATIENT_HCP, loggedInMID);
	}
	
}
