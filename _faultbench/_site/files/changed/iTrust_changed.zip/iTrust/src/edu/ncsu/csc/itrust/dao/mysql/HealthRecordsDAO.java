package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.beans.HealthRecord;
import edu.ncsu.csc.itrust.beans.loaders.HealthRecordsBeanLoader;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;

public class HealthRecordsDAO {
	private HealthRecordsBeanLoader loader = new HealthRecordsBeanLoader();
	private DAOFactory factory;

	public HealthRecordsDAO(DAOFactory factory) {
		this.factory = factory;
	}

	public List<HealthRecord> getAllHealthRecords(long mid) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM PersonalHealthInformation "
					+ "WHERE PatientID=? ORDER BY ASOFDATE DESC");
			ps.setLong(1, mid);
			ResultSet rs;
			rs = ps.executeQuery();
			return loader.loadList(rs);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public boolean add(HealthRecord record) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("INSERT INTO PersonalHealthInformation(PatientID,Height,Weight,"
					+ "Smoker,BloodPressureN,BloodPressureD,CholesterolHDL,CholesterolLDL,CholesterolTri,"
					+ "HCPID) VALUES(?,?,?,?,?,?,?,?,?,?)");
			loader.loadParameters(ps, record);
			int numInserted = ps.executeUpdate();
			return (numInserted == 1);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
}
