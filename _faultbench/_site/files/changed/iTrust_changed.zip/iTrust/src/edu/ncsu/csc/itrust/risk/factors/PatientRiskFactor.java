package edu.ncsu.csc.itrust.risk.factors;

abstract public class PatientRiskFactor {
	private Boolean hasRisk = null;

	abstract public String getDescription();

	abstract protected boolean hasFactor();

	public boolean hasRiskFactor() {
		if (hasRisk == null)
			hasRisk = hasFactor();
		return hasRisk;
	}
}
