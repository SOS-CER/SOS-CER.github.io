package edu.ncsu.csc.itrust.action;

import java.util.ArrayList;
import java.util.List;
import edu.ncsu.csc.itrust.action.base.PatientBaseAction;
import edu.ncsu.csc.itrust.beans.AllergyBean;
import edu.ncsu.csc.itrust.beans.FamilyMemberBean;
import edu.ncsu.csc.itrust.beans.HealthRecord;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.beans.PatientBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AllergyDAO;
import edu.ncsu.csc.itrust.dao.mysql.FamilyDAO;
import edu.ncsu.csc.itrust.dao.mysql.HealthRecordsDAO;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.NoHealthRecordsException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.risk.ChronicDiseaseMediator;
import edu.ncsu.csc.itrust.risk.RiskChecker;

public class EditPHRAction extends PatientBaseAction {
	private PatientDAO patientDAO;
	private AllergyDAO allergyDAO;
	private FamilyDAO familyDAO;
	private HealthRecordsDAO hrDAO;
	private OfficeVisitDAO ovDAO;
	private TransactionDAO transDAO;
	private long loggedInMID;
	private ChronicDiseaseMediator diseaseMediator;
	private DAOFactory factory;
	
	public EditPHRAction(DAOFactory factory, long loggedInMID, String pidString) throws iTrustException, DBException,
			NoHealthRecordsException {
		super(factory, pidString);
		this.patientDAO = factory.getPatientDAO();
		this.allergyDAO = factory.getAllergyDAO();
		this.familyDAO = factory.getFamilyDAO();
		this.hrDAO = factory.getHealthRecordsDAO();
		this.ovDAO = factory.getOfficeVisitDAO();
		this.transDAO = factory.getTransactionDAO();
		this.loggedInMID = loggedInMID;
		this.factory = factory;		
	}

	public String updateAllergies(long pid, String description) throws iTrustException {
		if (description != null && !description.equals("")) {
			try {
				allergyDAO.addAllergy(pid, description);
				transDAO.logTransaction(TransactionType.ENTER_EDIT_PHR, loggedInMID, pid, "added allergy "
						+ description);
				return "Allergy Added";
			} catch (DBException e) {
				e.printStackTrace();
				throw new iTrustException(e.getMessage());
			}
		} else
			return "";
	}

	public PatientBean getPatient() throws iTrustException {
		return patientDAO.getPatient(pid);
	}

	public List<AllergyBean> getAllergies() throws iTrustException {
		return allergyDAO.getAllergies(pid);
	}

	public List<FamilyMemberBean> getFamily() throws iTrustException {
		List<FamilyMemberBean> fam = new ArrayList<FamilyMemberBean>();
		fam.addAll(familyDAO.getParents(pid));
		fam.addAll(familyDAO.getSiblings(pid));
		fam.addAll(familyDAO.getChildren(pid));
		return fam;
	}

	public List<HealthRecord> getAllHealthRecords() throws iTrustException {
		List<HealthRecord> allHealthRecords = hrDAO.getAllHealthRecords(pid);
		transDAO.logTransaction(TransactionType.VIEW_RECORDS, loggedInMID, pid, "Viewed patient records");
		return allHealthRecords;
	}

	public List<OfficeVisitBean> getAllOfficeVisits() throws iTrustException {
		return ovDAO.getAllOfficeVisits(pid);
	}

	public List<RiskChecker> getDiseasesAtRisk() throws iTrustException, DBException, NoHealthRecordsException {
		try {
			this.diseaseMediator = new ChronicDiseaseMediator(factory, pid);
		} catch (NoHealthRecordsException e) {
			//TODO Proper exception handling here
			throw e;
		}
		return diseaseMediator.getDiseaseAtRisk();
	}
}
