package edu.ncsu.csc.itrust.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.ncsu.csc.itrust.beans.TransactionBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;

public class ViewMyAccessLogAction {
	private TransactionDAO transDAO;
	private long loggedInMID;

	public ViewMyAccessLogAction(DAOFactory factory, long loggedInMID) {
		this.loggedInMID = loggedInMID;
		this.transDAO = factory.getTransactionDAO();
	}

	public List<TransactionBean> getAccesses(String lowerDate, String upperDate) throws DBException, FormValidationException {
		List<TransactionBean> accesses = new ArrayList<TransactionBean>();
		if (lowerDate == null || upperDate == null)
			return transDAO.getAllRecordAccesses(loggedInMID);
		String message = "";
		try {
			Date lower = new SimpleDateFormat("MM/dd/yyyy").parse(lowerDate);
			Date upper = new SimpleDateFormat("MM/dd/yyyy").parse(upperDate);
			message = "for dates between " + lowerDate + " and " + upperDate;
			accesses = transDAO.getRecordAccesses(loggedInMID, lower, upper);
		} catch (ParseException e) {
			throw new FormValidationException("Enter dates in MM/dd/yyyy");
		}
		transDAO.logTransaction(TransactionType.VIEW_ACCESS_LOG, loggedInMID, 0L, message);
		return accesses;
	}

	public String getDefaultStart(List<TransactionBean> accesses) {
		String startDate = "";
		if (accesses.size() > 0) {
			startDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date(accesses.get(accesses.size() - 1)
					.getTimeLogged().getTime()));
		} else {
			startDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
		}
		return startDate;
	}

	public String getDefaultEnd(List<TransactionBean> accesses) {
		String endDate = "";
		if (accesses.size() > 0) {
			endDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date(accesses.get(0).getTimeLogged().getTime()));
		} else {
			endDate = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
		}
		return endDate;
	}
}
