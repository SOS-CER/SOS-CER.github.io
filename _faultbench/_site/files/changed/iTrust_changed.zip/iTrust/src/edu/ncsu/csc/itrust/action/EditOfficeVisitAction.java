package edu.ncsu.csc.itrust.action;

import java.util.ArrayList;
import java.util.List;

import edu.ncsu.csc.itrust.action.base.OfficeVisitBaseAction;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.beans.HospitalBean;
import edu.ncsu.csc.itrust.beans.MedicationBean;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.beans.PrescriptionBean;
import edu.ncsu.csc.itrust.beans.forms.EditOfficeVisitForm;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.dao.mysql.HospitalsDAO;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.validate.EditOfficeVisitValidator;

public class EditOfficeVisitAction extends OfficeVisitBaseAction {
	private EditOfficeVisitValidator validator = new EditOfficeVisitValidator();
	private PersonnelDAO personnelDAO;
	private HospitalsDAO hospitalDAO;
	private OfficeVisitDAO ovDAO;
	private AccessDAO accessDAO;
	private TransactionDAO transDAO;
	private long loggedInMID;

	private enum OVSubAction {
		ADD_DIAGNOSIS, REMOVE_DIAGNOSIS, ADD_PROCEDURE, REMOVE_PROCEDURE, ADD_MEDICATION, REMOVE_MEDICATION
	};

	public EditOfficeVisitAction(DAOFactory factory, long loggedInMID, String pidString, String ovIDString) throws iTrustException {
		super(factory, pidString, ovIDString);
		ovDAO = factory.getOfficeVisitDAO();
		this.personnelDAO = factory.getPersonnelDAO();
		this.hospitalDAO = factory.getHospitalsDAO();
		this.transDAO = factory.getTransactionDAO();
		this.accessDAO = factory.getAccessDAO();
		this.loggedInMID = loggedInMID;
	}

	public OfficeVisitBean getOfficeVisit() throws iTrustException {
		OfficeVisitBean officeVisit = ovDAO.getOfficeVisit(ovID);
		filterViewableDiagnoses(officeVisit);
		return officeVisit;
	}

	private void filterViewableDiagnoses(OfficeVisitBean ov) throws DBException {
		List<DiagnosisBean> diagnoses = ov.getDiagnoses();
		List<Long> allowableDiagnoses = accessDAO.getAllowableDiagnoses(loggedInMID, pid);
		List<DiagnosisBean> filteredDiagnoses = new ArrayList<DiagnosisBean>();
		for (Long ovdID : allowableDiagnoses) {
			for(DiagnosisBean d : diagnoses){
				if(ovdID==d.getOvDiagnosisID())
					filteredDiagnoses.add(d);
			}
		}
		ov.setDiagnoses(filteredDiagnoses);
	}

	/**
	 * This is a list of all hospitals, ordered by the office visit's hcp FIRST
	 * 
	 * @param hcpID
	 * @return
	 * @throws iTrustException
	 */
	public List<HospitalBean> getHospitals(long hcpID) throws iTrustException {
		try {
			List<HospitalBean> hcpsHospitals = personnelDAO.getHospitals(hcpID);
			List<HospitalBean> allHospitals = hospitalDAO.getAllHospitals();
			return combineLists(hcpsHospitals, allHospitals);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	private List<HospitalBean> combineLists(List<HospitalBean> hcpsHospitals, List<HospitalBean> allHospitals) {
		for (HospitalBean hos : allHospitals) {
			if (!hcpsHospitals.contains(hos))
				hcpsHospitals.add(hos);
		}
		return hcpsHospitals;
	}

	public String updateInformation(EditOfficeVisitForm form) throws FormValidationException {
		String confirm = "";
		try {
			checkAddSubAction(OVSubAction.ADD_DIAGNOSIS, form.getAddDiagID(), ovID);
			checkAddSubAction(OVSubAction.ADD_PROCEDURE, form.getAddProcID(), ovID);
			checkAddPrescription(form, ovID);
			checkRemoveSubAction(OVSubAction.REMOVE_DIAGNOSIS, form.getRemoveDiagID());
			checkRemoveSubAction(OVSubAction.REMOVE_PROCEDURE, form.getRemoveProcID());
			checkRemoveSubAction(OVSubAction.REMOVE_MEDICATION, form.getRemoveMedID());
			updateOv(form);
			transDAO.logTransaction(TransactionType.DOCUMENT_OFFICE_VISIT, loggedInMID,
					getOfficeVisit().getPatientID(), "edited office visit " + ovID);
			confirm = "success";
			return confirm;
		} catch (iTrustException e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	private void checkAddPrescription(EditOfficeVisitForm form, long ovID) throws DBException, FormValidationException {
		if (form.getAddMedID() != null && !"".equals(form.getAddMedID())) {
			new EditOfficeVisitValidator(true).validate(form);
			PrescriptionBean pres = new PrescriptionBean();
			pres.setDosage(Integer.valueOf(form.getDosage()));
			pres.setEndDateStr(form.getEndDate());
			pres.setStartDateStr(form.getStartDate());
			pres.setInstructions(form.getInstructions());
			MedicationBean med = new MedicationBean();
			med.setNDCode(form.getAddMedID());
			pres.setMedication(med);
			pres.setVisitID(ovID);
			ovDAO.addPrescription(pres);
		}
	}

	private void updateOv(EditOfficeVisitForm form) throws DBException, FormValidationException {
		validator.validate(form);
		OfficeVisitBean ov = new OfficeVisitBean(ovID);
		ov.setNotes(form.getNotes());
		ov.setVisitDateStr(form.getVisitDate());
		ov.setHcpID(Long.valueOf(form.getHcpID()));
		ov.setPatientID(Long.valueOf(form.getPatientID()));
		ov.setHospitalID(form.getHospitalID());
		ovDAO.update(ov);
	}

	private boolean checkAddSubAction(OVSubAction action, String code, long visitID) throws DBException {
		if (code == null || "".equals(code)) {
			return false;
		} else {
			switch (action) {
				case ADD_DIAGNOSIS :
					ovDAO.addDiagnosisToOfficeVisit(Double.valueOf(code), visitID);
					break;
				case ADD_PROCEDURE :
					ovDAO.addProcedureToOfficeVisit(code, visitID);
					break;
				default :
					return false;
			}
			return true;
		}
	}

	private boolean checkRemoveSubAction(OVSubAction action, String input) throws DBException {
		if (input == null || "".equals(input))
			return false;
		long removeID;
		try {
			removeID = Long.valueOf(input);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			return false;
		}
		switch (action) {
			case REMOVE_DIAGNOSIS :
				ovDAO.removeDiagnosisFromOfficeVisit(removeID);
				break;
			case REMOVE_PROCEDURE :
				ovDAO.removeProcedureFromOfficeVisit(removeID);
				break;
			case REMOVE_MEDICATION :
				ovDAO.removePrescription(removeID);
				break;
		}
		return true;
	}
}
