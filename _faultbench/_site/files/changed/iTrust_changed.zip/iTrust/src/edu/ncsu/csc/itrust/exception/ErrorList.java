package edu.ncsu.csc.itrust.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ErrorList implements Serializable, Iterable<String> {
	private List<String> errorList;

	public ErrorList() {
		errorList = new ArrayList<String>(); 
	}

	public void addIfNotNull(String errorMessage) {
		if (errorMessage != null && !"".equals(errorMessage))
			errorList.add(errorMessage);
	}

	public List<String> getMessageList() {
		return errorList;
	}

	public boolean hasErrors() {
		return errorList.size() != 0;
	}

	@Override
	public String toString() {
		return errorList.toString();
	}

	public Iterator<String> iterator() {
		return errorList.iterator();
	}
}
