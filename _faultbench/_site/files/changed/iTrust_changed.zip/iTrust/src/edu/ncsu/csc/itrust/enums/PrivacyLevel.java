package edu.ncsu.csc.itrust.enums;

public enum PrivacyLevel {
	ALL_STAFF("All"), DECLARED_ONLY("Declared HCP Only"), NO_ONE("No One");
	private String dbName;

	private PrivacyLevel(String dbName) {
		this.dbName = dbName;
	}

	public String getDBName() {
		return dbName;
	}

	public static PrivacyLevel parse(String str) {
		for (PrivacyLevel level : PrivacyLevel.values()) {
			if (level.getDBName().equals(str))
				return level;
		}
		return ALL_STAFF;
	}
}
