package edu.ncsu.csc.itrust;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ParameterUtil {
	@SuppressWarnings("unchecked")
	public static HashMap<String, String> convertMap(Map params) {
		HashMap<String, String> myMap = new HashMap<String, String>();
		Set<Map.Entry<String,String []>> entryset = params.entrySet();
		for (Map.Entry<String, String []> entry : entryset) {
			String[] value = entry.getValue();
			if (value != null)
				myMap.put(entry.getKey(), value[0]);
			else
				myMap.put(entry.getKey(), null);
		}
		return myMap;
	}
}
