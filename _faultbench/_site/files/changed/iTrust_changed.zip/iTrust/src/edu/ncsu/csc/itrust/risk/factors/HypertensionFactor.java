package edu.ncsu.csc.itrust.risk.factors;

import edu.ncsu.csc.itrust.beans.HealthRecord;

public class HypertensionFactor extends PatientRiskFactor {
	private static final int systolicThreshold = 240;
	private static final int diastolicThreshold = 120;
	private HealthRecord record;

	public HypertensionFactor(HealthRecord currentHealthRecord) {
		this.record = currentHealthRecord;
	}

	public String getDescription() {
		return "Patient has hypertension";
	}

	public boolean hasFactor() {
		return (record.getBloodPressureSystolic() > systolicThreshold)
				|| (record.getBloodPressureDiastolic() > diastolicThreshold);
	}
}
