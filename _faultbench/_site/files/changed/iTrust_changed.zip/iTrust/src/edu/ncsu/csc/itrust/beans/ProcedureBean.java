package edu.ncsu.csc.itrust.beans;

public class ProcedureBean {
	private long ovProcedureID = 0L;
	private String CPTCode;
	private String description;
	
	public ProcedureBean() {  }
	
	public ProcedureBean(String code) {
		CPTCode = code;
	}
	
	public ProcedureBean(String code, String description) {
		CPTCode = code;
		this.description = description;
	}

	/**
	 * Gets the CPT Code for this procedure
	 * @return The CPT Code for this procedure
	 */
	public String getCPTCode() {
		return CPTCode;
	}
	
	public void setCPTCode(String code) {
		CPTCode = code;
	}
	
	/**
	 * Gets the CPT Description for this procedure
	 * @return The CPT Description for this procedure
	 */
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}

	public long getOvProcedureID() {
		return ovProcedureID;
	}

	public void setOvProcedureID(long ovProcedureID) {
		this.ovProcedureID = ovProcedureID;
	}
	
}
