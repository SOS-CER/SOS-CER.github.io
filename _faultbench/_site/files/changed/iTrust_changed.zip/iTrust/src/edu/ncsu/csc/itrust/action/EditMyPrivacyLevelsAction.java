package edu.ncsu.csc.itrust.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.ncsu.csc.itrust.ParameterUtil;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.PrivacyLevel;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class EditMyPrivacyLevelsAction {
	private PatientDAO patientDAO;
	private TransactionDAO transDAO;
	private AccessDAO accessDAO;
	private long loggedInMID;

	public EditMyPrivacyLevelsAction(DAOFactory factory, long loggedInMID) throws iTrustException {
		this.patientDAO = factory.getPatientDAO();
		this.accessDAO = factory.getAccessDAO();
		this.transDAO = factory.getTransactionDAO();
		this.loggedInMID = loggedInMID;
	}

	@SuppressWarnings("unchecked")
	public void updateInformation(Map params) throws iTrustException, FormValidationException {
		HashMap<String, String> myMap = ParameterUtil.convertMap(params);
		accessDAO.updatePrivacyLevels(transferDiagnoses(myMap));
		transDAO.logTransaction(TransactionType.ALLOW_DISALLOW_ACCESS, loggedInMID);
	}

	// This is done so that you can't just mess with the URLs to change someone else's privacy
	// levels. We transfer *only* the diagnoses that *we* have
	// Also, so you only update the diagnoses that have changed
	private List<DiagnosisBean> transferDiagnoses(HashMap<String, String> myMap) throws DBException {
		List<DiagnosisBean> myDiagnoses = getDiagnoses();
		List<DiagnosisBean> updatedDiagnoses = new ArrayList<DiagnosisBean>();
		for (int i = 0; i < myDiagnoses.size(); i++) {
			DiagnosisBean d = myDiagnoses.get(i);
			String param = myMap.get("ovd" + d.getOvDiagnosisID());
			if (param != null && !"".equals(param)) {
				PrivacyLevel myLevel = PrivacyLevel.parse(param);
				if (!d.getPrivacyLevel().equals(myLevel)) {
					DiagnosisBean newD = new DiagnosisBean(); // new bean
					newD.setOvDiagnosisID(d.getOvDiagnosisID());
					newD.setPrivacyLevel(myLevel);
					updatedDiagnoses.add(newD);
				}
			}
		}
		return updatedDiagnoses;
	}

	public List<DiagnosisBean> getDiagnoses() throws DBException {
		return patientDAO.getDiagnoses(loggedInMID);
	}
}
