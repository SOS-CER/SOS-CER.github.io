package edu.ncsu.csc.itrust.risk;

import java.util.ArrayList;
import java.util.List;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.NoHealthRecordsException;

public class ChronicDiseaseMediator {
	private List<RiskChecker> riskCheckers;

	public ChronicDiseaseMediator(DAOFactory factory, long pid) throws DBException, NoHealthRecordsException {
		riskCheckers = new ArrayList<RiskChecker>();
		riskCheckers.add(new HeartDiseaseRisks(factory, pid));
		riskCheckers.add(new Type1DiabetesRisks(factory, pid));
		riskCheckers.add(new Type2DiabetesRisks(factory, pid));
	}

	public List<RiskChecker> getDiseaseAtRisk() {
		List<RiskChecker> diseases = new ArrayList<RiskChecker>();
		for (RiskChecker diseaseChecker : riskCheckers) {
			if (diseaseChecker.isAtRisk())
				diseases.add(diseaseChecker);
		}
		return diseases;
	}
}
