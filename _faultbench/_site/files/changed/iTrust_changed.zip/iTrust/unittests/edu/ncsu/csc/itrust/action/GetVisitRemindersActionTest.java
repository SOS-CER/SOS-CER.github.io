package edu.ncsu.csc.itrust.action;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class GetVisitRemindersActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private GetVisitRemindersAction action;

	@Override
	protected void setUp() throws Exception {
		action = new GetVisitRemindersAction(factory, 9000000000L);
	}

	public void testNormalReturn() throws Exception {
		TestDataGenerator gen = new TestDataGenerator();
		gen.clearPatientsOfficeVisits();
		gen.insertPatient1();
		action.getVisitReminders(GetVisitRemindersAction.ReminderType.DIAGNOSED_CARE_NEEDERS);
		action.getVisitReminders(GetVisitRemindersAction.ReminderType.FLU_SHOT_NEEDERS);
	}

	public void testNoSubAction() throws Exception {
		TestDataGenerator gen = new TestDataGenerator();
		gen.clearPatientsOfficeVisits();
		assertEquals(0, action.getVisitReminders(GetVisitRemindersAction.ReminderType.FLU_SHOT_NEEDERS).size());
	}
	
	public void testBadReminderType() throws Exception {
		try {
			action.getVisitReminders(null);
			fail("testBadReminderType: bad reminder type not caught");
		} catch(iTrustException e) {
			assertEquals("Reminder Type DNE", e.getMessage());
		}
	}
}
