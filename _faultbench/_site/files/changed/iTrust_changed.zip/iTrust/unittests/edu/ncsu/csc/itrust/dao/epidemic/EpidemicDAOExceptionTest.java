package edu.ncsu.csc.itrust.dao.epidemic;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.EpidemicDAO;
import edu.ncsu.csc.itrust.enums.State;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class EpidemicDAOExceptionTest extends TestCase {
	private EpidemicDAO evilDAO = DAOFactory.getEvilTestInstance().getEpidemicDAO();

	@Override
	protected void setUp() throws Exception {
	}

	public void testGetDiagnosisCountsException() throws Exception {
		try {
			evilDAO.getDiagnosisCounts(0.0, 0.0, "", State.AK, null, 0);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetWeeklyAverageException() throws Exception {
		try {
			evilDAO.getWeeklyAverage(0.0, 0.0, "", null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
}
