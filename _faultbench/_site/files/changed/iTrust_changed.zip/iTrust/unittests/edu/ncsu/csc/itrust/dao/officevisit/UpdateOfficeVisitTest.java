package edu.ncsu.csc.itrust.dao.officevisit;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;

public class UpdateOfficeVisitTest extends TestCase{
	private OfficeVisitDAO ovDAO = DAOFactory.getTestInstance().getOfficeVisitDAO();

	public void testUpdateNewOfficeVisit() throws Exception {
		OfficeVisitBean ov = new OfficeVisitBean();
		long newOVID = ovDAO.add(ov);
		ov = new OfficeVisitBean(newOVID);
		ov.setNotes("some notes");
		ov.setVisitDateStr("07/07/2007");
		ov.setPatientID(65);
		ov.setHcpID(5);
		ov.setHospitalID("9191919191");
		ovDAO.update(ov);
		ov = ovDAO.getOfficeVisit(newOVID);
		assertEquals("some notes",ov.getNotes());
		assertEquals("07/07/2007", new SimpleDateFormat("MM/dd/yyyy").format(ov.getVisitDate()));
		assertEquals(65, ov.getPatientID());
		assertEquals(5, ov.getHcpID());
		assertEquals("9191919191",ov.getHospitalID());
		deleteOV(newOVID);
	}
	

	private void deleteOV(long newOVID) throws SQLException {
		Connection conn = DAOFactory.getTestInstance().getConnection();
		conn.createStatement().execute(
				"DELETE FROM OfficeVisits WHERE ID=" + newOVID);
		conn.close();
	}
}
