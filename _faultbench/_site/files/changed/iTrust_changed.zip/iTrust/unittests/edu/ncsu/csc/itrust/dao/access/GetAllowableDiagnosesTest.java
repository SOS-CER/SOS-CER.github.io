package edu.ncsu.csc.itrust.dao.access;

import java.util.Collections;
import java.util.List;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;

public class GetAllowableDiagnosesTest extends TestCase {
	private AccessDAO accessDAO = DAOFactory.getTestInstance().getAccessDAO();
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.insertPatient2();
	}

	public void testFilteredDiagnosesNotDeclared() throws Exception {
		gen.insertHCP0();
		List<Long> allowableDiagnoses = getDiagnoses(9000000000L, 2L);
		assertEquals(2, allowableDiagnoses.size());
		
	}

	public void testFilteredDiagnosesIsDeclared() throws Exception {
		gen.insertHCP3();
		List<Long> allowableDiagnoses = getDiagnoses(9000000003L, 2L);
		assertEquals(3, allowableDiagnoses.size());
	}

	private List<Long> getDiagnoses(long hcpID, long pid) throws DBException {
		List<Long> allowableDiagnoses = accessDAO.getAllowableDiagnoses(hcpID, pid);
		Collections.sort(allowableDiagnoses);
		return allowableDiagnoses;
	}
}
