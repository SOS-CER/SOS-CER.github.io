package edu.ncsu.csc.itrust.dao.access;

import java.sql.Connection;
import java.sql.SQLException;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class GetSessionTimeoutTest extends TestCase {
	private AccessDAO accessDAO = DAOFactory.getTestInstance().getAccessDAO();
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.resetTimeout();
	}

	public void testChangeTimeout() throws Exception {
		assertEquals(20, accessDAO.getSessionTimeoutMins());
		accessDAO.setSessionTimeoutMins(5);
		assertEquals(5, accessDAO.getSessionTimeoutMins());
	}

	public void testUpdateBadTimeout() throws Exception {
		deleteTimeout();
		assertEquals(20, accessDAO.getSessionTimeoutMins());
		deleteTimeout();
		accessDAO.setSessionTimeoutMins(5);
		assertEquals(5, accessDAO.getSessionTimeoutMins());
	}

	private void deleteTimeout() throws SQLException {
		Connection conn = DAOFactory.getTestInstance().getConnection();
		conn.createStatement().execute("DELETE FROM GlobalVariables WHERE Name='Timeout'");
		conn.close();
	}
}
