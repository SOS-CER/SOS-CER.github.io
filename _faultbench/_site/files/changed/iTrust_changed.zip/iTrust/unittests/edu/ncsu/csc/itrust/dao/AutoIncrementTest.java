package edu.ncsu.csc.itrust.dao;

import java.sql.Connection;
import java.sql.SQLException;
import edu.ncsu.csc.itrust.DBUtil;
import junit.framework.TestCase;

public class AutoIncrementTest extends TestCase {
	@Override
	protected void setUp() throws Exception {
		Connection conn = DAOFactory.getTestInstance().getConnection();
		conn.createStatement().execute("DROP TABLE IF EXISTS testincrement");
		conn.createStatement().execute("CREATE TABLE testincrement(id integer auto_increment primary key)");
		conn.close();
	}

	public void testNoIncrementCollision() throws Exception {
		Connection conn1 = DAOFactory.getTestInstance().getConnection();
		conn1.createStatement().execute("INSERT INTO testincrement VALUES()");
		doTheSecond();
		assertEquals(1L, DBUtil.getLastInsert(conn1));
		// See? It's on a per-connection basis. Nothing to worry about.
	}

	private void doTheSecond() throws SQLException {
		Connection conn2 = DAOFactory.getTestInstance().getConnection();
		conn2.createStatement().execute("INSERT INTO testincrement VALUES()");
		assertEquals(2L, DBUtil.getLastInsert((conn2)));
	}

	@Override
	protected void tearDown() throws Exception {
		Connection conn = DAOFactory.getTestInstance().getConnection();
		conn.createStatement().execute("DROP TABLE IF EXISTS testincrement");
		conn.close();
	}
}
