package edu.ncsu.csc.itrust.action;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class LoginFailureActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private TestDataGenerator gen;
	private LoginFailureAction action;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.resetLoginFailures();
		action = new LoginFailureAction(factory, "192.168.1.1");
	}
	
	public void testNormalLoginFailureSequence() throws Exception {
		assertTrue(action.isValidForLogin());
		assertEquals("Login failed, attempt 1", action.recordLoginFailure());
		assertTrue(action.isValidForLogin());
		assertEquals("Login failed, attempt 2", action.recordLoginFailure());
		assertTrue(action.isValidForLogin());
		assertEquals("Login failed, attempt 3", action.recordLoginFailure());
		assertFalse(action.isValidForLogin());
	}
}
