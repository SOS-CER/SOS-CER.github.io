package edu.ncsu.csc.itrust.dao.allergies;

import java.util.List;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.AllergyBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AllergyDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class GetAllergiesTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private AllergyDAO allergyDAO = factory.getAllergyDAO();

	@Override
	protected void setUp() throws Exception {
		TestDataGenerator gen = new TestDataGenerator();
		gen.insertPatient2();
		gen.insertPatient1();
	}

	public void testGetAllergiesFor1() throws Exception {
		assertEquals(0, allergyDAO.getAllergies(1L).size());
	}

	public void testGetAllergiesFor2() throws Exception {
		List<AllergyBean> allergies = allergyDAO.getAllergies(2L);
		assertEquals(2, allergies.size());
		assertEquals("Pollen", allergies.get(0).getDescription());
		assertEquals(2, allergies.get(0).getPatientID());
		assertEquals("Penicillin", allergies.get(1).getDescription());
		assertEquals(2, allergies.get(1).getPatientID());
	}
}
