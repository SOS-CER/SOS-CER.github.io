package edu.ncsu.csc.itrust.dao.hospital;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.HospitalsDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class HospitalDAOExceptionTest extends TestCase {
	private HospitalsDAO evilDAO = DAOFactory.getEvilTestInstance().getHospitalsDAO();

	@Override
	protected void setUp() throws Exception {
	}

	public void testAddHospitalException() throws Exception {
		try {
			evilDAO.addHospital(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testAssignHospitalException() throws Exception {
		try {
			evilDAO.assignHospital(0L, "");
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetAllHospitalsException() throws Exception {
		try {
			evilDAO.getAllHospitals();
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetHospitalException() throws Exception {
		try {
			evilDAO.getHospital("");
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testRemoveAllHospitalAssignmentsException() throws Exception {
		try {
			evilDAO.removeAllHospitalAssignmentsFrom(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testRemoveHospitalAssignmentException() throws Exception {
		try {
			evilDAO.removeHospitalAssignment(0L, "");
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testUpdateHospitalException() throws Exception {
		try {
			evilDAO.updateHospital(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
}
