package edu.ncsu.csc.itrust.dao.patient;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.exception.iTrustException;
import junit.framework.TestCase;

public class AddPatientTest extends TestCase {
	PatientDAO patientDAO = DAOFactory.getTestInstance().getPatientDAO();

	@Override
	protected void setUp() throws Exception {
	}

	public void testAddEmptyPatient() throws Exception {
		long pid = patientDAO.addEmptyPatient();
		assertEquals(" ", patientDAO.getName(pid));
	}

	public void testGetEmptyPatient() throws Exception {
		try {
			patientDAO.getName(0L);
			fail("exception should have been thrown");
		} catch (iTrustException e) {
			assertEquals("User does not exist", e.getMessage());
		}
	}
}
