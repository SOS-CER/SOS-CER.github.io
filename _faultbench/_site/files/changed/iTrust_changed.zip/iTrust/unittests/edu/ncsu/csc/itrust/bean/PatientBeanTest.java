package edu.ncsu.csc.itrust.bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import junit.framework.TestCase;
import edu.ncsu.csc.itrust.DateUtil;
import edu.ncsu.csc.itrust.beans.PatientBean;

public class PatientBeanTest extends TestCase {
	private Date today;

	@Override
	protected void setUp() throws Exception {
		today = new Date();
	}

	public void testAgeZero() throws Exception {
		PatientBean baby = new PatientBean();
		baby.setDateOfBirthStr(new SimpleDateFormat("MM/dd/yyyy").format(today));
		assertEquals(0, baby.getAge());
	}

	public void testAge10() throws Exception {
		PatientBean kid = new PatientBean();
		kid.setDateOfBirthStr(DateUtil.yearsAgo(10));
		assertEquals(10, kid.getAge());
	}


	
	
}
