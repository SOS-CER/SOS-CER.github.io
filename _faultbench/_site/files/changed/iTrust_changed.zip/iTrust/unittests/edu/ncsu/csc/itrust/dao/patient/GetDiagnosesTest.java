package edu.ncsu.csc.itrust.dao.patient;

import java.util.List;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class GetDiagnosesTest extends TestCase {
	private PatientDAO patientDAO = DAOFactory.getTestInstance().getPatientDAO();
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
	}

	public void testGetPatient2() throws Exception {
		gen.insertPatient2();
		List<DiagnosisBean> diagnoses = patientDAO.getDiagnoses(2L);
		assertEquals(4, diagnoses.size());
		assertEquals(250.1, diagnoses.get(0).getICDCode());
		assertEquals("Diabetes with ketoacidosis", diagnoses.get(0).getDescription());
	}

	public void testNotPatient200() throws Exception {
		gen.deletePatient200();
		List<DiagnosisBean> diagnoses = patientDAO.getDiagnoses(200L);
		assertEquals(0, diagnoses.size());
	}
}
