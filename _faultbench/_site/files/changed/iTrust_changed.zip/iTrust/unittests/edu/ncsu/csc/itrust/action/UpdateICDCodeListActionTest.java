package edu.ncsu.csc.itrust.action;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;


public class UpdateICDCodeListActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private UpdateICDCodeListAction action;
	private TestDataGenerator gen;
	private final long performingAdmin = 9000000001l;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		action = new UpdateICDCodeListAction(factory, performingAdmin);
		
	}

	private String getAddCodeSuccessString(DiagnosisBean proc) {
		return "Success: " + proc.getICDCode() + " - " + proc.getDescription() + " added";
	}

	private void addEmpty(double code) throws Exception {
		DiagnosisBean proc = new DiagnosisBean(code, " ");
		assertEquals(getAddCodeSuccessString(proc), action.addICDCode(proc));
		proc = factory.getICDCodesDAO().getICDCode(code);
		assertEquals(" ", proc.getDescription());
	}

	public void testAddICDCode() throws Exception {
		gen.resetAllICD9CMCodes();
		final double code = 999.99;
		final String desc = "testAddICDCode";
		DiagnosisBean proc = new DiagnosisBean(code, desc);
		assertEquals(getAddCodeSuccessString(proc), action.addICDCode(proc));
		proc = factory.getICDCodesDAO().getICDCode(code);
		assertEquals(desc, proc.getDescription());
	}

	public void testAddDuplicate() throws Exception {
		gen.resetAllICD9CMCodes();
		final double code = 000.00;
		final String descrip0 = "description 0";
		DiagnosisBean proc = new DiagnosisBean(code, descrip0);
		assertEquals(getAddCodeSuccessString(proc), action.addICDCode(proc));
		proc.setDescription("description 1");
		assertEquals("Error: Code already exists.", action.addICDCode(proc));
		proc = factory.getICDCodesDAO().getICDCode(code);
		assertEquals(descrip0, proc.getDescription());
	}

	public void testUpdateICDInformation0() throws Exception {
		final double code = 888.88;
		final String desc = "new descrip 0";
		DiagnosisBean proc = new DiagnosisBean(code);
		addEmpty(code);
		proc.setDescription(desc);
		assertEquals("Success: 1 row(s) updated", action.updateInformation(proc));
		proc = factory.getICDCodesDAO().getICDCode(code);
		assertEquals(desc, proc.getDescription());
	}

	public void testUpdateNonExistent() throws Exception {
		final double code = 999.99;
		gen.resetAllICD9CMCodes();
		DiagnosisBean proc = new DiagnosisBean(code, "shouldnt be here");
		assertEquals("Error: Code not found.", action.updateInformation(proc));
		assertEquals(null, factory.getICDCodesDAO().getICDCode(code));
		assertEquals(5, factory.getICDCodesDAO().getAllICDCodes().size());
	}
}
