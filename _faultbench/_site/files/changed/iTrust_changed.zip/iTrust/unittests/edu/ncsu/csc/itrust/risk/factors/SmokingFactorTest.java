package edu.ncsu.csc.itrust.risk.factors;

import java.sql.Connection;
import java.sql.SQLException;
import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class SmokingFactorTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private TestDataGenerator gen;
	private PatientRiskFactor factor;

	@Override
	protected void setUp() throws Exception {
		factor = new SmokingFactor(factory, 2L);
		gen = new TestDataGenerator();
		gen.insertPatient2();
	}

	public void testHasHistory() throws Exception {
		assertTrue(factor.hasRiskFactor());
	}

	public void testHasNoHistory() throws Exception {
		clearHistoryOfSmoking();
		assertFalse(factor.hasRiskFactor());
	}
	
	public void testDBException() throws Exception {
		this.factory = DAOFactory.getEvilTestInstance();
		factor = new SmokingFactor(factory, 2L);
		assertFalse(factor.hasFactor());
	}

	private void clearHistoryOfSmoking() throws SQLException {
		Connection conn = factory.getConnection();
		conn.createStatement().execute("DELETE FROM PersonalHealthInformation WHERE PatientID=2 AND Smoker=1");
		conn.close();
	}
}
