package edu.ncsu.csc.itrust.action;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.HospitalBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;


public class UpdateHospitalListActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private UpdateHospitalListAction action;
	private TestDataGenerator gen = new TestDataGenerator();
	private  long performingAdmin = 9000000001l;

	@Override
	protected void setUp() throws Exception {
		action = new UpdateHospitalListAction(factory, performingAdmin);
		gen.resetAllHospitals();
	}

	private String getAddHospitalSuccessString(HospitalBean proc) {
		return "Success: " + proc.getHospitalID() + " - " + proc.getHospitalName() + " added";
	}

	private void addEmpty(String id) throws Exception {
		HospitalBean hosp = new HospitalBean(id, " ");
		assertEquals(getAddHospitalSuccessString(hosp), action.addHospital(hosp));
		hosp = factory.getHospitalsDAO().getHospital(id);
		assertEquals(" ", hosp.getHospitalName());
	}

	public void testAddHospital() throws Exception {
		 String id = "9999999999";
		 String name = "testAddHospital Hospital";
		HospitalBean hosp = new HospitalBean(id, name);
		assertEquals(getAddHospitalSuccessString(hosp), action.addHospital(hosp));
		hosp = factory.getHospitalsDAO().getHospital(id);
		assertEquals(name, hosp.getHospitalName());
	}

	public void testAddDuplicate() throws Exception {
		 String id = "0000000000";
		 String name0 = "hospital 0";
		HospitalBean hosp = new HospitalBean(id, name0);
		assertEquals(getAddHospitalSuccessString(hosp), action.addHospital(hosp));
		hosp.setHospitalName("hospital 1");
		assertEquals("Error: Hospital already exists.", action.addHospital(hosp));
		hosp = factory.getHospitalsDAO().getHospital(id);
		assertEquals(name0, hosp.getHospitalName());
	}

	public void testUpdateICDInformation0() throws Exception {
		 String id = "8888888888";
		 String name = "new hospital 8...";
		HospitalBean hosp = new HospitalBean(id);
		addEmpty(id);
		hosp.setHospitalName(name);
		assertEquals("Success: 1 row(s) updated", action.updateInformation(hosp));
		hosp = factory.getHospitalsDAO().getHospital(id);
		assertEquals(name, hosp.getHospitalName());
	}

	public void testUpdateNonExistent() throws Exception {
		 String id = "9999999999";
		HospitalBean hosp = new HospitalBean(id, "shouldn't be here");
		assertEquals("Error: Hospital not found.", action.updateInformation(hosp));
		assertEquals(null, factory.getHospitalsDAO().getHospital(id));
		assertEquals(3, factory.getHospitalsDAO().getAllHospitals().size());
	}
}
