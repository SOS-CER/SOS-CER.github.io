package edu.ncsu.csc.itrust.dao.access;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;

public class UpdateDiscretionaryAccessTest extends TestCase {
	private AccessDAO accessDAO = DAOFactory.getTestInstance().getAccessDAO();
	private OfficeVisitDAO ovDAO = DAOFactory.getTestInstance().getOfficeVisitDAO();
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.insertPatient2();
	}

	public void testUpdateDiscretionary() throws Exception {
		List<DiagnosisBean> diagnoses = getDiagnoses();
		assertEquals(3, diagnoses.size());
		assertFalse(diagnoses.get(0).isDiscretionaryAccess());
		assertTrue(diagnoses.get(1).isDiscretionaryAccess());
		diagnoses.get(0).setDiscretionaryAccess(true);
		diagnoses.get(1).setDiscretionaryAccess(false);
		accessDAO.updateDiscretionaryAccess(diagnoses);
		diagnoses = getDiagnoses();
		assertEquals(3, diagnoses.size());
		assertTrue(diagnoses.get(0).isDiscretionaryAccess());
		assertFalse(diagnoses.get(1).isDiscretionaryAccess());
	}

	private List<DiagnosisBean> getDiagnoses() throws DBException {
		List<DiagnosisBean> diagnoses = ovDAO.getDiagnoses(10);
		Collections.sort(diagnoses, new Comparator<DiagnosisBean>() {
			public int compare(DiagnosisBean o1, DiagnosisBean o2) {
				return Long.valueOf(o1.getOvDiagnosisID()).compareTo(Long.valueOf(o2.getOvDiagnosisID()));
			}
		});
		return diagnoses;
	}
}
