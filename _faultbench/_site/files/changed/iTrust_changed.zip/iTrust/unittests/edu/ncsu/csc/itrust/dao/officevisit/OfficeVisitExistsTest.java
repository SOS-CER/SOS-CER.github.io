package edu.ncsu.csc.itrust.dao.officevisit;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class OfficeVisitExistsTest extends TestCase {
	private OfficeVisitDAO ovDAO = DAOFactory.getTestInstance().getOfficeVisitDAO();

	public void testExists() throws Exception {
		new TestDataGenerator().insertOfficeVisit1();
		assertTrue(ovDAO.checkOfficeVisitExists(1, 1));
		// wrong patient
		assertFalse(ovDAO.checkOfficeVisitExists(1, 2));
	}

	public void testDoesNotExist() throws Exception {
		assertFalse(ovDAO.checkOfficeVisitExists(500, 1));
	}
}
