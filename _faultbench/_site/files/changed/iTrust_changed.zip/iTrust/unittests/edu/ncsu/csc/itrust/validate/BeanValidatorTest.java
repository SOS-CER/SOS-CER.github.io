package edu.ncsu.csc.itrust.validate;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.testutils.ValidatorProxy;

public class BeanValidatorTest extends TestCase {
	private ValidatorProxy validatorProxy = new ValidatorProxy();

	public void testCheckIsNullable() throws Exception {
		String value = null;
		String errorMessage = "";
		assertEquals(errorMessage, validatorProxy.checkFormat("Name", value, ValidationFormat.NAME, true));
	}

	public void testCheckIsNullableEmpty() throws Exception {
		String value = "";
		String errorMessage = "";
		assertEquals(errorMessage, validatorProxy.checkFormat("Name", value, ValidationFormat.NAME, true));
	}

	public void testCheckLongValues() throws Exception {
		Long value = 80L;
		String errorMessage = "";
		assertEquals(errorMessage, validatorProxy.checkFormat("Name", value, ValidationFormat.MID, true));
	}

	public void testProxyIsOnlyProxy() throws Exception {
		try {
			validatorProxy.validate(null);
			fail("exception should have been thrown");
		} catch (IllegalStateException e) {
			assertEquals("Mock object acts as a proxy to protected BeanValidator classes. Do not call this method", e
					.getMessage());
		}
	}
}
