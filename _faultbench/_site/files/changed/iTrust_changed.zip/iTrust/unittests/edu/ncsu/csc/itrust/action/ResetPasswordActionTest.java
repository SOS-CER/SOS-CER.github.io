package edu.ncsu.csc.itrust.action;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.validate.ValidationFormat;

public class ResetPasswordActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private ResetPasswordAction action;
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.deletePatient200();
		gen.insertPatient1();
		gen.insertHCP0();
		action = new ResetPasswordAction(factory);
	}

	public void testCheckMID() throws Exception {
		assertEquals("empty", 0, action.checkMID(""));
		assertEquals("null", 0, action.checkMID(null));
		assertEquals("not a number", 0, action.checkMID("a"));
		assertEquals("non-existant", 0, action.checkMID("200"));
		assertEquals("existant", 1, action.checkMID("1"));
		assertEquals("existant", 9000000000L, action.checkMID("9000000000"));
	}

	public void testCheckRole() throws Exception {
		assertEquals("patient", action.checkRole("patient"));
		assertEquals("hcp", action.checkRole("hcp"));
		assertEquals("uap", action.checkRole("uap"));
		assertEquals(null, action.checkRole("admin"));
		assertEquals(null, action.checkRole("HCP"));
	}

	public void testCheckAnswerNull() throws Exception {
		assertEquals("empty", null, action.checkAnswerNull(""));
		assertEquals("null", null, action.checkAnswerNull(null));
		assertEquals("answer", action.checkAnswerNull("answer"));
	}

	public void testGetSecurityQuestion() throws Exception {
		assertEquals("What is your favorite color?", action.getSecurityQuestion(1, "patient"));
		assertEquals("first letter?", action.getSecurityQuestion(9000000000L, "hcp"));
		assertEquals("first letter?", action.getSecurityQuestion(9000000000L, "uap"));
		assertEquals("", action.getSecurityQuestion(9000000000L, "blah"));
	}

	public void testResetPassword() throws Exception {
		assertEquals("Answer did not match", action.resetPassword(1L, "patient", "wrong", "12345678", "12345678"));
		assertEquals("Answer did not match", action.resetPassword(9000000000L, "hcp", "wrong", "12345678", "12345678"));
		assertEquals("Invalid role", action.resetPassword(9000000000L, "a", "a", "12345678", "12345678"));
		assertEquals("Password changed", action.resetPassword(1L, "patient", "blue", "12345678", "12345678"));
		assertEquals("Password changed", action.resetPassword(9000000000L, "hcp", "a", "12345678", "12345678"));
		assertEquals("Password changed", action.resetPassword(9000000000L, "uap", "a", "12345678", "12345678"));
	}

	public void testValidatePasswordNull() throws Exception {
		try {
			action.resetPassword(1L, "patient", "blue", null, "12345678");
			fail("exception should have been thrown");
		} catch (FormValidationException e) {
			assertEquals("Password cannot be empty", e.getErrorList().get(0));
			assertEquals(1, e.getErrorList().size());
		}
	}

	public void testValidatePasswordEmpty() throws Exception {
		try {
			action.resetPassword(1L, "patient", "blue", "", "12345678");
			fail("exception should have been thrown");
		} catch (FormValidationException e) {
			assertEquals("Password cannot be empty", e.getErrorList().get(0));
			assertEquals(1, e.getErrorList().size());
		}
	}

	public void testValidatePasswordWrong() throws Exception {
		try {
			action.resetPassword(1L, "patient", "blue", "1234567", "12345678");
			fail("exception should have been thrown");
		} catch (FormValidationException e) {
			assertEquals("Passwords don't match", e.getErrorList().get(0));
			assertEquals("Password must be in the following format: " + ValidationFormat.PASSWORD.getDescription(), e
					.getErrorList().get(1));
			assertEquals(2, e.getErrorList().size());
		}
	}
}
