package edu.ncsu.csc.itrust.action;

import java.util.List;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.HospitalBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class EditOfficeVisitActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private TestDataGenerator gen = new TestDataGenerator();
	private EditOfficeVisitAction action;

	@Override
	protected void setUp() throws Exception {
		gen.resetAllHospitals();
		gen.insertHCP0();
		gen.insertOfficeVisit1();
		action = new EditOfficeVisitAction(factory, 0L, "1", "1");
	}

	public void testGetHospitals() throws Exception {
		List<HospitalBean> hospitals = action.getHospitals(9000000000L);
		assertEquals(3, hospitals.size());
		assertEquals("Test Hospital 8181818181", hospitals.get(0).getHospitalName());
		assertEquals("Test Hospital 9191919191", hospitals.get(1).getHospitalName());
		assertEquals("Test Hospital 1", hospitals.get(2).getHospitalName());
	}
}
