package edu.ncsu.csc.itrust.testutils;

import java.sql.Connection;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.dao.IConnectionDriver;

/**
 * This class is an "evil" (or Diabolical) test connection driver that will not give you a
 * connection, but instead will throw a special SQLException every time. Unit tests need to test
 * this catch block and assert the SQLException message. <br>
 * <br>
 * It's implemented as a singleton to make unit tests easier (just a pointer comparison)
 * 
 * @author Andy
 * 
 */
public class EvilTestConnectionDriver implements IConnectionDriver {
	public static final String MESSAGE = "Exception thrown from Evil Test Connection Driver";

	public EvilTestConnectionDriver() {
	}

	public Connection getConnection() throws SQLException {
		throw new SQLException(MESSAGE);
	}
}
