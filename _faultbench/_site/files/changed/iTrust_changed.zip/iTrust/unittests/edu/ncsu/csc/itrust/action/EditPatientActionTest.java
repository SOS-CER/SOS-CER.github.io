package edu.ncsu.csc.itrust.action;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class EditPatientActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private TestDataGenerator gen = new TestDataGenerator();
	private EditPatientAction action;

	@Override
	protected void setUp() throws Exception {
		gen.deletePatient200();
		gen.insertPatient2();
		action = new EditPatientAction(factory, 0L, "2");
	}

	public void testConstructNormal() throws Exception {
		assertEquals(2L,action.getPid());
	}
	
	public void testNonExistent() throws Exception {
		try {
			action = new EditPatientAction(factory, 0L, "200");
			fail("exception should have been thrown");
		} catch (iTrustException e) {
			assertEquals("Patient does not exist", e.getMessage());
		}
	}

	public void testWrongFormat() throws Exception {
		try {
			action = new EditPatientAction(factory, 0L, "hello!");
			fail("exception should have been thrown");
		} catch (iTrustException e) {
			assertEquals("Patient ID is not a number: For input string: \"hello!\"", e.getMessage());
		}
	}

	public void testNull() throws Exception {
		try {
			action = new EditPatientAction(factory, 0L,null);
			fail("exception should have been thrown");
		} catch (iTrustException e) {
			assertEquals("Patient ID is not a number: null", e.getMessage());
		}
	}
}
