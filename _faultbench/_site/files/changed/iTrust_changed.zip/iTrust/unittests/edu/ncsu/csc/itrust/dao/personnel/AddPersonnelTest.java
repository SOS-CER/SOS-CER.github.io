package edu.ncsu.csc.itrust.dao.personnel;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.iTrustException;
import junit.framework.TestCase;

public class AddPersonnelTest extends TestCase {
	PersonnelDAO personnelDAO = DAOFactory.getTestInstance().getPersonnelDAO();
	
	@Override
	protected void setUp() throws Exception {
		
	}
	
	public void testAddEmptyPersonnel() throws Exception {
		long mid = personnelDAO.addEmptyPersonnel();
		assertEquals(" ", personnelDAO.getName(mid));
		assertEquals("hcp", personnelDAO.getPersonnel(mid).getRole());
	}
	
	public void testAddEmptyUAP() throws Exception {
		new TestDataGenerator().insertHCP0();
		long mid = personnelDAO.addEmptyPersonnel(9000000000l);
		assertEquals(" ", personnelDAO.getName(mid));
		assertEquals("uap", personnelDAO.getPersonnel(mid).getRole());
	}
	
	public void testDoesNotExist() throws Exception {
		try{
			personnelDAO.getName(0L);
			fail("exception should have been thrown");
		} catch(iTrustException e){
			assertEquals("User does not exist",e.getMessage());
		}
	}
}
