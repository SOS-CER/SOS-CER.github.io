package edu.ncsu.csc.itrust.enums;

import junit.framework.TestCase;

public class TransactionTypeTest extends TestCase {
	public void testParse() throws Exception {
		for(TransactionType type : TransactionType.values()){
			assertEquals(type, TransactionType.parse(type.getCode()));
		}
	}
	
	public void testBadParse() throws Exception {
		try{
			TransactionType.parse(21);
			TransactionType.parse(22);
			fail("exception should have been thrown");
		}catch(IllegalArgumentException e){
			assertEquals("No transaction type exists for code 22", e.getMessage());
		}
	}
}
