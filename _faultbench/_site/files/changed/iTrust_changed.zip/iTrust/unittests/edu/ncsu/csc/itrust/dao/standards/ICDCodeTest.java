package edu.ncsu.csc.itrust.dao.standards;

import java.util.List;
import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.ICDCodesDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class ICDCodeTest extends TestCase{
	private ICDCodesDAO icdDAO = DAOFactory.getTestInstance().getICDCodesDAO();

	@Override
	protected void setUp() throws Exception {
		TestDataGenerator gen = new TestDataGenerator();
		gen.resetAllICD9CMCodes();
	}
	
	public void testGetAllICD() throws Exception {
		List<DiagnosisBean> codes = icdDAO.getAllICDCodes();
		assertEquals(5,codes.size());
		assertEquals("Echovirus", codes.get(0).getDescription());
		assertEquals(79.3, codes.get(1).getICDCode());
	}
}
