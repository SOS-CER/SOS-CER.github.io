package edu.ncsu.csc.itrust.dao.transaction;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class TransactionDAOExceptionTest extends TestCase {
	private TransactionDAO evilDAO = DAOFactory.getEvilTestInstance().getTransactionDAO();

	@Override
	protected void setUp() throws Exception {
	}

	public void testGetAllAccessException() throws Exception {
		try {
			evilDAO.getAllRecordAccesses(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testAllTransactionsException() throws Exception {
		try {
			evilDAO.getAllTransactions();
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testRecordAccessesException() throws Exception {
		try {
			evilDAO.getRecordAccesses(0L, null, null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testLogException() throws Exception {
		try {
			evilDAO.logTransaction(null, 0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
}
