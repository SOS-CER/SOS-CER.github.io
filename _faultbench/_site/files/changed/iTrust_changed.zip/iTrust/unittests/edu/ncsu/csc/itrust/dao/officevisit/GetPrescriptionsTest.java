package edu.ncsu.csc.itrust.dao.officevisit;

import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.PrescriptionReportBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class GetPrescriptionsTest extends TestCase {
	private OfficeVisitDAO ovDAO = DAOFactory.getTestInstance().getOfficeVisitDAO();
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.insertPatient2();
		gen.insertHCP0();
		gen.insertHospitals();
		gen.resetAllNDCodes();
	}

	public void testGetPrescriptions() throws Exception {
		List<Long> ovIDs = Arrays.asList(5L, 2L);
		List<PrescriptionReportBean> prescriptions = ovDAO.getPrescriptionReports(ovIDs, 2L);
		assertEquals(2, prescriptions.size());
		assertPrescription(prescriptions.get(0));
		assertPrescription(prescriptions.get(1));
	}

	private void assertPrescription(PrescriptionReportBean prescription) {
		assertEquals("009042407", prescription.getPrescription().getMedication().getNDCode());
		assertEquals("Tetracycline", prescription.getPrescription().getMedication().getDescription());
		assertEquals(5L, prescription.getPrescription().getVisitID());
		assertEquals(5, prescription.getPrescription().getDosage());
		assertEquals("10/10/2006", prescription.getPrescription().getStartDateStr());
		assertEquals("10/11/2006", prescription.getPrescription().getEndDateStr());
		assertEquals("Take twice daily", prescription.getPrescription().getInstructions());
		assertEquals(9000000000L, prescription.getOfficeVisit().getHcpID());
		assertEquals("1", prescription.getOfficeVisit().getHospitalID());
		assertEquals(2L, prescription.getOfficeVisit().getPatientID());
		assertEquals("06/10/2007", prescription.getOfficeVisit().getVisitDateStr());
	}

	public void testGetWithNotRightPID() throws Exception {
		List<Long> ovIDs = Arrays.asList(5L, 2L);
		List<PrescriptionReportBean> prescriptions = ovDAO.getPrescriptionReports(ovIDs, 1L); // injection!
		assertEquals(0, prescriptions.size());
	}
}
