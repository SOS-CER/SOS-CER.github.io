package edu.ncsu.csc.itrust.dao.officevisit;

import java.sql.Connection;
import java.sql.SQLException;
import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class AddOfficeVisitTest extends TestCase {
	private OfficeVisitDAO ovDAO = DAOFactory.getTestInstance().getOfficeVisitDAO();

	public void testAddNewOfficeVisit() throws Exception {
		OfficeVisitBean ovPut = new OfficeVisitBean();
		long newOVID = ovDAO.add(ovPut);
		OfficeVisitBean ovGet = ovDAO.getOfficeVisit(newOVID);
		assertEquals(newOVID, ovGet.getVisitID());
		deleteOV(newOVID);
	}

	public void testGetOfficeVisit() throws Exception {
		new TestDataGenerator().insertOfficeVisit1();
		OfficeVisitBean ov = ovDAO.getOfficeVisit(1);
		assertEquals(1, ov.getVisitID());
		assertEquals(9000000000L, ov.getHcpID());
		assertEquals("Generated for Death for Patient: 1", ov.getNotes());
		assertEquals(1, ov.getPatientID());
	}

	public void testGetEmptyOfficeVisit() throws Exception {
		assertNull(ovDAO.getOfficeVisit(0L));
	}

	private void deleteOV(long newOVID) throws SQLException {
		Connection conn = DAOFactory.getTestInstance().getConnection();
		conn.createStatement().execute(
				"DELETE FROM OfficeVisits WHERE ID=" + newOVID);
		conn.close();
	}
}
