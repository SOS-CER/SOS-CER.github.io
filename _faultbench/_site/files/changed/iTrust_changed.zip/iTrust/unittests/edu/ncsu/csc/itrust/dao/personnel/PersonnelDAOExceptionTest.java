package edu.ncsu.csc.itrust.dao.personnel;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class PersonnelDAOExceptionTest extends TestCase {
	private PersonnelDAO evilDAO = DAOFactory.getEvilTestInstance().getPersonnelDAO();

	@Override
	protected void setUp() throws Exception {
	}

	public void testAddEmptyPersonnelException() throws Exception {
		try {
			evilDAO.addEmptyPersonnel();
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testAddEmptyPersonnelAMIDException() throws Exception {
		try {
			evilDAO.addEmptyPersonnel(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testCheckPersonnelExistsException() throws Exception {
		try {
			evilDAO.checkPersonnelExists(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testEditPersonnelException() throws Exception {
		try {
			evilDAO.editPersonnel(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetHospitalsException() throws Exception {
		try {
			evilDAO.getHospitals(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetNameException() throws Exception {
		try {
			evilDAO.getName(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testPersonnelException() throws Exception {
		try {
			evilDAO.getPersonnel(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
}
