/*
 * TextChooser.java - A graphical text selector allowing author/title sorting
 * Copyright (C) 2001-7 Andrew Oliver
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

/**
 * A graphical text selector allowing author.title sorting
 */
public class TextChooser {
  private int iResult;
  private JLabel txfTitle;
  private java.util.List listTitlesByAuthor;
  private Map mapAuthorToTitle = new HashMap();
  private Map mapTitleToAuthor = new HashMap();

  void addTitle(String strTitle) {
    // Generate author+title string
    String strJustTitle = "";
    String strJustAuthor = "{Unlisted Author}";
    int iiDelimiter = strTitle.lastIndexOf(" by ");
    if (iiDelimiter >= 0) {
      strJustTitle = strTitle.substring(0, iiDelimiter);
      strJustAuthor = strTitle.substring(iiDelimiter + 4);
    } else {
      iiDelimiter = strTitle.lastIndexOf(", by ");
      if (iiDelimiter >= 0) {
        strJustTitle = strTitle.substring(0, iiDelimiter);
        strJustAuthor = strTitle.substring(iiDelimiter + 5);
      } else { // No author
        strJustTitle = strTitle;
      }
    }
    String strAuthor = strJustAuthor + ": " + strJustTitle;
    listTitlesByAuthor.add(strAuthor);
      
    // Setup bidirectional maps
    mapAuthorToTitle.put(strAuthor, strTitle);
    mapTitleToAuthor.put(strTitle, strAuthor);
  }

  private void setupAuthorListAndMap(java.util.List listTitles) {
    listTitlesByAuthor = new LinkedList();
    
    // for each title+author
    Iterator iter = listTitles.iterator();
    while (iter.hasNext()) {
      String strTitle = (String) iter.next();

      addTitle(strTitle);
    }

    Collections.sort(listTitlesByAuthor, new TitleComparator());
  }

  public TextChooser(java.util.List listTitles) {
    JPanel lists = new JPanel();
    lists.setLayout(new BorderLayout());

    // Setup title label and edit field
    JPanel selection = new JPanel();
    selection.setLayout(new BorderLayout());
    JLabel labelTitle = new JLabel("Selected Title: "); 
    selection.add(labelTitle, BorderLayout.NORTH);
    txfTitle = new JLabel(" ");
    selection.add(txfTitle, BorderLayout.SOUTH);
    //lists.add(labelTitle, BorderLayout.NORTH);
    //lists.add(txfTitle, BorderLayout.NORTH);
    lists.add(selection, BorderLayout.NORTH);

    // Create both lists
    final JList list = new JList(new Vector(listTitles));
    setupAuthorListAndMap(listTitles);
    final JList listAuthor = new JList(new Vector(listTitlesByAuthor));

    // Show list sorted by title
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    list.addListSelectionListener(new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent lse) {
          String strTitle = (String) list.getSelectedValue();
          txfTitle.setText(strTitle);
          listAuthor.setSelectedValue(mapTitleToAuthor.get(strTitle), true);
        }
      });
    JScrollPane scrollpane = new JScrollPane(list);
    lists.add(scrollpane, BorderLayout.CENTER);

    // Show list sorted by author
    listAuthor.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    listAuthor.addListSelectionListener(new ListSelectionListener() {
        public void valueChanged(ListSelectionEvent lse) {
          String strAuthor = (String) listAuthor.getSelectedValue();
          txfTitle.setText((String) mapAuthorToTitle.get(strAuthor));
          list.setSelectedValue(mapAuthorToTitle.get(strAuthor), true);
        }
      });
    JScrollPane scrollpaneAuthor = new JScrollPane(listAuthor);
    lists.add(scrollpaneAuthor, BorderLayout.SOUTH);

    iResult = JOptionPane.showConfirmDialog(null, lists, "View which book?",
                                            JOptionPane.OK_CANCEL_OPTION);
  }

  public int getResult() {
    return iResult;
  }

  public String getTitle() {
    return txfTitle.getText();
  }
}
