import java.io.*;
import java.util.*;
import java.util.zip.*;

public class Test {
  static void produceGZIPFromString() {
    String strText = "Foobar\nblah\n";

    try {
      PrintStream prs = new PrintStream(new GZIPOutputStream(new FileOutputStream("etext.gz")));
      prs.print(strText);
      prs.close();
    } catch (IOException iox) {
      System.out.println("IO Exception: " + iox);
      iox.printStackTrace();
    }
  }

  static void displayFirstFileFromZIP(String strFileName) {
	  BufferedReader reader = null;
    try {
      ZipInputStream zis = new ZipInputStream(new FileInputStream(strFileName));
      ZipEntry zen = zis.getNextEntry();
						reader =
								new BufferedReader(new InputStreamReader(zis));
						
						int icLineCount = 0;
						String strCurrentLine;
						while ((strCurrentLine = reader.readLine()) != null) {
								icLineCount++;
						}
      System.out.println("Line count="+icLineCount);
    } catch (IOException iox) {
      System.out.println("IO Exception: " + iox);
      iox.printStackTrace();
    } finally {
    	try {
    		if (reader != null) {
    			reader.close();
    		}
    	} catch (IOException e) {
    		System.out.println("IO Exception: " + e);
    	      e.printStackTrace();
    	}
    }
  }

  static void testGutindexParsing() {
    Map mapTitles = TextList.getTitleMap();

    Iterator iterTitle = mapTitles.entrySet().iterator();
    while (iterTitle.hasNext()) {
    	Map.Entry entry = (Map.Entry) iterTitle.next();
    	String contents = (String) entry.getValue();
      String strTitle = (String) entry.getKey();
      System.out.println("title/author: " + strTitle + "/" +
                         contents);
    }
  }

  public static void main(String[] args) {
    //produceGZIPFromString();
    //displayFirstFileFromZIP(args[0]);
    testGutindexParsing();
  }
}
