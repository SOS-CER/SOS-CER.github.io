/*
 * Display.java - Text display component
 * Copyright (C) 2001-7 Andrew Oliver
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import javax.swing.event.*;

public class Display extends JComponent implements ChangeListener, MouseWheelListener, MouseListener {
  boolean blnFontUpdateRequested = false;
  boolean blnIgnoreModelChanges = false;
  boolean blnWakeUp;
  BoundedRangeModel model;
  Document doc;
  int intTopLine;
  int iiWidestLine = -1;
  State state;
  String strFontName;
  ScrollThread scrolling;
    
  public Display(String strFileName, State state, String strFontName, BoundedRangeModel model) {
    this.state = state;
    this.strFontName = strFontName;

    // Setup scrollbar handling
    this.model = model;
    model.addChangeListener(this);

    addKeyListener(new DisplayKeyHandler());
    addComponentListener(new ComponentHandler());
    displayLocalFile(strFileName);
    scrolling = new ScrollThread();
    scrolling.setDaemon(true);
    scrolling.start();
    addMouseWheelListener(this);
    addMouseListener(this);
  }

  /**
   * Move display when user moves scrollbar
   */
  public void stateChanged(ChangeEvent che) {
    if (!blnIgnoreModelChanges) {
      state.setPosition(doc.getName(), model.getValue());
      repaint();
    }
  }

  private class ScrollThread extends Thread {
    private boolean blnKeepScrolling;
    private int iSecondTenthsBetweenScroll = 25;
    
    public ScrollThread() {
      iSecondTenthsBetweenScroll =
        state.getScrollDelay();
    }

    public void run() {
      while (true) {
        if (blnKeepScrolling) {
          moveDown();
          repaint();
        }
        
        int icTenths = 0;
        while ((icTenths < iSecondTenthsBetweenScroll) && !blnWakeUp) {
          try {
            sleep(100);
            icTenths++;
          } catch (InterruptedException inx) {}
        }
        blnWakeUp = false;
      }
    }
    
    /**
     * @return new scrolling state
     */
    public boolean toggle() {
      blnKeepScrolling = !blnKeepScrolling;

      // Scroll immediately when turned on
      if (blnKeepScrolling) {
        blnWakeUp = true;
      }
      
      return blnKeepScrolling;
    }

    public void faster() {
      if (iSecondTenthsBetweenScroll > 10) {
        iSecondTenthsBetweenScroll -= 5;
        state.setScrollDelay(iSecondTenthsBetweenScroll);
        System.out.println("Scrolling accelerated to " +
                           iSecondTenthsBetweenScroll);
      }
    }

    public void slower() {
      iSecondTenthsBetweenScroll += 5;
      state.setScrollDelay(iSecondTenthsBetweenScroll);
      System.out.println("Scrolling slowed to " +
                         iSecondTenthsBetweenScroll);
    }
  }
  
  public void setFontName(String strFontName) {
    this.strFontName = strFontName;
    state.setFont(strFontName);
    requestFontUpdate();
  }

  protected void requestFontUpdate() {
    blnFontUpdateRequested = true;
  }

  protected void updateFont() {
    setFont(makeFont(maxFontPitch()));

    model.setMaximum(doc.getLineCount() + maxLinesVisible() - 1);
    model.setExtent(maxLinesVisible());
    blnIgnoreModelChanges = false;
  }
  
  public Font makeFont(int iPitch) {
    return new Font(strFontName,
                    Font.PLAIN,
                        iPitch);
  }
  
  public void paint(Graphics g) {
    if (blnFontUpdateRequested) {
      blnFontUpdateRequested = false;
      updateFont();
    }

    g.setColor(getBackgroundColor());
    g.fillRect(0, 0, getWidth(), getHeight());
    g.setColor(getTextColor());
    // TODO -- fix to steal focus less aggressively -- causes problems using toolbar
    requestFocus();
    
    Graphics2D g2 = (Graphics2D) g;
    FontMetrics metrics = g2.getFontMetrics();
    
    int iStartLine = state.getPosition(doc.getName());
    int iEndLine = iStartLine + maxLinesVisible();
    
    int iYPos = metrics.getHeight();
    int icLines = doc.getLineCount();
    for (int iiLine = iStartLine; (iiLine < iEndLine) && (iiLine < icLines); iiLine++) {
      String strCurrentLine = doc.getLine(iiLine);
      int height = metrics.getHeight();
      g2.drawString(strCurrentLine, 0, iYPos);
      iYPos += height;
    }
  }
  
  public int getWidestLineIndex() {
    if (iiWidestLine == -1) {
      Graphics2D g2 = (Graphics2D) getGraphics();
      
      // Find widest line
      FontMetrics metrics = g2.getFontMetrics(makeFont(20));
      int iWidestLineWidth = 0;
      int iiStartLine = 0;
      if (doc.getLineAfterHeader() != -1) {
        iiStartLine = doc.getLineAfterHeader();
      }
      for (int i = iiStartLine; i < doc.getLineCount(); i++) {
        String strLine = doc.getLine(i);
        
        int iWidth = metrics.stringWidth(strLine);
        
        if (iWidth > iWidestLineWidth) {
          iWidestLineWidth = iWidth;
          iiWidestLine = i;
        }
      }
    }
    
    return iiWidestLine;
  }

  // Determine maximum font pitch by finding widest line and
  // trying font pitches until one is just under display width
  public int maxFontPitch() {
    Graphics2D g2 = (Graphics2D) getGraphics();
    
    // Try pitches for line iiWidestLine
    int iPitch = 10;
    int iDisplayWidth = getWidth();
    String strLine = doc.getLine(getWidestLineIndex());
    //System.out.println("longest line: " + strLine);
    for (int i = 10; i < 50; i++) {
      Font font = makeFont(i);
      FontMetrics metrics = g2.getFontMetrics(font);
      int iWidth = metrics.stringWidth(strLine);
      if (iWidth > iDisplayWidth) {
        iPitch = i - 1;
        break;
      }
    }
    
    return iPitch;
  }
  
  public int maxLinesVisible() {
    Graphics2D g2 = (Graphics2D) getGraphics();
    return getHeight() / g2.getFontMetrics().getHeight();
  }

  public boolean isFocusTraversable() {
    return true;
  }

  private class DisplayKeyHandler extends KeyAdapter {
    public void keyReleased(KeyEvent keyevent) {
      int iKeyCode = keyevent.getKeyCode();

      switch (iKeyCode) {
      case KeyEvent.VK_UP: moveUp(); break;
      case KeyEvent.VK_DOWN: moveDown(); break;
      case KeyEvent.VK_HOME: home(); break;
      case KeyEvent.VK_F: changeFont(); break;
      case KeyEvent.VK_SPACE:
      case KeyEvent.VK_PAGE_DOWN:
        pageDown(); break;
      case KeyEvent.VK_B:
      case KeyEvent.VK_PAGE_UP:
        pageUp(); break;
      case KeyEvent.VK_O: changeBook(); break;
      case KeyEvent.VK_G: getRemoteBook(); break;
      case KeyEvent.VK_A: scrolling.toggle(); break;
      case KeyEvent.VK_I: scrolling.faster(); break;
      case KeyEvent.VK_D: scrolling.slower(); break;
      case KeyEvent.VK_Q: exit(); break;
      }
      
      repaint();
    }
  }

  private void updateResizeableElements() {
    requestFontUpdate();
  }

  private class ComponentHandler extends ComponentAdapter {
    public void componentResized(ComponentEvent event) {
      updateResizeableElements();
    }

    public void componentShown(ComponentEvent event) {
      updateResizeableElements();
    }
  }

  public void mouseWheelMoved(MouseWheelEvent wheelEvent) {
    moveDown(wheelEvent.getUnitsToScroll());
  }

  public void mouseClicked(MouseEvent event) {
    // Left-click pages down
    if (event.getButton() == MouseEvent.BUTTON1) {
      pageDown();
    }

    // Right-click pages up
    if (event.getButton() == MouseEvent.BUTTON3) {
      pageUp();
    }
  }

  public void mousePressed(MouseEvent event) {
  }

  public void mouseReleased(MouseEvent event) {
  }

  public void mouseEntered(MouseEvent event) {
  }

  public void mouseExited(MouseEvent event) {
  }

  /**
   * @return new scrolling state
   */
  public boolean toggleScrolling() {
    return scrolling.toggle();
  }

  public void scrollFaster() {
    scrolling.faster();
  }

  public void scrollSlower() {
    scrolling.slower();
  }

  private void setPosition(int iNewPosition) {
    state.setPosition(doc.getName(), iNewPosition);
    model.setValue(iNewPosition);
  }

  public void home() {
    setPosition(0);
  }

  public void moveUp(int iLines) {
    int iPos = state.getPosition(doc.getName());
    if (iPos > (iLines - 1)) {
      setPosition(iPos - iLines);
    }
  }

  public void moveUp() {
    moveUp(1);
  }

  public void moveDown(int iLines) {
    int iPos = state.getPosition(doc.getName());
    if (iPos < (doc.getLineCount() - iLines)) {
      setPosition(iPos + iLines);
    }
  }

  public void moveDown() {
    moveDown(1);
  }
  
  public void pageDown() {
    moveDown(maxLinesVisible());
  }

  public void pageUp() {
    moveUp(maxLinesVisible());
  }

  protected void displayLocalFile(String strName) {
    if (strName != null) {
      doc = new Document(strName);

      blnIgnoreModelChanges = true;
      model.setMinimum(0);
      model.setMaximum(Integer.MAX_VALUE);

      // Setup position after header if not already reading
      if (doc.getLineAfterHeader() != -1) {
        if (state.getPosition(strName) == 0) {
          setPosition(doc.getLineAfterHeader());
        }
      }
      model.setValue(state.getPosition(doc.getName()));

      // Setup model min/max
      if (doc.getLineAfterHeader() != -1) {
        model.setMinimum(doc.getLineAfterHeader());
      } else {
        model.setMinimum(0);
      }
      model.setMaximum(doc.getLineCount());

      iiWidestLine = -1;
      requestFontUpdate();
    }
  }

  public void changeBook() {
    LocalTextSelect textselect = new LocalTextSelect();
    int status = textselect.getStatus();

    if (status == LocalTextSelect.SELECTION_MADE) {
      String strName = textselect.getSelection();
      displayLocalFile(strName);
    } else if (status == LocalTextSelect.NO_SELECTIONS_AVAILABLE) {
      int iResult =
        JOptionPane.showConfirmDialog(null, 
                                      "No local books are available.  Would you like to download a new book instead?", 
                                      "No local books available",
                                      JOptionPane.YES_NO_OPTION);
      
      if (iResult == JOptionPane.YES_OPTION) {
        getRemoteBook();
      }
    }
  }

  public void getRemoteBook() {
    RemoteTextSelect textselect = new RemoteTextSelect();
    String strName = textselect.getSelection();
    displayLocalFile(strName);
  }

  public void changeFont() {
    FontSelect fontselect = new FontSelect(this);
  }

  public void setBackgroundColor(Color color) {
    state.setBackgroundColor(color);
    repaint();
  }

  public void setTextColor(Color color) {
    state.setTextColor(color);
    repaint();
  }

  public Color getBackgroundColor() {
    return state.getBackgroundColor();
  }

  public Color getTextColor() {
    return state.getTextColor();
  }

  public void exit() {
    state.setLastDocName(doc.getName());
    state.save();
    System.exit(0);
  }
}
