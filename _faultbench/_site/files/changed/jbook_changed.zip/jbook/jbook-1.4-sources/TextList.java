/*
 * TextList.java - The list of texts available online
 * Copyright (C) 2001-7 Andrew Oliver
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.*;
import java.util.*;
import java.util.regex.*;

/**
	* A single list of available texts
	*/
public class TextList {
  static Map mapURLByTitle;
  static Map mapTitleByFilename;
  static final int MAX_LINES_TO_GREP = 64;
  static final String BYLINE_REGEXP = ".*, by .*";

  static synchronized void setup() {
    if (mapURLByTitle == null) {
      setupFileList();
      setupNumberedFileList();
      setupTitleList();
    }
  }

  static Map getURLMap() {
    setup();
    return mapURLByTitle;
  }

  public static String gutenbergUrlFromNumber(String strNumber) {
    String strUrl = "http://www.gutenberg.org/dirs/";

    int ciDirs = strNumber.length() - 1;
    for (int i = 0; i < ciDirs; i++) {
      strUrl += strNumber.substring(i, i+1) + "/";
    }

    strUrl += strNumber + "/" + strNumber;

    return strUrl;
  }

  public static String gutenbergFileUrlFromNumber(String strNumber) {
    String strUrl = "http://www.gutenberg.org/files/";

    strUrl += strNumber + "/" + strNumber;

    return strUrl;
  }


  /**
   * Add entries from the new-style gutenberg index
   */
  public static void setupNumberedFileList() {
	  BufferedReader reader = null;
    try {
      String strDatePattern = "((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \\d\\d\\d\\d )?";
      Pattern patternBook = Pattern.compile(strDatePattern +
                                            "(.*), by ([a-zA-Z_0-9 ]*)\\s+(\\[.*\\])?(\\[.*\\])?\\s+(\\d+)$");
      reader = new BufferedReader(new FileReader("GUTINDEX.ALL"));
      String strLine;
      while (true) {
        strLine = reader.readLine();
        
        if (strLine == null) {
          break;
        }
        
        Matcher m = patternBook.matcher(strLine);
        if (m.matches()) {
          String strTitle = m.group(3) + ", by " + m.group(4);
          strTitle = strTitle.trim();
          String strNumber = m.group(7);
          
          
          //System.out.println("Adding " + strTitle + "/" + strNumber);
          String strUrl = gutenbergUrlFromNumber(strNumber);
          mapURLByTitle.put(strTitle, strUrl);
          //System.out.println("Added " + strTitle + "/" + strUrl);
        }
      }
    } catch (IOException iox) {
      // Silently eat errors reading gutindex
    } finally {
    	try {
    		reader.close();
    	} catch (IOException e) {
    		// Silently eat errors reading gutindex
    	}
    }
  }
    
  /**
   * Determine the title given the filename.
   *
   * @param strFilename The filename of the ebook to look up .
   * @return
   */
  static String getTitleFromFilename(String strFilename) {
    System.out.println("Getting title from filename: " + strFilename);
    String strTitle = 
      (String)TextList.getTitleMap().get(strFilename);
    System.out.println("title: " + strTitle);
    if (strTitle == null) {
      strTitle = grepTitle(strFilename);
      if (strTitle != null) {
        mapTitleByFilename.put(strFilename, strTitle);         
      }
    }
    return strTitle;
  }

  /**
   * Determine the title given the filename by grepping for a line of
   * format Brad the Imp Wailer, by Joe Author in the first
   * MAX_LINES_TO_GREP lines.
   *
   * @param strFilename The filename of the ebook to look up.
   * @return The found title, or null if not found.  
   */
  static private String grepTitle(String strFilename) {
    // TODO: open file properly regardless of compressed or not
    File file = new File(strFilename + ".txt");
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new 
        InputStreamReader(new FileInputStream(file)));
      for (int iLine = 0; iLine < MAX_LINES_TO_GREP; iLine++) {
        String strLine = reader.readLine();
        System.out.println("read line: " + strLine);
        if (strLine.matches(BYLINE_REGEXP)) {
          System.out.println("Matching line: " + strLine);
          return strLine;
        }
      }
      // Not found
      return null;
    } catch (IOException e) {
      return null;
    } finally {
    	try {
    		reader.close();
    	} catch (IOException e) {
    		return null;
    	}
    }
  }

  static Map getTitleMap() {
    setup();
    return mapTitleByFilename;
  }
    
  /** 
   * Accepts a URL, strips off the text after the last '/'
   */
  static public String fileNameFromURL(String strURL) {
    String strFileName = strURL.substring(strURL.lastIndexOf('/') + 1);
    return strFileName;
  }

  public static void setupTitleList() {
    mapTitleByFilename = new HashMap();
    Iterator i = mapURLByTitle.keySet().iterator();
    while (i.hasNext()) {
      String strTitle = (String) i.next();
      String strURL = (String) mapURLByTitle.get(strTitle);
      String strFilename = fileNameFromURL(strURL);
      mapTitleByFilename.put(strFilename, strTitle);
    }
  }
  
  public static void setupFileList() {
    mapURLByTitle = new HashMap();
    BufferedReader reader = null;
    // Get list of files
    try {
      reader = new BufferedReader(new FileReader("gutenberg.lst"));
    
      String strTitle;
      String strURL;
      while (true) {
        strTitle = reader.readLine();
        strURL = reader.readLine();

        if ((strTitle == null) || (strURL == null))
          break;
        
        strURL = strURL.substring(0, strURL.lastIndexOf('.'));
        mapURLByTitle.put(strTitle, strURL);
      }
    } catch (IOException iox) {
      // Unable to read gutenberg list.
      System.out.println("Unable to read gutenberg list.  Using built-in list.");

      mapURLByTitle.put("The Reef by Edith Wharton", 
                        "http://sailor.gutenberg.org/etext95/treef10");
      mapURLByTitle.put("Selected Writings Volume 1 by Guy de Maupassant", 
                        "http://sailor.gutenberg.org/etext96/swgem10");
      mapURLByTitle.put("Modest Proposal by Johnathan Swift", 
                        "http://sailor.gutenberg.org/etext97/mdprp10");
    } finally {
    	try {
    		reader.close();
    	} catch (IOException e) {
    		 // Unable to read gutenberg list.
    	      System.out.println("Unable to read gutenberg list.  Using built-in list.");

    	      mapURLByTitle.put("The Reef by Edith Wharton", 
    	                        "http://sailor.gutenberg.org/etext95/treef10");
    	      mapURLByTitle.put("Selected Writings Volume 1 by Guy de Maupassant", 
    	                        "http://sailor.gutenberg.org/etext96/swgem10");
    	      mapURLByTitle.put("Modest Proposal by Johnathan Swift", 
    	                        "http://sailor.gutenberg.org/etext97/mdprp10");
    	}
    }
  }
}
