package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.UpdateICDCodeListAction;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import fit.ActionFixture;

public class ICDCodesFixture extends ActionFixture {
	private UpdateICDCodeListAction action;
	private String exception = "";
	private String icd;
	private String description;

	public ICDCodesFixture() throws FileNotFoundException, IOException, SQLException {
		TestDataGenerator gen = new TestDataGenerator();
		gen.resetAllICD9CMCodes();
	}

	public void adminMID(long adminMID) {
		action = new UpdateICDCodeListAction(DAOFactory.getTestInstance(), adminMID);
	}

	public void icd(String icd) {
		this.icd = icd;
	}

	public void description(String description) {
		this.description = description;
	}

	public void addCode() {
		DiagnosisBean diagn = new DiagnosisBean();
		diagn.setICDCode(Double.valueOf(icd));
		diagn.setDescription(description);
		try {
			action.addICDCode(diagn);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getCode() throws DBException {
		return DAOFactory.getTestInstance().getICDCodesDAO().getICDCode(Double.valueOf(icd)).getDescription();
	}

	public void updateCode() {
		DiagnosisBean diagn = new DiagnosisBean();
		diagn.setICDCode(Double.valueOf(icd));
		diagn.setDescription(description);
		try {
			action.updateInformation(diagn);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getException() {
		return exception;
	}
}
