package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.EditOfficeVisitAction;
import edu.ncsu.csc.itrust.beans.forms.EditOfficeVisitForm;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import fit.ActionFixture;

public class EditOfficeVisitFixture extends ActionFixture {
	EditOfficeVisitAction action;
	private String pid;
	private String message = "";
	private String exception = "";
	private long loggedInMID;
	private String addDiagID;
	private String addMedID;
	private String addProcID;
	private String dosage;
	private String endDate;
	private String hospitalID;
	private String instructions;
	private String notes;
	private String removeDiagID;
	private String removeMedID;
	private String removeProcID;
	private String startDate;
	private String visitDate;

	public EditOfficeVisitFixture() throws FileNotFoundException, IOException, SQLException {
		TestDataGenerator gen = new TestDataGenerator();
		gen.insertPatient2();
		gen.resetAllHospitals();
		gen.resetAllHospitalAssignments();
		gen.resetAllCPTCodes();
		gen.resetAllICD9CMCodes();
		gen.resetAllNDCodes();
	}

	public void loggedInMID(long loggedInMID) {
		this.loggedInMID = loggedInMID;
	}

	public void pid(String pid) {
		this.pid = pid;
	}

	public void ovID(String ovID) throws iTrustException {
		action = new EditOfficeVisitAction(DAOFactory.getTestInstance(), loggedInMID, pid, ovID);
	}

	public void addDiagID(String str) {
		this.addDiagID = str;
	};

	public void addMedID(String str) {
		this.addMedID = str;
	};

	public void addProcID(String str) {
		this.addProcID = str;
	};

	public void dosage(String str) {
		this.dosage = str;
	};

	public void endDate(String str) {
		this.endDate = str;
	};

	public void hospitalID(String str) {
		this.hospitalID = str;
	};

	public void instructions(String str) {
		this.instructions = str;
	};

	public void notes(String str) {
		this.notes = str;
	};

	public void removeDiagID(String str) {
		this.removeDiagID = str;
	};

	public void removeMedID(String str) {
		this.removeMedID = str;
	};

	public void removeProcID(String str) {
		this.removeProcID = str;
	};

	public void startDate(String str) {
		this.startDate = str;
	};

	public void visitDate(String str) {
		this.visitDate = str;
	};

	public void update() {
		EditOfficeVisitForm form = new EditOfficeVisitForm();
		form.setAddDiagID(addDiagID);
		form.setAddMedID(addMedID);
		form.setAddProcID(addProcID);
		form.setDosage(dosage);
		form.setEndDate(endDate);
		form.setHcpID(String.valueOf(loggedInMID));
		form.setHospitalID(hospitalID);
		form.setInstructions(instructions);
		form.setNotes(notes);
		form.setRemoveDiagID(removeDiagID);
		form.setRemoveMedID(removeMedID);
		form.setRemoveProcID(removeProcID);
		form.setStartDate(startDate);
		form.setVisitDate(visitDate);
		form.setPatientID(pid);
		try {
			message = action.updateInformation(form);
		} catch (FormValidationException e) {
			exception = e.getMessage();
		} catch (NumberFormatException e2){
			exception = e2.getMessage();
		}
	}

	public String getMessage() {
		String theMessage = message;
		message = "";
		return theMessage;
	}

	public String getException() {
		String theException = exception;
		exception = "";
		return theException;
	}

	public int numberOfDiagnoses() throws iTrustException {
		return action.getOfficeVisit().getDiagnoses().size();
	}

	public int numberOfProcedures() throws iTrustException {
		return action.getOfficeVisit().getProcedures().size();
	}

	public int numberOfPrescriptions() throws iTrustException {
		return action.getOfficeVisit().getPrescriptions().size();
	}
}
