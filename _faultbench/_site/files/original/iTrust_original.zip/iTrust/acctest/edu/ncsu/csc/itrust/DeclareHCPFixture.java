package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.DeclareHCPAction;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.iTrustException;
import fit.ActionFixture;

public class DeclareHCPFixture extends ActionFixture {
	private DeclareHCPAction action;
	private String hcpID;
	private long pid;
	private String exception = "";

	public DeclareHCPFixture() throws FileNotFoundException, IOException, SQLException {
		TestDataGenerator gen = new TestDataGenerator();
		gen.insertPatient2();
		gen.insertHCP0();
		gen.insertHCP3();
	}

	public void patientId(long patientMID) {
		this.pid = patientMID;
		action = new DeclareHCPAction(DAOFactory.getTestInstance(), patientMID);
	}

	public void hcpId(String hcpID) {
		this.hcpID = hcpID;
	}

	public void declare() throws iTrustException {
		try {
			action.declareHCP(hcpID);
		} catch (iTrustException e) {
			exception = e.getMessage();
		}
	}

	public void undeclare() throws iTrustException {
		action.undeclareHCP(hcpID);
	}

	public boolean declared() throws iTrustException {
		try {
			return DAOFactory.getTestInstance().getPatientDAO().checkDeclaredHCP(pid, Long.valueOf(hcpID));
		} catch (iTrustException e) {
			exception = e.getMessage();
			throw e;
		}
	}

	public String exception() {
		return exception;
	}
}
