package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.ResetPasswordAction;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import fit.ActionFixture;

public class ResetPasswordFixture extends ActionFixture {
	ResetPasswordAction action;
	private long mid;
	private String role;
	private String answer;
	private String pw;
	private String confirm;
	private String message;

	public ResetPasswordFixture() throws FileNotFoundException, IOException, SQLException {
		TestDataGenerator gen = new TestDataGenerator();
		gen.insertPatient2();
		action = new ResetPasswordAction(DAOFactory.getTestInstance());
	}

	public void role(String role) {
		this.role = action.checkRole(role);
	}

	public void mid(String midString) {
		this.mid = action.checkMID(midString);
	}

	public String getSecurityQuestion() {
		return action.getSecurityQuestion(mid, role);
	}

	public void answer(String answer) {
		this.answer = answer;
	}

	public void password(String pw) {
		this.pw = pw;
	}

	public void confirmPassword(String confirm) throws FormValidationException {
		this.confirm = confirm;
	}

	public String getPassword() throws SQLException, FormValidationException {
		try {
			message = action.resetPassword(mid, role, answer, pw, confirm);
		} catch (FormValidationException e) {
			this.message = e.getMessage();
		}
		Connection conn = null;
		try {
			conn = DAOFactory.getTestInstance().getConnection();
			ResultSet rs = conn.createStatement().executeQuery("select password from Users where mid=2");
			rs.next();
			return rs.getString("password");
		} finally {
			DBUtil.closeConnection(conn, null);
		}
	}

	public String getMessage() {
		return message;
	}
}
