package edu.ncsu.csc.itrust;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.action.UpdateCPTCodeListAction;
import edu.ncsu.csc.itrust.beans.ProcedureBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import fit.ActionFixture;

public class CPTCodesFixture extends ActionFixture {
	private UpdateCPTCodeListAction action;
	private String exception = "";
	private String code;
	private String description;

	public CPTCodesFixture() throws FileNotFoundException, IOException, SQLException {
		TestDataGenerator gen = new TestDataGenerator();
		gen.resetAllCPTCodes();
	}

	public void adminMID(long adminMID) {
		action = new UpdateCPTCodeListAction(DAOFactory.getTestInstance(), adminMID);
	}

	public void icd(String code) {
		this.code = code;
	}

	public void description(String description) {
		this.description = description;
	}

	public void addCode() {
		ProcedureBean bean = new ProcedureBean();
		bean.setCPTCode(code);
		bean.setDescription(description);
		try {
			action.addCPTCode(bean);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getCode() throws DBException {
		return DAOFactory.getTestInstance().getCPTCodesDAO().getCPTCode(code).getDescription();
	}

	public void updateCode() {
		ProcedureBean bean = new ProcedureBean();
		bean.setCPTCode(code);
		bean.setDescription(description);
		try {
			action.updateInformation(bean);
		} catch (FormValidationException e) {
			this.exception = e.getMessage();
		}
	}

	public String getException() {
		return exception;
	}
}
