CREATE TABLE Users(
	MID BIGINT PRIMARY KEY,
	Password VARCHAR(20),
	Role VARCHAR(10)
);

CREATE TABLE ICDCodes (
	ID bigint(20) unsigned,
	Code decimal(5,2) NOT NULL,
	Description varchar(1000) NOT NULL,
	PRIMARY KEY (Code)
);

CREATE TABLE CPTCodes(
	Code varchar(5) NOT NULL COMMENT 'Actual CPT Code', 
	Description varchar(100) NOT NULL COMMENT 'Description of the CPT Codes', 
	PRIMARY KEY (Code)
);

CREATE TABLE NDCodes(
	Code varchar(9) NOT NULL, 
	Description varchar(40) NOT NULL, 
	PRIMARY KEY  (Code)
);

CREATE TABLE Hospitals(
	HospitalID varchar(10),
	HospitalName varchar(30) NOT NULL, 
	PRIMARY KEY (hospitalID)
);

CREATE TABLE Personnel(
	MID bigint(10) unsigned auto_increment,
	AMID bigint(10) unsigned default NULL,
	role enum('admin','hcp','uap','test') NOT NULL default 'admin',
	enabled tinyint(1) unsigned NOT NULL default '0',
	lastName varchar(20) NOT NULL default '',
	firstName varchar(20) NOT NULL default '',
	address1 varchar(20) NOT NULL default '',
	address2 varchar(20) NOT NULL default '',
	city varchar(15) NOT NULL default '',
	state enum('AK','AL','AR','AZ','CA','CO','CT','DE','DC','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','MT','NC','ND','NE','NH','NJ','NM','NV','NY','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY') NOT NULL default 'AK',
	zip varchar(10) NOT NULL default '',
	zip1 varchar(5)  default '',
	zip2 varchar(4)  default '',
	phone varchar(12) NOT NULL default '',
	phone1 varchar(3) default '',
    phone2 varchar(3) default '',
    phone3 varchar(4) default '',
	hospitalID int(10) unsigned,
	sQuestion varchar(50) NOT NULL DEFAULT '',
	sAnswer char(32) NOT NULL DEFAULT '',
	specialty varchar(40) default NULL,
	PRIMARY KEY  (MID)
);

CREATE TABLE Patients(
	MID int(10) unsigned  auto_increment, 
	lastName varchar(20)  default '', 
	firstName varchar(20)  default '', 
	email varchar(55)  default '', 
	sQuestion varchar(50)  default '', 
	sAnswer varchar(30)  default '', 
	address1 varchar(20)  default '', 
	address2 varchar(20)  default '', 
	city varchar(15)  default '', 
	state enum('AK','AL','AR','AZ','CA','CO','CT','DE','DC','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','MT','NC','ND','NE','NH','NJ','NM','NV','NY','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY')  default 'AK', 
	zip1 varchar(5)  default '', 
	zip2 varchar(4)  default '',
	phone1 varchar(3) default '',
    phone2 varchar(3) default '',
    phone3 varchar(4) default '',
	eName varchar(40)  default '', 
	ePhone1 varchar(3)  default '', 
	ePhone2 varchar(3)  default '', 		
	ePhone3 varchar(4)  default '', 	
	iCName varchar(20)  default '', 
	iCAddress1 varchar(20)  default '', 
	iCAddress2 varchar(20)  default '', 
	iCCity varchar(15)  default '', 
	ICState enum('AK','AL','AR','AZ','CA','CO','CT','DE','DC','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','MT','NC','ND','NE','NH','NJ','NM','NV','NY','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY')  default 'AK', 
	iCZip1 varchar(5)  default '', 
	iCZip2 varchar(4)  default '',
	iCPhone1 varchar(3)  default '',
	iCPhone2 varchar(3)  default '',
	iCPhone3 varchar(4)  default '',			
	iCID varchar(20)  default '', 
	DateOfBirth DATE,
	DateOfDeath DATE,
	CauseOfDeath VARCHAR(10) default '',
	MotherMID INTEGER(10) default 0,
	FatherMID INTEGER(10) default 0,
	BloodType VARCHAR(3) default '',
	Ethnicity VARCHAR(20) default '',
	Gender VARCHAR(13) default 'Not Specified',
	TopicalNotes VARCHAR(200) default '',
	PRIMARY KEY (MID)
);

CREATE TABLE LoginFailures(
	ipaddress varchar(12) NOT NULL, 
	failureCount int NOT NULL default 0, 
	lastFailure TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (ipaddress)
);

CREATE TABLE TransactionLog(
	transactionID int(10) unsigned NOT NULL auto_increment, 
	loggedInMID bigint(30) UNSIGNED NOT NULL DEFAULT '0', 
	secondaryMID bigint(30) UNSIGNED NOT NULL DEFAULT '0', 
	transactionCode int(10) UNSIGNED NOT NULL default '0', 
	timeLogged timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP, 
	addedInfo VARCHAR(50) default '',
	PRIMARY KEY  (transactionID)
);

CREATE TABLE HCPRelations(
	HCP bigint(30) unsigned NOT NULL default '0', 
	UAP bigint(30) unsigned NOT NULL default '0', 
	PRIMARY KEY (HCP, UAP)
);

CREATE TABLE PersonalRelations(
	PatientID INT( 10 ) NOT NULL COMMENT 'MID of the patient',
	RelativeID INT( 10 ) NOT NULL COMMENT 'MID of the Relative',
	RelativeType VARCHAR( 35 ) NOT NULL COMMENT 'Relation Type'
);

CREATE TABLE Representatives(
	representerMID int(10) unsigned default 0, 
	representeeMID int(10) unsigned default 0, 
	PRIMARY KEY  (representerMID,representeeMID)
);

CREATE TABLE HCPAssignedHos(
	hosID VARCHAR(10) NOT NULL, 
	HCPID bigint(30) unsigned NOT NULL, 
	PRIMARY KEY (hosID,HCPID)
);

CREATE TABLE DeclaredHCP(
	PatientID bigint(30) unsigned NOT NULL default '0', 
	HCPID bigint(30) unsigned NOT NULL default '0', 
	PRIMARY KEY  (PatientID,HCPID)
);

CREATE TABLE OfficeVisits(
	ID int(10) unsigned auto_increment,
	visitDate date default '0000-00-00',  
	HCPID bigint(30) unsigned default '0', 
	notes mediumtext, 
	PatientID bigint(30) unsigned default '0', 
	HospitalID VARCHAR(10) default '',
	PRIMARY KEY  (ID)
);

CREATE TABLE PersonalHealthInformation (
	PatientID bigint(30) unsigned NOT NULL default '0',
	Height float default '0',  
	Weight float default '0',  
	Smoker tinyint(1) NOT NULL default '0' COMMENT 'Is the person a smoker',  
	BloodPressureN int(11) default '0',  
	BloodPressureD int(11) default '0',  
	CholesterolHDL int(11) default '0' COMMENT 'HDL Cholesterol',  
	CholesterolLDL int(11) default '0' COMMENT 'LDL Ccholesterol',  
	CholesterolTri int(11) default '0' COMMENT 'Cholesterol Triglyceride',  
	HCPID bigint(30) default NULL,  
	AsOfDate timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
);

CREATE TABLE PersonalAllergies(
	PatientID INT( 10 ) NOT NULL COMMENT 'MID of the Patient',
	Allergy VARCHAR( 50 ) NOT NULL COMMENT 'Description of the allergy'
);

CREATE TABLE Allergies(
	ID INT(10) unsigned auto_increment primary key,
	PatientID INT( 10 ) NOT NULL COMMENT 'MID of the Patient',
	Description VARCHAR( 50 ) NOT NULL COMMENT 'Description of the allergy',
	FirstFound TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE OVProcedure(
	ID INT(10) auto_increment primary key,
	VisitID INT( 10 ) NOT NULL COMMENT 'ID of the Office Visit',
	CPTCode VARCHAR( 10 ) NOT NULL COMMENT 'CPTCode of the procedure'
);

CREATE TABLE OVMedication (
    ID INT(10)  auto_increment primary key,
	VisitID INT( 10 ) NOT NULL COMMENT 'ID of the Office Visit',
	NDCode VARCHAR( 9 ) NOT NULL COMMENT 'NDCode for the medication',
	StartDate DATE,
	EndDate DATE,
	Dosage INT DEFAULT 0 COMMENT 'Always in mg - this could certainly be changed later',
	Instructions VARCHAR(500) DEFAULT ''
) ;

CREATE TABLE OVDiagnosis (
    ID INT(10) auto_increment primary key,
	VisitID INT( 10 ) NOT NULL COMMENT 'ID of the Office Visit',
	DiscretionaryAccess boolean default true, 
	PrivacyLevel enum('All', 'Declared HCP Only', 'No One') default 'All',
	ICDCode DECIMAL( 5, 2 ) NOT NULL COMMENT 'Code for the Diagnosis'
);

CREATE TABLE GlobalVariables (
	Name VARCHAR(20) primary key,
	Value VARCHAR(20)
);

INSERT INTO GlobalVariables(Name,Value) VALUES ('Timeout', '20');