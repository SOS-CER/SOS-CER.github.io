DELETE FROM Patients WHERE MID=2;
DELETE FROM Users WHERE MID=2;
DELETE FROM Allergies WHERE PatientID=2;
DELETE FROM PersonalHealthInformation WHERE PatientID=2;
DELETE FROM OVDiagnosis WHERE VisitID IN (SELECT ID FROM OfficeVisits WHERE PatientID=2);
DELETE FROM OVMedication WHERE VisitID IN (SELECT ID FROM OfficeVisits WHERE PatientID=2);
DELETE FROM OVProcedure WHERE VisitID IN (SELECT ID FROM OfficeVisits WHERE PatientID=2);
DELETE FROM OfficeVisits WHERE PatientID=2 OR ID IN (2,3,4,5,6,7,8,9,10);
DELETE FROM DeclaredHCP WHERE PatientID=2;
DELETE FROM Representatives WHERE RepresenterMID=2;

INSERT INTO Patients
(MID, 
firstName,
lastName, 
email,
sQuestion,
sAnswer,
address1,
address2,
city,
state,
zip1,
zip2,
phone1,
phone2,
phone3,
eName,
ePhone1,
ePhone2,
ePhone3,
iCName,
iCAddress1,
iCAddress2,
iCCity, 
ICState,
iCZip1,
iCZip2,
iCPhone1,
iCPhone2,
iCPhone3,
iCID,
DateOfBirth,
DateOfDeath,
CauseOfDeath,
MotherMID,
FatherMID,
BloodType,
Ethnicity,
Gender,
TopicalNotes
)
VALUES (
2,
'Andy',
'Programmer',
'andy.programmer@gmail.com',
'how you doin?',
'good',
'344 Bob Street',
'',
'Raleigh',
'NC',
'27607',
'',
'555',
'555',
'5555',
'Mr Emergency',
'555',
'555',
'5551',
'IC',
'Street1',
'Street2',
'City',
'PA',
'19003',
'2715',
'555',
'555',
'5555',
'1',
'1984-05-19',
NULL,
'',
1,
0,
'O-',
'Caucasian',
'Male',
'This person is absolutely crazy. Do not touch them.'
);

INSERT INTO Users(MID, password, role) 
			VALUES (2, 'pw', 'patient');

INSERT INTO Allergies(PatientID,Description, FirstFound) 
	VALUES (2, 'Pollen', '2007-06-05 20:33:58'),
	       (2, 'Penicillin', '2007-06-04 20:33:58');

INSERT INTO PersonalHealthInformation
(PatientID,Height,Weight,Smoker,BloodPressureN,BloodPressureD,CholesterolHDL,CholesterolLDL,CholesterolTri,HCPID, AsOfDate)
VALUES ( 2,  60,   200,   0,      190,          100,           500,             239,         290,          9000000000, '2007-06-07 20:33:58'),
	   ( 2,  62,   210,   1,      195,          250,             36,             215,           280,          9000000000, '2007-06-07 20:34:58');

INSERT INTO OfficeVisits(id,visitDate,HCPID,notes,HospitalID,PatientID)
VALUES (2,'2007-6-09',9000000000,'Yet another office visit.','1',2),
	   (3,'2005-10-10',9000000000,'Yet another office visit.','1',2),
	   (4,'2005-10-10',9000000000,'Yet another office visit.','1',2),
	   (5,'2007-6-10',9000000000,'Yet another office visit.','1',2),
	   (6,'2005-10-10',9000000000,'Yet another office visit.','1',2),
	   (7,'2005-10-10',9000000000,'Yet another office visit.','1',2),
	   (8,'2005-10-10',9000000000,'Yet another office visit.','1',2),
	   (9,'2006-10-10',9000000000,'Yet another office visit.','1',2),
	   (10,'1985-10-10',9000000000,'Yet another office visit.','',2);

INSERT INTO OVDiagnosis(ICDCode, VisitID, DiscretionaryAccess, PrivacyLevel) 
	VALUES  (250.1, 5, true, 'All'),
			(79.30, 10, false, 'All'),
			(250.1, 10, true, 'Declared HCP Only'),
			(250.1, 10, true, 'No One');

INSERT INTO OVMedication(NDCode, VisitID, StartDate,EndDate,Dosage,Instructions)
	VALUES ('009042407', 5, '2006-10-10', '2006-10-11', 5, 'Take twice daily'),
		   ('009042407', 5, '2006-10-10', '2006-10-11', 5, 'Take twice daily');
INSERT INTO OVProcedure(CPTCode, VisitID) VALUES ('1270F', 5);

INSERT INTO DeclaredHCP(PatientID,HCPID) VALUE(2, 9000000003);

INSERT INTO Representatives(RepresenterMID, RepresenteeMID) VALUES(2,1);
