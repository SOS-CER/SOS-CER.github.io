DELETE FROM OVDiagnosis WHERE VisitID=1;
DELETE FROM OVMedication WHERE VisitID=1;
DELETE FROM OVProcedure WHERE VisitID=1;
DELETE FROM OfficeVisits WHERE ID=1;

INSERT INTO OfficeVisits(
	id,
	visitDate,
	HCPID,
	notes,
	HospitalID,
	PatientID
)
VALUES (
1,
'2005-10-10',
9000000000,
'Generated for Death for Patient: 1',
'1',
1
);