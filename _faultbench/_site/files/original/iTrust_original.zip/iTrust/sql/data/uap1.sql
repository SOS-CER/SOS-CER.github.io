DELETE FROM Personnel WHERE MID=8000000009;
DELETE FROM Users WHERE MID=8000000009;

INSERT INTO Personnel
(MID,
AMID,
lastName,
firstName,
address1,
address2,
city,
state,
zip1,
zip2,
phone1,
phone2,
phone3,
sQuestion,
sAnswer
)
VALUES (
8000000009,
9000000000,
'LastUAP',
'FirstUAP',
'100 Ave',
'',
'Raleigh',
'NC',
'27607',
'',
'111',
'111',
'1111',
'opposite of yin',
'yang'
);

INSERT INTO Users(MID, password, role) 
VALUES (8000000009, 'uappass1', 'uap');