package edu.ncsu.csc.itrust.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.beans.PrescriptionReportBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

@SuppressWarnings("unchecked")
public class PrescriptionReportActionTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private TestDataGenerator gen = new TestDataGenerator();
	private PrescriptionReportAction action;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.insertHCP0();
		gen.insertPatient2();
	}

	public void testEmptyParamMap() throws Exception {
		action = new PrescriptionReportAction(factory, 9000000000L, "2");
		List<OfficeVisitBean> officeVisits = action.getAllOfficeVisits();
		Map params = new HashMap();
		assertEquals("", action.getQueryString(params, officeVisits));
	}

	public void testQueryStringNotChecked() throws Exception {
		action = new PrescriptionReportAction(factory, 9000000000L, "2");
		List<OfficeVisitBean> officeVisits = action.getAllOfficeVisits();
		Map params = new HashMap();
		params.put("ov0", new String[]{"unchecked"});
		params.put("ov2", new String[]{"unchecked"});
		params.put("ov3", new String[]{"unchecked"});
		params.put("ov4", new String[]{"unchecked"});
		params.put("ov5", new String[]{"unchecked"});
		params.put("ov6", new String[]{"unchecked"});
		params.put("ov7", new String[]{"unchecked"});
		params.put("ov8", new String[]{"unchecked"});
		assertEquals("", action.getQueryString(params, officeVisits));
	}

	public void testQueryString3Checked() throws Exception {
		action = new PrescriptionReportAction(factory, 9000000000L, "2");
		List<OfficeVisitBean> officeVisits = action.getAllOfficeVisits();
		Map params = new HashMap();
		params.put("ov0", new String[]{"on"});
		params.put("ov1", new String[]{"on"});
		params.put("ov2", new String[]{"unchecked"});
		params.put("ov3", new String[]{"unchecked"});
		params.put("ov4", new String[]{"on"});
		params.put("ov5", new String[]{"unchecked"});
		params.put("ov6", new String[]{"unchecked"});
		params.put("ov7", new String[]{"unchecked"});
		params.put("ov8", new String[]{"unchecked"});
		assertEquals("&n=3&ovOff0=0&ovOff1=1&ovOff2=4", action.getQueryString(params, officeVisits));
	}

	public void testNotFull() throws Exception {
		action = new PrescriptionReportAction(factory, 9000000000L, "2");
		List<OfficeVisitBean> officeVisits = action.getAllOfficeVisits();
		Map params = new HashMap();
		params.put("ov0", new String[]{"on"});
		params.put("ov1", new String[]{"on"});
		params.put("ov2", new String[]{"unchecked"});
		params.put("ov3", new String[]{"unchecked"});
		params.put("ov4", new String[]{"on"});
		assertEquals("&n=3&ovOff0=0&ovOff1=1&ovOff2=4", action.getQueryString(params, officeVisits));
	}

	public void testGetPrescriptionReports() throws Exception {
		action = new PrescriptionReportAction(factory, 9000000000L, "2");
		List<OfficeVisitBean> officeVisits = action.getAllOfficeVisits();
		Map params = new HashMap();
		params.put("ovOff0", new String[]{"0"});
		params.put("ovOff1", new String[]{"1"});
		params.put("ovOff2", new String[]{"4"});
		List<PrescriptionReportBean> prescriptionReports = action.getPrescriptionReports(params, officeVisits);
		assertEquals(2, prescriptionReports.size());
		// use the office visit DAO test to verify that all of the correct info is taken
		assertEquals("Take twice daily", prescriptionReports.get(0).getPrescription().getInstructions());
		assertEquals("Take twice daily", prescriptionReports.get(1).getPrescription().getInstructions());
	}

	public void testGetNoPrescriptionReports() throws Exception {
		action = new PrescriptionReportAction(factory, 9000000000L, "2");
		List<OfficeVisitBean> officeVisits = action.getAllOfficeVisits();
		Map params = new HashMap();
		params.put("ov1", new String[]{"1"});
		List<PrescriptionReportBean> prescriptionReports = action.getPrescriptionReports(params, officeVisits);
		assertEquals(0, prescriptionReports.size());
	}
}
