package edu.ncsu.csc.itrust.dao.personnel;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.PersonnelBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class EditPersonnelTest extends TestCase {
	PersonnelDAO personnelDAO = DAOFactory.getTestInstance().getPersonnelDAO();

	@Override
	protected void setUp() throws Exception {
		TestDataGenerator gen = new TestDataGenerator();
		gen.insertUAP1();
	}

	public void testGetPersonnel2() throws Exception {
		PersonnelBean p = personnelDAO.getPersonnel(8000000009l);
		assertNotNull(p);
		assertIsPersonnel2(p);
	}

	public void testEditPersonnel2() throws Exception {
		PersonnelBean p = personnelDAO.getPersonnel(8000000009l);
		p.setFirstName("Person1");
		personnelDAO.editPersonnel(p);
		assertEquals("Person1", p.getFirstName());
		assertEquals("LastUAP", p.getLastName());
	}

	public void testGetNonExistentPersonnel() throws Exception {
		assertNull(personnelDAO.getPersonnel(0L));
	}

	private void assertIsPersonnel2(PersonnelBean p) {
		assertEquals(8000000009L, p.getMID());
		assertEquals("FirstUAP", p.getFirstName());
		assertEquals("LastUAP", p.getLastName());
		assertEquals("opposite of yin", p.getSecurityQuestion());
		assertEquals("yang", p.getSecurityAnswer());
		assertEquals("100 Ave", p.getStreetAddress1());
		assertEquals("", p.getStreetAddress2());
		assertEquals("Raleigh", p.getCity());
		assertEquals("NC", p.getState());
		assertEquals("27607", p.getZip());
		assertEquals("111-111-1111", p.getPhone());
	}
}
