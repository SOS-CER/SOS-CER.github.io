package edu.ncsu.csc.itrust.dao.access;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class AccessDAOExceptionTest extends TestCase {
	private AccessDAO evilDAO = DAOFactory.getEvilTestInstance().getAccessDAO();

	
	@Override
	protected void setUp() throws Exception {
	}

	public void testGetAllowableException() throws Exception {
		try {
			evilDAO.getAllowableDiagnoses(0, 0);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetSessionTimeoutException() throws Exception {
		try {
			evilDAO.getSessionTimeoutMins();
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testUpdateDiscretionaryException() throws Exception {
		try {
			evilDAO.updateDiscretionaryAccess(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertSame(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testUpdatePrivacyException() throws Exception {
		try {
			evilDAO.updatePrivacyLevels(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertSame(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testSetSessionTimeoutException() throws Exception {
		try {
			evilDAO.setSessionTimeoutMins(0);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertSame(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
}
