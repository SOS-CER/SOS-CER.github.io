package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import junit.framework.TestCase;

public class ChangeSessionTimeoutActionTest extends TestCase {
	ChangeSessionTimeoutAction action = new ChangeSessionTimeoutAction(DAOFactory.getTestInstance());

	public void testNotANumber() throws Exception {
		try {
			action.changeSessionTimeout("a");
			fail("exception should have been thrown");
		} catch (FormValidationException e) {
			assertEquals(1, e.getErrorList().size());
			assertEquals("That is not a number", e.getErrorList().get(0));
		}
	}

	public void testBadNumber() throws Exception {
		try {
			action.changeSessionTimeout("0");
			fail("exception should have been thrown");
		} catch (FormValidationException e) {
			assertEquals(1, e.getErrorList().size());
			assertEquals("Must be a number greater than 0", e.getErrorList().get(0));
		}
	}

	public void testFullChange() throws Exception {
		TestDataGenerator gen = new TestDataGenerator();
		gen.resetTimeout();
		assertEquals(20, action.getSessionTimeout());
		action.changeSessionTimeout("21");
		assertEquals(21, action.getSessionTimeout());
	}
}
