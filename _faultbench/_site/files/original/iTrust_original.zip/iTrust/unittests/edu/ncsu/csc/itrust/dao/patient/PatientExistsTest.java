package edu.ncsu.csc.itrust.dao.patient;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class PatientExistsTest extends TestCase {
	PatientDAO patientDAO = DAOFactory.getTestInstance().getPatientDAO();

	@Override
	protected void setUp() throws Exception {
		TestDataGenerator gen = new TestDataGenerator();
		gen.insertPatient2();
		gen.deletePatient200();
	}

	public void testGetPatient2() throws Exception {
		assertTrue(patientDAO.checkPatientExists(2));
	}

	public void testNotPatient200() throws Exception {
		assertFalse(patientDAO.checkPatientExists(200));
	}
}
