package edu.ncsu.csc.itrust.dao.auth;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AuthDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class UserExistsTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	AuthDAO authDAO = factory.getAuthDAO();
	private TestDataGenerator gen = new TestDataGenerator();

	@Override
	protected void setUp() throws Exception {
		gen.deletePatient200();
		gen.insertPatient1();
	}

	public void testUserExists() throws Exception {
		assertTrue(authDAO.checkUserExists(1L));
		assertFalse(authDAO.checkUserExists(200L));
	}
}
