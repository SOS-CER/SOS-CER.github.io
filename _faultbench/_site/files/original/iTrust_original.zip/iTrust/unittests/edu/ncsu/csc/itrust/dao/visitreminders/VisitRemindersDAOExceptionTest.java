package edu.ncsu.csc.itrust.dao.visitreminders;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.VisitRemindersDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class VisitRemindersDAOExceptionTest extends TestCase {
	private VisitRemindersDAO evilDAO = DAOFactory.getEvilTestInstance().getVisitRemindersDAO();
	
	@Override
	protected void setUp() throws Exception {
	}
	
	public void testGetDiagnosedVisitNeedersException() throws Exception {
		try {
			evilDAO.getDiagnosedVisitNeeders(0);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
	
	public void testGetFluShotDelinquentsException() throws Exception {
		try {
			evilDAO.getFluShotDelinquents(0);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
	
}
