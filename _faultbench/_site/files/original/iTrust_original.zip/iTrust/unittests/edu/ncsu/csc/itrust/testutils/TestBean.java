package edu.ncsu.csc.itrust.testutils;


public class TestBean{
	//Empty class isn't used at all - this is just used as a test hook into testing BeanValidator.
}
