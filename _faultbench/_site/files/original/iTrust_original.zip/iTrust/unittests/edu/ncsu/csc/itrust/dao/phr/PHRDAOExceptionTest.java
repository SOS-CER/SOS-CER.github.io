package edu.ncsu.csc.itrust.dao.phr;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.HealthRecordsDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class PHRDAOExceptionTest extends TestCase {
	private HealthRecordsDAO evilDAO = DAOFactory.getEvilTestInstance().getHealthRecordsDAO();

	@Override
	protected void setUp() throws Exception {
	}

	public void testAddException() throws Exception {
		try {
			evilDAO.add(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetException() throws Exception {
		try {
			evilDAO.getAllHealthRecords(0L);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
}
