package edu.ncsu.csc.itrust.dao.visitreminders;

import java.util.List;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.sql.SQLException;

import junit.framework.TestCase;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.VisitRemindersDAO;
import edu.ncsu.csc.itrust.beans.VisitFlag;
import edu.ncsu.csc.itrust.beans.forms.VisitReminderReturnForm;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.exception.DBException;

/**
 * Currently only tests missed-last-year's-flu-shot half of flu shot methods
 *   (only includes static data)
 * 
 * Testing for month decision is in DateUtil tests
 */
public class GetVisitRemindersTest extends TestCase {
	private DAOFactory factory = DAOFactory.getTestInstance();
	private VisitRemindersDAO visRemDAO = factory.getVisitRemindersDAO();
	private TestDataGenerator gen = new TestDataGenerator();
	private long LHCP = 9000000003l;
	
	private void setUpPatients() throws IOException, FileNotFoundException, SQLException {
		gen.insertPatient1();
		gen.insertPatient2();
		gen.insertPatient3();
		/*
		gen.insertOfficeVisit1();
		gen.insertAdditionalOfficeVisits();
		*/
	}
	
	private void removePatients() throws IOException, FileNotFoundException, SQLException {
		gen.removePatient1();
		gen.removePatient2();
		gen.removePatient3();
	}
	
	public void testGetFluShotDelinquents()
			throws DBException, IOException, FileNotFoundException, SQLException 
	{
		setUpPatients();
		List<VisitReminderReturnForm> visRems = visRemDAO.getFluShotDelinquents(LHCP);
		assertEquals(2, visRems.size());
		VisitReminderReturnForm reminder = visRems.get(0);
		assertEquals(reminder.getLastName(), "Needs");
		assertEquals(reminder.getPatientID(), 3);
		assertEquals(reminder.getVisitFlags()[0].getType(), VisitFlag.MISSED_MEDICATION);
		assertEquals(reminder.getVisitFlags()[0].getValue(), "Flu Shot");
		reminder = visRems.get(1);
		assertEquals(reminder.getLastName(), "Person");
		assertEquals(reminder.getPatientID(), 1);
		assertEquals(reminder.getVisitFlags()[0].getType(), VisitFlag.MISSED_MEDICATION);
		assertEquals(reminder.getVisitFlags()[0].getValue(), "Flu Shot");
	}
	
	public void testGetDiagnosedVisitNeeders()
			throws DBException, IOException, FileNotFoundException, SQLException 
	{
		setUpPatients();
		List<VisitReminderReturnForm> visRems = visRemDAO.getDiagnosedVisitNeeders(LHCP);
		//assertEquals(2, visRems.size());
		VisitReminderReturnForm reminder = visRems.get(0);
		assertEquals(reminder.getLastName(), "Needs");
		assertEquals(reminder.getPatientID(), 3);
		assertEquals(reminder.getVisitFlags()[0].getType(), VisitFlag.DIAGNOSED);
		assertEquals(reminder.getVisitFlags()[0].getValue(), "459.99");
		reminder = visRems.get(1);
		assertEquals(reminder.getLastName(), "Person");
		assertEquals(reminder.getPatientID(), 1);
		assertEquals(reminder.getVisitFlags()[0].getType(), VisitFlag.DIAGNOSED);
		assertEquals(reminder.getVisitFlags()[0].getValue(), "250.00");
	}
	
	public void testGetFluShotDelinquentsEmpty()
			throws DBException, IOException, FileNotFoundException, SQLException
	{
		removePatients();
		gen.insertPatient2();
		List<VisitReminderReturnForm> visRems = visRemDAO.getFluShotDelinquents(LHCP);
		assertEquals(0, visRems.size());
	}
	
	public void testGetDiagnosedVisitNeedersEmpty()
			throws DBException, IOException, FileNotFoundException, SQLException
	{
		removePatients();
		gen.insertPatient2();
		List<VisitReminderReturnForm> visRems = visRemDAO.getDiagnosedVisitNeeders(LHCP);
		assertEquals(0, visRems.size());
	}
}
