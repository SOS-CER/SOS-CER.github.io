package edu.ncsu.csc.itrust.dao.standards;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.CPTCodesDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;

public class CPTDAOExceptionTest extends TestCase {
	private CPTCodesDAO evilDAO = DAOFactory.getEvilTestInstance().getCPTCodesDAO();

	@Override
	protected void setUp() throws Exception {
	}

	public void testAddCodeException() throws Exception {
		try {
			evilDAO.addCPTCode(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetAllCodesException() throws Exception {
		try {
			evilDAO.getAllCPTCodes();
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testGetException() throws Exception {
		try {
			evilDAO.getCPTCode("");
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}

	public void testUpdateCodeException() throws Exception {
		try {
			evilDAO.updateCode(null);
			fail("DBException should have been thrown");
		} catch (DBException e) {
			assertEquals(EvilTestConnectionDriver.MESSAGE, e.getSQLException().getMessage());
		}
	}
}
