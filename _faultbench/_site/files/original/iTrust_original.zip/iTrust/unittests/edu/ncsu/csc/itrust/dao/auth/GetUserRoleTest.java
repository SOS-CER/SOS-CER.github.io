package edu.ncsu.csc.itrust.dao.auth;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class GetUserRoleTest extends TestCase{
	private TestDataGenerator gen = new TestDataGenerator(); 
	
	@Override
	protected void setUp() throws Exception {
		
	}
	
	public void testHCPMeganHunt() throws Exception {
		gen.insertHCP0();
		assertEquals("HCP 90..0", "hcp", DAOFactory.getTestInstance().getAuthDAO().getUserRole(9000000000L).getUserRolesString());
	}
	
}
