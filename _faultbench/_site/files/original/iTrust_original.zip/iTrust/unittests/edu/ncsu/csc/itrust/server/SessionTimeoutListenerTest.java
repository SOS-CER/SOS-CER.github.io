package edu.ncsu.csc.itrust.server;

import javax.servlet.http.HttpSessionEvent;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;

public class SessionTimeoutListenerTest extends TestCase {
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.resetTimeout();
	}

	// This uses a rudimentary mock object system - where we create these objects that are
	// essentially stubs, except for keeping track of info passed to them.
	public void testListenerWorked() throws Exception {
		SessionTimeoutListener listener = new SessionTimeoutListener(DAOFactory.getTestInstance());
		HttpSessionEvent event = new MockHttpSessionEvent();
		listener.sessionCreated(event);
		assertEquals(1200, MockHttpSession.mins);
	}

	public void testNothingWithSessionDestroyed() throws Exception {
		SessionTimeoutListener listener = new SessionTimeoutListener(DAOFactory.getTestInstance());
		listener.sessionDestroyed(null);
	}

	public void testDBException() throws Exception {
		SessionTimeoutListener listener = new SessionTimeoutListener();
		listener.sessionCreated(new MockHttpSessionEvent());
		assertEquals(1200, MockHttpSession.mins);
	}

	
}
