package edu.ncsu.csc.itrust.dao.access;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import junit.framework.TestCase;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.datagenerators.TestDataGenerator;
import edu.ncsu.csc.itrust.enums.PrivacyLevel;
import edu.ncsu.csc.itrust.exception.DBException;

public class UpdatePrivacyLevelTest extends TestCase {
	private AccessDAO accessDAO = DAOFactory.getTestInstance().getAccessDAO();
	private OfficeVisitDAO ovDAO = DAOFactory.getTestInstance().getOfficeVisitDAO();
	private TestDataGenerator gen;

	@Override
	protected void setUp() throws Exception {
		gen = new TestDataGenerator();
		gen.insertPatient2();
	}

	public void testUpdatePrivacyLevelWithAccess() throws Exception {
		List<DiagnosisBean> diagnoses = getDiagnoses();
		assertEquals(3, diagnoses.size());
		assertEquals(PrivacyLevel.ALL_STAFF, diagnoses.get(0).getPrivacyLevel());
		assertEquals(PrivacyLevel.DECLARED_ONLY, diagnoses.get(1).getPrivacyLevel());
		DiagnosisBean d = new DiagnosisBean();
		d.setOvDiagnosisID(diagnoses.get(1).getOvDiagnosisID());
		d.setPrivacyLevel(PrivacyLevel.NO_ONE);
		assertEquals("Privacy levels successfully set.", accessDAO.updatePrivacyLevels(Arrays.asList(d)));
		diagnoses = getDiagnoses();
		assertEquals(3, diagnoses.size());
		assertEquals(PrivacyLevel.NO_ONE, diagnoses.get(1).getPrivacyLevel());
	}

	public void testUpdatePrivacyLevelWithoutAccess() throws Exception {
		List<DiagnosisBean> diagnoses = getDiagnoses();
		assertFalse(diagnoses.get(0).isDiscretionaryAccess());
		assertEquals(PrivacyLevel.ALL_STAFF, diagnoses.get(0).getPrivacyLevel());
		DiagnosisBean d = new DiagnosisBean();
		d.setOvDiagnosisID(diagnoses.get(0).getOvDiagnosisID());
		d.setPrivacyLevel(PrivacyLevel.NO_ONE);
		d.setDescription("My Description");
		d.setICDCode(79.3);
		assertEquals("Could not update the following diagnoses: My Description(79.3)", accessDAO.updatePrivacyLevels(Arrays.asList(d)));
		diagnoses = getDiagnoses();
		assertEquals(3, diagnoses.size());
		assertEquals(PrivacyLevel.ALL_STAFF, diagnoses.get(0).getPrivacyLevel());
	}

	private List<DiagnosisBean> getDiagnoses() throws DBException {
		List<DiagnosisBean> diagnoses = ovDAO.getDiagnoses(10);
		Collections.sort(diagnoses, new Comparator<DiagnosisBean>() {
			public int compare(DiagnosisBean o1, DiagnosisBean o2) {
				return Long.valueOf(o1.getOvDiagnosisID()).compareTo(Long.valueOf(o2.getOvDiagnosisID()));
			}
		});
		return diagnoses;
	}
}
