package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.beans.OperationalProfile;
import edu.ncsu.csc.itrust.beans.TransactionBean;
import edu.ncsu.csc.itrust.beans.loaders.OperationalProfileLoader;
import edu.ncsu.csc.itrust.beans.loaders.TransactionBeanLoader;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;

public class TransactionDAO {
	private DAOFactory factory;
	private TransactionBeanLoader loader = new TransactionBeanLoader();
	private OperationalProfileLoader operationalProfileLoader = new OperationalProfileLoader();

	public TransactionDAO(DAOFactory factory) {
		this.factory = factory;
	}

	public List<TransactionBean> getAllTransactions() throws DBException {
		Connection conn = null;
		try {
			conn = factory.getConnection();
			ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM TransactionLog ORDER BY timeLogged DESC");
			return loader.loadList(rs);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, null);
		}
	}

	public void logTransaction(TransactionType type, long loggedInMID) throws DBException {
		logTransaction(type, loggedInMID, 0L, "");
	}

	public void logTransaction(TransactionType type, long loggedInMID, long secondaryMID, String addedInfo)
			throws DBException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = factory.getConnection();
			PreparedStatement ps = conn.prepareStatement("INSERT INTO TransactionLog(loggedInMID, secondaryMID, "
					+ "transactionCode, addedInfo) VALUES(?,?,?,?)");
			ps.setLong(1, loggedInMID);
			ps.setLong(2, secondaryMID);
			ps.setInt(3, type.getCode());
			ps.setString(4, addedInfo);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, pstmt);
		}
	}

	public List<TransactionBean> getAllRecordAccesses(long patientID) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn
					.prepareStatement("SELECT * FROM TransactionLog WHERE secondaryMID=? AND transactionCode=? ORDER BY timeLogged DESC");
			ps.setLong(1, patientID);
			ps.setInt(2, TransactionType.VIEW_RECORDS.getCode());
			ResultSet rs = ps.executeQuery();
			return loader.loadList(rs);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public List<TransactionBean> getRecordAccesses(long patientID, Date lower, Date upper) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM TransactionLog WHERE secondaryMID=? AND transactionCode=? "
					+ "AND timeLogged >= ? AND timeLogged <= ? ORDER BY timeLogged DESC");
			ps.setLong(1, patientID);
			ps.setInt(2, TransactionType.VIEW_RECORDS.getCode());
			ps.setTimestamp(3, new Timestamp(lower.getTime()));
			// add 1 day's worth to include the upper
			ps.setTimestamp(4, new Timestamp(upper.getTime() + 1000L * 60L * 60 * 24L));
			ResultSet rs = ps.executeQuery();
			return loader.loadList(rs);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public OperationalProfile getOperationalProfile() throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ResultSet rs = conn.createStatement().executeQuery(
					"SELECT TransactionCode, count(transactionID) as TotalCount, "
							+ "count(if(loggedInMID<9000000000, transactionID, null)) as PatientCount, "
							+ "count(if(loggedInMID>=9000000000, transactionID, null)) as PersonnelCount "
							+ "FROM TransactionLog GROUP BY transactionCode ORDER BY transactionCode ASC");
			return operationalProfileLoader.loadSingle(rs);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
}
