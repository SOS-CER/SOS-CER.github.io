package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.beans.MedicationBean;
import edu.ncsu.csc.itrust.beans.loaders.MedicationBeanLoader;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class NDCodesDAO {
	private DAOFactory factory;
	private MedicationBeanLoader medicationLoader = new MedicationBeanLoader();
	
	public NDCodesDAO(DAOFactory factory) {
		this.factory = factory;
	}
	
	public List<MedicationBean> getAllNDCodes() throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM NDCodes ORDER BY CODE");
			ResultSet rs = ps.executeQuery();
			return medicationLoader.loadList(rs);
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public MedicationBean getNDCode(String code) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM NDCodes WHERE Code = ?");
			ps.setString(1, code);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) return medicationLoader.loadSingle(rs);
			return null;
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	/**
	 * NOTE: method should be passed non-null values for non-null fields
	 * @param med
	 * @return
	 * @throws DBException
	 * @throws iTrustException
	 */
	public boolean addNDCode(MedicationBean med)
			throws DBException, iTrustException
	{
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"INSERT INTO NDCodes (Code, Description) " +
					"VALUES (?,?)");
			ps.setString(1, med.getNDCode());
			ps.setString(2, med.getDescription());
			return (1 == ps.executeUpdate());
		} catch (SQLException e) {
			e.printStackTrace();
			if(1062 == e.getErrorCode())
				throw new iTrustException("Error: Code already exists.");
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public int updateCode(MedicationBean med) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"UPDATE NDCodes SET Description = ? " +
					"WHERE Code = ?");
			/* TODO: CHECK BOTH WAYS */
			/* ps.setStrint(1, ...) and medicationLoader.loadParameters
			 * accomplish the same thing and both pass unit tests as of
			 * 2007-jun-04 */
			ps.setString(1, med.getDescription());
			// OR NEXT LINE
			//medicationLoader.loadParameters(ps, med);
			ps.setString(2, med.getNDCode());
			return ps.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
}
