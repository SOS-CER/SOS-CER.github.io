package edu.ncsu.csc.itrust.risk;

import java.util.ArrayList;
import java.util.List;

import edu.ncsu.csc.itrust.beans.HealthRecord;
import edu.ncsu.csc.itrust.beans.PatientBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.HealthRecordsDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.NoHealthRecordsException;
import edu.ncsu.csc.itrust.risk.factors.PatientRiskFactor;

abstract public class RiskChecker {
	private static final int RISK_THRESHOLD = 3;
	protected PatientBean patient;
	protected HealthRecord currentHealthRecord;
	protected DAOFactory factory; 

	public RiskChecker(DAOFactory factory, long patientID) throws DBException, NoHealthRecordsException {
		this.factory = factory;
		HealthRecordsDAO hrDAO = factory.getHealthRecordsDAO();
		List<HealthRecord> records = hrDAO.getAllHealthRecords(patientID);
		if (records.size() > 0)
			currentHealthRecord = records.get(0);
		else
			throw new NoHealthRecordsException();
		patient = factory.getPatientDAO().getPatient(patientID);
	}

	abstract public String getName();
	
	abstract protected List<PatientRiskFactor> getDiseaseRiskFactors();

	abstract public boolean qualifiesForDisease();

	/**
	 * This method exists purely for performance - just stop once you hit the threshold. <br>
	 * <br>
	 * Also, the risk factors should be cached in the RiskFactor implementors - in
	 * getPatientRiskFactors there should be no double-querying
	 * 
	 * @return isAtRisk
	 */
	public boolean isAtRisk() {
		if (qualifiesForDisease()) {
			int numRisks = 0;
			List<PatientRiskFactor> diseaseRiskFactors = getDiseaseRiskFactors();
			for (PatientRiskFactor factor : diseaseRiskFactors) {
				if (factor.hasRiskFactor())
					numRisks++;
				if (numRisks >= RISK_THRESHOLD)
					return true;
			}
		}
		return false; // both an else from qualifies or NOT over the threshold
	}

	public List<PatientRiskFactor> getPatientRiskFactors() {
		List<PatientRiskFactor> patientRiskFactors = new ArrayList<PatientRiskFactor>();
		List<PatientRiskFactor> diseaseRiskFactors = getDiseaseRiskFactors();
		for (PatientRiskFactor factor : diseaseRiskFactors) {
			if (factor.hasRiskFactor()) {
				patientRiskFactors.add(factor);
			}
		}
		return patientRiskFactors;
	}
}
