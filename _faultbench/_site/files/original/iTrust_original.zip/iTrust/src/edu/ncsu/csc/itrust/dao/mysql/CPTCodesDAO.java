package edu.ncsu.csc.itrust.dao.mysql;

import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.beans.ProcedureBean;
import edu.ncsu.csc.itrust.beans.loaders.ProcedureBeanLoader;

public class CPTCodesDAO {
	private DAOFactory factory;
	private ProcedureBeanLoader procedureBeanLoader = new ProcedureBeanLoader();

	public CPTCodesDAO(DAOFactory factory) {
		this.factory = factory;
	}
	
	public List<ProcedureBean> getAllCPTCodes() throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM CPTCodes ORDER BY CODE");
			ResultSet rs = ps.executeQuery();
			return procedureBeanLoader.loadList(rs);
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public ProcedureBean getCPTCode(String code) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"SELECT * FROM CPTCodes WHERE Code = ?");
			ps.setString(1, code);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) return procedureBeanLoader.loadSingle(rs);
			return null;
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	/**
	 * NOTE: method should be passed non-null values for non-null fields
	 * @param proc
	 * @return
	 * @throws DBException
	 * @throws iTrustException
	 */
	public boolean addCPTCode(ProcedureBean proc)
			throws DBException, iTrustException
	{
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"INSERT INTO CPTCodes (Code, Description) " +
					"VALUES (?,?)");
			ps.setString(1, proc.getCPTCode());
			ps.setString(2, proc.getDescription());
			return (1 == ps.executeUpdate());
		} catch (SQLException e) {
			e.printStackTrace();
			if(1062 == e.getErrorCode())
				throw new iTrustException("Error: Code already exists.");
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
	public int updateCode(ProcedureBean proc) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement(
					"UPDATE CPTCodes SET Description = ? " +
					"WHERE Code = ?");
			/* ps.setStrint(1, ...) and procedureBeanLoader.loadParameters
			 * accomplish the same thing and both pass unit tests as of
			 * 2007-jun-01 */
			ps.setString(1, proc.getDescription());
			// OR NEXT LINE
			//procedureBeanLoader.loadParameters(ps, proc);
			ps.setString(2, proc.getCPTCode());
			return ps.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
	
}
