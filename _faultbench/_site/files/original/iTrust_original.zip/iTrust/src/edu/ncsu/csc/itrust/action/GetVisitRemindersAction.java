package edu.ncsu.csc.itrust.action;

//import edu.ncsu.csc.itrust.action.base.PatientBaseAction;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;

import edu.ncsu.csc.itrust.beans.forms.VisitReminderReturnForm;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.VisitRemindersDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class GetVisitRemindersAction {
	
	/**
	 * 
	 * Reminder Type enumeration.
	 * 
	 */
	public static enum ReminderType {
		DIAGNOSED_CARE_NEEDERS("Diagnosed Care Needers"),
		FLU_SHOT_NEEDERS("Flu Shot Needers");
		
		private String typeName;
		private ReminderType(String typeName) {
			this.typeName = typeName;
		}
		
		private static final HashMap<String, ReminderType> map = new HashMap<String, ReminderType>();
		static {
			for(ReminderType rt: ReminderType.values()) {
				map.put(rt.getTypeName(), rt);
			}
		}
		
		public static ReminderType getReminderType(String name) {
			return map.get(name);
		}
		
		public String getTypeName() { return typeName; }
	}
	
	
	/**
	 * 
	 * Begin GetVisitRemindersAction code
	 * 
	 */
	private TransactionDAO transDAO;
	//private Validator validator = new Validator();
	private VisitRemindersDAO visitReminderDAO;
	private long loggedInMID;
	
	
	public GetVisitRemindersAction(DAOFactory factory, long loggedInMID)
			throws iTrustException
	{
		this.transDAO = factory.getTransactionDAO();
		this.loggedInMID = loggedInMID;
		visitReminderDAO = factory.getVisitRemindersDAO();
	}
	
	public List<VisitReminderReturnForm> getVisitReminders(ReminderType type)
			throws iTrustException, FormValidationException
	{
		if(null == type) throw new iTrustException("Reminder Type DNE");
		transDAO.logTransaction(TransactionType.PATIENT_REMINDERS, loggedInMID, 0l, type.getTypeName());
		switch(type) {
			case DIAGNOSED_CARE_NEEDERS :
				return stripDupes(visitReminderDAO.getDiagnosedVisitNeeders(loggedInMID));
			
			case FLU_SHOT_NEEDERS :
				return visitReminderDAO.getFluShotDelinquents(loggedInMID);
			default : throw new iTrustException("Reminder Type DNE");
		}
	}
	
	private List<VisitReminderReturnForm> stripDupes(List<VisitReminderReturnForm> patients) {
		if(null == patients) return null;
		if(0 == patients.size()) return patients;
		List<VisitReminderReturnForm> retPatients = new ArrayList<VisitReminderReturnForm>();
		VisitReminderReturnForm temp = patients.get(0);
		retPatients.add(temp);
		for(VisitReminderReturnForm vr : patients) {
			if(vr.getPatientID() != temp.getPatientID()) retPatients.add(vr);
			temp = vr;
		}
		return retPatients;
	}
}
