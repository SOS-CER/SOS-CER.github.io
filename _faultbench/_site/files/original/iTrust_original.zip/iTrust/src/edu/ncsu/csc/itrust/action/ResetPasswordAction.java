package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AuthDAO;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.ErrorList;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.validate.ValidationFormat;

public class ResetPasswordAction {
	private AuthDAO authDAO;
	private PatientDAO patientDAO;
	private PersonnelDAO personnelDAO;

	public ResetPasswordAction(DAOFactory factory) {
		this.authDAO = factory.getAuthDAO();
		this.patientDAO = factory.getPatientDAO();
		this.personnelDAO = factory.getPersonnelDAO();
	}

	public long checkMID(String midString) {
		try {
			long mid = Long.valueOf(midString);
			if (!authDAO.checkUserExists(mid))
				return 0;
			return mid;
		} catch (NumberFormatException e) {
			return 0L;
		} catch (DBException e) {
			return 0L;
		}
	}

	public String checkRole(String role) {
		if ("patient".equals(role) || "hcp".equals(role) || "uap".equals(role))
			return role;
		else
			return null;
	}

	public String checkAnswerNull(String answer) {
		if (answer == null || "".equals(answer))
			return null;
		else
			return answer;
	}

	public String getSecurityQuestion(long mid, String role) {
		try {
			if ("patient".equals(role)) {
				return patientDAO.getPatient(mid).getSecurityQuestion();
			} else if ("hcp".equals(role) || "uap".equals(role)) {
				return personnelDAO.getPersonnel(mid).getSecurityQuestion();
			} else
				return "";
		} catch (DBException e) {
			e.printStackTrace();
			return "";
		}
	}

	public String resetPassword(long mid, String role, String answer, String password, String confirmPassword)
			throws FormValidationException {
		try {
			validatePassword(password, confirmPassword);
			if ("patient".equals(role)) {
				if (answer.equals(patientDAO.getPatient(mid).getSecurityAnswer())) {
					authDAO.resetPassword(mid, password);
					return "Password changed";
				} else
					return "Answer did not match";
			} else if ("hcp".equals(role) || "uap".equals(role)) {
				if (answer.equals(personnelDAO.getPersonnel(mid).getSecurityAnswer())) {
					authDAO.resetPassword(mid, password);
					return "Password changed";
				} else
					return "Answer did not match";
			} else
				return "Invalid role";
		} catch (DBException e) {
			return "Error in validation of security answer";
		}
	}

	private void validatePassword(String password, String confirmPassword) throws FormValidationException {
		ErrorList errorList = new ErrorList();
		if (password == null || "".equals(password)) {
			errorList.addIfNotNull("Password cannot be empty");
		} else {
			if (!password.equals(confirmPassword))
				errorList.addIfNotNull("Passwords don't match");
			if (!ValidationFormat.PASSWORD.getRegex().matcher(password).matches()) {
				errorList.addIfNotNull("Password must be in the following format: "
						+ ValidationFormat.PASSWORD.getDescription());
			}
		}
		if (errorList.hasErrors())
			throw new FormValidationException(errorList);
	}
}
