package edu.ncsu.csc.itrust.dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.DBUtil;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.enums.Role;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class AuthDAO {
	public static final long LOGIN_TIMEOUT = 15 * 60 * 1000;// 15 min
	private DAOFactory factory;

	public AuthDAO(DAOFactory factory) {
		this.factory = factory;
	}

	public void addUser(Long mid, Role role, String password) throws DBException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = factory.getConnection();
			pstmt = conn.prepareStatement("INSERT INTO Users(MID,PASSWORD,ROLE) VALUES(?,?,?)");
			pstmt.setLong(1, mid);
			pstmt.setString(2, password);
			pstmt.setString(3, role.getUserRolesString());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, pstmt);
		}
	}

	public String getUserName(long mid) throws DBException, iTrustException {
		Role role = getUserRole(mid);
		switch (role) {
			case HCP :
			case ADMIN :
			case UAP :
				return factory.getPersonnelDAO().getName(mid);
			case PATIENT :
				return factory.getPatientDAO().getName(mid);
			case TESTER :
				return String.valueOf(mid);
			default :
				throw new iTrustException("Role " + role + " not supported");
		}
	}

	public Role getUserRole(long mid) throws DBException, iTrustException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = factory.getConnection();
			pstmt = conn.prepareStatement("SELECT role FROM Users WHERE MID=?");
			pstmt.setLong(1, mid);
			ResultSet rs;
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return Role.parse(rs.getString("role"));
			} else {
				throw new iTrustException("User does not exist");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, pstmt);
		}
	}

	public void resetPassword(long mid, String password) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("UPDATE Users SET password=? WHERE MID=?");
			ps.setString(1, password);
			ps.setLong(2, mid);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public void recordLoginFailure(String ipAddr) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("UPDATE LoginFailures SET FailureCount=FailureCount+1 WHERE IPAddress=?");
			ps.setString(1, ipAddr);
			int numUpdated = ps.executeUpdate();
			if (numUpdated == 0) // if there wasn't an empty row to begin with
				insertLoginFailureRow(ipAddr, 1, conn);// now they have a row AND a strike against
			// 'em
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	public int getLoginFailures(String ipAddr) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM LoginFailures WHERE IPADDRESS=?");
			ps.setString(1, ipAddr);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				// if we're more than X minutes out, clear the failure count
				if (System.currentTimeMillis() - rs.getTimestamp("lastFailure").getTime() > LOGIN_TIMEOUT) {
					updateFailuresToZero(ipAddr, conn);
					return 0;
				} else {
					return rs.getInt("failureCount");
				}
			} else {
				insertLoginFailureRow(ipAddr, 0, conn);
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}

	private void insertLoginFailureRow(String ipAddr, int failureCount, Connection conn) throws DBException,
			SQLException {
		PreparedStatement ps = conn.prepareStatement("INSERT INTO LoginFailures(IPAddress, failureCount) VALUES(?,?)");
		ps.setString(1, ipAddr);
		ps.setInt(2, failureCount);
		ps.executeUpdate();
	}

	private void updateFailuresToZero(String ipAddr, Connection conn) throws DBException, SQLException {
		PreparedStatement ps = conn.prepareStatement("UPDATE LoginFailures SET failureCount=0 WHERE IPAddress=?");
		ps.setString(1, ipAddr);
		ps.executeUpdate();
	}

	public boolean checkUserExists(long mid) throws DBException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = factory.getConnection();
			ps = conn.prepareStatement("SELECT * FROM Users WHERE MID=?");
			ps.setLong(1, mid);
			ResultSet rs = ps.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBException(e);
		} finally {
			DBUtil.closeConnection(conn, ps);
		}
	}
}
