package edu.ncsu.csc.itrust.action;

import java.util.List;

import edu.ncsu.csc.itrust.action.base.PersonnelBaseAction;
import edu.ncsu.csc.itrust.beans.HospitalBean;
import edu.ncsu.csc.itrust.beans.PersonnelBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AuthDAO;
import edu.ncsu.csc.itrust.dao.mysql.HospitalsDAO;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.Role;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.validate.HospitalBeanValidator;

public class ManageHospitalAssignmentsAction extends PersonnelBaseAction {
	private TransactionDAO transDAO;
	private PersonnelDAO personnelDAO;
	private HospitalsDAO hospitalsDAO;
	private AuthDAO authDAO;
	private long loggedInMID;

	public ManageHospitalAssignmentsAction(DAOFactory factory,
			long loggedInMID, String pidString) throws iTrustException {
		super(factory, pidString);
		this.loggedInMID = loggedInMID;
		this.transDAO = factory.getTransactionDAO();
		this.personnelDAO = factory.getPersonnelDAO();
		this.hospitalsDAO = factory.getHospitalsDAO();
		this.authDAO = factory.getAuthDAO();
		checkUserIsHCP();
	}

	private void checkUserIsHCP() throws DBException, iTrustException {
		Role pidRole = authDAO.getUserRole(pid);
		if (!Role.HCP.equals(pidRole))
			throw new iTrustException("User is not an HCP");
	}

	public List<HospitalBean> getAssignedHospitals() throws iTrustException {
		return personnelDAO.getHospitals(pid);
	}

	public PersonnelBean getHCP() throws DBException {
		return personnelDAO.getPersonnel(pid);
	}

	public String updateInformation(String addID, String removeID)
			throws iTrustException, FormValidationException {
		
		if (addID != null && addID!="" && addID!="null") {
			return assignHCPToHospital(addID);
		}
		
		if (removeID != null && removeID!="" && removeID!="null") {
			return removeHCPAssignmentToHospital(removeID);
		} 
		return "No information updated";
	}

	public String assignHCPToHospital(String hospitalID)
			throws iTrustException, FormValidationException {
		new HospitalBeanValidator().validateIDOnly(hospitalID);
		boolean confirm = hospitalsDAO.assignHospital(pid, hospitalID);
		if (confirm) {
			transDAO.logTransaction(TransactionType.MAINTAIN_HOSPITALS,
					loggedInMID, pid, "HCP " + pid + " assigned to hospital "
							+ hospitalID);
			return "HCP successfully assigned.";
		} else
			return "Assignment did not occur";

	}

	public String removeHCPAssignmentToHospital(String hospitalID)
			throws iTrustException, FormValidationException {
		new HospitalBeanValidator().validateIDOnly(hospitalID);
		boolean confirm = hospitalsDAO
				.removeHospitalAssignment(pid, hospitalID);
		if (confirm) {
			transDAO.logTransaction(TransactionType.ENTER_EDIT_DEMOGRAPHICS,
					loggedInMID, pid, "HCP " + pid
							+ " unassigned from hospital " + hospitalID);
			return "HCP successfully unassigned";
		} else
			return "HCP not unassigned";

	}
	
	public List<HospitalBean> getAllHospitals() throws DBException{
		return hospitalsDAO.getAllHospitals();
	}

}
