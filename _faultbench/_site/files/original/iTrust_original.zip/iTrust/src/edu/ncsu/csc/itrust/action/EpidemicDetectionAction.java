package edu.ncsu.csc.itrust.action;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import edu.ncsu.csc.itrust.beans.forms.EpidemicForm;
import edu.ncsu.csc.itrust.beans.forms.EpidemicReturnForm;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.State;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.epidemic.EpidemicChooser;
import edu.ncsu.csc.itrust.epidemic.EpidemicDetector;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.validate.EpidemicFormValidator;

public class EpidemicDetectionAction {
	private DAOFactory factory;
	private long loggedInMID;
	private TransactionDAO transDAO;

	public EpidemicDetectionAction(DAOFactory factory, long loggedInMID) {
		this.factory = factory;
		this.loggedInMID = loggedInMID;
		this.transDAO = factory.getTransactionDAO();
	}

	public EpidemicReturnForm execute(EpidemicForm form) throws FormValidationException, DBException {
		new EpidemicFormValidator().validate(form);
		EpidemicReturnForm rForm = new EpidemicReturnForm();
		rForm.setImageQuery(getImageQuery(form));
		if ("true".equals(form.getUseEpidemic())) {
			rForm.setUsedEpidemic(true);
			rForm.setEpidemicMessage(checkForEpidemic(form));
		} else
			rForm.setUsedEpidemic(false);
		transDAO.logTransaction(TransactionType.REQUEST_BIOSURVEILLANCE, loggedInMID);
		return rForm;
	}

	private String getImageQuery(EpidemicForm form) throws FormValidationException {
		double icdLower;
		double icdUpper;
		if ("true".equals(form.getUseEpidemic())) {
			EpidemicChooser chooser = new EpidemicChooser();
			icdLower = chooser.getICDLower(form.getDetector());
			icdUpper = chooser.getICDUpper(form.getDetector());
		} else {
			icdLower = Double.valueOf(form.getIcdLower());
			icdUpper = Double.valueOf(form.getIcdUpper());
		}
		return "date=" + form.getDate() + "&icdLower=" + icdLower + "&icdUpper=" + icdUpper + "&state="
				+ State.parse(form.getState()).getAbbrev() + "&weeksBack=" + form.getWeeksBack() + "&zip="
				+ form.getZip();
	}

	private String checkForEpidemic(EpidemicForm form) throws FormValidationException {
		try {
			State state = State.parse(form.getState());
			Date from = new SimpleDateFormat("MM/dd/yyyy").parse(form.getDate());
			int weeksBack = Integer.valueOf(form.getWeeksBack());
			String epidemicString = chooseEpidemic(form.getDetector(), form.getZip(), state, from, weeksBack)
					.checkForEpidemic();
			return "".equals(epidemicString) ? "No epidemic detected" : epidemicString;
		} catch (DBException e) {
			e.printStackTrace();
			return "Error in epidemic detection";
		} catch (ParseException e) {
			e.printStackTrace();
			return "Error in epidemic detection";
		}
	}

	private EpidemicDetector chooseEpidemic(String detector, String zip, State state, Date from, int weeksBack)
			throws FormValidationException, DBException {
		return new EpidemicChooser().chooseEpidemic(factory, detector, zip, state, from, weeksBack);
	}
}
