package edu.ncsu.csc.itrust.action;

import java.awt.image.BufferedImage;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import edu.ncsu.csc.itrust.beans.DiagnosisCount;
import edu.ncsu.csc.itrust.beans.forms.EpidemicForm;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.EpidemicDAO;
import edu.ncsu.csc.itrust.enums.State;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.validate.EpidemicFormValidator;

public class EpidemicDetectionImageAction {
	private EpidemicDAO epDAO;

	public EpidemicDetectionImageAction(DAOFactory factory) {
		this.epDAO = factory.getEpidemicDAO();
	}

	public BufferedImage createGraph(EpidemicForm form) throws FormValidationException, DBException, ParseException {
		new EpidemicFormValidator().validate(form);
		JFreeChart chart = ChartFactory.createBarChart3D("Diagnosis Count for ICD Range " + form.getIcdLower() + " to "
				+ form.getIcdUpper(), "Category Axis Label", "Value Axis Label", createDataSet(form),
				PlotOrientation.VERTICAL, true, true, true);
		return chart.createBufferedImage(700, 500);
	}

	private CategoryDataset createDataSet(EpidemicForm form) throws DBException, ParseException, FormValidationException {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		List<DiagnosisCount> dCounts = epDAO.getDiagnosisCounts(Double.valueOf(form.getIcdLower()), Double.valueOf(form.getIcdUpper()), form.getZip(), State.parse(form
				.getState()), new SimpleDateFormat("MM/dd/yyyy").parse(form.getDate()), Integer.valueOf(form
				.getWeeksBack()));
		int week = Integer.valueOf(form.getWeeksBack());
		for (DiagnosisCount dCount : dCounts) {
			dataset.addValue(dCount.getNumInRegion(), "Regional", week + " weeks ago");
			dataset.addValue(dCount.getNumInState(), "State", week + " weeks ago");
			dataset.addValue(dCount.getNumInTotal(), "Total", week + " weeks ago");
			week--;
		}
		return dataset;
	}
}
