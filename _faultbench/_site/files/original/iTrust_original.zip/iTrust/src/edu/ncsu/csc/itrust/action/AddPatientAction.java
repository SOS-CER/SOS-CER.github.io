package edu.ncsu.csc.itrust.action;

import java.util.Random;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AuthDAO;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.Role;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;

public class AddPatientAction {
	private TransactionDAO transDAO;
	private PatientDAO patientDAO;
	private AuthDAO authDAO;
	private long loggedInMID;

	public AddPatientAction(DAOFactory factory, long loggedInMID) {
		this.patientDAO = factory.getPatientDAO();
		this.authDAO = factory.getAuthDAO();
		this.transDAO = factory.getTransactionDAO();
		this.loggedInMID = loggedInMID;
	}

	public long execute() throws DBException {
		long newMID = patientDAO.addEmptyPatient();
		authDAO.addUser(newMID, Role.PATIENT, getRandomPassword());
		transDAO.logTransaction(TransactionType.ENTER_EDIT_DEMOGRAPHICS, loggedInMID);
		return newMID;
	}

	private String getRandomPassword() {
		Random rand = new Random();
		String str = "";
		for (int i = 0; i < 10; i++) {
			str += (char) (rand.nextInt(26) + 'a');
		}
		return str;
	}
}
