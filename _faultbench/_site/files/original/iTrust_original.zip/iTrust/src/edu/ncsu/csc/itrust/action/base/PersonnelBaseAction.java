package edu.ncsu.csc.itrust.action.base;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class PersonnelBaseAction {
	private DAOFactory factory;
	protected long pid;

	public PersonnelBaseAction(DAOFactory factory, String pidString) throws iTrustException{
		this.factory = factory;
		this.pid = checkPersonnelID(pidString);
	}
	
	private long checkPersonnelID(String input) throws iTrustException {
		try {
			long pid = Long.valueOf(input);
			if (factory.getPersonnelDAO().checkPersonnelExists(pid))
				return pid;
			else
				throw new iTrustException("Personnel does not exist");
		} catch (NumberFormatException e) {
			throw new iTrustException("Personnel ID is not a number: " + e.getMessage());
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}
	
	public long getPid() {
		return pid;
	}
}
