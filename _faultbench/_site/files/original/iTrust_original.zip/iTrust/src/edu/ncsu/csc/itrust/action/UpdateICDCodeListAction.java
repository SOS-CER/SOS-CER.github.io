package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.ICDCodesDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.beans.DiagnosisBean;
import edu.ncsu.csc.itrust.validate.DiagnosisBeanValidator;
import edu.ncsu.csc.itrust.exception.FormValidationException;

public class UpdateICDCodeListAction {
	private long performerID = 0;
	private ICDCodesDAO icdDAO;
	private TransactionDAO transDAO;
	private DiagnosisBeanValidator validator = new DiagnosisBeanValidator();
	
	public UpdateICDCodeListAction(DAOFactory factory, long performerID) {
		this.performerID = performerID;
		transDAO = factory.getTransactionDAO();
		icdDAO = factory.getICDCodesDAO();
	}

	public String addICDCode(DiagnosisBean diagn) throws FormValidationException {
		validator.validate(diagn);
		try {
			if (icdDAO.addICDCode(diagn)) {
				transDAO.logTransaction(TransactionType.MANAGE_DIAGNOSIS_CODE, performerID, 0L, "added ICD code "
						+ diagn.getICDCode());
				return "Success: " + diagn.getICDCode() + " - " + diagn.getDescription() + " added";
			}
			else
				return "unexpected error"; // TODO: needs better error message
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		} catch (iTrustException e) {
			return e.getMessage();
		}
	}

	public String updateInformation(DiagnosisBean diagn) throws FormValidationException {
		validator.validate(diagn);
		try {
			int rows = icdDAO.updateCode(diagn);
			if(0 == rows) {
				return "Error: Code not found.";
			} else {
				transDAO.logTransaction(TransactionType.MANAGE_DIAGNOSIS_CODE, performerID, 0L, "updated ICD code "
						+ diagn.getICDCode());
				return "Success: " + rows + " row(s) updated";
			}
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

}
