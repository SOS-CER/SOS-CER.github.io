package edu.ncsu.csc.itrust;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import edu.ncsu.csc.itrust.dao.DAOFactory;

public class DBBuilder {
	private DAOFactory factory;

	public DBBuilder() {
		factory = DAOFactory.getTestInstance();
	}

	public DBBuilder(DAOFactory factory) {
		this.factory = factory;
	}

	public static void main(String[] args) throws Exception {
		rebuildAll();
	}

	public static void rebuildAll() throws FileNotFoundException, IOException, SQLException {
		DBBuilder dbBuilder = new DBBuilder(DAOFactory.getTestInstance());
		dbBuilder.dropTables();
		dbBuilder.createTables();
		System.out.println("Operation Completed");
	}

	public void dropTables() throws FileNotFoundException, IOException, SQLException {
		List<String> queries = parseSQLFile("sql/dropTables.sql");
		executeSQL(queries);
		System.out.println("Tables dropped.");
	}

	public void createTables() throws FileNotFoundException, IOException, SQLException {
		List<String> queries = parseSQLFile("sql/createTables.sql");
		executeSQL(queries);
		System.out.println("Tables created.");
	}
	
	public void executeSQL(List<String> queries) throws SQLException {
		Connection conn = factory.getConnection();
		for (String createQuery : queries) {
			System.out.println("Executing: " + createQuery);
			conn.createStatement().execute(createQuery);
		}
		conn.close();
		conn = null;
	}

	public void executeSQLFile(String filepath) throws FileNotFoundException, SQLException, IOException {
		executeSQL(parseSQLFile(filepath));
	}

	public List<String> parseSQLFile(String filepath) throws FileNotFoundException, IOException {
		List<String> queries = new ArrayList<String>();
		BufferedReader reader = new BufferedReader(new FileReader(new File(filepath)));
		String line = "";
		String currentQuery = "";
		while ((line = reader.readLine()) != null) {
			for (int i = 0; i < line.length(); i++) {
				if (line.charAt(i) == ';') {
					queries.add(currentQuery);
					currentQuery = "";
				} else
					currentQuery += line.charAt(i);
			}
		}
		reader.close();
		return queries;
	}
}
