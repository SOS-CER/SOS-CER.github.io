package edu.ncsu.csc.itrust.action;

import java.util.List;
import edu.ncsu.csc.itrust.action.base.PatientBaseAction;
import edu.ncsu.csc.itrust.beans.PatientBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class EditRepresentativesAction extends PatientBaseAction {
	private PatientDAO patientDAO;
	private TransactionDAO transDAO;
	private long loggedInMID;

	public EditRepresentativesAction(DAOFactory factory, long loggedInMID, String pidString) throws iTrustException {
		super(factory, pidString);
		this.loggedInMID = loggedInMID;
		this.transDAO = factory.getTransactionDAO();
		this.patientDAO = factory.getPatientDAO();
	}

	public List<PatientBean> getRepresented(long pid) throws iTrustException {
		try {
			return patientDAO.getRepresented(pid);
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public String addRepresentative(String input) throws iTrustException {
		try {
			long representee = Long.valueOf(input);
			boolean confirm = patientDAO.addRepresentative(pid, representee);
			if (confirm) {
				transDAO.logTransaction(TransactionType.DECLARE_REPRESENTATIVE, loggedInMID, pid, "patient " + pid
						+ " now represents patient " + representee);
				return "Patient represented";
			} else
				return "No change made";
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		} catch (NumberFormatException e) {
			return "MID not a number";
		}
	}

	public String removeRepresentative(String input) throws iTrustException {
		try {
			long representee = Long.valueOf(input);
			boolean confirm = patientDAO.removeRepresentative(pid, representee);
			if (confirm){
				transDAO.logTransaction(TransactionType.DECLARE_REPRESENTATIVE, loggedInMID, pid, "patient " + pid
						+ " no longer represents patient " + representee);
				return "Patient represented";
			}
			else
				return "No change made";
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		} catch (NumberFormatException e) {
			return "MID not a number";
		}
	}
}
