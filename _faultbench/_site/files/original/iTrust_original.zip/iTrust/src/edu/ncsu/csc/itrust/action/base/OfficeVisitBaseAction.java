package edu.ncsu.csc.itrust.action.base;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

abstract public class OfficeVisitBaseAction extends PatientBaseAction {
	private OfficeVisitDAO ovDAO;
	protected long ovID;

	public OfficeVisitBaseAction(DAOFactory factory, String pidString, String ovIDString) throws iTrustException {
		super(factory, pidString);
		this.ovDAO = factory.getOfficeVisitDAO();
		this.ovID = checkOfficeVisitID(ovIDString);
	}

	private long checkOfficeVisitID(String input) throws iTrustException {
		try {
			long ovID = Long.valueOf(input);
			if (ovDAO.checkOfficeVisitExists(ovID, pid))
				return ovID;
			else
				throw new iTrustException("Office Visit " + ovID + " with Patient MID " + pid + " does not exist");
		} catch (NumberFormatException e) {
			throw new iTrustException("Office Visit ID is not a number: " + e.getMessage());
		} catch (DBException e) {
			e.printStackTrace();
			throw new iTrustException(e.getMessage());
		}
	}

	public long getOvID() {
		return ovID;
	}
}
