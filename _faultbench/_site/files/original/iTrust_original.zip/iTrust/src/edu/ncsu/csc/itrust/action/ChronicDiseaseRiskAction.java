package edu.ncsu.csc.itrust.action;

import java.util.List;

import edu.ncsu.csc.itrust.action.base.PatientBaseAction;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.AuthDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.NoHealthRecordsException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.risk.ChronicDiseaseMediator;
import edu.ncsu.csc.itrust.risk.RiskChecker;

public class ChronicDiseaseRiskAction extends PatientBaseAction {
	private AuthDAO authDAO;
	private long loggedInMID;
	private ChronicDiseaseMediator diseaseMediator;
	private TransactionDAO transDAO;

	public ChronicDiseaseRiskAction(DAOFactory factory, long loggedInMID, String pidString) throws iTrustException,
			DBException, NoHealthRecordsException {
		super(factory, pidString);
		this.authDAO = factory.getAuthDAO();
		this.transDAO = factory.getTransactionDAO();
		this.loggedInMID = loggedInMID;
		this.diseaseMediator = new ChronicDiseaseMediator(factory, pid);
	}

	public long getPatientID() {
		return pid;
	}

	public String getUserName() throws DBException, iTrustException {
		return authDAO.getUserName(pid);
	}

	public List<RiskChecker> getDiseasesAtRisk() throws iTrustException, DBException {
		transDAO.logTransaction(TransactionType.IDENTIFY_RISK_FACTORS, loggedInMID, pid, "");
		return diseaseMediator.getDiseaseAtRisk();
	}
}
