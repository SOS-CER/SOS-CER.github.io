package edu.ncsu.csc.itrust;

import java.util.HashMap;
import java.util.Map;

public class ParameterUtil {
	@SuppressWarnings("unchecked")
	public static HashMap<String, String> convertMap(Map params) {
		HashMap<String, String> myMap = new HashMap<String, String>();
		for (Object key : params.keySet()) {
			String[] value = ((String[]) params.get(key));
			if (value != null)
				myMap.put(key.toString(), value[0]);
			else
				myMap.put(key.toString(), null);
		}
		return myMap;
	}
}
