package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.HospitalsDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.beans.HospitalBean;
import edu.ncsu.csc.itrust.validate.HospitalBeanValidator;
import edu.ncsu.csc.itrust.exception.FormValidationException;

public class UpdateHospitalListAction {
	private long performerID = 0;
	private HospitalsDAO hospDAO;
	private TransactionDAO transDAO;

	public UpdateHospitalListAction(DAOFactory factory, long performerID) {
		this.hospDAO = factory.getHospitalsDAO();
		this.transDAO = factory.getTransactionDAO();
	}

	public String addHospital(HospitalBean hosp) throws FormValidationException {
		new HospitalBeanValidator().validate(hosp);
		try {
			if (hospDAO.addHospital(hosp)) {
				transDAO.logTransaction(TransactionType.MAINTAIN_HOSPITALS, performerID, 0L, "added hospital "
						+ hosp.getHospitalName());
				return "Success: " + hosp.getHospitalID() + " - " + hosp.getHospitalName() + " added";
			} else
				return "unexpected error"; // TODO: needs better error message
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		} catch (iTrustException e) {
			return e.getMessage();
		}
	}

	public String updateInformation(HospitalBean hosp) throws FormValidationException {
		new HospitalBeanValidator().validate(hosp);
		try {
			int rows = 0;
			return ((0 == (rows = updateHospital(hosp))) ? "Error: Hospital not found." : "Success: " + rows
					+ " row(s) updated");
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}

	private int updateHospital(HospitalBean hosp) throws DBException {
		return hospDAO.updateHospital(hosp);
	}
}
