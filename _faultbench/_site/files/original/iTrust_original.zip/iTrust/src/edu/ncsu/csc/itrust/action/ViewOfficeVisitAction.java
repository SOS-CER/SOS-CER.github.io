package edu.ncsu.csc.itrust.action;

import java.util.List;

import edu.ncsu.csc.itrust.action.base.OfficeVisitBaseAction;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.beans.PrescriptionBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class ViewOfficeVisitAction extends OfficeVisitBaseAction{
	private OfficeVisitDAO ovDAO;
	private PersonnelDAO personnelDAO;

	public ViewOfficeVisitAction(DAOFactory factory, long loggedInMID, String ovIDString) throws iTrustException {
		super(factory, String.valueOf(loggedInMID), ovIDString);
		this.personnelDAO = factory.getPersonnelDAO();
		this.ovDAO = factory.getOfficeVisitDAO();
	}

	public OfficeVisitBean getOfficeVisit() throws iTrustException {
		return ovDAO.getOfficeVisit(ovID);
	}

	public List<PrescriptionBean> getPrescriptions() throws DBException{
		return ovDAO.getPrescriptions(ovID);
	}
	
	public String getHCPName(long hcpID) throws iTrustException {
		try {
			return personnelDAO.getName(hcpID);
		} catch (DBException e) {
			e.printStackTrace();
			return "--HCP Name Not Specified--"; 
		}
	}
}
