package edu.ncsu.csc.itrust.dao;

import java.sql.Connection;
import java.sql.SQLException;

public interface IConnectionDriver {
	public Connection getConnection() throws SQLException;
}
