package edu.ncsu.csc.itrust.action;

import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.NDCodesDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.iTrustException;
import edu.ncsu.csc.itrust.beans.MedicationBean;
import edu.ncsu.csc.itrust.validate.MedicationBeanValidator;
import edu.ncsu.csc.itrust.exception.FormValidationException;

public class UpdateNDCodeListAction {
	private long performerID = 0;
	private TransactionDAO transDAO;
	private NDCodesDAO ndDAO;
	private MedicationBeanValidator validator = new MedicationBeanValidator();

	public UpdateNDCodeListAction(DAOFactory factory, long performerID) {
		this.performerID = performerID;
		ndDAO = factory.getNDCodesDAO();
		transDAO = factory.getTransactionDAO();
	}

	public String addNDCode(MedicationBean med) throws FormValidationException {
		validator.validate(med);
		try {
			if (ndDAO.addNDCode(med)) {
				transDAO.logTransaction(TransactionType.MANAGE_DRUG_CODE, performerID, 0L, "added ND code "
						+ med.getNDCode());
				return "Success: " + med.getNDCode() + " - " + med.getDescription() + " added";
			}
			else
				return "unexpected error"; // TODO: needs better error message
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		} catch (iTrustException e) {
			return e.getMessage();
		}
	}

	public String updateInformation(MedicationBean med) throws FormValidationException{
		validator.validate(med);
		try {
			int rows = updateCode(med);
			if(0 == rows) {
				return "Error: Code not found.";
			} else {
				transDAO.logTransaction(TransactionType.MANAGE_DRUG_CODE, performerID, 0L, "updated ND code "
						+ med.getNDCode());
				return "Success: " + rows + " row(s) updated";
			}
		} catch (DBException e) {
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * Medication information should already be validated
	 * 
	 * @param med
	 * @return
	 * @throws DBException
	 */
	private int updateCode(MedicationBean med) throws DBException {
		return ndDAO.updateCode(med);
	}

}
