package edu.ncsu.csc.itrust.enums;


public enum TransactionType {
	ENTER_EDIT_DEMOGRAPHICS(1, "Enter/Edit patient/personnel demographics"),
	DECLARE_HCP(2, "Declare/Undeclare an hcp"),
	ALLOW_DISALLOW_ACCESS(3, "Allow/Disallow access to patient diagnosis"),
	VIEW_ACCESS_LOG(4, "View patient's record access log"),
	VIEW_RECORDS(5, "View patient's medical records"),
	AUTHENTICATE_USER(6,"Authenticate user"),
	ENTER_EDIT_PHR(7, "Enter/Edit Personal Health Information"),
	DOCUMENT_OFFICE_VISIT(8, "Document an office visit"),
	CREATE_DISABLE_PATIENT_HCP(9, "Create or disable a patient or hcp"),
	MANAGE_DIAGNOSIS_CODE(10, "Manage ICD9CM diagnosis codes"),
	REQUEST_BIOSURVEILLANCE(11, "Request biosurveillance"),
	MANAGE_PROCEDURE_CODE(12,"Manage CPT Procedure Codes"),
	MANAGE_DRUG_CODE(13, "Manage ND Drug Codes"),
	IDENTIFY_RISK_FACTORS(14, "Identify risk factors for chronic diseases"),
	CAUSE_OF_DEATH(15, "Examine cause-of-death trends"),
	DECLARE_REPRESENTATIVE(16,"Declare Personal Health Representative"),
	PATIENT_REMINDERS(17,"Proactively determine necessary patient care"),
	MAINTAIN_HOSPITALS(18, "Maintain hospital listing"),
	VIEW_PRESCRIPTION_REPORT(19, "View prescription report"),
	VIEW_HOSPITAL_STATS(20, "View hospital statistics"),
	VIEW_COMPREHENSIVE_RECORD(21, "View comprehensive patient report");
	
	private TransactionType(int code, String description) {
		this.code = code;
		this.description = description;
	}
	private int code;
	private String description;
	
	public int getCode(){
		return code;
	}
	
	public String getDescription(){
		return description;
	}

	public static TransactionType parse(int code) {
		
		for (TransactionType type : TransactionType.values()) {
			if (type.code == code)
				return type;
		}
		throw new IllegalArgumentException("No transaction type exists for code " + code);
	}
}
