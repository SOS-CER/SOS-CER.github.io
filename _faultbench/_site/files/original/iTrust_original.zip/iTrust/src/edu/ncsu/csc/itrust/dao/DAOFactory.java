package edu.ncsu.csc.itrust.dao;

import java.sql.Connection;
import java.sql.SQLException;

import edu.ncsu.csc.itrust.dao.mysql.AccessDAO;
import edu.ncsu.csc.itrust.dao.mysql.AllergyDAO;
import edu.ncsu.csc.itrust.dao.mysql.AuthDAO;
import edu.ncsu.csc.itrust.dao.mysql.CPTCodesDAO;
import edu.ncsu.csc.itrust.dao.mysql.EpidemicDAO;
import edu.ncsu.csc.itrust.dao.mysql.FamilyDAO;
import edu.ncsu.csc.itrust.dao.mysql.HealthRecordsDAO;
import edu.ncsu.csc.itrust.dao.mysql.HospitalsDAO;
import edu.ncsu.csc.itrust.dao.mysql.ICDCodesDAO;
import edu.ncsu.csc.itrust.dao.mysql.NDCodesDAO;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.PersonnelDAO;
import edu.ncsu.csc.itrust.dao.mysql.RiskDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.dao.mysql.VisitRemindersDAO;
import edu.ncsu.csc.itrust.testutils.EvilTestConnectionDriver;
import edu.ncsu.csc.itrust.testutils.TestConnectionDriver;

public class DAOFactory {
	private static DAOFactory productionInstance = null;
	private static DAOFactory testInstance = null;
	private static DAOFactory evilTestInstance = null;
	private IConnectionDriver driver;

	public static DAOFactory getProductionInstance() {
		if (productionInstance == null)
			productionInstance = new DAOFactory(new ProductionConnectionDriver());
		return productionInstance;
	}

	public static DAOFactory getTestInstance() {
		if (testInstance == null)
			testInstance = new DAOFactory(new TestConnectionDriver());
		return testInstance;
	}
	
	public static DAOFactory getEvilTestInstance() {
		if (evilTestInstance == null)
			evilTestInstance = new DAOFactory(new EvilTestConnectionDriver());
		return evilTestInstance;
	}

	private DAOFactory(IConnectionDriver driver) {
		this.driver = driver;
	}

	public Connection getConnection() throws SQLException {
		return driver.getConnection();
	}

	public AccessDAO getAccessDAO(){
		return new AccessDAO(this);
	}

	public AllergyDAO getAllergyDAO() {
		return new AllergyDAO(this);
	}

	public AuthDAO getAuthDAO() {
		return new AuthDAO(this);
	}

	public CPTCodesDAO getCPTCodesDAO() {
		return new CPTCodesDAO(this);
	}

	public EpidemicDAO getEpidemicDAO() {
		return new EpidemicDAO(this);
	}

	public FamilyDAO getFamilyDAO() {
		return new FamilyDAO(this);
	}

	public HealthRecordsDAO getHealthRecordsDAO() {
		return new HealthRecordsDAO(this);
	}

	public HospitalsDAO getHospitalsDAO() {
		return new HospitalsDAO(this);
	}

	public ICDCodesDAO getICDCodesDAO() {
		return new ICDCodesDAO(this);
	}

	public NDCodesDAO getNDCodesDAO() {
		return new NDCodesDAO(this);
	}

	public OfficeVisitDAO getOfficeVisitDAO() {
		return new OfficeVisitDAO(this);
	}

	public PatientDAO getPatientDAO() {
		return new PatientDAO(this);
	}

	public PersonnelDAO getPersonnelDAO() {
		return new PersonnelDAO(this);
	}

	public RiskDAO getRiskDAO(){
		return new RiskDAO(this);
	}

	public TransactionDAO getTransactionDAO() {
		return new TransactionDAO(this);
	}
	
	public VisitRemindersDAO getVisitRemindersDAO() {
		return new VisitRemindersDAO(this);
	}
}
