package edu.ncsu.csc.itrust.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.ncsu.csc.itrust.ParameterUtil;
import edu.ncsu.csc.itrust.action.base.PatientBaseAction;
import edu.ncsu.csc.itrust.beans.OfficeVisitBean;
import edu.ncsu.csc.itrust.beans.PatientBean;
import edu.ncsu.csc.itrust.beans.PrescriptionReportBean;
import edu.ncsu.csc.itrust.dao.DAOFactory;
import edu.ncsu.csc.itrust.dao.mysql.OfficeVisitDAO;
import edu.ncsu.csc.itrust.dao.mysql.PatientDAO;
import edu.ncsu.csc.itrust.dao.mysql.TransactionDAO;
import edu.ncsu.csc.itrust.enums.TransactionType;
import edu.ncsu.csc.itrust.exception.DBException;
import edu.ncsu.csc.itrust.exception.FormValidationException;
import edu.ncsu.csc.itrust.exception.NoHealthRecordsException;
import edu.ncsu.csc.itrust.exception.iTrustException;

public class PrescriptionReportAction extends PatientBaseAction {
	private OfficeVisitDAO ovDAO;
	private TransactionDAO transDAO;
	private PatientDAO patientDAO;
	private long loggedInMID;

	public PrescriptionReportAction(DAOFactory factory, long loggedInMID, String pidString) throws iTrustException,
			DBException, NoHealthRecordsException {
		super(factory, pidString);
		this.transDAO = factory.getTransactionDAO();
		this.ovDAO = factory.getOfficeVisitDAO();
		this.patientDAO = factory.getPatientDAO();
		this.loggedInMID = loggedInMID;
	}

	public List<OfficeVisitBean> getAllOfficeVisits() throws DBException {
		return ovDAO.getAllOfficeVisits(pid);
	}

	// suppressing warnings because JSP doesn't have a generic for request.getParameterMap()
	@SuppressWarnings("unchecked")
	public List<PrescriptionReportBean> getPrescriptionReports(Map params, List<OfficeVisitBean> officeVisits)
			throws DBException {
		HashMap<String, String> myParams = ParameterUtil.convertMap(params);
		List<Long> ovIDs = new ArrayList<Long>();
		for (int i = 0; i < officeVisits.size(); i++) {
			try {
				if (params.get("ovOff" + i) != null) {
					int offset = Integer.valueOf(myParams.get("ovOff" + i));
					ovIDs.add(officeVisits.get(offset).getVisitID());
				}
			} catch (NumberFormatException e) {
				// just skip it
			}
		}
		transDAO.logTransaction(TransactionType.VIEW_PRESCRIPTION_REPORT, loggedInMID, pid, "Getting reports for office visits " + ovIDs.toString());
		if (ovIDs.size() == 0)
			return new ArrayList<PrescriptionReportBean>();
		
		return ovDAO.getPrescriptionReports(ovIDs, pid);
	}

	public PatientBean getPatient() throws DBException {
		return patientDAO.getPatient(pid);
	}

	// suppressing warnings because JSP doesn't have a generic for request.getParameterMap()
	@SuppressWarnings("unchecked")
	public String getQueryString(Map paramMap, List<OfficeVisitBean> officeVisits) throws FormValidationException,
			DBException {
		HashMap<String, String> myParams = ParameterUtil.convertMap(paramMap);
		List<Integer> ovOffsets = checkOfficeVisits(myParams, officeVisits);
		String queryString = buildQueryString(ovOffsets);
		return queryString;
	}

	private ArrayList<Integer> checkOfficeVisits(HashMap<String, String> myParams, List<OfficeVisitBean> officeVisits) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < officeVisits.size(); i++) {
			if ("on".equals(myParams.get("ov" + i)))
				list.add(i);
		}
		return list;
	}

	private String buildQueryString(List<Integer> ovOffsets) {
		int n = ovOffsets.size();
		if (n == 0)
			return "";
		String str = "&n=" + n;
		for (int i = 0; i < ovOffsets.size(); i++) {
			str += "&ovOff" + i + "=" + ovOffsets.get(i);
		}
		return str;
	}
}
