import java.io.*;
import java.util.*;
import java.util.zip.*;

public class Test {
  static void produceGZIPFromString() {
    String strText = "Foobar\nblah\n";

    try {
      PrintStream prs = new PrintStream(new GZIPOutputStream(new FileOutputStream("etext.gz")));
      prs.print(strText);
      prs.close();
    } catch (IOException iox) {
      System.out.println("IO Exception: " + iox);
      iox.printStackTrace();
    }
  }

  static void displayFirstFileFromZIP(String strFileName) {
    try {
      ZipInputStream zis = new ZipInputStream(new FileInputStream(strFileName));
      ZipEntry zen = zis.getNextEntry();
						BufferedReader reader =
								new BufferedReader(new InputStreamReader(zis));
						
						int icLineCount = 0;
						String strCurrentLine;
						while ((strCurrentLine = reader.readLine()) != null) {
								icLineCount++;
						}
      System.out.println("Line count="+icLineCount);
    } catch (IOException iox) {
      System.out.println("IO Exception: " + iox);
      iox.printStackTrace();
    }
  }

  static void testGutindexParsing() {
    Map mapTitles = TextList.getTitleMap();

    Iterator iterTitle = mapTitles.keySet().iterator();
    while (iterTitle.hasNext()) {
      String strTitle = (String) iterTitle.next();
      System.out.println("title/author: " + strTitle + "/" +
                         mapTitles.get(strTitle));
    }
  }

  public static void main(String[] args) {
    //produceGZIPFromString();
    //displayFirstFileFromZIP(args[0]);
    testGutindexParsing();
  }
}
