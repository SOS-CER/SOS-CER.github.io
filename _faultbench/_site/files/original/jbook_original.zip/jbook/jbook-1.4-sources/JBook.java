/*
 * JBook.java - Top-level JBook Frame
 * Copyright (C) 2001 Andrew Oliver
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;

public class JBook extends JFrame {
  private Action actionToggleScrolling;
  private Action actionScrollFaster;
  private Action actionScrollSlower;
  private Action actionToggleFullScreen;
  private final Display display;
  protected boolean blnFullScreen = false;
  protected JMenuBar menuBar;
  protected JMenu menu;
  protected JScrollBar scrollbar;
  protected JToolBar toolBar;
  protected MouseListener displayFocusSetter;

  private void addAction(Action action, String strDescription,
                         int event, String strKeystroke) {
    JButton button = toolBar.add(action);
    button.setToolTipText(strDescription);
    button.addMouseListener(displayFocusSetter);
    JMenuItem menuItem = menu.add(action);
    menuItem.setMnemonic(event);
    menuItem.setAccelerator(KeyStroke.getKeyStroke(strKeystroke));
  }

  private void exitAction() {
    Rectangle rectWindow = this.getBounds();
    State state = State.getState();
    state.setX(rectWindow.x);
    state.setY(rectWindow.y);
    state.setWidth(rectWindow.width);
    state.setHeight(rectWindow.height);

    display.exit();
  }
  
  public JBook() {
    super("JBook");

    // Setup state
    State state = State.getState();
    state.load();

    // Setup layout for components
    getContentPane().setLayout(new BorderLayout());

    // Add scrollbar
    scrollbar = new JScrollBar(JScrollBar.VERTICAL, 0, 10, 0, 99);
    getContentPane().add(scrollbar, BorderLayout.EAST);

    // Add text component
    display = new Display(state.getLastDocName(), state, state.getFont(), scrollbar.getModel());
    getContentPane().add(display,
                         BorderLayout.CENTER);

    // Handle exit request
    addWindowListener(new WindowAdapter() {
        public void windowClosing(WindowEvent e) {
   exitAction();
        }
      });

    // Setup Menu and Toolbar
    menuBar = new JMenuBar();
    setJMenuBar(menuBar);
    toolBar = new JToolBar();
    getContentPane().add(toolBar, BorderLayout.NORTH);

    menu = new JMenu("Book");
    menu.setMnemonic(KeyEvent.VK_B);
    menuBar.add(menu);

    JButton button;
    JMenuItem menuItem;

    displayFocusSetter = new MouseAdapter() {
        public void mouseReleased(MouseEvent e) {
          display.requestFocus();
        }
      };

    // Open allows the user to pick a new book to read
    Action action = new
      AbstractAction("Open", getIcon("Open24.gif")) {
        public void actionPerformed(ActionEvent e) {
          display.changeBook();
        }
      };
    addAction(action, "Open a different book", KeyEvent.VK_O, "control O");

    // Select remote book
    action = new
      AbstractAction("Open Remote Book", getIcon("Home24.gif")) {
        public void actionPerformed(ActionEvent e) {
          display.getRemoteBook();
        }
      };
    addAction(action, "Download and read a new Project Gutenberg book",
              KeyEvent.VK_G, "control G");

    menu.addSeparator();
    toolBar.addSeparator();

    // Exit
    action = new
      AbstractAction("Exit JBook", getIcon("Stop24.gif")) {
        public void actionPerformed(ActionEvent e) {
   exitAction();
        }
      };
    menuItem = menu.add(action);
    menuItem.setMnemonic(KeyEvent.VK_X);
    menuItem.setAccelerator(KeyStroke.getKeyStroke("control X"));

    toolBar.addSeparator();

    menu = new JMenu("Settings");
    menu.setMnemonic(KeyEvent.VK_S);
    menuBar.add(menu);

    // Turns auto-scrolling on and off
    actionToggleScrolling = new
      AbstractAction("Toggle AutoScrolling", getIcon("Play24.gif")) {
        public void actionPerformed(ActionEvent e) {
          boolean blnNewScrollState = display.toggleScrolling();
          setActionsFromScrollingState(blnNewScrollState);
        }
      };
    addAction(actionToggleScrolling, "Turn AutoScrolling on or off", KeyEvent.VK_A, "control A");

    // Makes auto-scrolling faster
    actionScrollFaster = new
      AbstractAction("Scroll Faster", getIcon("Up24.gif")) {
        public void actionPerformed(ActionEvent e) {
          display.scrollFaster();
        }
      };
    addAction(actionScrollFaster, "Make text scroll upward faster", KeyEvent.VK_I, "control I");
    actionScrollFaster.setEnabled(false);

    // Makes auto-scrolling slower
    actionScrollSlower = new
      AbstractAction("Scroll Slower", getIcon("Down24.gif")) {
        public void actionPerformed(ActionEvent e) {
          display.scrollSlower();
        }
      };
    addAction(actionScrollSlower, "Make text scroll upward slower", KeyEvent.VK_D, "control D");
    actionScrollSlower.setEnabled(false);

    menu.addSeparator();
    toolBar.addSeparator();

    // Select font
    action = new
      AbstractAction("Choose Font", getIcon("Italic24.gif")) {
        public void actionPerformed(ActionEvent e) {
          display.changeFont();
        }
      };
    addAction(action, "Select font for displaying the book", KeyEvent.VK_F, "control F");

    menu.addSeparator();
    toolBar.addSeparator();

    // Turns full screen mode on and off
    actionToggleFullScreen = new
      AbstractAction("Toggle Full Screen Mode", getIcon("ZoomIn24.gif")) {
        public void actionPerformed(ActionEvent e) {
          toggleFullScreen();
          setActionsFromFullScreenState(blnFullScreen);
        }
      };
    addAction(actionToggleFullScreen, "Turn Full Screen Mode on or off", KeyEvent.VK_S, "control S");

    menu.addSeparator();
    toolBar.addSeparator();

    // Let user pick text color
    action = new
      AbstractAction("Select Text Color...", getIcon("Bold24.gif")) {
        public void actionPerformed(ActionEvent e) {
          // Show ColorChooser
          Color color = JColorChooser.showDialog(display, "Pick the text color", display.getTextColor());
          
          // Set new color
          if (color != null) {
            display.setTextColor(color);
          }
        }
      };
    addAction(action, "Show color chooser and set text color from selection", KeyEvent.VK_C, "control C");

    // Let user pick background color
    action = new
      AbstractAction("Select Background Color...", getIcon("Properties24.gif")) {
        public void actionPerformed(ActionEvent e) {
          // Show ColorChooser
          Color color = JColorChooser.showDialog(display, "Pick the background color", display.getBackgroundColor());
          
          // Set new color
          if (color != null) {
            display.setBackgroundColor(color);
          }
        }
      };
    addAction(action, "Show color chooser and set background color from selection", KeyEvent.VK_B, "control B");
  }

  /**
   * Sets actions' enabled states and icons based on scrolling state
   */
  private void setActionsFromScrollingState(boolean blnScrollState) {
    // Set enable/disable icon based on state
    if (blnScrollState) {
      actionToggleScrolling.putValue(Action.SMALL_ICON, getIcon("Pause24.gif"));
    } else {
      actionToggleScrolling.putValue(Action.SMALL_ICON, getIcon("Play24.gif"));
    }

    // Enable rate icons if scrolling
    if (blnScrollState) {
      actionScrollFaster.setEnabled(true);
      actionScrollSlower.setEnabled(true);
    } else {
      actionScrollFaster.setEnabled(false);
      actionScrollSlower.setEnabled(false);
    }
  }

  /**
   * Sets actions' enabled states and icons based on full screen state
   */
  private void setActionsFromFullScreenState(boolean blnFullScreenState) {
    // Set icon based on state
    if (blnFullScreenState) {
      actionToggleFullScreen.putValue(Action.SMALL_ICON, getIcon("ZoomOut24.gif"));
    } else {
      actionToggleFullScreen.putValue(Action.SMALL_ICON, getIcon("ZoomIn24.gif"));
    }
  }

  private static final String strPathToIcons =
    "/images/";

  /**
   * Returns an icon object for a specified image.  Works for iamges
   * on the filesystem or in JAR files.
   *
   * @param strRelativePath The image name relative to the images
   * directory
   * @return the icon, or null if the icon could not be found
   */
  public ImageIcon getIcon(String strRelativePath) {
    String strAbsoluteImageURL = strPathToIcons + strRelativePath;
        
    ImageIcon icon = null;
        
    URL urlResource =
      JBook.class.getResource(strAbsoluteImageURL);
        
    if (urlResource != null) {
      icon = new
        ImageIcon(Toolkit.getDefaultToolkit().getImage(urlResource));
    }
        
    return icon;
  }

  public void toggleFullScreen() {
    if (blnFullScreen) {
      //setJMenuBar(menuBar);
      getContentPane().add(toolBar, BorderLayout.NORTH);
      getContentPane().add(scrollbar, BorderLayout.EAST);
    } else {
      //setJMenuBar(null);
      getContentPane().remove(toolBar);
      getContentPane().remove(scrollbar);
    }
    validate();
    blnFullScreen = !blnFullScreen;
  }
    
  public static void main (String[] args) {
    // Create top-level window
    JBook jbook = new JBook();

    // Get saved defaults
    int inset = 0;
    Dimension screenSize = 
      Toolkit.getDefaultToolkit().getScreenSize();
    int iX = State.getState().getX();
    int iY = State.getState().getY();
    int iWidth = State.getState().getWidth();
    if (iWidth == -1) {
      iWidth = screenSize.width - inset*2;
    }
    int iHeight = State.getState().getHeight();
    if (iHeight == -1) {
      iHeight = screenSize.height - inset*2;
    }


    // Setup initial size
    jbook.setBounds(iX, iY, iWidth, iHeight);

    // Show window
    jbook.setVisible(true);
  }
}
