/*
 * Document.java - Contains an entire line-oriented document
 * Copyright (C) 2001-7 Andrew Oliver
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.io.*;
import java.util.*;
import java.util.zip.*;

/**
 * Allows access to a documents lines
 */
public class Document {
  List listLines;
  String strFileName;
  int iiLineAfterHeader = -1;
    
  /**
   * Reads a document from a file.
   */
  public Document(String strFileName) {
    this.strFileName = strFileName;
    listLines = new ArrayList(10000);

    try {
      if (strFileName.endsWith(".zip")) {
        parseZipText(strFileName);
      } else if (strFileName.endsWith(".txt")) {
        parsePlainText(strFileName);
      } else if (strFileName.endsWith(".gz")) {
        parseGzipText(strFileName);
      } else {
        // Try appending .gz, then .txt, then .zip
        try {
          parseGzipText(strFileName+".gz");
        } catch (IOException iox2) {
          try {
            parsePlainText(strFileName+".txt");
          } catch (IOException iox3) {
            parseZipText(strFileName+".zip");
          }
        }
      }
    } catch (Exception xpt) {
      System.out.println("Error reading file " + strFileName);
    }
  }

  private void parseFromReader(BufferedReader reader) throws IOException {
    int icLineCount = 0;
    String strCurrentLine;
    while ((strCurrentLine = reader.readLine()) != null) {
      icLineCount++;
      listLines.add(strCurrentLine);
      if (strCurrentLine.startsWith("*END*THE SMALL PRINT") ||
          strCurrentLine.startsWith("*END THE SMALL PRINT")) {
        iiLineAfterHeader = icLineCount;
      }
    }
  }

  private void parseZipText(String strFileName) throws IOException {
    ZipInputStream zis = new ZipInputStream(new FileInputStream(strFileName));
    ZipEntry zen = zis.getNextEntry();
    BufferedReader reader =
      new BufferedReader(new InputStreamReader(zis));
    
    parseFromReader(reader);
  }
  
  private void parsePlainText(String strFileName) throws IOException {
    BufferedReader reader =
      new BufferedReader(new FileReader(strFileName));
    
    parseFromReader(reader);
  }
  
  private void parseGzipText(String strFileName) throws IOException {
    BufferedReader reader =
      new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(strFileName))));
    
    parseFromReader(reader);
  }
  
  public String getName() {
    return strFileName;
  }

  public String getLine(int iiLine) {
    if ((iiLine < getLineCount()) && (iiLine >= 0))
      return (String) listLines.get(iiLine);
    else
      return "";
  }

  public int getLineAfterHeader() {
    return iiLineAfterHeader;
  }
    
  public int getLineCount() {
    return listLines.size();
  }
}
