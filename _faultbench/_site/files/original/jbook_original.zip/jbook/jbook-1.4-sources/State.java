/*
 * State.java - Persistent store of bookmarks and more
 * Copyright (C) 2001 Andrew Oliver
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.Color;
import java.io.*;
import java.util.*;

public class State {
  Color colorBackground = Color.black;
  Color colorText = Color.yellow;
  int iX = -1;
  int iY = -1;
  int iWidth = -1;
  int iHeight = -1;
  Properties props = new Properties();
  static State state;

  public static State getState() {
    if (state == null) {
      state = new State();
    }
    return state;
  }

  private int getIntProperty(String strName, int iDefault) {
    String strValue = (String) props.getProperty(strName);
    if (strValue != null) {
      return Integer.parseInt(strValue);
    } else {
      return iDefault;
    }
  }

  private void setIntProperty(String strName, int intValue) {
    props.setProperty(strName, Integer.toString(intValue));
  }

  public int getPosition(String strName) {
    return getIntProperty(strName, 0);
  }

  public void setPosition(String strName, int intPosition) {
    setIntProperty(strName, intPosition);
  }

  public String getFont() {
    String strFont = (String) props.getProperty("Font");
    if (strFont != null) {
      return strFont;
    } else {
      return "Courier";
    }
  }

  public void setFont(String strFont) {
    props.setProperty("Font", strFont);
  }

  public int getScrollDelay() {
    String strScrollDelay = (String) props.getProperty("ScrollDelay");
    if (strScrollDelay != null) {
      return Integer.parseInt(strScrollDelay);
    } else {
      return 35;
    }
  }

  public void setScrollDelay(int intScrollDelay) {
    props.setProperty("ScrollDelay", Integer.toString(intScrollDelay));
  }

  public String getLastDocName() {
    String strLastDocName = (String) props.getProperty("LastDocName");
    if (strLastDocName != null) {
      return strLastDocName;
    } else {
      return "hyde10.txt";
    }
  }

  public void setLastDocName(String strLastDocName) {
    props.setProperty("LastDocName", strLastDocName);
  }

  private void setColor(String strName, Color color) {
    String strColor = color.getRed() + "," +
      color.getGreen() + "," +
      color.getBlue();
    props.setProperty(strName, strColor);
  }

  private Color getColor(String strName) {
    String strColor = props.getProperty(strName);
    if (strColor == null) {
      if (strName == "TextColor") {
        return Color.white;
      } else {
        return Color.black;
      }
    }
    StringTokenizer stkColor = new StringTokenizer(strColor, ",");
    int iRed = Integer.parseInt(stkColor.nextToken());
    int iGreen = Integer.parseInt(stkColor.nextToken());
    int iBlue = Integer.parseInt(stkColor.nextToken());
    return new Color(iRed, iGreen, iBlue);
  }

  public void setBackgroundColor(Color color) {
    setColor("BackgroundColor", color);
  }

  public void setTextColor(Color color) { 
    setColor("TextColor", color);
  }

  public Color getBackgroundColor() {
    return getColor("BackgroundColor");
  }

  public Color getTextColor() {
    return getColor("TextColor");
  }

  public void setX(int iX) {
    setIntProperty("x", iX);
  }

  public int getX() {
    return getIntProperty("x", 0);
  }

  public void setY(int iY) {
    setIntProperty("y", iY);
  }

  public int getY() {
    return getIntProperty("y", 0);
  }

  public void setWidth(int iWidth) {
    setIntProperty("width", iWidth);
  }

  public int getWidth() {
    return getIntProperty("width", -1);
  }

  public void setHeight(int iHeight) {
    setIntProperty("height", iHeight);
  }

  public int getHeight() {
    return getIntProperty("height", -1);
  }

  public void save() {
    try {
      FileOutputStream fos = new FileOutputStream("jbook.ini");
      props.store(fos, "books");
    } catch (Exception xpt) {
      System.out.println("Error saving preferences: " + xpt);
    }
  }

  public void load() {
    try {
      FileInputStream fis = new FileInputStream("jbook.ini");
      props.load(fis);
    } catch (Exception xpt) {
      //System.out.println("Error reading preferences: " + xpt);
    }
  }
}
