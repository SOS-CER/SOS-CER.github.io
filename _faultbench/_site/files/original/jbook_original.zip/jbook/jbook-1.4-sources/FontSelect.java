/*
 * FontSelect.java - Font selection dialog and state
 * Copyright (C) 2001-7 Andrew Oliver
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

public class FontSelect {
  java.util.List listFontNames = new LinkedList();
  String strOriginalFont;
    
  public FontSelect(Display displayNew) {
    // Setup dialog
    JDialog dialog = new FontDialog(displayNew, displayNew.getTopLevelAncestor());
    dialog.pack();
    dialog.setLocationRelativeTo(displayNew);
    dialog.show();
  }

  private class FontDialog extends JDialog {
    public FontDialog(Display displayNew, Container container) {
      super((Frame) container, "Use which font?", false);
      final Display display = displayNew;

      saveOriginalFont();
      
      // Setup list of files
      setupFontList();
      
      // Setup file list display
      final JList list = new JList(new Vector(listFontNames));
      list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      list.setSelectedValue(State.getState().getFont(), false);
      JScrollPane scroller = new JScrollPane(list);
      
      // Setup listener to change font on demand
      list.addListSelectionListener(new ListSelectionListener() {
          public void valueChanged(ListSelectionEvent lse) {
            String strFont = (String) list.getSelectedValue();
            display.setFontName(strFont);
            display.repaint();
          }
        });

      getContentPane().setLayout(new BorderLayout());
      getContentPane().add(scroller, BorderLayout.NORTH);

      JButton buttonOK = new JButton("OK");
      getContentPane().add(buttonOK, BorderLayout.WEST);
      buttonOK.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent ace) {
            dispose();
          }
        });
      JButton buttonCancel = new JButton("Cancel");
      getContentPane().add(buttonCancel, BorderLayout.EAST);
      buttonCancel.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent ace) {
            restoreOriginalFont(display);
            dispose();
          }
        });
    }
  }

  private void saveOriginalFont() {
    strOriginalFont = State.getState().getFont();
  }

  private void restoreOriginalFont(Display display) {
    display.setFontName(strOriginalFont);
    display.repaint();
  }
  
  public void setupFontList() {
    GraphicsEnvironment ge =
      GraphicsEnvironment.getLocalGraphicsEnvironment();
    String[] fontNames = ge.getAvailableFontFamilyNames();
    for (int i = 0; i < fontNames.length; i++) {
      if (fontNames[i].equals("") == false) {
                listFontNames.add(fontNames[i]);
      }
    }
  }
}
