/*
 * LocalTextSelect.java - EBook selection dialog and state
 * Copyright (C) 2001 Andrew Oliver
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.io.*;
import java.util.*;
import java.util.zip.*;
import javax.swing.*;

public class LocalTextSelect {
  public static int NOT_FINISHED = 0;
  public static int SELECTION_MADE = 1;
  public static int CANCELED = 2;
  public static int NO_SELECTIONS_AVAILABLE = 3;

  int intStatus = NOT_FINISHED;
  List listTitles = new LinkedList();
  Map mapFilenameByTitle;
  String strFileName = null;
    
  public LocalTextSelect() {
    intStatus = NOT_FINISHED;
                                
    // Setup list of files
    setupFileList();

    if (listTitles.size() > 0) {
      // Setup file list display
      TextChooser textchooser = new TextChooser(listTitles);                                          
                                                
      if (textchooser.getResult() == JOptionPane.OK_OPTION) {
        String strTitle = textchooser.getTitle();
        strFileName = (String) mapFilenameByTitle.get(strTitle);
        intStatus = SELECTION_MADE;
      } else { // Canceled
        intStatus = CANCELED;
      }
    } else { // no files
      intStatus = NO_SELECTIONS_AVAILABLE;
    }
  }

  public int getStatus() {
    return intStatus;
  }

  public String getSelection() {
    return strFileName;
  }

  public String getTitle(File file) {
    // Try getting title from map
    String strTitle = 
      (String) TextList.getTitleMap().get(file.getName());
    if (strTitle == null) {
      try {
        // Next try getting from file
        BufferedReader reader = null;
        if (file.getName().endsWith(".txt")) {  
          reader = new BufferedReader(new FileReader(file));
        } else if (file.getName().endsWith(".gz")) {  
          //System.out.println("gz file " + file.getName());
          reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(file))));
        }

        if (null != reader) {
          int iLine = 0;
          String strAuthor = null;
          while ((iLine < 100) && (strTitle == null)) {
            String strLine = reader.readLine();
            iLine++;
            if ((null != strLine) && strLine.startsWith("Title: ")) {
              strTitle = strLine.substring(7).trim();
              while ((iLine < 200) && (strAuthor == null)) {
                strLine = reader.readLine();
                iLine++;
                if (strLine.startsWith("Author: ")) {
                  strAuthor = strLine.substring(8).trim();
                  strTitle += ", by " + strAuthor;
                }
                  
              }
            }
          }
        }
      } catch (IOException iox) {
        System.out.println("Exception: " + iox);
      }
      if (strTitle == null) {
        // Finally just use the filename
        strTitle = file.getName();
      }
    }
    return strTitle;
  }

  public void setupFileList() {
    // Get list of files
    File[] afiles = (new File(".")).listFiles();
                                
    // Prepare map from title to filename
    mapFilenameByTitle = new HashMap();

    // for each file
    for (int i = 0; i < afiles.length; i++) {
      if (afiles[i].getName().endsWith(".txt") ||
          afiles[i].getName().endsWith(".gz")) {
        String strFilename = afiles[i].getName();
        String strTitle = getTitle(afiles[i]);
        listTitles.add(strTitle);
        mapFilenameByTitle.put(strTitle, strFilename);
      }
    }

    Collections.sort(listTitles, new TitleComparator());
  }
}
