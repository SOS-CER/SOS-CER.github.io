import java.io.*;
import java.util.zip.*;

/** Test ZipInputStream handling of ZIP files */
public class TestZip {
  public static void main(String[] args) {
    try {
      ZipInputStream zis = new ZipInputStream(new FileInputStream("aesop10a.zip"));
      ZipEntry zen = zis.getNextEntry();
      BufferedReader reader =
        new BufferedReader(new InputStreamReader(zis));

      // Exception occurs on the next line
      reader.readLine();
    } catch (IOException iox) {
      System.out.println("IO Exception: " + iox);
      iox.printStackTrace();
    }
  }
}
