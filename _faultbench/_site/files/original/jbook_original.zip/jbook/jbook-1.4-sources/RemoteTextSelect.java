/*
 * RemoteTextSelect.java - EBook download dialog and state
 * Copyright (C) 2001 Andrew Oliver
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;
import javax.swing.*;

public class RemoteTextSelect {
		Map mapURLByTitle;
		String strFileName = null;
    
		public RemoteTextSelect() {
				// Setup list of files
				setupFileList();
				
				// Setup file list display
				List listTitles = new LinkedList(mapURLByTitle.keySet());
				Collections.sort(listTitles, new TitleComparator());
				
				TextChooser textchooser = new TextChooser(listTitles);						
						
				if (textchooser.getResult() == JOptionPane.OK_OPTION) {
						String strSelection = textchooser.getTitle();
						
						// Get URL
						String strURL = (String) mapURLByTitle.get(strSelection) + ".txt";

						// Set filename
						strFileName = TextList.fileNameFromURL((String) mapURLByTitle.get(strSelection)) + ".gz";

						try {
								// Open destination file
								GZIPOutputStream gos = 
          new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(strFileName, false)));

								// Retrieve file
								URL url = new URL(strURL);

								// GZIP files
								//InputStream is = new GZIPInputStream(url.openStream());

								// ZIP files
								//ZipInputStream is = new ZipInputStream(url.openStream());
								//is.getNextEntry();

								// Plain text files
								InputStream is = url.openStream();

								BufferedInputStream bis = new BufferedInputStream(is);
						
								// Read chunks until done, writing to file
								int iBufSize = 8192;
								byte[] abytBuffer = new byte[iBufSize];
								int icBytesRead;
								while ((icBytesRead = bis.read(abytBuffer, 0, iBufSize)) > -1) {
										gos.write(abytBuffer, 0, icBytesRead);
								}

        gos.close();
						} catch (Exception xpt) {
								String strMessage =
										"Unable to download file " + strFileName + " from Project Gutenberg: " + xpt;
								System.out.println(strMessage);
								JOptionPane.showMessageDialog(null, strMessage, "Remote Text Could Not Be Retrieved", 
																																						JOptionPane.ERROR_MESSAGE);

								// Remove the file
								File file = new File(strFileName);
								file.delete();
								strFileName = null;
						}
				}
		}

		public String getSelection() {
				return strFileName;
		}

		private void setupFileList() {
				mapURLByTitle = new HashMap();

				Map mapRemote = TextList.getURLMap();
				
				// For every remote file, add to list if not available locally
				Iterator iter = mapRemote.keySet().iterator();
				while (iter.hasNext()) {
						String strTitle = (String) iter.next();
						String strURL = (String) mapRemote.get(strTitle);

						boolean blnExistsLocally = (new File(TextList.fileNameFromURL(strURL))).exists();

						if (!blnExistsLocally) {
								mapURLByTitle.put(strTitle, strURL);
						}
				}
		}
}
