package net.sourceforge.importscrubber;

import java.io.*;
import java.util.Properties;

public class Settings
{
    private String _appName;
    private Properties _props;

    public Settings(String appName)
    {
        _appName = appName;
        File homeDir = new File(System.getProperty("user.home"));
        if(!homeDir.exists()) {
            homeDir.mkdirs();
        }
        File appDir = new File(System.getProperty("user.home"), _appName);
        if(!appDir.exists()) {
            appDir.mkdir();
        }
        load();
    }

    public void load()
    {
        _props = new Properties();
        
        BufferedInputStream in = null;
        try {
        	File appDir = new File(System.getProperty("user.home"), _appName);
        	in = new BufferedInputStream(new FileInputStream(new File(appDir, _appName)));
            _props.load(in);
            in.close();
        } catch(FileNotFoundException exception) {
        	try {
        		in.close();
        	} catch (IOException e) { }
        } catch (IOException e) {
        	try {
        		in.close();
        	} catch (IOException e2) { }
        }
    }

    public void put(String pKey, String pValue)
    {
        _props.put(pKey, pValue);
    }

    public String get
        (String pKey)
    {
        return _props.getProperty(pKey);
    }

    public void save() throws IOException
    {
        File appDir = new File(System.getProperty("user.home"), _appName);
        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(new File(appDir, _appName)));
        try {
	        _props.store(out, "Importscrubber");
	        out.close();
        } catch (IOException e) {
        	out.close();
        	throw new IOException(e.getMessage());
        }
    }

}
