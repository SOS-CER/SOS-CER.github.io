-- phpMyAdmin SQL Dump
-- version 2.8.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 30, 2006 at 01:25 PM
-- Server version: 5.0.22
-- PHP Version: 5.1.4
-- 
-- Database: 'paireval'
-- 

USE paireval;

-- --------------------------------------------------------

-- 
-- Table structure for table 'assignment'
-- 

CREATE TABLE assignment (
  number varchar(10) NOT NULL default '',
  course varchar(20) NOT NULL default '',
  start_date date default NULL,
  end_date date default NULL,
  group_number int(4) default NULL,
  reviews int(2) default NULL,
  PRIMARY KEY  (number,course)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'collaboration'
-- 

CREATE TABLE collaboration (
  `user` varchar(20) NOT NULL default '0',
  number int(2) NOT NULL default '0',
  responsibility int(2) default '0',
  organized int(2) default '0',
  advice int(2) default '0',
  procrastinate int(2) default '0',
  savestime int(2) default '0',
  prefertopair int(2) default '0',
  largeprojects int(2) default '0',
  sololearning int(2) default '0',
  codingerrors int(2) default '0',
  preferalone int(2) default '0',
  newideas int(2) default '0',
  badpartner int(2) default '0',
  logicerrors int(2) default '0',
  commute int(2) default '0',
  plans mediumtext,
  major varchar(100) default NULL,
  PRIMARY KEY  (`user`,number)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'course'
-- 

CREATE TABLE course (
  cnum varchar(20) NOT NULL default '',
  `name` varchar(70) default NULL,
  owner varchar(20) default NULL,
  PRIMARY KEY  (cnum)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'eval'
-- 

CREATE TABLE eval (
  course varchar(20) NOT NULL default '',
  assignment varchar(10) NOT NULL default '',
  `user` varchar(20) NOT NULL default '',
  partner varchar(20) NOT NULL default '',
  q1 int(2) default NULL,
  q2 int(2) default NULL,
  q3 int(2) default NULL,
  q4 int(2) default NULL,
  q5 int(2) default NULL,
  overall int(2) default NULL,
  `comment` varchar(255) default NULL,
  q6 int(2) default NULL,
  q7 int(2) default NULL,
  number int(2) NOT NULL default '0',
  PRIMARY KEY  (course,assignment,`user`,partner,number)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'grouping'
-- 

CREATE TABLE grouping (
  course varchar(20) NOT NULL default '',
  assignment varchar(10) NOT NULL default '',
  group_number varchar(10) default NULL,
  `user` varchar(20) NOT NULL default '',
  PRIMARY KEY  (course,assignment,`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'lstyles'
-- 

CREATE TABLE lstyles (
  `user` varchar(20) NOT NULL default '',
  ref int(3) default NULL,
  inte int(3) default NULL,
  verb int(3) default NULL,
  glo int(3) default NULL,
  PRIMARY KEY  (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'myers_briggs'
-- 

CREATE TABLE myers_briggs (
  `user` varchar(20) NOT NULL default '',
  ei varchar(20) default NULL,
  si varchar(20) default NULL,
  tf varchar(20) default NULL,
  jp varchar(20) default NULL,
  eiv int(3) default NULL,
  siv int(3) default NULL,
  tfv int(3) default NULL,
  jpv int(3) default NULL,
  PRIMARY KEY  (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'pref'
-- 

CREATE TABLE pref (
  `user` varchar(20) NOT NULL default '',
  x1 varchar(20) default NULL,
  x2 varchar(20) default NULL,
  x3 varchar(20) default NULL,
  course varchar(20) NOT NULL default '',
  PRIMARY KEY  (course,`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'registration'
-- 

CREATE TABLE registration (
  `user` varchar(20) NOT NULL default '',
  course varchar(20) NOT NULL default '',
  section_name varchar(20) NOT NULL default '',
  PRIMARY KEY  (`user`,course,section_name)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'role'
-- 

CREATE TABLE role (
  course varchar(20) NOT NULL default '',
  `user` varchar(20) NOT NULL default '',
  role_id int(4) default NULL,
  PRIMARY KEY  (course,`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'section'
-- 

CREATE TABLE section (
  `name` varchar(20) NOT NULL default '',
  course varchar(20) NOT NULL default '',
  ta varchar(20) default NULL,
  PRIMARY KEY  (`name`,course)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------





-- 
-- Table structure for table 'selfeval'
-- 

CREATE TABLE selfeval (
  `user` varchar(20) NOT NULL default '',
  ethic int(2) default NULL,
  esteem int(2) default NULL,
  timemng int(2) default NULL,
  speed int(2) default NULL,
  problemsolving int(2) default NULL,
  interest int(2) default NULL,
  coding int(2) default NULL,
  experience int(2) NOT NULL default '0',
  helping int(2) NOT NULL default '0',
  testing int(2) NOT NULL default '0',
  roadblock int(2) NOT NULL default '0',
  impression mediumtext,
  PRIMARY KEY  (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Table structure for table 'usr'
-- 

CREATE TABLE usr (
  id varchar(20) NOT NULL default '',
  first_name varchar(50) default NULL,
  last_name varchar(50) default NULL,
  `password` varchar(32) default NULL,
  email varchar(50) default NULL,
  base_role int(4) default NULL,
  PRIMARY KEY  (id)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

-- 
-- Create admin user
-- 

INSERT INTO usr (id, password, base_role) VALUES ('admin', MD5('admin'), '8');

