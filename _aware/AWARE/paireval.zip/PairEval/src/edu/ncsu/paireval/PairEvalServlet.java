package edu.ncsu.paireval;

import javax.servlet.*;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.apache.tapestry.ApplicationServlet;

public class PairEvalServlet extends ApplicationServlet {
    public static String dbURL, dbDriver, dbUser, dbPassword;
    
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        ServletContext ctx = config.getServletContext();
        dbURL = ctx.getInitParameter("db_url");
        dbDriver = ctx.getInitParameter("db_driver");
        dbUser = ctx.getInitParameter("db_user");
        dbPassword = ctx.getInitParameter("db_password");
    }
    
    
    protected String getApplicationSpecificationPath() throws ServletException {
        return super.getApplicationSpecificationPath();
    }
}
