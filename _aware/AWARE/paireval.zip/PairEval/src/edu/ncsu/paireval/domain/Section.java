package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

public class Section implements Serializable{
    public static final String NAME_ALL = "All";
    String name;
    String courseNumber;
    String TA;
    
    public static Section allSectionFor(String courseNumber) {
        Section ret = new Section();
        ret.courseNumber = courseNumber;
        ret.name = NAME_ALL;
        return ret;
    }
    
    public static Section[] findByCourse(String number) {
        ArrayList ret = new ArrayList();
        String sql = "select * from section where course = ? ORDER BY name ASC;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, number);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Section section = new Section();
                section.name = rst.getString("name");
                section.TA = rst.getString("ta");
                section.courseNumber = number;
                ret.add(section);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (Section[])ret.toArray(new Section[ret.size()]);
    }
    
    static public Section create(String courseNumber, String sectionName) {
        Section section = new Section();
        section.courseNumber = courseNumber;
        section.name = sectionName;
        String sql = "insert into section (name, course) values (?, ?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, sectionName);
            stmnt.setString(2, courseNumber);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            section = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return section;
    }
    
    public static Section findByName(
            String courseNumber, String sectionName) {
        Section section = new Section();
        String sql = "select * from section where name = ? and course = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, sectionName);
            stmnt.setString(2, courseNumber);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                section.courseNumber = courseNumber;
                section.name = sectionName;
                section.TA = rst.getString("ta");
            } else {
                section = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return section;
    }
    
    public int getSize() {
        return Registration.getSectionSize(courseNumber, name);
    }

    public void remove() {
        String sql = "delete from section where course = ? and name = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, name);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
    
    public void save() {
        String sql = "update section set ta = ? where course = ? and name = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, TA);
            stmnt.setString(2, courseNumber);
            stmnt.setString(3, name);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public String getName() {
        return name;
    }
    
    public String getCourseNumber() {
        return courseNumber;
    }
    
    public String getTA() {
        return TA;
    }
    
    public void setTA(String TA) {
        this.TA = TA;
    }
}
