package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import edu.ncsu.paireval.Util;
import edu.ncsu.paireval.database.DBConnection;


public class Assignment implements Serializable{
    String number, courseNumber;
    Date startDate, endDate;
    int groupNumber;
    int reviewNumber;
    
    public static Assignment findByNumber(
            String courseNumber, String assignmentNumber) {
        Assignment assignment = new Assignment();
        String sql = "select * from assignment " +
                "where course = ? and number = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, assignmentNumber);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                assignment.number = assignmentNumber;
                assignment.courseNumber = courseNumber;
                assignment.startDate = rst.getDate("start_date");
                assignment.endDate = rst.getDate("end_date");
                assignment.groupNumber = rst.getInt("group_number");
                assignment.reviewNumber = rst.getInt("reviews");
            } else {
                assignment = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return assignment;
    }

    public static Assignment create(
            String courseNumber, String assignmentNumber) {
        Assignment assignment = new Assignment();
        assignment.courseNumber = courseNumber;
        assignment.number = assignmentNumber;
        String sql = "insert into assignment (course, number) values (?, ?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, assignmentNumber);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            assignment = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return assignment;
    }

    public static Assignment[] findByCourse(String number) {
        ArrayList ret = new ArrayList();
        String sql = "select * from assignment" +
                " where course = ? order by end_date;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, number);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Assignment assignment = new Assignment();
                assignment.number = rst.getString("number");
                assignment.courseNumber = number;
                assignment.startDate = rst.getDate("start_date");
                assignment.endDate = rst.getDate("end_date");
                assignment.groupNumber = rst.getInt("group_number");
                assignment.reviewNumber = rst.getInt("reviews");
                ret.add(assignment);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (Assignment[])ret.toArray(new Assignment[ret.size()]);
    }

    public String getNumber() {
        return number;
    }

    public String getCourseNumber() {
        return courseNumber;
    }

    public Date getStartDate() {
        return startDate;
    }
    
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    
    public Date getEndDate() {
        return endDate;
    }
    
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public void save() {
        String sql = "update assignment set start_date = ?," +
                " end_date = ?, group_number = ?, reviews = ?" +
                " where course = ? and number = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setDate(1, Util.convert(startDate));
            stmnt.setDate(2, Util.convert(endDate));
            stmnt.setInt(3, groupNumber);
            stmnt.setInt(4, reviewNumber);
            stmnt.setString(5, courseNumber);
            stmnt.setString(6, number);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public void remove() {
        String sql = "delete from assignment where course = ? and number = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, number);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public int getGroupNumber() {
        return groupNumber;
    }
    
    public void setGroupNumber(int groupNumber) {
        this.groupNumber = groupNumber;
    }
    
    public int getReviewNumber() {
        return reviewNumber;
    }
    
    public void setReviewNumber(int reviewNumber) {
        this.reviewNumber = reviewNumber;
    }
    
    public String getLabel() {
        SimpleDateFormat format = new SimpleDateFormat("MM/dd");
        StringBuffer buf = new StringBuffer();
        buf.append(getNumber())
                .append("(")
                .append(format.format(getStartDate()))
                .append(" - ")
                .append(format.format(getEndDate()))
                .append(")");
        return buf.toString();
    }
    
    public boolean equals(Assignment other) {
    	if((other.number).equals(this.number) && (other.courseNumber).equals(this.courseNumber))
    		return true;
    	return false;
    }
}
