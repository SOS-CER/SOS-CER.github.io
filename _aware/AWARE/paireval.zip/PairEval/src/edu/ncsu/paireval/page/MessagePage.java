package edu.ncsu.paireval.page;

import edu.ncsu.paireval.component.ProtectedPage;

public class MessagePage extends ProtectedPage {
    transient String displayMessage, taskTitle;
    
    public void detach() {
        displayMessage = null;
        taskTitle = null;
        super.detach();
    }
    
    public boolean isAccessible() {
        return true;
    }

    public String getDisplayMessage() {
        return displayMessage;
    }
    
    public void setDisplayMessage(String displayedMessage) {
        this.displayMessage = displayedMessage;
    }
    
    public String getTaskTitle() {
        return taskTitle;
    }
    
    public void setTaskTitle(String taskTitle) {
        this.taskTitle = taskTitle;
    }
}
