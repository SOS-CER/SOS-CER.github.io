package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.form.IPropertySelectionModel;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.component.SectionNumberSelectionModel;
import edu.ncsu.paireval.domain.*;

public class ViewStudent extends RoleBasedPage {
    String selectedSection;
    String currentStudentID;
    User currentStudent;
    
    public int getAllowedRoles() {
        return Role.INSTRUCTOR | Role.TA;
    }
    
    public void detach() {
        selectedSection = null;
        super.detach();
    }

    public void removeStudent(IRequestCycle cycle) {
        Registration reg = Registration.find(
                currentStudentID, getCurrentCourseNumber(), selectedSection);
        if(reg != null) reg.remove();
        Role role = Role.findByUserCourse(
                currentStudentID, getCurrentCourseNumber());
        if(role != null) {
            role.removeRole(Role.STUDENT);
            role.save();
        }
    }
    
    public void sectionSelected(IRequestCycle cycle) {
        //do nothing
    }
    
    public IPropertySelectionModel getSelectableSections() {
        //teacher: all sections in the course
        //TA: the sections he's TAing
        User user = getCurrentUser();
        String courseID = getCurrentCourseNumber();
        Role role = Role.findByUserCourse(user.getID(), courseID);
        if(role.hasRole(Role.INSTRUCTOR)) {
            return SectionNumberSelectionModel.populate(courseID, false);
        } else {
            return SectionNumberSelectionModel.populateByTA(
                    courseID, user.getID());
        }
    }
    
    public String getSelectedSection() {
        return selectedSection;
    }
    
    public void setSelectedSection(String selectedSection) {
        this.selectedSection = selectedSection;
    }
    
    public String[] getStudents() {
        if(selectedSection == null) return null;
        Registration[] reg = Registration.findBySection(
                getCurrentCourseNumber(), selectedSection);
        String[] ret = new String[reg.length];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = reg[i].getUserID();
        }
        return ret;
    }
    
    public String getCurrentStudent() {
        return currentStudentID;
    }

    public void setCurrentStudent(String currentStudent) {
        this.currentStudentID = currentStudent;
        this.currentStudent = User.findByID(currentStudentID);
    }
    
    public String getCurrentStudentName() {
        return currentStudent.getName();
    }
    
    public String getEmailLink() {
        return "mailto:" + currentStudent.getEmail();
    }
    
    public String getEmail() {
        return currentStudent.getEmail();
    }
}
