package edu.ncsu.paireval.component;

import org.apache.tapestry.PageRedirectException;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageValidateListener;
import org.apache.tapestry.html.BasePage;

import edu.ncsu.paireval.Visit;
import edu.ncsu.paireval.domain.User;
import edu.ncsu.paireval.page.Login;

public abstract class ProtectedPage
        extends BasePage implements PageValidateListener {
    public void pageValidate(PageEvent event) {
        Visit visit = (Visit)getVisit();
        if(visit != null) {
            if(visit.isLoggedIn() && isAccessible()) return;
        }
        Login login = (Login) getRequestCycle().getPage("Login");
        throw new PageRedirectException(login);
    }
    
    public abstract boolean isAccessible();
   
    public User getCurrentUser() {
        return ((Visit)getVisit()).getUser();
    }
}
