package edu.ncsu.paireval.component;

import org.apache.tapestry.IBinding;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;
import org.apache.tapestry.form.IPropertySelectionModel;
import org.apache.tapestry.form.StringPropertySelectionModel;

import edu.ncsu.paireval.Visit;

public class TaskBorder extends Border implements PageRenderListener{
    IPropertySelectionModel courseSelectionModel;
    
    public String getTaskTitle() {
        IBinding taskTitleBinding = getBinding("task");
        if(taskTitleBinding == null) {
            return getTitle();
        }
        return taskTitleBinding.getString();
    }

    public boolean isAccessible(String pageName) {
        ProtectedPage page = 
                (ProtectedPage)getPage().getRequestCycle().getPage(pageName);
        return page.isAccessible();
    }
    
    public IPropertySelectionModel getCourseSelectionModel() {
        return courseSelectionModel;
    }

    public void pageBeginRender(PageEvent event) {
        Visit visit = (Visit)getPage().getVisit();
        String[] courses = visit.getUser().getSelectableCourseNumbers();
        if(courses.length > 0 && visit.getCurrentCourseNumber() == null) {
            visit.setCurrentCourseNumber(courses[0]);
        } else if(courses.length == 0) {
            visit.setCurrentCourseNumber(null);
        }
        courseSelectionModel = new StringPropertySelectionModel(courses);
    }
}
