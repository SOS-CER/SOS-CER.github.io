package edu.ncsu.paireval.validator;

import org.apache.tapestry.form.IFormComponent;
import org.apache.tapestry.valid.StringValidator;
import org.apache.tapestry.valid.ValidatorException;

import edu.ncsu.paireval.domain.Course;

public class NewCourseIDValidator extends StringValidator {
    public Object toObject(IFormComponent field, String input)
            throws ValidatorException {
        String number = (String) super.toObject(field, input);
        if (Course.findByNumber(number) != null) {
            throw new ValidatorException("This number is already used.");
        }
        return number;
    }

}