package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.*;

import edu.ncsu.paireval.Util;
import edu.ncsu.paireval.database.DBConnection;

public class PartnerPref implements Serializable{
    String userID;
    String[] xes = new String[3];
    String course;
    
    public static PartnerPref findOrCreateByUserID(String course, String id) {
        PartnerPref pref = findByUserID(course, id);
        if(pref == null) {
            pref = createNew(course, id);
        }
        return pref;
    }
    
    public static PartnerPref findByUserID(String course, String id) {
        PartnerPref pref = new PartnerPref();
        String sql = "select * from pref where user = ? and course = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            stmnt.setString(2, course);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                pref.userID = id;
                pref.xes[0] = rst.getString("x1");
                pref.xes[1] = rst.getString("x2");
                pref.xes[2] = rst.getString("x3");
                pref.course = course;
            } else {
                pref = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return pref;
    }
    
    public static PartnerPref createNew(String course, String userID) {
        PartnerPref pref = new PartnerPref();
        pref.userID = userID;
        String sql = "insert into pref (user, course) values (?, ?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, userID);
            stmnt.setString(2, course);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            pref = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return pref;
    }
    
    public void save() {
        String sql = "update pref set x1=?, x2=?, x3=? where " +
                "user = ? and course = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, xes[0]);
            stmnt.setString(2, xes[1]);
            stmnt.setString(3, xes[2]);
            stmnt.setString(4, userID);
            stmnt.setString(5, course);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public boolean isX(String userID) {
        return userID.equals(xes[0]) ||
                userID.equals(xes[1]) ||
                userID.equals(xes[2]);
    }
    
    public String getUserID() {
        return userID;
    }
    
    public void setX(int index, String x) {
        this.xes[index] = x;
    }
    
    public void resetPref() {
        xes[1] = xes[2] = xes[0] = null;
    }
    
    public String getX1() {
        return getX(0);
    }
    
    public String getX2() {
        return getX(1);
    }
    
    public String getX3() {
        return getX(2);
    }
    
    String getX(int index) {
        if(Util.isEmptyString(xes[index])) return "";
        return User.findByID(xes[index]).getName();
    }
}
