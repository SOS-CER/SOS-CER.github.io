package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

public class TAAssignment implements Serializable{
    String userID, courseID, sectionName;

    public static TAAssignment createNew(String courseID, String sectionName) {
        TAAssignment assignment = new TAAssignment();
        assignment.courseID = courseID;
        assignment.sectionName = sectionName;
        return assignment;
    }
    
    public static TAAssignment find(String courseID, String sectionName) {
        Section section = Section.findByName(courseID, sectionName);
        if(section == null) return null;
        TAAssignment assignment = new TAAssignment();
        assignment.userID = section.getTA();
        assignment.courseID = section.getCourseNumber();
        assignment.sectionName = section.getName();
        return assignment;
    }
    
    public static TAAssignment[] findByTACourse(
            String userID, String courseID) {
        ArrayList ret = new ArrayList();
        String sql = "select * from section where course = ? and ta = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseID);
            stmnt.setString(2, userID);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                TAAssignment assignment = new TAAssignment();
                assignment.courseID = rst.getString("course");
                assignment.sectionName = rst.getString("name");
                assignment.userID = rst.getString("ta");
                ret.add(assignment);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (TAAssignment[])ret.toArray(new TAAssignment[ret.size()]);
    }
    
    public static TAAssignment findOrCreate(
            String courseID, String sectionName) {
        TAAssignment assignment = find(courseID, sectionName);
        if(assignment == null) {
            assignment = createNew(courseID, sectionName);
        }
        return assignment;
    }

    public void remove() {
        Section section = Section.findByName(courseID, sectionName);
        if(section != null) {
            section.setTA(null);
            section.save();
        }
    }
    
    public void save() {
        Section section = Section.findByName(courseID, sectionName);
        if(section != null) {
            section.setTA(userID);
            section.save();
        }
    }
    
    public String getCourseID() {
        return courseID;
    }
    
    public String getSectionName() {
        return sectionName;
    }
    
    public String getUserID() {
        return userID;
    }
    
    public void setUserID(String userID) {
        this.userID = userID;
    }
}
