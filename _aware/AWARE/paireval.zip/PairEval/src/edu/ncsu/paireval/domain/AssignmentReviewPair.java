package edu.ncsu.paireval.domain;

public class AssignmentReviewPair {
    Assignment assignment;
    int reviewNumber;
    
    public AssignmentReviewPair(Assignment assignment, int reviewNumber) {
        this.assignment = assignment;
        this.reviewNumber = reviewNumber;
    }
    public Assignment getAssignment() {
        return assignment;
    }
    
    public int getReviewNumber() {
        return reviewNumber;
    }
}
