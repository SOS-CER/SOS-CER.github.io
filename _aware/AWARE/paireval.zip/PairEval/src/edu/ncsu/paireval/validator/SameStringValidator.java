package edu.ncsu.paireval.validator;

import org.apache.tapestry.form.IFormComponent;
import org.apache.tapestry.valid.StringValidator;
import org.apache.tapestry.valid.ValidatorException;

public class SameStringValidator extends StringValidator {
    String toMatch;
    
    public void setToMatch(String toMatch) {
        this.toMatch = toMatch;
    }
    
    public Object toObject(IFormComponent field, String input)
            throws ValidatorException {
        String toCompare = (String) super.toObject(field, input);
        if (!toCompare.equals(toMatch)) {
            throw new ValidatorException("The two string sequences are not the same.");
        }
        return input;
    }

}