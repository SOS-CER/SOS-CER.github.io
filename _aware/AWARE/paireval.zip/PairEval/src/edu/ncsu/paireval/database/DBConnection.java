package edu.ncsu.paireval.database;

import java.sql.*;

import edu.ncsu.paireval.PairEvalServlet;
import edu.ncsu.paireval.domain.PairEvalException;

public class DBConnection {
    Connection ctn;
    
    public static DBConnection getInstance() {
        DBConnection dbctn = new DBConnection();
        initCtn(dbctn);
        return dbctn;
    }
    
    private static void initCtn(DBConnection dbctn)
            throws PairEvalException{
        try {
            Class.forName(PairEvalServlet.dbDriver);
        } catch (ClassNotFoundException e) {
            throw new PairEvalException("Cannot locate database driver.");
        }
        
        try {
            dbctn.ctn = DriverManager.getConnection(
                    PairEvalServlet.dbURL,
                    PairEvalServlet.dbUser,
                    PairEvalServlet.dbPassword);
        } catch (SQLException sqle) {
            throw new PairEvalException(
                    "Cannot initialize database connection: " + sqle.getMessage());
        }
    }

    public void release() {
        try {
            if(ctn != null) ctn.close();
        } catch (SQLException ignored) {
        }
    }
    
    public PreparedStatement getStatement(String stmnt) {
        try {
            PreparedStatement s = ctn.prepareStatement(stmnt);
            return s;
        } catch (SQLException e) {
            System.err.println("Cannot create prepared statement.");
            e.printStackTrace();
            return null;
        }
    }
}
