package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.Role;
import edu.ncsu.paireval.domain.StudentReg;

public class StudentQuery extends RoleBasedPage {
    String lastName;
    StudentReg currentReg;
    
    public void detach() {
        lastName = null;
        super.detach();
    }
    
    public int getAllowedRoles() {
        return Role.INSTRUCTOR | Role.TA;
    }
    
    public void more(IRequestCycle cycle) {
        StudentDetail detailPage =
            (StudentDetail)cycle.getPage("StudentDetail");
        detailPage.setUser(currentReg.getStudent());
        cycle.activate(detailPage);
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public StudentReg[] getQueryResult() {
        if(lastName == null) return new StudentReg[0];
        return StudentReg.findByLastNameAndCourse(
                lastName,getCurrentUser().getSelectableCourseNumbers()); 
    }
    
    public void setCurrentReg(StudentReg reg) {
        this.currentReg = reg;
    }
    
    public StudentReg getCurrentReg() {
        return currentReg;
    }
}
