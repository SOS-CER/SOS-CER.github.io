package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

/**
 * This class describes the relationship between a user and a course. It is used
 * in RoleBasedPage. However, it has nothing to do with users' base roles, which
 * are used to decide the users' privileges when they are not associated with
 * any course.
 */
public class Role implements Serializable {
    public final static int STUDENT = 1;

    public final static int TA = 2;

    public final static int INSTRUCTOR = 4;

    String course, userId; //PK

    int roleID;

    public static Role findByUserCourse(String id, String course) {
        Role role = new Role();
        String sql = "select * from role where course = ? and user = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, course);
            stmnt.setString(2, id);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                role.course = course;
                role.userId = id;
                role.roleID = rst.getInt("role_id");
            } else {
                role = null;
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return role;
    }

    public static Role createNew(String id, String course) {
        Role role = new Role();
        role.course = course;
        role.userId = id;
        String sql = "insert into role (course, user) values (?, ?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, course);
            stmnt.setString(2, id);
            stmnt.execute();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            role = null;
        } finally {
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return role;
    }
    
    public static Role[] findByCourse(String course) {
        ArrayList ret = new ArrayList();
        String sql = "select * from role where course = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, course);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Role role = new Role();
                role.course = course;
                role.roleID = rst.getInt("role_id");
                role.userId = rst.getString("user");
                ret.add(role);
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (Role[]) ret.toArray(new Role[ret.size()]);
    }

    public static Role[] findByUserCourse(String id) {
        ArrayList ret = new ArrayList();
        String sql = "select * from role where user = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Role role = new Role();
                role.course = rst.getString("course");
                role.roleID = rst.getInt("role_id");
                role.userId = id;
                ret.add(role);
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (Role[]) ret.toArray(new Role[ret.size()]);
    }

    public static Role findOrCreate(String userID, String course) {
        Role r = findByUserCourse(userID, course);
        if (r == null) {
            r = createNew(userID, course);
        }
        return r;
    }

    public void save() {
        if (roleID == 0) {
            remove();
        } else {
            String sql = "update role set role_id = ?"
                    + " where course = ? and user = ?;";
            DBConnection ctn = DBConnection.getInstance();
            PreparedStatement stmnt = ctn.getStatement(sql);
            try {
                stmnt.setInt(1, roleID);
                stmnt.setString(2, course);
                stmnt.setString(3, userId);
                stmnt.execute();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            } finally {
                try {
                    if (stmnt != null)
                        stmnt.close();
                } catch (SQLException ignored) {
                }
                ctn.release();
            }
        }
    }

    public void addRole(int roleID) {
        this.roleID |= roleID;
    }

    public void removeRole(int roleID) {
        this.roleID &= (~roleID);
    }

    public boolean hasRole(int role) {
        int result = this.roleID & role;
        return result != 0;
    }

    public int getRoleID() {
        return roleID;
    }

    public String getCourse() {
        return course;
    }

    public String getUserId() {
        return userId;
    }

    public void remove() {
        String sql = "delete from role where course = ? and user = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, course);
            stmnt.setString(2, userId);
            stmnt.execute();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
}