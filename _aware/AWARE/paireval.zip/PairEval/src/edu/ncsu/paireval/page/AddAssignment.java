package edu.ncsu.paireval.page;

import java.util.Date;

import org.apache.tapestry.IRequestCycle;

import edu.ncsu.paireval.Util;
import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.Assignment;
import edu.ncsu.paireval.domain.Course;
import edu.ncsu.paireval.domain.Role;

public class AddAssignment extends RoleBasedPage{
    String assignmentNumber;
    Date startDate, endDate;
    String addError;
    String viewError;
    String groupNumber;
    Assignment selectedAssignment;
    Date selectedStartDate, selectedEndDate;
    String selectedGroupNumber;
    String reviewNumber;
    private String selectedReviewNumber;
    
    public void detach() {
        viewError = null;
        selectedAssignment = null;
        groupNumber = addError = assignmentNumber = null;
        startDate = endDate = null;
        super.detach();
    }
    
    public int getAllowedRoles() {
        return Role.INSTRUCTOR;
    }

    public void add(IRequestCycle cycle) {
        if(Util.isEmptyString(assignmentNumber)) {
            addError = "Please enter a valid assignment number.";
            return;
        }
        if(Util.isEmptyString(groupNumber)) {
            addError = "Please enter the number of groups.";
            return;
        }
        if(startDate == null || endDate == null) {
            addError = "Start date and end date are mandatory fields.";
            return;
        }
        if(startDate.compareTo(endDate) >= 0) {
            addError = "Start date should be after end date.";
            return;
        }
        String courseNumber = getCurrentCourseNumber();
        Course course = Course.findByNumber(courseNumber);
        if(course == null) {
            addError = "Course not found.";
            return;
        }
        Assignment assignment = course.createAssignment(assignmentNumber);
        assignment.setStartDate(startDate);
        assignment.setEndDate(endDate);
        assignment.setGroupNumber(Integer.parseInt(groupNumber));
        assignment.setReviewNumber(Integer.parseInt(reviewNumber));
        assignment.save();
        addError = "Assignment " + assignmentNumber + " for course " + 
                courseNumber + " created.";
        assignmentNumber = null;
        startDate = endDate = null;
    }

    public void save(IRequestCycle cycle) {
        if(selectedGroupNumber == null) {
            viewError = "Number of groups should not be empty.";
            return;
        }
        if(selectedStartDate == null) {
            viewError = "Start date should not be empty.";
            return;
        }
        if(selectedEndDate == null) {
            viewError = "End date should not be empty.";
            return;
        }
        if(selectedStartDate.compareTo(selectedEndDate) >= 0) {
            viewError = "Start date for assignment " +
                    selectedAssignment.getNumber() +
                    " should be before the end date.";
            return;
        }
        selectedAssignment.setStartDate(selectedStartDate);
        selectedAssignment.setEndDate(selectedEndDate);
        selectedAssignment.setGroupNumber(
                Integer.parseInt(selectedGroupNumber));
        selectedAssignment.setReviewNumber(
                Integer.parseInt(selectedReviewNumber));
        selectedAssignment.save();
        viewError = "Assignment " + selectedAssignment.getNumber() + " saved.";
    }
    
    public void delete(IRequestCycle cycle) {
        selectedAssignment.remove();
        viewError = "Assignment " + selectedAssignment.getNumber() + " deleted.";
    }
    
    public String getAssignmentNumber() {
        return assignmentNumber;
    }
    
    public void setAssignmentNumber(String assignmentNumber) {
        this.assignmentNumber = assignmentNumber;
    }
    
    public Date getStartDate() {
        return startDate;
    }
    
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
    
    public Date getEndDate() {
        return endDate;
    }
    
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
    
    public String getAddError() {
        return addError;
    }
    
    public void setAddError(String error) {
        this.addError = error;
    }

    public String getViewError() {
        return viewError;
    }
    
    public Assignment[] getAssignments() {
        Course course = Course.findByNumber(getCurrentCourseNumber());
        if(course == null) {
            viewError = "Course not found";
            return null;
        }
        return course.getAssignments();
    }
    
    public Assignment getSelectedAssignment() {
        return selectedAssignment;
    }
    
    public void setSelectedAssignment(Assignment selectedAssignment) {
        this.selectedAssignment = selectedAssignment;
    }
    
    public Date getSelectedStartDate() {
        return selectedAssignment.getStartDate();
    }
    
    public void setSelectedStartDate(Date date) {
        this.selectedStartDate = date;
    }
    
    public Date getSelectedEndDate() {
        return selectedAssignment.getEndDate();
    }
    
    public void setSelectedEndDate(Date date) {
        this.selectedEndDate = date;
    }
    
    public String getGroupNumber() {
        return groupNumber;
    }
    
    public void setGroupNumber(String groupNumber) {
        this.groupNumber = groupNumber;
    }
    
    public String getSelectedGroupNumber() {
        return String.valueOf(selectedAssignment.getGroupNumber());
    }
    
    public void setSelectedGroupNumber(String selectedGroupNumber) {
        this.selectedGroupNumber = selectedGroupNumber;
    }
    
    public String getReviewNumber() {
        return reviewNumber;
    }
    
    public void setReviewNumber(String reviewNumber) {
        this.reviewNumber = reviewNumber;
    }
    
    public String getSelectedReviewNumber() {
        return String.valueOf(selectedAssignment.getReviewNumber());
    }
    
    public void setSelectedReviewNumber(String selectedReviewNumber) {
        this.selectedReviewNumber = selectedReviewNumber;
    }
}
