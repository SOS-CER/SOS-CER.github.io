package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

public class StudentReg implements Serializable {
    User student;
    String course;
    String section;
    
    public static StudentReg[] findByLastNameAndCourse(
            String lastName, String[] courseNumbers) {
        if(courseNumbers.length == 0) return new StudentReg[0];
        ArrayList ret = new ArrayList();
        StringBuffer sql = new StringBuffer();
        sql.append("select * from usr, registration ")
                .append("where usr.id = registration.user ")
                .append("and usr.last_name = ? ")
                .append("and registration.course in (");
        for (int i = 0; i < courseNumbers.length; i++) {
            sql.append("?");
            if(i == courseNumbers.length - 1) {
                sql.append(");");
            } else {
                sql.append(", ");
            }
        }
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql.toString());
        ResultSet rst = null;
        try {
            stmnt.setString(1, lastName);
            for (int i = 0; i < courseNumbers.length; i++) {
                stmnt.setString(i+2, courseNumbers[i]);
            }
            rst = stmnt.executeQuery();
            while (rst.next()) {
                StudentReg reg = new StudentReg();
                User user = new User();
                user.id = rst.getString("id");
                user.firstName = rst.getString("first_name");
                user.lastName = rst.getString("last_name");
                user.email = rst.getString("email");
                user.baseRole = rst.getInt("base_role");
                reg.student = user;
                reg.course = rst.getString("course");
                reg.section = rst.getString("section_name");
                ret.add(reg);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (StudentReg[])ret.toArray(new StudentReg[ret.size()]);
    }

    public User getStudent() {
        return student;
    }
    
    public String getCourse() {
        return course;
    }
    
    public String getSection() {
        return section;
    }

}
