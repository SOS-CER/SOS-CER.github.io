package edu.ncsu.paireval.domain;

import java.sql.*;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

public class Grouping {
    String courseNumber, assignment, groupNumber, studentID;

    public static Grouping[] findByGroup(String courseNumber,
            String assignment, String group) {
        ArrayList ret = new ArrayList();
        String sql = "select * from grouping where "
                + "course = ? and assignment = ? and group_number = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, assignment);
            stmnt.setString(3, group);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Grouping grouping = new Grouping();
                grouping.courseNumber = courseNumber;
                grouping.assignment = assignment;
                grouping.groupNumber = group;
                grouping.studentID = rst.getString("user");
                ret.add(grouping);
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (Grouping[]) ret.toArray(new Grouping[ret.size()]);
    }

    public static Grouping find(String course, String assignment, String group,
            String studentID) {
        Grouping grouping = new Grouping();
        String sql = "select * from grouping where "
                + "course=? and assignment=? and group_number=? and user=?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, course);
            stmnt.setString(2, assignment);
            stmnt.setString(3, group);
            stmnt.setString(4, studentID);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                grouping.courseNumber = course;
                grouping.assignment = assignment;
                grouping.groupNumber = group;
                grouping.studentID = studentID;
            } else {
                course = null;
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return grouping;
    }

    public static String findGroup(String course, String assignment,
            String studentID) {
        String ret = null;
        String sql = "select * from grouping where "
                + "course=? and assignment=? and user=?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, course);
            stmnt.setString(2, assignment);
            stmnt.setString(3, studentID);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                ret = rst.getString("group_number");
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return ret;
    }

    public static void createNew(String course, String assignment,
            String group, String id) {
        String sql = "insert into grouping ("
                + "course, assignment, group_number, user) values (?,?,?,?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, course);
            stmnt.setString(2, assignment);
            stmnt.setString(3, group);
            stmnt.setString(4, id);
            stmnt.execute();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            group = null;
        } finally {
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public String getAssignment() {
        return assignment;
    }

    public String getCourseNumber() {
        return courseNumber;
    }

    public String getGroupNumber() {
        return groupNumber;
    }

    public String getStudentID() {
        return studentID;
    }

    public void remove() {
        String sql = "delete from grouping where "
                + "course=? and assignment=? and user=?";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, assignment);
            stmnt.setString(3, studentID);
            stmnt.execute();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
}