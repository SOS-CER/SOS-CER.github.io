package edu.ncsu.paireval.domain;

import java.sql.*;

import edu.ncsu.paireval.database.DBConnection;

public class SelfEval {
    String userID, impression;
    int ethic, esteem, timeMng, speed, problemSolving, interest, coding, experience, helping, testing, roadblock;

    public static SelfEval findOrCreateByUser(String id) {
        SelfEval eval = findByUser(id);
        if(eval == null) {
            eval = createNew(id);
        }
        return eval;
    }
    
    public static SelfEval createNew(String userID) {
        SelfEval se = new SelfEval();
        se.userID = userID;
        String sql = "insert into selfeval (user) values (?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, userID);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            se = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return se;
    }
    
    public static SelfEval findByUser(String id) {
        SelfEval se = new SelfEval();
        String sql = "select * from selfeval where user = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                se.userID = id;
                se.esteem = rst.getInt("esteem");
                se.ethic = rst.getInt("ethic");
                se.timeMng = rst.getInt("timemng");
                se.speed = rst.getInt("speed");
                se.problemSolving = rst.getInt("problemsolving");
                se.interest = rst.getInt("interest");
                se.coding = rst.getInt("coding");
                se.experience = rst.getInt("experience");
                se.helping = rst.getInt("helping");
                se.testing = rst.getInt("testing");
                se.roadblock = rst.getInt("roadblock");
                se.impression = rst.getString("impression");
                
            } else {
                se = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return se;
    }

    public void save() {
        StringBuffer sql = new StringBuffer();
        sql.append("update selfeval set")
                .append(" ethic = ?, esteem = ?, timemng = ?,")
				.append(" speed = ?, problemsolving = ?, interest = ?,")
				.append(" coding = ?, experience = ?, helping = ?,")
				.append(" testing = ?, roadblock = ?, impression = ? where user = ?;");
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql.toString());
        try {
            stmnt.setInt(1, ethic);
            stmnt.setInt(2, esteem);
            stmnt.setInt(3, timeMng);
            stmnt.setInt(4, speed);
            stmnt.setInt(5, problemSolving);
            stmnt.setInt(6, interest);
            stmnt.setInt(7, coding);
            stmnt.setInt(8, experience);
            stmnt.setInt(9, helping);
            stmnt.setInt(10, testing);
            stmnt.setInt(11, roadblock);
            stmnt.setString(12, impression);
            stmnt.setString(13, userID);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
    
    public String getUserID() {
        return userID;
    }
    
    public void setUserID(String userID) {
        this.userID = userID;
    }
    
    public int getEthic() {
        return ethic;
    }

    public void setEthic(int ethic) {
        this.ethic = ethic;
    }
    
    public int getEsteem() {
        return esteem;
    }
    
    public void setEsteem(int esteem) {
        this.esteem = esteem;
    }
    
    public int getTimeMng() {
        return timeMng;
    }
    
    public void setTimeMng(int timeMng) {
        this.timeMng = timeMng;
    }
    
    public int getSpeed() {
    	return speed;
    }
    
    public void setSpeed(int speed) {
    	this.speed = speed;
    }
    
    public int getProblemSolving() {
    	return problemSolving;
    }
    
    public void setProblemSolving(int ps) {
    	this.problemSolving = ps;
    }
    
    public int getInterest() {
    	return interest;
    }
    
    public void setInterest(int interest) {
    	this.interest = interest;
    }
    
    public int getCoding () {
    	return coding;
    }
    
    public void setCoding(int coding) {
    	this.coding = coding;
    }
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public int getHelping() {
		return helping;
	}
	public void setHelping(int helping) {
		this.helping = helping;
	}
	public int getRoadblock() {
		return roadblock;
	}
	public void setRoadblock(int roadblock) {
		this.roadblock = roadblock;
	}
	public int getTesting() {
		return testing;
	}
	public void setTesting(int testing) {
		this.testing = testing;
	}

	public String getImpression() {
		return impression;
	}

	public void setImpression(String impression) {
		this.impression = impression;
	}
}
