package edu.ncsu.paireval.domain;

import java.sql.*;

import edu.ncsu.paireval.database.DBConnection;

public class Collaboration {
	String userID;

	int number;

	int responsibility, savesTime, preferToPair, largeProjects, soloLearning,
			organized, advice, codingErrors, procrastinate, preferAlone,
			newIdeas, badPartner, logicErrors, commute;

	String plans, major;

	public static Collaboration findOrCreateByUserNum(String id, int num) {
		Collaboration eval = findByUserNum(id, num);
		if (eval == null) {
			eval = createNew(id, num);
		}
		return eval;
	}

	public static Collaboration createNew(String userID, int num) {
		Collaboration se = new Collaboration();
		se.userID = userID;
		se.number = num;
		String sql = "insert into collaboration (user,number) values (?,?);";
		DBConnection ctn = DBConnection.getInstance();
		PreparedStatement stmnt = ctn.getStatement(sql);
		try {
			stmnt.setString(1, userID);
			stmnt.setInt(2, num);
			stmnt.execute();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
			se = null;
		} finally {
			try {
				if (stmnt != null)
					stmnt.close();
			} catch (SQLException ignored) {
			}
			ctn.release();
		}
		return se;
	}

	public static Collaboration findByUserNum(String id, int num) {
		Collaboration se = new Collaboration();
		String sql = "select * from collaboration where user = ? AND number = ?;";
		DBConnection ctn = DBConnection.getInstance();
		PreparedStatement stmnt = ctn.getStatement(sql);
		ResultSet rst = null;
		try {
			stmnt.setString(1, id);
			stmnt.setInt(2, num);
			rst = stmnt.executeQuery();
			if (rst.next()) {
				se.userID = id;
				se.number = num;
				se.responsibility = rst.getInt("responsibility");
				se.savesTime = rst.getInt("savestime");
				se.preferToPair = rst.getInt("prefertopair");
				se.largeProjects = rst.getInt("largeprojects");
				se.soloLearning = rst.getInt("sololearning");
				se.organized = rst.getInt("organized");
				se.advice = rst.getInt("advice");
				se.codingErrors = rst.getInt("codingerrors");
				se.procrastinate = rst.getInt("procrastinate");
				se.preferAlone = rst.getInt("preferalone");
				se.newIdeas = rst.getInt("newideas");
				se.badPartner = rst.getInt("badpartner");
				se.logicErrors = rst.getInt("logicerrors");
				se.commute = rst.getInt("commute");
				se.plans = rst.getString("plans");
				se.major = rst.getString("major");

			} else {
				se = null;
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (rst != null)
					rst.close();
			} catch (SQLException ignored) {
			}
			try {
				if (stmnt != null)
					stmnt.close();
			} catch (SQLException ignored) {
			}
			ctn.release();
		}
		return se;
	}

	public void save() {
		StringBuffer sql = new StringBuffer();
		sql.append("update collaboration set").append(
				" responsibility = ?, savestime = ?, prefertopair = ?,")
				.append(" largeprojects = ?, sololearning = ?, organized = ?,")
				.append(" advice = ?, codingerrors = ?, procrastinate = ?,")
				.append("preferalone = ?, newideas = ?, badpartner = ?,")
				.append(" logicerrors = ?, commute = ?, plans = ?, major = ?").append(
						"where user = ? AND number = ?;");
		DBConnection ctn = DBConnection.getInstance();
		PreparedStatement stmnt = ctn.getStatement(sql.toString());
		try {
			stmnt.setInt(1, responsibility);
			stmnt.setInt(2, savesTime);
			stmnt.setInt(3, preferToPair);
			stmnt.setInt(4, largeProjects);
			stmnt.setInt(5, soloLearning);
			stmnt.setInt(6, organized);
			stmnt.setInt(7, advice);
			stmnt.setInt(8, codingErrors);
			stmnt.setInt(9, procrastinate);
			stmnt.setInt(10, preferAlone);
			stmnt.setInt(11, newIdeas);
			stmnt.setInt(12, badPartner);
			stmnt.setInt(13, logicErrors);
			stmnt.setInt(14, commute);
			stmnt.setString(15, plans);
			stmnt.setString(16, major);
			stmnt.setString(17, userID);
			stmnt.setInt(18, number);

			stmnt.execute();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} finally {
			try {
				if (stmnt != null)
					stmnt.close();
			} catch (SQLException ignored) {
			}
			ctn.release();
		}
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public int getAdvice() {
		return advice;
	}

	public void setAdvice(int advice) {
		this.advice = advice;
	}

	public int getBadPartner() {
		return badPartner;
	}

	public void setBadPartner(int badPartner) {
		this.badPartner = badPartner;
	}

	public int getCodingErrors() {
		return codingErrors;
	}

	public void setCodingErrors(int codingErrors) {
		this.codingErrors = codingErrors;
	}

	public int getLargeProjects() {
		return largeProjects;
	}

	public void setLargeProjects(int largeProjects) {
		this.largeProjects = largeProjects;
	}

	public int getLogicErrors() {
		return logicErrors;
	}

	public void setLogicErrors(int logicErrors) {
		this.logicErrors = logicErrors;
	}

	public int getNewIdeas() {
		return newIdeas;
	}

	public void setNewIdeas(int newIdeas) {
		this.newIdeas = newIdeas;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getOrganized() {
		return organized;
	}

	public void setOrganized(int organized) {
		this.organized = organized;
	}

	public int getPreferAlone() {
		return preferAlone;
	}

	public void setPreferAlone(int preferAlone) {
		this.preferAlone = preferAlone;
	}

	public int getPreferToPair() {
		return preferToPair;
	}

	public void setPreferToPair(int preferToPair) {
		this.preferToPair = preferToPair;
	}

	public int getProcrastinate() {
		return procrastinate;
	}

	public void setProcrastinate(int procrastinate) {
		this.procrastinate = procrastinate;
	}

	public int getResponsibility() {
		return responsibility;
	}

	public void setResponsibility(int responsibility) {
		this.responsibility = responsibility;
	}

	public int getSavesTime() {
		return savesTime;
	}

	public void setSavesTime(int savesTime) {
		this.savesTime = savesTime;
	}

	public int getSoloLearning() {
		return soloLearning;
	}

	public void setSoloLearning(int soloLearning) {
		this.soloLearning = soloLearning;
	}

	public int getCommute() {
		return commute;
	}

	public void setCommute(int commute) {
		this.commute = commute;
	}

	public String getPlans() {
		return plans;
	}

	public void setPlans(String plans) {
		if (plans.length() > 1000)
			this.plans = plans.substring(0, 999);
		else
			this.plans = plans;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}
}
