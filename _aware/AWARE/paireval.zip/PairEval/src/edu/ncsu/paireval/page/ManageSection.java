package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.Course;
import edu.ncsu.paireval.domain.Role;
import edu.ncsu.paireval.domain.Section;

public class ManageSection extends RoleBasedPage {
    String error, sectionName;
    String currentSection;
    
    public int getAllowedRoles() {
        return Role.INSTRUCTOR;
    }

    public void detach() {
        sectionName = null;
        error = null;
        currentSection = null;
        super.detach();
    }
    
    public void addSection(IRequestCycle cycle) {
        Course course = Course.findByNumber(getCurrentCourseNumber());
        if(Section.findByName(getCurrentCourseNumber(), sectionName) != null) {
            error = "Section " + sectionName + " already exists.";
        } else {
            course.createSection(sectionName);
            error = "Section " + sectionName + " created.";
        }
    }
    
    public void removeSection(IRequestCycle cycle) {
        Section section = Section.findByName(
                getCurrentCourseNumber(), currentSection);
        section.remove();
        error = "Section " + currentSection + " removed.";
    }
    
    public void viewStudents(IRequestCycle cycle) {
        ViewStudent vs = (ViewStudent)cycle.getPage("ViewStudent");
        vs.setSelectedSection(currentSection);
        cycle.activate(vs);
    }
    
    public String getError() {
        return error;
    }
    
    public String getSectionName() {
        return sectionName;
    }
    
    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }
    
    public String[] getSections() {
        Section[] sections = Section.findByCourse(getCurrentCourseNumber());
        String[] ret = new String[sections.length];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = sections[i].getName();
        }
        return ret;
    }
    
    public String getCurrentSection() {
        return currentSection;
    }
    
    public void setCurrentSection(String currentSection) {
        this.currentSection = currentSection;
    }
    
    public int getCurrentSectionSize() {
        Section section = Section.findByName(
                getCurrentCourseNumber(), currentSection);
        return section.getSize();
    }
}
