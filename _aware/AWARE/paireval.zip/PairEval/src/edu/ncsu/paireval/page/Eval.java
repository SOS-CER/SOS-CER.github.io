package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;
import org.apache.tapestry.form.IPropertySelectionModel;

import edu.ncsu.paireval.component.AssignmentSelectionModel;
import edu.ncsu.paireval.component.NumberSelectionModel;
import edu.ncsu.paireval.component.SelectionModelUtil;
import edu.ncsu.paireval.component.StringToIntSelectionModel;
import edu.ncsu.paireval.component.PartnerSelectionModel;
import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.Assignment;
import edu.ncsu.paireval.domain.PartnerEval;
import edu.ncsu.paireval.domain.Role;
import edu.ncsu.paireval.domain.User;

public class Eval extends RoleBasedPage implements PageRenderListener{
    final public static Integer N1 = new Integer(1);
    final public static Integer N2 = new Integer(2);
    final public static Integer N3 = new Integer(3);
    final public static Integer N4 = new Integer(4);
    final public static Integer N5 = new Integer(5);
    final public static Integer N6 = new Integer(6);
    final public static Integer N7 = new Integer(7);
    final public static Integer N8 = new Integer(8);
    final public static Integer N9 = new Integer(9);
    
    IPropertySelectionModel assignmentSelectionModel, partnerSelectionModel;
    String selectedAssignment;
    User selectedPartner;
    String selectedAssignmentNumber;
    int q1, q2, q3, q4, q5, q6, q7;
    int overall;
    String comments;
    String error;
    int number;
    IPropertySelectionModel evalSelectionModel = 
            StringToIntSelectionModel.newInstance(
                    new String[]{"never", "rarely",
                                 "sometimes", "usually", "always"});
    IPropertySelectionModel competencySelectionModel =
            StringToIntSelectionModel.newInstance(
                    new String[]{"Better than me",
                                 "About the same", "Weaker than me"});
    IPropertySelectionModel compatibilitySelectionModel =
            StringToIntSelectionModel.newInstance(
                    new String[]{"Very Compatible", "OK", "Not Compatible"});
    
    public int getAllowedRoles() {
        return Role.STUDENT;
    }
    
    public void pageBeginRender(PageEvent event) {
        assignmentSelectionModel = AssignmentSelectionModel.populate(
                getCurrentCourseNumber());
        if(assignmentSelectionModel.getOptionCount() > 0 &&
                selectedAssignment == null) {
            selectedAssignment = 
                    (String)assignmentSelectionModel.getOption(0);
        }
    }
    
    public void detach() {
        selectedPartner = null;
        selectedAssignment = null;
        q1 = q2 = q3 = q4 = q5 = q6 = q7 = overall = 0;
        error = null;
        comments = null;
        super.detach();
    }
    
    public void addEval(IRequestCycle cycle) {
        if(selectedAssignmentNumber == null || selectedPartner == null) {
            error = "You cannot do peer evaluation for this assignment.";
            return;
        }
        String courseNumber = getCurrentCourseNumber();
        String userID = getCurrentUser().getID();
        PartnerEval eval = PartnerEval.find(
                courseNumber, selectedAssignmentNumber, number,
                userID, selectedPartner.getID());
        if(eval == null) {
            if(comments != null && comments.length() > 255) {
                error = "The upper limit of comments is 255 characters.";
                return;
            }
            if(overall == 0) {
                error = "Please select the overall rating.";
                return;
            }
            PartnerEval.createNew(
                    courseNumber, selectedAssignmentNumber, number,
                    userID, selectedPartner.getID(),
                    q1, q2, q3, q4, q5, q6, q7, overall, comments);
            error = "Evaluation saved.";
        } else {
            q1 = eval.getQ1();
            q2 = eval.getQ2();
            q3 = eval.getQ3();
            q4 = eval.getQ4();
            q5 = eval.getQ5();
            q6 = eval.getQ6();
            q7 = eval.getQ7();
            overall = eval.getOverall();
            comments = eval.getComments();
            error = "You have done this evaluation before. Here is your answer.";
        }
    }

    public IPropertySelectionModel getAssignmentSelectionModel() {
        return assignmentSelectionModel;
    }
    
    public String getSelectedAssignment() {
        return selectedAssignment;
    }
    
    public void setSelectedAssignment(String selectedAssignment) {
        this.selectedAssignment = selectedAssignment;
    }
    
    public IPropertySelectionModel getPartnerSelectionModel() {
        partnerSelectionModel = PartnerSelectionModel.populate(
                getCurrentUser(), getCurrentCourseNumber(),
                selectedAssignment);
        return partnerSelectionModel;
    }
    
    public User getSelectedPartner() {
        return selectedPartner;
    }
    
    public void setSelectedPartner(User selectedPartner) {
        this.selectedPartner = selectedPartner;
    }
    
    public String getSelectedAssignmentNumber() {
        if(selectedAssignment == null) return null;
        return selectedAssignment;
    }
    
    public int getNumber() {
        return number;
    }
    
    public void setNumber(int number) {
        this.number = number;
    }
    
    public IPropertySelectionModel getNumberSelectionModel() {
        Assignment a = Assignment.findByNumber(
                getCurrentCourseNumber(), selectedAssignment);
        if(a != null) {
            return NumberSelectionModel.populate(1, a.getReviewNumber());
        } else {
            return SelectionModelUtil.emptyModel();
        }
    }
    
    public void setSelectedAssignmentNumber(String selectedAssignmentNumber) {
        this.selectedAssignmentNumber = selectedAssignmentNumber;
        this.selectedAssignment = selectedAssignmentNumber;
    }
    
    public IPropertySelectionModel getEvalSelectionModel() {
        return evalSelectionModel;
    }
    
    public IPropertySelectionModel getCompetencySelectionModel() {
        return competencySelectionModel;
    }
    
    public IPropertySelectionModel getCompatibilitySelectionModel() {
        return compatibilitySelectionModel;
    }
    
    public String getError() {
        return error;
    }
    
    public Integer getQ1() {
        return new Integer(q1);
    }
    
    public void setQ1(Integer q1) {
        this.q1 = q1.intValue();
    }
    
    public Integer getQ2() {
        return new Integer(q2);
    }
    
    public void setQ2(Integer q2) {
        this.q2 = q2.intValue();
    }
    
    public Integer getQ3() {
        return new Integer(q3);
    }
    
    public void setQ3(Integer q3) {
        this.q3 = q3.intValue();
    }
    
    public Integer getQ4() {
        return new Integer(q4);
    }
    
    public void setQ4(Integer q4) {
        this.q4 = q4.intValue();
    }
    
    public Integer getQ5() {
        return new Integer(q5);
    }
    
    public void setQ5(Integer q5) {
        this.q5 = q5.intValue();
    }
    
    public Integer getQ6() {
        return new Integer(q6);
    }
    
    public void setQ6(Integer q6) {
        this.q6 = q6.intValue();
    }
    
    public Integer getQ7() {
        return new Integer(q7);
    }
    
    public void setQ7(Integer q7) {
        this.q7 = q7.intValue();
    }
    
    public boolean isSubmitDisabled() {
        if(getSelectedAssignmentNumber() == null) return true;
        if(partnerSelectionModel.getOptionCount() == 0) return true;
        return false;
    }
    
    public Integer getOverall() {
        return new Integer(overall);
    }
    
    public void setOverall(Integer overall) {
        this.overall = overall.intValue();
    }
    
    public String getComments() {
        return comments;
    }
    
    public void setComments(String comments) {
        this.comments = comments;
    }
}
