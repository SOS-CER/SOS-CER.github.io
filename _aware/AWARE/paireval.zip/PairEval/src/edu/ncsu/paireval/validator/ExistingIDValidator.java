package edu.ncsu.paireval.validator;

import org.apache.tapestry.form.IFormComponent;
import org.apache.tapestry.valid.StringValidator;
import org.apache.tapestry.valid.ValidatorException;

import edu.ncsu.paireval.domain.User;

public class ExistingIDValidator extends StringValidator {
    public Object toObject(IFormComponent field, String input)
            throws ValidatorException {
        String id = (String) super.toObject(field, input);
        if (User.findByID(id) == null) {
            throw new ValidatorException("ID does not exist.");
        }
        return id;
    }
}