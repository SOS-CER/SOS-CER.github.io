package edu.ncsu.paireval;

public class A {
    public static void main(String[] args) {
        A a = new A();
        a.test();
    }
    
    public void test() {
        B b1 = new B();
        B b2 = new B();
        System.out.println(b1.getClass() == b2.getClass());
    }
    
    public class B{
        public void p() {
            System.out.println("b");
        }
    }
}
