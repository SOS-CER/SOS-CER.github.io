package edu.ncsu.paireval.component;

import org.apache.tapestry.IMarkupWriter;
import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.form.IFormComponent;
import org.apache.tapestry.valid.FieldTracking;
import org.apache.tapestry.valid.IValidator;
import org.apache.tapestry.valid.ValidationDelegate;

public class FormValidationDelegate extends ValidationDelegate {
    public void writeSuffix(IMarkupWriter writer, IRequestCycle cycle,
            IFormComponent component, IValidator validator) {
        if (isInError()) {
            FieldTracking tracking = getComponentTracking();
            writer.printRaw("<br>&nbsp;");
            writer.begin("span");
            writer.attribute("class", "error");
            tracking.getErrorRenderer().render(writer, cycle);
            writer.end();
        }
    }

    public void writeAttributes(IMarkupWriter writer, IRequestCycle cycle,
            IFormComponent component, IValidator validator) {
        if (isInError()) {
            writer.attribute("style", "background:#FFE0E0");
        }
    }
}