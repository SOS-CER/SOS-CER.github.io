package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import edu.ncsu.paireval.database.DBConnection;

public class PartnerEval implements Serializable{
    String course, assignment, user, partner;
    int number;
    int q1, q2, q3, q4, q5, q6, q7, overall;
    String comments;

    public static PartnerEval find(String courseNumber,
            String assignmentNumber, int number,
            String userID, String partnerID) {
        PartnerEval eval = new PartnerEval();
        String sql = "select * from eval "
                + "where course = ? and assignment = ? and "
                + "user = ? and partner = ? and number = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, assignmentNumber);
            stmnt.setString(3, userID);
            stmnt.setString(4, partnerID);
            stmnt.setInt(5, number);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                eval.course = courseNumber;
                eval.assignment = assignmentNumber;
                eval.user = userID;
                eval.number = number;
                eval.partner = partnerID;
                eval.q1 = rst.getInt("q1");
                eval.q2 = rst.getInt("q2");
                eval.q3 = rst.getInt("q3");
                eval.q4 = rst.getInt("q4");
                eval.q5 = rst.getInt("q5");
                eval.q6 = rst.getInt("q6");
                eval.q7 = rst.getInt("q7");
                eval.overall = rst.getInt("overall");
                eval.comments = rst.getString("comment");
            } else {
                eval = null;
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return eval;
    }

    public static void createNew(
            String courseNumber, String assignmentNumber, int number,
            String userID, String partnerID, int q1, int q2, int q3,
            int q4, int q5, int q6, int q7, int overall, String comments) {

    	String sql = "insert into eval (course, assignment, user, partner," +
                " q1, q2, q3, q4, q5, q6, q7, overall, comment, number)" +
                " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, assignmentNumber);
            stmnt.setString(3, userID);
            stmnt.setString(4, partnerID);
            stmnt.setInt(5, q1);
            stmnt.setInt(6, q2);
            stmnt.setInt(7, q3);
            stmnt.setInt(8, q4);
            stmnt.setInt(9, q5);
            stmnt.setInt(10, q6);
            stmnt.setInt(11, q7);
            stmnt.setInt(12, overall);
            stmnt.setString(13, comments);
            stmnt.setInt(14, number);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
    
    public int getOverall() {
        return overall;
    }

    public void setOverall(int overall) {
        this.overall = overall;
    }

    public int getQ1() {
        return q1;
    }

    public void setQ1(int q1) {
        this.q1 = q1;
    }

    public int getQ2() {
        return q2;
    }

    public void setQ2(int q2) {
        this.q2 = q2;
    }

    public int getQ3() {
        return q3;
    }

    public void setQ3(int q3) {
        this.q3 = q3;
    }

    public int getQ4() {
        return q4;
    }

    public void setQ4(int q4) {
        this.q4 = q4;
    }

    public int getQ5() {
        return q5;
    }

    public void setQ5(int q5) {
        this.q5 = q5;
    }
    
    public int getQ6() {
        return q6;
    }
    
    public void setQ6(int q6) {
        this.q6 = q6;
    }
    
    public int getQ7() {
        return q7;
    }
    
    public void setQ7(int q7) {
        this.q7 = q7;
    }
    
    public String getAssignment() {
        return assignment;
    }

    public String getCourse() {
        return course;
    }

    public String getPartner() {
        return partner;
    }

    public String getUser() {
        return user;
    }
    
    public String getComments() {
        return comments;
    }
    
    public int getNumber() {
        return number;
    }
}