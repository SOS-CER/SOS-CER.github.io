package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;
import org.apache.tapestry.form.IPropertySelectionModel;
import org.apache.tapestry.form.StringPropertySelectionModel;

import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.domain.MyerBriggs;
import edu.ncsu.paireval.domain.User;

public class WriteMyersBriggs extends ProtectedPage
        implements PageRenderListener{
    boolean completed;
    String EI, SI, TF, JP;
    Integer EIValue, SIValue, TFValue, JPValue;

    public void pageBeginRender(PageEvent event) {
        User user = getCurrentUser();
        MyerBriggs mb = MyerBriggs.findByUser(user.getID());
        if(mb != null) {
            completed = true;
            EI = mb.getEI();
            SI = mb.getSI();
            TF = mb.getTF();
            JP = mb.getJP();
            EIValue = mb.getEIValue();
            SIValue = mb.getSIValue();
            TFValue = mb.getTFValue();
            JPValue = mb.getJPValue();
        }
    }
    
    public void detach() {
        EI = SI = TF = JP = null;
        EIValue = SIValue = TFValue = JPValue = null;
        completed = false;
        super.detach();
    }

    public boolean isAccessible() {
        return getCurrentUser().isStudent();
    }
    
    public void save(IRequestCycle cycle) {
        User user = getCurrentUser();
        if(MyerBriggs.findByUser(user.getID()) == null) {
            MyerBriggs mb = MyerBriggs.createNew(user.getID());
            mb.setEI(EI);
            mb.setEIValue(EIValue);
            mb.setSI(SI);
            mb.setSIValue(SIValue);
            mb.setTF(TF);
            mb.setTFValue(TFValue);
            mb.setJP(JP);
            mb.setJPValue(JPValue);
            mb.save();
        }
        cycle.activate("LearningStyles");
    }
    
    public boolean isCompleted() {
        return completed;
    }
    
    public IPropertySelectionModel getEISelectionModel() {
        return new StringPropertySelectionModel(
                new String[]{"Extraversion", "Introversion"});
    }
    
    public String getEI() {
        return EI;
    }
    
    public void setEI(String ei) {
        EI = ei;
    }
    
    public Integer getEIValue() {
        return EIValue;
    }
    
    public void setEIValue(Integer value) {
        EIValue = value;
    }
    
    public IPropertySelectionModel getSISelectionModel() {
        return new StringPropertySelectionModel(
                new String[]{"Sensing", "Intuition"});
    }
    
    public String getSI() {
        return SI;
    }
    
    public void setSI(String si) {
        SI = si;
    }
    
    public Integer getSIValue() {
        return SIValue;
    }
    
    public void setSIValue(Integer value) {
        SIValue = value;
    }

    public IPropertySelectionModel getTFSelectionModel() {
        return new StringPropertySelectionModel(
                new String[]{"Thinking", "Feeling"});
    }
    
    public String getTF() {
        return TF;
    }
    
    public void setTF(String tf) {
        TF = tf;
    }
    
    public Integer getTFValue() {
        return TFValue;
    }
    
    public void setTFValue(Integer value) {
        TFValue = value;
    }
    
    public IPropertySelectionModel getJPSelectionModel() {
        return new StringPropertySelectionModel(
                new String[]{"Judging", "Perceiving"});
    }
    
    public String getJP() {
        return JP;
    }
    
    public void setJP(String jp) {
        JP = jp;
    }
    
    public Integer getJPValue() {
        return JPValue;
    }
    
    public void setJPValue(Integer value) {
        JPValue = value;
    }
    
}
