package edu.ncsu.paireval.validator;

import org.apache.tapestry.form.IFormComponent;
import org.apache.tapestry.valid.StringValidator;
import org.apache.tapestry.valid.ValidatorException;

import edu.ncsu.paireval.domain.Course;

public class NewAssignmentValidator extends StringValidator {
    String courseNumber;

    public void setCourseNumber(String courseNumber) {
        this.courseNumber = courseNumber;
    }

    public Object toObject(IFormComponent field, String input)
            throws ValidatorException {
        String assignment = (String) super.toObject(field, input);
        Course course = Course.findByNumber(courseNumber);
        if (course == null) {
            throw new ValidatorException("Course not found");
        }
        if (course.findAssignment(assignment) != null) {
            throw new ValidatorException("Assignment already exists");
        }
        return assignment;
    }
}