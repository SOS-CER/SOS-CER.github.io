package edu.ncsu.paireval.page;

import java.io.Serializable;
import java.util.ArrayList;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.form.IPropertySelectionModel;
import org.apache.tapestry.form.StringPropertySelectionModel;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.component.SectionNumberSelectionModel;
import edu.ncsu.paireval.domain.Assignment;
import edu.ncsu.paireval.domain.Grouping;
import edu.ncsu.paireval.domain.MyerBriggs;
import edu.ncsu.paireval.domain.PartnerPref;
import edu.ncsu.paireval.domain.Registration;
import edu.ncsu.paireval.domain.Role;
import edu.ncsu.paireval.domain.SelfEval;
import edu.ncsu.paireval.domain.User;

public class GroupingPage extends RoleBasedPage {
	static class UserSelection implements Serializable {
		User user;

		boolean selected;

		public String getName() {
			return user.getName();
		}

		public boolean isSelected() {
			return selected;
		}

		public void setSelected(boolean selected) {
			this.selected = selected;
		}
		
		public String getGroupLabel() {
			return user.getGroupLabel();
		}
	}

	String selectedAssignment;

	String selectedSection;

	String selectedGroup;

	UserSelection currentMember, currentNonMember;

	UserSelection[] members;

	UserSelection[] nonMembers;

	public int getAllowedRoles() {
		return Role.INSTRUCTOR | Role.TA;
	}

	public void detach() {
		selectedGroup = selectedAssignment = selectedSection = null;
		members = nonMembers = null;
		super.detach();
	}

	public void assignmentChanged(IRequestCycle cycle) {
	}

	public void memberChanged(IRequestCycle cycle) {
		if (cycle.getRequestContext().getParameter("btnAdd") != null) {
			add();
		}
		if (cycle.getRequestContext().getParameter("btnRemove") != null) {
			remove();
		}
		buildMembers();
		buildNonMembers();
	}

	public void add() {
		for (int i = 0; i < nonMembers.length; i++) {
			if (nonMembers[i].isSelected()) {
				Grouping.createNew(getCurrentCourseNumber(),
						selectedAssignment, selectedGroup, nonMembers[i].user
								.getID());
			}
		}
	}

	public void remove() {
		for (int i = 0; i < members.length; i++) {
			if (members[i].isSelected()) {
				Grouping g = Grouping.find(getCurrentCourseNumber(),
						selectedAssignment, selectedGroup, members[i].user
								.getID());
				if (g != null)
					g.remove();
			}
		}
	}

	public IPropertySelectionModel getSelectableAssignments() {
		Assignment[] assignments = Assignment
				.findByCourse(getCurrentCourseNumber());
		String[] assignmentIDs = new String[assignments.length];
		for (int i = 0; i < assignmentIDs.length; i++) {
			assignmentIDs[i] = assignments[i].getNumber();
		}
		if (selectedAssignment == null && assignmentIDs.length > 0) {
			selectedAssignment = assignmentIDs[0];
		}
		return new StringPropertySelectionModel(assignmentIDs);
	}

	public String getSelectedAssignment() {
		return selectedAssignment;
	}

	public void setSelectedAssignment(String selectedAssignment) {
		this.selectedAssignment = selectedAssignment;
	}

	public IPropertySelectionModel getSelectableSections() {
		User user = getCurrentUser();
		Role role = Role.findByUserCourse(user.getID(),
				getCurrentCourseNumber());
		IPropertySelectionModel ret;
		if (role.hasRole(Role.INSTRUCTOR)) {
			ret = SectionNumberSelectionModel.populate(
					getCurrentCourseNumber(), false);
		} else {
			ret = SectionNumberSelectionModel.populateByTA(
					getCurrentCourseNumber(), user.getID());
		}
		if (ret.getOptionCount() > 0 && selectedSection == null) {
			selectedSection = ret.getValue(0);
		}
		return ret;
	}

	public String getSelectedSection() {
		return selectedSection;
	}

	public void setSelectedSection(String selectedSection) {
		this.selectedSection = selectedSection;
	}

	public IPropertySelectionModel getGroups() {
		Assignment assignment = Assignment.findByNumber(
				getCurrentCourseNumber(), selectedAssignment);
		if (assignment == null) {
			return new StringPropertySelectionModel(new String[0]);
		} else {
			String[] groups = new String[assignment.getGroupNumber()];
			for (int i = 0; i < groups.length; i++) {
				groups[i] = String.valueOf(i + 1);
			}
			if (selectedGroup == null)
				selectedGroup = groups[0];
			return new StringPropertySelectionModel(groups);
		}
	}

	public String getSelectedGroup() {
		return selectedGroup;
	}

	public void setSelectedGroup(String selectedGroup) {
		this.selectedGroup = selectedGroup;
	}

	public UserSelection[] getMembers() {
		if (members == null)
			buildMembers();
		return members;
	}

	void buildMembers() {
		Grouping[] grouping = Grouping.findByGroup(getCurrentCourseNumber(),
				selectedAssignment, selectedGroup);
		UserSelection[] ret = new UserSelection[grouping.length];
		for (int i = 0; i < grouping.length; i++) {
			String studentID = grouping[i].getStudentID();
			MyerBriggs mb = MyerBriggs.findByUser(studentID);
			SelfEval se = SelfEval.findByUser(studentID);

			ret[i] = new UserSelection();
			ret[i].user = User.findByID(studentID);
			
			if (mb != null) {
				ret[i].user.setSI(mb.getSI());
				ret[i].user.setSIvalue(mb.getSIValue().intValue());
			}
			
			if (se != null)
				ret[i].user.setEthic(se.getEthic());
			
		}
		this.members = ret;
	}

	public UserSelection getCurrentMember() {
		return currentMember;
	}

	public void setCurrentMember(UserSelection currentMember) {
		this.currentMember = currentMember;
	}

	public UserSelection[] getNonMembers() {
		if (nonMembers == null)
			buildNonMembers();
		return nonMembers;
	}

	void buildNonMembers() {
		// Non members are the students in the same section, except that:
		// 1. they are a member in some group
		// 2. they are of non-favorable partner of the students in the group
		// 3. someone in the group is a non-favorable partner of them
		// 2 and 3 are described in canWorkWith method.

		String course = getCurrentCourseNumber();
		Registration[] reg = Registration
				.findBySection(course, selectedSection);
		ArrayList ret = new ArrayList();
		for (int i = 0; i < reg.length; i++) {
			String studentID = reg[i].getUserID();
			MyerBriggs mb = MyerBriggs.findByUser(studentID);
			SelfEval se = SelfEval.findByUser(studentID);
			if (ungrouped(studentID) && canWorkWith(studentID)) {
				UserSelection us = new UserSelection();
				us.user = User.findByID(studentID);

				if (mb != null) {
					us.user.setSI(mb.getSI());
					us.user.setSIvalue(mb.getSIValue().intValue());
				}
				
				if (se != null)
					us.user.setEthic(se.getEthic());

				ret.add(us);
			}
		}
		nonMembers = (UserSelection[]) ret
				.toArray(new UserSelection[ret.size()]);
	}

	private boolean ungrouped(String studentID) {
		String group = Grouping.findGroup(getCurrentCourseNumber(),
				selectedAssignment, studentID);
		return group == null;
	}

	private boolean canWorkWith(String studentID) {
		boolean ret = true;
		PartnerPref selfPref = PartnerPref.findOrCreateByUserID(
				getCurrentCourseNumber(), studentID);
		for (int i = 0; i < members.length; i++) {
			String member = members[i].user.getID();
			PartnerPref pref = PartnerPref.findOrCreateByUserID(
					getCurrentCourseNumber(), member);
			ret = ret && !pref.isX(studentID);
			ret = ret && !selfPref.isX(member);
		}
		return ret;
	}

	public void setCurrentNonMember(UserSelection currentNonMember) {

		this.currentNonMember = currentNonMember;
	}

	public UserSelection getCurrentNonMember() {
		return currentNonMember;
	}

}
