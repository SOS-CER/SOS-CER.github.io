package edu.ncsu.paireval.component;

import java.util.ArrayList;

import org.apache.tapestry.form.IPropertySelectionModel;

import edu.ncsu.paireval.domain.*;
import edu.ncsu.paireval.domain.Course;
import edu.ncsu.paireval.domain.Section;

public final class SectionNumberSelectionModel
        implements IPropertySelectionModel {
    Section[] sections;
    
    private SectionNumberSelectionModel() {}
    
    static public SectionNumberSelectionModel populate(
            String courseNumber, boolean allIncluded) {
        Course c = Course.findByNumber(courseNumber);
        SectionNumberSelectionModel ret = new SectionNumberSelectionModel();
        ArrayList sections = new ArrayList();
        if(allIncluded) {
            sections.add(Section.allSectionFor(courseNumber));
        }
        if(c != null){
            Section[] array = c.getSections();
            for (int i = 0; i < array.length; i++) {
                sections.add(array[i]);
            }
        }
        ret.sections = (Section[]) sections.toArray(
                new Section[sections.size()]);
        return ret;
    }
    
    static public SectionNumberSelectionModel populateByTA(
            String courseNumber, String userID) {
        TAAssignment[] assignment = TAAssignment.findByTACourse(
                userID, courseNumber);
        SectionNumberSelectionModel ret = new SectionNumberSelectionModel();
        ret.sections = new Section[assignment.length];
        for (int i = 0; i < assignment.length; i++) {
            ret.sections[i] = Section.findByName(
                    courseNumber, assignment[i].getSectionName());
        }
        return ret;        
    }
    
    public int getOptionCount() {
        return sections.length;
    }

    public Object getOption(int index) {
        return sections[index].getName();
    }

    public String getLabel(int index) {
        return sections[index].getName();
    }

    public String getValue(int index) {
        return sections[index].getName();
    }

    public Object translateValue(String value) {
        return value;
    }

}
