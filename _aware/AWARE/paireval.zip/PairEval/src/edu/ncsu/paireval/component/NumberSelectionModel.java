package edu.ncsu.paireval.component;

import org.apache.tapestry.form.IPropertySelectionModel;

public class NumberSelectionModel implements IPropertySelectionModel {
    int min, max;
    
    public static NumberSelectionModel populate(int min, int max) {
        NumberSelectionModel model = new NumberSelectionModel();
        model.max = max;
        model.min = min;
        return model;
    }

    public int getOptionCount() {
        return max - min + 1;
    }

    public Object getOption(int index) {
        return new Integer(index + min);
    }

    public String getLabel(int index) {
        return getOption(index).toString();
    }

    public String getValue(int index) {
        return getLabel(index);
    }

    public Object translateValue(String value) {
        return Integer.valueOf(value);
    }

}
