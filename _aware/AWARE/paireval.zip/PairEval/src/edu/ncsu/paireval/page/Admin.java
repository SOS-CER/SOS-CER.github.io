package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;

import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.domain.User;

public class Admin  extends ProtectedPage {
    String userID, firstName, lastName, email, password;
    String resetPasswdMessage;
    String addInstructorMessage;
    String resetID, newPassword;
    boolean instructorChecked, adminChecked;
    
    private void resetAddInstructorFields() {
        email = password = lastName = firstName = userID = null;
        instructorChecked = adminChecked = false;
    }

    public boolean isAccessible() {
        return getCurrentUser().isAdmin();
    }
    
    public void detach() {
        resetAddInstructorFields();
        addInstructorMessage = null;
        resetPasswdMessage = null;
        super.detach();
    }
    
    public void addInstructor(IRequestCycle cycle) {
        if(isAddInstructorInputCorrect()) {
            if(instructorChecked || adminChecked) {
                User user = User.create(userID);
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setPassword(password);
                user.setEmail(email);
                if(instructorChecked) user.addRole(User.INSTRUCTOR);
                if(adminChecked) user.addRole(User.ADMIN);
                user.save();
                addInstructorMessage = "New instructor/admin added.";
                resetAddInstructorFields();
            } else {
                addInstructorMessage = "Please select at least one role";
            }
        } else {
            addInstructorMessage = "Please input correct information.";
        }
    }
    
    public void resetPasswd(IRequestCycle cycle) {
        if(isResetPassedInputCorrect()) {
            User user = User.findByID(resetID);
            if(user == null) {
                resetPasswdMessage = "User ID not found.";
            }
            user.setPassword(newPassword);
            user.save();
            resetPasswdMessage = "Password for " + resetID + 
                    " is set to " + newPassword;
        } else {
            resetPasswdMessage = "Please input correct information.";
        }
    }
    
    private boolean isResetPassedInputCorrect() {
        return resetID != null && newPassword != null;
    }

    private boolean isAddInstructorInputCorrect() {
        return email != null &&
                password != null &&
                lastName != null &&
                firstName != null &&
                userID != null;
    }
    
    public String getUserID() {
        return userID;
    }
    
    public void setUserID(String userID) {
        this.userID = userID;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getAddInstructorMessage() {
        return addInstructorMessage;
    }
    
    public void setAddInstructorMessage(String addInstructorMessage) {
        this.addInstructorMessage = addInstructorMessage;
    }
    
    public String getResetPasswdMessage() {
        return resetPasswdMessage;
    }
    
    public void setResetPasswdMessage(String resetPasswdMessage) {
        this.resetPasswdMessage = resetPasswdMessage;
    }
    
    public String getResetID() {
        return resetID;
    }
    
    public void setResetID(String resetID) {
        this.resetID = resetID;
    }
    
    public String getNewPassword() {
        return newPassword;
    }
    
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
    
    public boolean isInstructorChecked() {
        return instructorChecked;
    }
    
    public void setInstructorChecked(boolean instructorChecked) {
        this.instructorChecked = instructorChecked;
    }
    
    public boolean isAdminChecked() {
        return adminChecked;
    }
    
    public void setAdminChecked(boolean adminChecked) {
        this.adminChecked = adminChecked;
    }
}
