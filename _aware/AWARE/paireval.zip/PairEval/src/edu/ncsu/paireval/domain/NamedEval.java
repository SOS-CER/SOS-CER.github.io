package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

public class NamedEval implements Serializable{
    static final String[] CcyValues = {"Better" ,"OK", "Worse"};
    static final String[] CtyValues = {"Y", "OK", "N"};    

    String name, partnerID, partnerMail;
    int o, ccy, cty;
    String comment;
    
    public static NamedEval[] find(
            String course, String user,
            String assignment, int number, boolean selfIncluded) {
        ArrayList ret = new ArrayList();
        String sql = "select partner, email, first_name, last_name, overall, q6, q7, comment" +
                " from usr, eval where user = ? and partner = id and" +
                " course = ? and assignment = ? and number = ? ";
        if (!selfIncluded) {
            sql += "and user <> partner ";
        }
        sql += "order by partner";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, user);
            stmnt.setString(2, course);
            stmnt.setString(3, assignment);
            stmnt.setInt(4, number);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                NamedEval eval = new NamedEval();
                eval.name = rst.getString("first_name") +
                        " " + rst.getString("last_name");
                eval.partnerID = rst.getString("partner");
                eval.partnerMail = rst.getString("email");
                eval.o = rst.getInt("overall");
                eval.ccy = rst.getInt("q6");
                eval.cty = rst.getInt("q7");
                eval.comment = rst.getString("comment");
                ret.add(eval);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (NamedEval[])ret.toArray(new NamedEval[ret.size()]);
    }

    public String getName() {
        return name;
    }
    
    public String getPartnerID() {
    	return partnerID;
    }
    
    public String getPartnerMail() {
    	return partnerMail;
    }

    public String getPartnerMailURL() {
    	return "mailto:"+partnerMail;
    }
    
    public int getOverall() {
        return o;
    }
    
    public String getCcy() {
        return CcyValues[ccy];
    }
    
    public int getCcyValue() {
        return ccy;
    }
    
    public String getCty() {
        return CtyValues[cty];
    }
    
    public int getCtyValue() {
        return cty;
    }
    
    public String getComment() {
        return comment;
    }
}
