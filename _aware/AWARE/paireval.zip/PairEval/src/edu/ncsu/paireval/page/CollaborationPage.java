package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;

import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.domain.Collaboration;

public class CollaborationPage extends ProtectedPage implements
		PageRenderListener {
	public final static int[] SCALE = { 1, 2, 3, 4, 5, 6, 7 };

	public final int number = 2;

	int responsibility, savesTime, preferToPair, largeProjects, soloLearning,
			organized, advice, codingErrors, procrastinate, preferAlone,
			newIdeas, badPartner, logicErrors, commute;

	String plans, major;

	public void detach() {
		responsibility = 0;
		savesTime = 0;
		preferToPair = 0;
		largeProjects = 0;
		soloLearning = 0;
		organized = 0;
		advice = 0;
		codingErrors = 0;
		procrastinate = 0;
		preferAlone = 0;
		newIdeas = 0;
		badPartner = 0;
		logicErrors = 0;
		commute = 0;
		plans = null;
		major = null;
		super.detach();
	}

	public boolean isAccessible() {
		return getCurrentUser().isStudent();
	}

	public void pageBeginRender(PageEvent event) {
		if (!event.getRequestCycle().isRewinding()) {
			String id = getCurrentUser().getID();
			Collaboration eval = Collaboration.findByUserNum(id, number);
			if (eval != null) {
				responsibility = eval.getResponsibility();
				savesTime = eval.getSavesTime();
				preferToPair = eval.getPreferToPair();
				largeProjects = eval.getLargeProjects();
				soloLearning = eval.getSoloLearning();
				organized = eval.getOrganized();
				advice = eval.getAdvice();
				codingErrors = eval.getCodingErrors();
				procrastinate = eval.getProcrastinate();
				preferAlone = eval.getPreferAlone();
				newIdeas = eval.getNewIdeas();
				badPartner = eval.getBadPartner();
				logicErrors = eval.getLogicErrors();
				commute = eval.getCommute();
				plans = eval.getPlans();
				major = eval.getMajor();
			}
		}
	}

	public void save(IRequestCycle cycle) {
		String id = getCurrentUser().getID();
		Collaboration eval = Collaboration.findOrCreateByUserNum(id, number);

		eval.setResponsibility(responsibility);
		eval.setSavesTime(savesTime);
		eval.setPreferToPair(preferToPair);
		eval.setLargeProjects(largeProjects);
		eval.setSoloLearning(soloLearning);
		eval.setOrganized(organized);
		eval.setAdvice(advice);
		eval.setCodingErrors(codingErrors);
		eval.setProcrastinate(procrastinate);
		eval.setPreferAlone(preferAlone);
		eval.setNewIdeas(newIdeas);
		eval.setBadPartner(badPartner);
		eval.setLogicErrors(logicErrors);
		eval.setCommute(commute);
		eval.setPlans(plans);
		eval.setMajor(major);

		eval.save();
		MessagePage page = (MessagePage) cycle.getPage("MessagePage");
		page
				.setDisplayMessage("You have finished the collaboration experiences evaluation. Thank you.");
		page.setTaskTitle("Thanks");
		cycle.activate(page);
	}

	public int getResponsibility() {
		return responsibility;
	}

	public void setResponsibility(int ethic) {
		this.responsibility = ethic;
	}

	public int getSavesTime() {
		return savesTime;
	}

	public void setSavesTime(int esteem) {
		this.savesTime = esteem;
	}

	public int getPreferToPair() {
		return preferToPair;
	}

	public void setPreferToPair(int timeMng) {
		this.preferToPair = timeMng;
	}

	public int getLargeProjects() {
		return largeProjects;
	}

	public void setLargeProjects(int speed) {
		this.largeProjects = speed;
	}

	public int getSoloLearning() {
		return soloLearning;
	}

	public void setSoloLearning(int ps) {
		this.soloLearning = ps;
	}

	public int getOrganized() {
		return organized;
	}

	public void setOrganized(int interest) {
		this.organized = interest;
	}

	public int getAdvice() {
		return advice;
	}

	public void setcoding(int coding) {
		this.advice = coding;
	}

	public int getCodingErrors() {
		return codingErrors;
	}

	public void setCodingErrors(int codingErrors) {
		this.codingErrors = codingErrors;
	}

	public int getLogicErrors() {
		return logicErrors;
	}

	public void setLogicErrors(int logicErrors) {
		this.logicErrors = logicErrors;
	}

	public int getNewIdeas() {
		return newIdeas;
	}

	public void setNewIdeas(int newIdeas) {
		this.newIdeas = newIdeas;
	}

	public int getPreferAlone() {
		return preferAlone;
	}

	public void setPreferAlone(int preferAlone) {
		this.preferAlone = preferAlone;
	}

	public int getProcrastinate() {
		return procrastinate;
	}

	public void setProcrastinate(int procrastinate) {
		this.procrastinate = procrastinate;
	}

	public int getBadPartner() {
		return badPartner;
	}

	public void setBadPartner(int badPartner) {
		this.badPartner = badPartner;
	}

	public int getNumber() {
		return number;
	}

	public void setAdvice(int advice) {
		this.advice = advice;
	}

	public int getCommute() {
		return commute;
	}

	public void setCommute(int commute) {
		this.commute = commute;
	}

	public String getPlans() {
		return plans;
	}

	public void setPlans(String plans) {
		this.plans = plans;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}
}
