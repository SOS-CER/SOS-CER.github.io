package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.html.BasePage;

public class Secret extends BasePage {
    public void formSubimtted(IRequestCycle cycle) {
//        User[] users = User.findAll();
//        for (int i = 0; i < users.length; i++) {
//            users[i].setPassword(users[i].getEmail());
//            users[i].save();
//        }
    }
}
