package edu.ncsu.paireval.page;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.Assignment;
import edu.ncsu.paireval.domain.AssignmentReviewPair;
import edu.ncsu.paireval.domain.NamedEval;
import edu.ncsu.paireval.domain.Role;
import edu.ncsu.paireval.domain.Section;
import edu.ncsu.paireval.domain.User;
import edu.ncsu.paireval.domain.Registration;

public class EvalReportResult extends RoleBasedPage {
    String course, assignment, section;
    boolean selfIncluded;
    Assignment[] assignments;
    User currentStudent;
    AssignmentReviewPair currentAssignment;
    NamedEval currentEval;
    int number;
    Section currentStudentSection;
    
    public int getAllowedRoles() {
        return Role.INSTRUCTOR | Role.TA;
    }
    
    public void detach() {
        course = assignment = section = null;
        selfIncluded = false;
        assignments = null;
        super.detach();
    }
    
    public String getCourse() {
        return course;
    }
   
    public void setCourse(String course) {
        this.course = course;
    }
    
    public String getAssignment() {
        return assignment;
    }
    
    public void setAssignment(String assignment) {
        this.assignment = assignment;
    }
    
    public String getSection() {
        return section;
    }
    
    public void setSection(String section) {
        this.section = section;
    }
    
    
    public boolean isSelfIncluded() {
        return selfIncluded;
    }
    
    public void setSelfIncluded(boolean selfIncluded) {
        this.selfIncluded = selfIncluded;
    }

    public User[] getStudents() {
        if(section.equals(Section.NAME_ALL)) {
            return User.findStudent(course);
        } else {
            return User.findStudent(course, section);
        }
    }
    
    public User getCurrentStudent() {
        return currentStudent;
    }
   
    public void setCurrentStudent(User currentStudent) {
        this.currentStudent = currentStudent;
    }

    public String getCurrentStudentSection() {
    	Section aSection = Registration.findSectionByStudent(currentStudent.getID(),getCourse());
    	return aSection.getName();
    }
    
    public void setCurrentStudentSection(Section section) {
    	this.currentStudentSection = section;
    }
    
    public AssignmentReviewPair[] getAssignments() {
        if(assignments == null) assignments = Assignment.findByCourse(course);
        Assignment selectedAssignment = Assignment.findByNumber(course,assignment);
        
        int lastDesiredAssignment = assignments.length;
        for (int i = 0; i < assignments.length; i++) {
        	if(assignments[i].equals(selectedAssignment))
        		lastDesiredAssignment = i + 1; 
        }
        
        int totalReviews = 0;
        for (int i = 0; i < lastDesiredAssignment; i++) {
        	totalReviews += assignments[i].getReviewNumber();
        }
        AssignmentReviewPair[] ret = new AssignmentReviewPair[totalReviews];
        int counter = 0;
        for (int i = 0; i < lastDesiredAssignment; i++) {
            for(int j = 0; j < assignments[i].getReviewNumber(); j++) {
                ret[counter++] = new AssignmentReviewPair(
                        assignments[i], j+1);
            }
        }
        return ret;
    }
    
    public AssignmentReviewPair getCurrentAssignment() {
        return currentAssignment;
    }
    
    public void setCurrentAssignment(AssignmentReviewPair assignment) {
        this.currentAssignment = assignment;
    }
    
    public String getAssignmentNameClass() {
        return isSelectedAssignment()? "dashtablehead" : "dashtableheadWhite";
    }
    
    public NamedEval[] getEvals() {
        return NamedEval.find(course, currentStudent.getID(),
                currentAssignment.getAssignment().getNumber(),
                currentAssignment.getReviewNumber(), selfIncluded);
    }
    
    public NamedEval getCurrentEval() {
        return currentEval;
    }
    
    public void setCurrentEval(NamedEval eval) {
        this.currentEval = eval;
    }
    
    public boolean isSelectedAssignment() {
        Assignment a = currentAssignment.getAssignment();
        return (a.getNumber().equals(assignment) &&
                currentAssignment.getReviewNumber() == number);
    }
    
    public String getOverallClass() {
        if(currentEval.getOverall() < 6) {
            return "dashtableRed";
        }
        if(currentEval.getOverall() >7) {
            return "dashtableGreen";
        }
        return "dashtable";
    }
    
    public String getCcyClass() {
        if(currentEval.getCcyValue() > 1) {
            return "dashtableRed";
        }
        return "dashtable";
    }

    public String getCtyClass() {
        String ret;
        if(currentEval.getCtyValue() > 1) {
            ret = "dashtableRed";
        } else {
            ret = "dashtable";
        }
        if(!isSelectedAssignment()) {
            ret += "R";
        }
        return ret;
    }
    
    public int getNumber() {
        return number;
    }
    
    public void setNumber(int number) {
        this.number = number;
    }
    
    public String getCurrentAssignmentName() {
        return currentAssignment.getAssignment().getNumber() +
                " #" + currentAssignment.getReviewNumber();
    }
}
