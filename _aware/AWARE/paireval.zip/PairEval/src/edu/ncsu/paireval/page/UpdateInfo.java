package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;

import edu.ncsu.paireval.Visit;
import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.domain.User;

public class UpdateInfo extends ProtectedPage {
    transient String origPassword, newPassword, retype;
    String lastName, firstName, email;
    
    public void detach() {
        origPassword = newPassword = retype = null;
        email = firstName = lastName = null;
        super.detach();
    }
    
    public boolean isAccessible() {
        return true;
    }
    
    public String getOrigPassword() {
        return origPassword;
    }
    
    public void setOrigPassword(String origPassword) {
        this.origPassword = origPassword;
    }
    
    public String getNewPassword() {
        return newPassword;
    }
    
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
    
    public String getRetype() {
        return retype;
    }
    
    public void setRetype(String retype) {
        this.retype = retype;
    }
    
    public String getUserID() {
        return getCurrentUser().getID();
    }
    
    public String getLastName() {
        return getCurrentUser().getLastName();
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getFirstName() {
        return getCurrentUser().getFirstName();
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getEmail() {
        return getCurrentUser().getEmail();
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public void changePassword(IRequestCycle cycle) {
        if(origPassword != null && retype != null) {
            Visit visit = (Visit)getVisit();
            User user = visit.getUser();
            user.setPassword(newPassword);
            user.save();
            
            MessagePage page = (MessagePage)cycle.getPage("MessagePage");
            page.setDisplayMessage("Password has been changed successfully");
            page.setTaskTitle("Change Password");
            cycle.activate(page);
        }
    }
    
    public void updateInfo(IRequestCycle cycle) {
        if(checkUpdateFields()) {
            User user = getCurrentUser();
            user.setLastName(lastName);
            user.setFirstName(firstName);
            user.setEmail(email);
            user.save();
        }
    }
    
    private boolean checkUpdateFields() {
        return lastName != null &&
                firstName != null &&
                email != null;
    }
}
