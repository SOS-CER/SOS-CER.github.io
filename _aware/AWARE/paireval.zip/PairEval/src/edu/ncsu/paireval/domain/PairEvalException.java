package edu.ncsu.paireval.domain;

public class PairEvalException extends RuntimeException {
    public PairEvalException(String message) {
        super(message);
    }
}
