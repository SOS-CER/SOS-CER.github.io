package edu.ncsu.paireval.component;

import org.apache.tapestry.BaseComponent;
import org.apache.tapestry.IBinding;

import edu.ncsu.paireval.Util;

public class ErrorText extends BaseComponent {
    public String getText() {
        IBinding textBinding = getBinding("text");
        if(textBinding == null) return "";
        return textBinding.getString();
    }

    public boolean isError() {
        String text = getText();
        return !Util.isEmptyString(text);
    }
}
