package edu.ncsu.paireval;

public class Util {
    public static boolean isEmptyString(String someString) {
        if(someString == null) return true;
        someString = someString.trim();
        if(someString.equals("")) return true;
        return false;
    }
    
    public static java.sql.Date convert(java.util.Date date) {
        java.sql.Date ret = new java.sql.Date(date.getTime());
        return ret;
    }
}
