package edu.ncsu.paireval.component;

import org.apache.tapestry.BaseComponent;
import org.apache.tapestry.IBinding;

public class Border extends BaseComponent {
    public String getTitle() {
        IBinding titleBinding = getBinding("title");
        return titleBinding.getString();
    }
    
    public String getPageTitle() {
        IBinding pageTitleBinding = getBinding("pageTitle");
        if(pageTitleBinding == null) return "No Title";
        return "Pair Eval -- " + pageTitleBinding.getString();
    }
}
