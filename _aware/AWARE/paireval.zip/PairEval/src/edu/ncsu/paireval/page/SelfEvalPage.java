package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;

import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.domain.SelfEval;

public class SelfEvalPage extends ProtectedPage implements PageRenderListener {
	public final static int[] SCALE = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

	int ethic, esteem, timeMng, speed, problemSolving, interest, coding,
			experience, helping, testing, roadblock;
	
	String impression;

	public void detach() {
		ethic = 0;
		esteem = 0;
		timeMng = 0;
		speed = 0;
		problemSolving = 0;
		interest = 0;
		coding = 0;
		experience = 0;
		helping = 0;
		testing = 0;
		roadblock = 0;
		super.detach();
	}

	public boolean isAccessible() {
		return getCurrentUser().isStudent();
	}

	public void pageBeginRender(PageEvent event) {
		if (!event.getRequestCycle().isRewinding()) {
			String id = getCurrentUser().getID();
			SelfEval eval = SelfEval.findByUser(id);
			if (eval != null) {
				ethic = eval.getEthic();
				esteem = eval.getEsteem();
				timeMng = eval.getTimeMng();
				speed = eval.getSpeed();
				problemSolving = eval.getProblemSolving();
				interest = eval.getInterest();
				coding = eval.getCoding();
				experience = eval.getExperience();
				helping = eval.getHelping();
				testing = eval.getTesting();
				roadblock = eval.getRoadblock();
				impression = eval.getImpression();

			}
		}
	}

	public void save(IRequestCycle cycle) {
		String id = getCurrentUser().getID();
		SelfEval eval = SelfEval.findOrCreateByUser(id);
		eval.setEthic(ethic);
		eval.setEsteem(esteem);
		eval.setTimeMng(timeMng);
		eval.setSpeed(speed);
		eval.setProblemSolving(problemSolving);
		eval.setInterest(interest);
		eval.setCoding(coding);
		eval.setExperience(experience);
		eval.setHelping(helping);
		eval.setTesting(testing);
		eval.setRoadblock(roadblock);
		eval.setImpression(impression);
		eval.save();
		cycle.activate("Collaboration");
	}

	public int getEthic() {
		return ethic;
	}

	public void setEthic(int ethic) {
		this.ethic = ethic;
	}

	public int getEsteem() {
		return esteem;
	}

	public void setEsteem(int esteem) {
		this.esteem = esteem;
	}

	public int getTimeMng() {
		return timeMng;
	}

	public void setTimeMng(int timeMng) {
		this.timeMng = timeMng;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public int getProblemSolving() {
		return problemSolving;
	}

	public void setProblemSolving(int ps) {
		this.problemSolving = ps;
	}

	public int getInterest() {
		return interest;
	}

	public void setInterest(int interest) {
		this.interest = interest;
	}

	public int getCoding() {
		return coding;
	}

	public void setCoding(int coding) {
		this.coding = coding;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getHelping() {
		return helping;
	}

	public void setHelping(int helping) {
		this.helping = helping;
	}

	public int getRoadblock() {
		return roadblock;
	}

	public void setRoadblock(int roadblock) {
		this.roadblock = roadblock;
	}

	public int getTesting() {
		return testing;
	}

	public void setTesting(int testing) {
		this.testing = testing;
	}

	public String getImpression() {
		return impression;
	}

	public void setImpression(String impression) {
		this.impression = impression;
	}
}
