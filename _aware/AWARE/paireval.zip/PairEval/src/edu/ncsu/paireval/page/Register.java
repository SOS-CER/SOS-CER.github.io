package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.html.BasePage;

import edu.ncsu.paireval.Util;
import edu.ncsu.paireval.Visit;
import edu.ncsu.paireval.domain.User;

public class Register extends BasePage {
    String error;
    String userID;
    String password;
    String retype;
    String lastName;
    String firstName;
    String email;
    
    public void detach() {
        resetFields();
        error = null;
        super.detach();
    }
    
    private void resetFields() {
        retype = password = userID = null;
        email = firstName = lastName = null;
    }
    
    public boolean checkFields() {
        return !(Util.isEmptyString(userID) ||
                Util.isEmptyString(password) ||
                Util.isEmptyString(retype) ||
                Util.isEmptyString(lastName) ||
                Util.isEmptyString(firstName) ||
                Util.isEmptyString(email));
    }

    public void register(IRequestCycle cycle) {
        if(checkFields()) {
            User user = User.create(userID);
            user.setEmail(email);
            user.setFirstName(firstName);
            user.setLastName(lastName);
            user.setPassword(password);
            user.addRole(User.STUDENT);
            user.save();
            user.authenticate(password);
            Visit visit = (Visit)getVisit();
            visit.setUser(user);
            visit.setCurrentCourseNumber(null);
            cycle.activate("Welcome");
        } else {
            error = "Please enter correct information.";
        }
    }
    
    public String getError() {
        return error;
    }
    
    public String getUserID() {
        return userID;
    }
    
    public void setUserID(String userID) {
        this.userID = userID;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getRetype() {
        return retype;
    }
    
    public void setRetype(String retype) {
        this.retype = retype;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
}
