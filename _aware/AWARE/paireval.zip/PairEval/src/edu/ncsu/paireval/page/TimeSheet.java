package edu.ncsu.paireval.page;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.Role;

public class TimeSheet extends RoleBasedPage {
    public int getAllowedRoles() {
        return Role.STUDENT;
    }
}
