package edu.ncsu.paireval;

import java.io.Serializable;

import edu.ncsu.paireval.domain.User;

public class Visit implements Serializable {
    User user = null;
    String currentCourseNumber = null;
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public User getUser() {
        return user;
    }
    
    public boolean isLoggedIn() {
        return user != null && user.isAuthenticated();
    }
    
    public String getCurrentCourseNumber() {
        return currentCourseNumber;
    }
    
    public void setCurrentCourseNumber(String currentCourseNumber) {
        this.currentCourseNumber = currentCourseNumber;
    }
}
