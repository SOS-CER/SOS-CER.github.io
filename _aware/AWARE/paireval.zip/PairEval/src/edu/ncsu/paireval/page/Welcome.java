package edu.ncsu.paireval.page;

import edu.ncsu.paireval.component.ProtectedPage;

public class Welcome extends ProtectedPage {
    public boolean isAccessible() {
        return true;
    }
}
