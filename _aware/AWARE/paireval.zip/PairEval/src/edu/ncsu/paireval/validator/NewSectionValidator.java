package edu.ncsu.paireval.validator;

import org.apache.tapestry.form.IFormComponent;
import org.apache.tapestry.valid.StringValidator;
import org.apache.tapestry.valid.ValidatorException;

import edu.ncsu.paireval.domain.Course;

public class NewSectionValidator extends StringValidator{
    String courseNumber;
    
    public void setCourse(String courseNumber) {
        this.courseNumber = courseNumber;
    }
    
    public Object toObject(IFormComponent field, String input)
            throws ValidatorException {
        String sectionNumber = (String) super.toObject(field, input);
        Course course = Course.findByNumber(courseNumber);
        if(course == null) {
            throw new ValidatorException("Course not found.");
        }
        if(course.findSection(sectionNumber) != null) {
            throw new ValidatorException("Section already exists.");
        }
        return sectionNumber;
    }

}