package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.html.BasePage;

import edu.ncsu.paireval.Visit;
import edu.ncsu.paireval.domain.PairEvalException;
import edu.ncsu.paireval.domain.User;

public class Login extends BasePage {
    String userID, password, error;
    
    public void detach() {
        userID = "";
        password = "";
        error = "";
        super.detach();
    }
    
    public void formSubmit(IRequestCycle requestCycle) {
        try{
            User user = User.findUser(userID, password);
            if (user == null) {
                error = "User ID and password do not match. Try again.";
                return;
            } else {
                Visit visit = (Visit)getVisit();
                visit.setUser(user);
                visit.setCurrentCourseNumber(null);
            }
            requestCycle.activate("Welcome");
        } catch (PairEvalException pee) {
            error = pee.getMessage();
        }
    }
    
    public void setUserID(String userID) {
        this.userID = userID.trim();
    }
    
    public String getUserID() {
        return userID;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getPassword() {
        return "";
    }
    
    public String getError() {
        return error;
    }
}
