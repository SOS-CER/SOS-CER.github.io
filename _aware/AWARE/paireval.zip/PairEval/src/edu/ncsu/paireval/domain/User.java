package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Hex;

import edu.ncsu.paireval.database.DBConnection;

public class User implements Serializable {
    //base roles
    public static final int STUDENT = 1;
    public static final int INSTRUCTOR = 4;
    public static final int ADMIN = 8;

    public static User NULL_USER = new User() {
        public String getID() {
            return "NA";
        }
        
        public String getName() {
            return "NA";
        }
        
        public String getEmail() {
            return "NA";
        }
    };
    
    int baseRole;

    boolean authenticated;

    String id, firstName, lastName, password, email;
    
    String SI = null;
    
    int SIvalue = -1, ethic = -1;
    
    public static User findUser(String userID, String password) {
        User user = findByID(userID);
        if (user != null) {
            if (user.authenticate(password)) {
                return user;
            }
        }
        return null;
    }

    private static void populateToList(
            List ret, ResultSet rst) throws SQLException {
        while (rst.next()) {
            User user = new User();
            user.id = rst.getString("id");
            user.firstName = rst.getString("first_name");
            user.lastName = rst.getString("last_name");
            user.email = rst.getString("email");
            user.baseRole = rst.getInt("base_role");
            ret.add(user);
        }
    }
    
    public static User[] findStudent(String courseNumber) {
        ArrayList ret = new ArrayList();
        String sql = "select * from usr, registration" +
                " where id = user and course = ? order by last_name;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseNumber);
            rst = stmnt.executeQuery();
            populateToList(ret, rst);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (User[]) ret.toArray(new User[ret.size()]);
    }

    public static User[] findStudent(
            String courseNumber, String sectionNumber) {
        ArrayList ret = new ArrayList();
        String sql = "select * from usr, registration" +
                " where id = user and course = ? and section_name = ?" +
                " order by last_name;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, sectionNumber);
            rst = stmnt.executeQuery();
            populateToList(ret, rst);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (User[]) ret.toArray(new User[ret.size()]);
    }

    public User[] getPartners(String courseNumber, String assignment) {
        ArrayList ret = new ArrayList();
        String sql = "select usr.id, usr.first_name, usr.last_name, usr.email, usr.base_role"
                + " from usr, grouping as s, grouping as t"
                + " where usr.id = t.user "
                + "and s.course = ? "
                + "and s.assignment = ? "
                + "and s.user = ? "
                + "and s.course = t.course "
                + "and s.assignment = t.assignment "
                + "and s.group_number = t.group_number "
                + "and t.user <> s.user;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, assignment);
            stmnt.setString(3, id);
            rst = stmnt.executeQuery();
            populateToList(ret, rst);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (User[]) ret.toArray(new User[ret.size()]);
    }

    public User[] getClassmates(String courseID) {
        Section sec = Registration.findSectionByStudent(id, courseID);
        ArrayList ret = new ArrayList();
        String sql = "select id, first_name, last_name, email, base_role"
                + " from usr, registration"
                + " where registration.user = usr.id "
                + "and registration.course = ? "
                + "and registration.section_name = ? " + "and id <> ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseID);
            stmnt.setString(2, sec.getName());
            stmnt.setString(3, id);
            rst = stmnt.executeQuery();
            populateToList(ret, rst);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (User[]) ret.toArray(new User[ret.size()]);
    }

    public static User findByID(String id) {
        User user = new User();
        String sql = "select * from usr where id = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                user.id = rst.getString("id");
                user.setEmail(rst.getString("email"));
                user.setFirstName(rst.getString("first_name"));
                user.setLastName(rst.getString("last_name"));
                user.baseRole = rst.getInt("base_role");
            } else {
                user = null;
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return user;
    }
    
    public static User[] findAll() {
        ArrayList ret = new ArrayList();
        String sql = "select * from usr;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            rst = stmnt.executeQuery();
            populateToList(ret, rst);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (rst != null)
                    rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return (User[]) ret.toArray(new User[ret.size()]);
    }

    public static User create(String id) {
        User user = new User();
        user.id = id;
        String sql = "insert into usr (id) values (?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, id);
            stmnt.execute();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return user;
    }

    public boolean authenticate(String password) {
        authenticated = matchPassword(password);
        return authenticated;
    }

    public boolean matchPassword(String password) {
        String sqlOrigPass = "select password from usr where id = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmntOrig = ctn.getStatement(sqlOrigPass);
        ResultSet rstOrig = null;
        try {
            stmntOrig.setString(1, id);
            rstOrig = stmntOrig.executeQuery();
            rstOrig.next();
            String orig = rstOrig.getString(1);
            if(orig == null) return true;
            String in = encodePassword(password);
            return orig.equals(in);
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return false;
        } finally {
            try {
                if (rstOrig != null)
                    rstOrig.close();
            } catch (SQLException ignored) {
            }
            try {
                if (stmntOrig != null)
                    stmntOrig.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public String getID() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void addRole(int role) {
        baseRole |= role;
    }

    public void removeRole(int role) {
        baseRole &= (~role);
    }

    public boolean hasRole(int role) {
        int result = role & baseRole;
        return result != 0;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void save() {
        StringBuffer sql = new StringBuffer();
        sql.append("update usr set ").append("first_name = ?, ").append(
                "last_name = ?, ").append("password = ?, ").append(
                "email = ?, ").append("base_role = ? ").append("where id = ?");

        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql.toString());
        try {
            stmnt.setString(1, firstName);
            stmnt.setString(2, lastName);
            stmnt.setString(3, encodePassword(password));
            stmnt.setString(4, email);
            stmnt.setInt(5, baseRole);
            stmnt.setString(6, id);
            stmnt.execute();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public void addRole(String course, int roleID) {
        Role role = Role.findOrCreate(id, course);
        role.addRole(roleID);
        role.save();
    }

    public void removeRole(String course, int roleID) {
        Role role = Role.findByUserCourse(id, course);
        if (role != null) {
            role.removeRole(roleID);
            role.save();
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String[] getSelectableCourseNumbers() {
        Role[] roles = Role.findByUserCourse(id);
        String[] ret = new String[roles.length];
        for (int i = 0; i < roles.length; i++) {
            ret[i] = roles[i].getCourse();
        }
        return ret;
    }

    public int getRoles(String courseNumber) {
        Role role = Role.findByUserCourse(id, courseNumber);
        if (role == null)
            return 0;
        return role.getRoleID();
    }

    public boolean isAuthenticated() {
        return authenticated;
    }

    public boolean isAdmin() {
        return hasRole(ADMIN);
    }

    public boolean isInstructor() {
        return hasRole(INSTRUCTOR);
    }

    public boolean isStudent() {
        return hasRole(STUDENT);
    }

    public void remove() {
        String sql = "delete from usr where id = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, id);
            stmnt.execute();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if (stmnt != null)
                    stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public boolean equals(Object obj) {
        if (obj instanceof User) {
            User u = (User) obj;
            return u.id.equals(this.id);
        } else {
            return false;
        }
    }

    public int hashCode() {
        if (id == null)
            return 0;
        return id.hashCode();
    }

    public String getName() {
        return getFirstName() + " " + getLastName();
    }

    public static String encodePassword(String clearTextPassword)
            throws PairEvalException {
        if(clearTextPassword == null) clearTextPassword = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(clearTextPassword.getBytes());
            return String.valueOf(Hex.encodeHex(md.digest()));
        } catch (NoSuchAlgorithmException e) {
            throw new PairEvalException(e.getMessage());
        }
    }
    
    public String getMailURL() {
        return "mailto:" + email;
    }

	public int getEthic() {
		return ethic;
	}

	public void setEthic(int ethic) {
		this.ethic = ethic;
	}

	public String getSI() {
		return SI;
	}

	public void setSI(String si) {
		SI = si;
	}

	public int getSIvalue() {
		return SIvalue;
	}

	public void setSIvalue(int ivalue) {
		SIvalue = ivalue;
	}
	
	public String getGroupLabel() {
		String label = getName() + " -- [";
		
		if (getSI() != null) {
			label = label + getSI() + ": " + getSIvalue();
			if (getEthic() != -1)
				label = label + ", ";
		}
		
		if(getEthic() != -1) 
			label = label + "Ethic: " + getEthic();
			
		label = label + "]";
		return label;
	}

}