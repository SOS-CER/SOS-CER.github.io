package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;

import edu.ncsu.paireval.Visit;
import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.domain.LearnStyle;
import edu.ncsu.paireval.domain.User;

public class WriteLearningStyles extends ProtectedPage
        implements PageRenderListener{
    public final static Integer N11 = new Integer(-11);
    public final static Integer N9 = new Integer(-9);
    public final static Integer N7 = new Integer(-7);
    public final static Integer N5 = new Integer(-5);
    public final static Integer N3 = new Integer(-3);
    public final static Integer N1 = new Integer(-1);
    public final static Integer P1 = new Integer(1);
    public final static Integer P3 = new Integer(3);
    public final static Integer P5 = new Integer(5);
    public final static Integer P7 = new Integer(7);
    public final static Integer P9 = new Integer(9);
    public final static Integer P11 = new Integer(11);
    
    Integer ref, inte, vrb, glo;
    boolean completed;
    String error;
    
    public void detach() {
        ref = inte = vrb = glo = null;
        error = null;
        super.detach();
    }
    
    public void pageBeginRender(PageEvent event) {
        User user = getUser();
        LearnStyle style = LearnStyle.findByStudentID(user.getID());
        if(style == null) {
            completed = false;
        } else {
            ref = style.getRef();
            inte = style.getInte();
            vrb = style.getVrb();
            glo = style.getGlo();
            completed = true;
        }
    }

    public boolean isAccessible() {
        return getCurrentUser().isStudent();
    }

    public void formSubmit(IRequestCycle cycle) {
        User user = getUser();
        LearnStyle style = LearnStyle.findByStudentID(user.getID());
        if(style != null) {
            cycle.activate("SelfEval");
        } else {
            if(answerCompleted()) {
                style = LearnStyle.createWithStudentID(user.getID());
                style.setGlo(glo);
                style.setInte(inte);
                style.setRef(ref);
                style.setVrb(vrb);
                style.save();
                cycle.activate("SelfEval");
            } else {
                error = "Please fill out all results.";
            }
        }
    }
    
    public Integer getRef() {
        return ref;
    }
    
    public void setRef(Integer ref) {
        this.ref = ref;
    }
    
    public Integer getInte() {
        return inte;
    }
    
    public void setInte(Integer inte) {
        this.inte = inte;
    }
    
    public Integer getGlo() {
        return glo;
    }
    
    public void setGlo(Integer glo) {
        this.glo = glo;
    }
    
    public Integer getVrb() {
        return vrb;
    }
    
    public void setVrb(Integer vrb) {
        this.vrb = vrb;
    }
    
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
    
    public boolean isCompleted() {
        return completed;
    }
    
    public String getError() {
        if(error == null) return "You will only need to fill this survey once." +
                " After you finish this, you can only view your answers, but" +
                " not resubmit it. Check your answers twice before you submit" +
                " it.";
        return error;
    }

    private User getUser() {
        Visit visit = (Visit)getVisit();
        User user = visit.getUser();
        return user;
    }
    
    private boolean answerCompleted() {
        return glo != null &&
                inte != null &&
                vrb != null &&
                glo != null;
    }
}
