package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;
import org.apache.tapestry.form.IPropertySelectionModel;
import org.apache.tapestry.form.StringPropertySelectionModel;

import edu.ncsu.paireval.Util;
import edu.ncsu.paireval.component.*;
import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.component.SelectionModelUtil;
import edu.ncsu.paireval.domain.*;
import edu.ncsu.paireval.domain.Course;
import edu.ncsu.paireval.domain.User;

public class RegisterCourse extends ProtectedPage implements PageRenderListener {
	String courseNumber, sectionName;
	IPropertySelectionModel sectionSelectionModel;
	IPropertySelectionModel courseSelectionModel;
	Registration currentCourse;

	public boolean isAccessible() {
		User user = getCurrentUser();
		return user.isStudent();
	}

	public void pageBeginRender(PageEvent event) {
		if (event.getRequestCycle().isRewinding())
			return;
		courseSelectionModel = CourseNumberSelectionModel.populateAll();
		if (courseNumber != null) {
			Course course = Course.findByNumber(courseNumber);
			if (course != null) {
				buildSelectionModelFromCourse(course);
			} else {
				sectionSelectionModel = SelectionModelUtil.emptyModel();
			}
		} else {
			if (courseSelectionModel.getOptionCount() > 0) {
				String courseNumber = courseSelectionModel.getOption(0)
						.toString();
				Course course = Course.findByNumber(courseNumber);
				buildSelectionModelFromCourse(course);
			} else {
				sectionSelectionModel = SelectionModelUtil.emptyModel();
			}
		}
	}

	private void buildSelectionModelFromCourse(Course course) {
		Section[] sections = course.getSections();
		String[] sectionNames = new String[sections.length];
		for (int i = 0; i < sectionNames.length; i++) {
			sectionNames[i] = sections[i].getName();
		}
		sectionSelectionModel = new StringPropertySelectionModel(sectionNames);
	}

	public void detach() {
		sectionName = courseNumber = null;
		super.detach();
	}

	public void addCourse(IRequestCycle cycle) {
		if (Util.isEmptyString(courseNumber))
			return;
		User user = getCurrentUser();
		Role role = Role.findOrCreate(user.getID(), courseNumber);
		role.addRole(Role.STUDENT);
		role.save();
		Registration.findOrCreate(user.getID(), courseNumber, sectionName);
	}

	public void removeCourse(IRequestCycle cycle) {
		User user = getCurrentUser();
		Role role = Role.findByUserCourse(user.getID(), currentCourse
				.getCourseID());
		if (role != null) {
			role.removeRole(Role.STUDENT);
			role.save();
		}
		currentCourse.remove();
	}

	public String getCourseNumber() {
		return courseNumber;
	}

	public void setCourseNumber(String courseNumber) {
		this.courseNumber = courseNumber;
	}

	public IPropertySelectionModel getSectionSelectionModel() {
		return sectionSelectionModel;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public IPropertySelectionModel getCourseSelectionModel() {
		return courseSelectionModel;
	}

	public Registration[] getRegisteredCourses() {
		User user = getCurrentUser();
		return Registration.findByStudent(user.getID());
	}

	public Registration getCurrentCourse() {
		return currentCourse;
	}

	public void setCurrentCourse(Registration currentCourse) {
		this.currentCourse = currentCourse;
	}
}
