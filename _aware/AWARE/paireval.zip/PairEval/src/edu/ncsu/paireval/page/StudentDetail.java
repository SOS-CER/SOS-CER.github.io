package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.*;

public class StudentDetail extends RoleBasedPage {
    User user;
    Registration currentReg;
    Assignment currentAssignment;
    String currentGroup;
    PartnerPref pref;

    public int getAllowedRoles() {
        return Role.INSTRUCTOR | Role.TA;
    }
    
    public void detach() {
        user = User.NULL_USER;
        pref = null;
        super.detach();
    }
    
    public void grouping(IRequestCycle cycle) {
        Object[] params = cycle.getServiceParameters();
        GroupingPage grouping = (GroupingPage)cycle.getPage("Grouping");
        grouping.setCurrentCourseNumber((String)params[0]);
        grouping.setSelectedAssignment((String)params[1]);
        grouping.setSelectedSection((String)params[2]);
        grouping.setSelectedGroup((String)params[3]);
        cycle.activate(grouping);
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }

    public String getEmailLink() {
        return "mailto:" + user.getEmail();
    }
    
    public Registration[] getRegisteredCourses() {
        return Registration.findByStudent(user.getID());
    }
    
    public Registration getCurrentCourse() {
        return currentReg;
    }

    public void setCurrentCourse(Registration reg) {
        currentReg = reg;
    }
    
    public Assignment[] getAssignments() {
        return Assignment.findByCourse(currentReg.getCourseID());
    }
    
    public Assignment getCurrentAssignment() {
        return currentAssignment;
    }
    
    public void setCurrentAssignment(Assignment assignment) {
        currentAssignment = assignment;
    }
    
    public String getGroup() {
        currentGroup = Grouping.findGroup(
                currentReg.getCourseID(),
                currentAssignment.getNumber(), user.getID());
        if (currentGroup == null) return "N/A";
        return currentGroup;
    }
    
    public String[] getGroupingParams() {
        return new String[]{currentAssignment.getCourseNumber(),
                currentAssignment.getNumber(),
                currentReg.getSectionName(),
                currentGroup};
    }
    
    public boolean isGroupingDisabled() {
        Role r = Role.findByUserCourse(
                getCurrentUser().getID(), currentReg.getCourseID());
        if(r == null) return true;
        if(r.hasRole(Role.INSTRUCTOR) || r.hasRole(Role.TA)) return false;
        return true;
    }
    
    public PartnerPref getPref() {
        if(pref == null) {
            pref = PartnerPref.findOrCreateByUserID(
                    currentReg.getCourseID(), user.getID());
        }
        return pref;
    }
}
