package edu.ncsu.paireval.page;

import java.util.ArrayList;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.PartnerPref;
import edu.ncsu.paireval.domain.Role;
import edu.ncsu.paireval.domain.User;

public class PartnerPrefPage extends RoleBasedPage
        implements PageRenderListener{
    String error;
    String currentClassmate;
    PartnerPref pref;
    ArrayList xes;

    public int getAllowedRoles() {
        return Role.STUDENT;
    }
    
    public void pageBeginRender(PageEvent event) {
        if(!event.getRequestCycle().isRewinding()) {
            pref = PartnerPref.findOrCreateByUserID(
                    getCurrentCourseNumber(),
                    getCurrentUser().getID());
        } else {
            xes = new ArrayList();
        }
    }

    public void detach() {
        error = null;
        pref = null;
        super.detach();
    }
    
    public void savePref(IRequestCycle cycle) {
        if(xes.size() > 3) {
            error = "You selected more than three students.";
        } else {
            PartnerPref newPref = PartnerPref.findOrCreateByUserID(
                    getCurrentCourseNumber(),
                    getCurrentUser().getID());
            newPref.resetPref();
            for(int i = 0; i<xes.size(); i++) {
                newPref.setX(i, (String)xes.get(i));
            }
            newPref.save();
            error = "Preferences saved.";
        }
    }
    
    public String getError() {
        return error;
    }
    
    public String[] getClassmates() {
        User user = getCurrentUser();
        User[] classmates = user.getClassmates(getCurrentCourseNumber());
        String[] classmateID = new String[classmates.length];
        for (int i = 0; i < classmateID.length; i++) {
            classmateID[i] = classmates[i].getID();
        }
        return classmateID;
    }
    
    public void setCurrentClassmate(String id) {
        currentClassmate = id;
    }
    
    public String getClassmateName() {
        User user = User.findByID(currentClassmate);
        if(user == null) {
            //should not happen
            return "*ERROR*";
        } else {
            return user.getName();
        }
    }
    
    public boolean isCurrentStudentSelected() {
        return pref.isX(currentClassmate);
    }
    
    public void setCurrentStudentSelected(boolean selected) {
        if(selected) xes.add(currentClassmate);

    }
}
