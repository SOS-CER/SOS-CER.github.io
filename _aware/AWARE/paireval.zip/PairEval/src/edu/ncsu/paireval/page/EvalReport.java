package edu.ncsu.paireval.page;

import java.util.ArrayList;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.form.IPropertySelectionModel;
import org.apache.tapestry.form.StringPropertySelectionModel;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.component.SectionNumberSelectionModel;
import edu.ncsu.paireval.domain.Assignment;
import edu.ncsu.paireval.domain.Role;
import edu.ncsu.paireval.domain.User;

public class EvalReport extends RoleBasedPage {
    String selectedAssignment;
    String selectedSection;
    boolean selfIncluded;
    String reviewNumber;
    String error;

    public int getAllowedRoles() {
        return Role.TA | Role.INSTRUCTOR;
    }
    
    public void detach() {
        selectedAssignment = null;
        selectedSection = null;
        selfIncluded = false;
        error = null;
        reviewNumber = "1";
        super.detach();
    }
    
    public void generateReport(IRequestCycle cycle) {
        int iReviewNumber;
        try {
            iReviewNumber = Integer.parseInt(reviewNumber);
        } catch (NumberFormatException nfe) {
            error = "Please input a correct number.";
            return;
        }
        Assignment a = Assignment.findByNumber(
                getCurrentCourseNumber(), selectedAssignment);
        if(iReviewNumber < 1 || iReviewNumber > a.getReviewNumber()) {
            error = "This assignment does not have this review#";
            return;
        }
        EvalReportResult result = 
                (EvalReportResult)cycle.getPage("EvalReportResult");
        result.setCourse(getCurrentCourseNumber());
        result.setSection(selectedSection);
        result.setAssignment(selectedAssignment);
        result.setSelfIncluded(selfIncluded);
        result.setNumber(iReviewNumber);
        cycle.activate(result);
    }
    
    public String getSelectedAssignment() {
        return selectedAssignment;
    }
    
    public void setSelectedAssignment(String selectedAssignment) {
        this.selectedAssignment = selectedAssignment;
    }
    
    public IPropertySelectionModel getAssignmentSelectionModel() {
        Assignment[] assignments = Assignment.findByCourse(
                getCurrentCourseNumber());
        String[] numbers = collectAssignmentNumbers(assignments);
        return new StringPropertySelectionModel(numbers);
    }
    
    String[] collectAssignmentNumbers(Assignment[] assignments) {
        ArrayList lst = new ArrayList(assignments.length);
        for (int i = 0; i < assignments.length; i++) {
            lst.add(assignments[i].getNumber());
        }
        return (String[])lst.toArray(new String[assignments.length]);
    }
    
    public String getSelectedSection() {
        return selectedSection;
    }
    
    public void setSelectedSection(String selectedSection) {
        this.selectedSection = selectedSection;
    }
    
    public IPropertySelectionModel getSectionSelectionModel() {
        User user = getCurrentUser();
        Role role = Role.findByUserCourse(
                user.getID(), getCurrentCourseNumber());
        IPropertySelectionModel ret;
        if(role.hasRole(Role.INSTRUCTOR)) {
            ret = SectionNumberSelectionModel.populate(
                    getCurrentCourseNumber(), true);
        } else {
            ret = SectionNumberSelectionModel.populateByTA(
                    getCurrentCourseNumber(), user.getID());
        }
        return ret;
    }
    
    public boolean isSelfIncluded() {
        return selfIncluded;
    }
    
    public void setSelfIncluded(boolean selfIncluded) {
        this.selfIncluded = selfIncluded;
    }
    
    public String getReviewNumber() {
        return reviewNumber;
    }
    
    public void setReviewNumber(String reviewNumber) {
        this.reviewNumber = reviewNumber;
    }
    
    public String getError() {
        return error;
    }
}
