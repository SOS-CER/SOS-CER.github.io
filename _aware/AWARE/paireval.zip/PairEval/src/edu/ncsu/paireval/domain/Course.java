package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

public class Course implements Serializable{
    String name, number;
    String owner;
    
    public static Course findByNumber(String number) {
        Course course = new Course();
        String sql = "select * from course where cnum = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, number);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                course.number = rst.getString("cnum");
                course.name = rst.getString("name");
                course.owner = rst.getString("owner");
            } else {
                course = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return course;
    }
    
    public static Course[] findAll() {
        ArrayList ret = new ArrayList();
        String sql = "select * from course;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Course course = new Course();
                course.number = rst.getString("cnum");
                course.name = rst.getString("name");
                course.owner = rst.getString("owner");
                ret.add(course);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (Course[])ret.toArray(new Course[ret.size()]);
    }

    public static Course[] findByOwner(String id) {
        ArrayList ret = new ArrayList();
        String sql = "select * from course where owner = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Course course = new Course();
                course.number = rst.getString("cnum");
                course.name = rst.getString("name");
                course.owner = rst.getString("owner");
                ret.add(course);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (Course[])ret.toArray(new Course[ret.size()]);
    }

    public static Course create(String courseNumber, String courseName) {
        Course c = new Course();
        c.name = courseName;
        c.number = courseNumber;
        String sql = "insert into course (cnum, name) values (?, ?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, courseNumber);
            stmnt.setString(2, courseName);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            c = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return c;
    }
    
    public String getName() {
        return name;
    }
    
    public String getNumber() {
        return number;
    }

    public void remove() {
        //remove all roles associated to this course
        Role[] roles = Role.findByCourse(number);
        for (int i = 0; i < roles.length; i++) {
            roles[i].remove();
        }
        
        //remove the course from db
        String sql = "delete from course where cnum = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, number);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public void save() {
        String sql = "update course set name = ?, owner = ? where cnum = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, name);
            stmnt.setString(2, owner);
            stmnt.setString(3, number);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }

    public Section findSection(String sectionNumber) {
        return Section.findByName(number, sectionNumber);
    }

    public Assignment findAssignment(String assignmentNumber) {
        return Assignment.findByNumber(number, assignmentNumber);
    }

    public Section createSection(String sectionName) {
        Section section = Section.create(number, sectionName);
        return section;
    }

    public Assignment createAssignment(String assignmentNumber) {
        Assignment assignment = Assignment.create(
                number, assignmentNumber);
        return assignment;
    }

    public Section[] getSections() {
        return Section.findByCourse(number);
    }

    public void removeSection(String sectionNumber) {
        Section s = Section.findByName(number, sectionNumber);
        if(s != null) {
            s.remove();
        }
    }

    public Assignment[] getAssignments() {
        return Assignment.findByCourse(number);
    }
    
    public String getOwner() {
        return owner;
    }
    
    public void setOwner(String owner) {
        this.owner = owner;
    }
}
