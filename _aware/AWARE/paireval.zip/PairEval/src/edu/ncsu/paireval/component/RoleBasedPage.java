package edu.ncsu.paireval.component;

import edu.ncsu.paireval.Visit;
import edu.ncsu.paireval.domain.User;

public abstract class RoleBasedPage extends ProtectedPage {
    public boolean isAccessible() {
        User user = getCurrentUser();
        int userRole = user.getRoles(getCurrentCourseNumber());
        int roleApplied = getAllowedRoles() & userRole;
        return roleApplied != 0;
    }

    public String getCurrentCourseNumber() {
        return ((Visit)getVisit()).getCurrentCourseNumber();
    }
    
    public void setCurrentCourseNumber(String courseNumber) {
        ((Visit)getVisit()).setCurrentCourseNumber(courseNumber);
    }
    
    public abstract int getAllowedRoles();
}
