package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;
import org.apache.tapestry.event.PageEvent;
import org.apache.tapestry.event.PageRenderListener;
import org.apache.tapestry.form.IPropertySelectionModel;

import edu.ncsu.paireval.Util;
import edu.ncsu.paireval.Visit;
import edu.ncsu.paireval.component.CourseNumberSelectionModel;
import edu.ncsu.paireval.component.ProtectedPage;
import edu.ncsu.paireval.domain.Course;
import edu.ncsu.paireval.domain.Role;

public class ManageCourse extends ProtectedPage implements PageRenderListener{
    String message;
    String courseNumber;
    String courseName;
    transient IPropertySelectionModel courseSelectionModel;
    
    public void detach() {
        message = null;
        courseNumber = null;
        courseName = null;
        super.detach();
    }
    
    public boolean isAccessible() {
        return getCurrentUser().isInstructor();
    }
    
    public void pageBeginRender(PageEvent event) {
        this.courseSelectionModel = CourseNumberSelectionModel.populateByOwner(
                getCurrentUser().getID());
    }

    
    public String getMessage() {
        return message;
    }
    
    public String getCourseNumber() {
        return courseNumber;
    }
    
    public void setCourseNumber(String number) {
        this.courseNumber = number;
    }
    
    public String getCourseName() {
        return courseName;
    }
    
    public void setCourseName(String name) {
        this.courseName = name;
    }
    
    public void addCourse(IRequestCycle requestCycle) {
        if(Util.isEmptyString(courseNumber)) {
            message = "Please choose a valid course number.";
            return;
        }
        Course course = Course.create(courseNumber, courseName);
        Visit visit = (Visit)getVisit();
        course.setOwner(visit.getUser().getID());
        course.save();
        Role role = Role.createNew(visit.getUser().getID(), courseNumber);
        role.addRole(Role.INSTRUCTOR);
        role.save();
        message = "Course " + courseNumber + " added.";
        courseName = courseNumber = null;
    }
    
    public void removeCourse(IRequestCycle requestCycle) {
        if(Util.isEmptyString(courseNumber)) {
            message = "Please specify the course number to be removed.";
            return;
        }
        Course toRemove = Course.findByNumber(courseNumber);
        if(toRemove == null) {
            message = "Course not found.";
            return;
        }
        toRemove.remove();
        message = "Course " + courseNumber + " removed.";
        courseNumber = null;
    }
    
    public IPropertySelectionModel getCourseNumberSelectionModel() {
        return courseSelectionModel;
    }
}
