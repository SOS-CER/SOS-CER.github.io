package edu.ncsu.paireval.page;

import org.apache.tapestry.IRequestCycle;

import edu.ncsu.paireval.component.RoleBasedPage;
import edu.ncsu.paireval.domain.*;
import edu.ncsu.paireval.domain.Course;
import edu.ncsu.paireval.domain.Role;

public class AssignTA extends RoleBasedPage {
    String currentSection;
    
    public int getAllowedRoles() {
        return Role.INSTRUCTOR;
    }

    public void detach() {
        currentSection = null;
        super.detach();
    }
    
    public void assignTA(IRequestCycle cycle) {
    }
    
    public String[] getSections() {
        Course course = Course.findByNumber(getCurrentCourseNumber());
        Section[] sections = course.getSections();
        String[] ret = new String[sections.length];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = sections[i].getName();
        }
        return ret;
    }
    
    public String getCurrentSection() {
        return currentSection;
    }
    
    public void setCurrentSection(String currentSection) {
        this.currentSection = currentSection;
    }
    
    public String getCurrentTA() {
        TAAssignment assignment = TAAssignment.find(
                getCurrentCourseNumber(), currentSection);
        if(assignment == null) {
            return null;
        } else{
            return assignment.getUserID();
        }
    }
    
    public void setCurrentTA(String currentTA) {
        if(currentTA != null) {
            TAAssignment assignment = TAAssignment.findOrCreate(
                    getCurrentCourseNumber(), currentSection);
            assignment.setUserID(currentTA);
            assignment.save();
            Role role = Role.findOrCreate(currentTA, getCurrentCourseNumber());
            role.addRole(Role.TA);
            role.save();
        } else {
            TAAssignment assignment = TAAssignment.find(
                    getCurrentCourseNumber(), currentSection);
            if(assignment != null) assignment.remove();
            Role role = Role.findByUserCourse(
                    assignment.getUserID(), getCurrentCourseNumber());
            if(role != null) {
                role.removeRole(Role.TA);
                role.save();
            }
        }
    }
}
