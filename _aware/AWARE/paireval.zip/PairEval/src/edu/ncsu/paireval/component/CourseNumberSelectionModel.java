package edu.ncsu.paireval.component;

import org.apache.tapestry.form.IPropertySelectionModel;

import edu.ncsu.paireval.domain.Course;

public final class CourseNumberSelectionModel
        implements IPropertySelectionModel {
    Course[] foundCourses;
    
    private CourseNumberSelectionModel(){
    }
    
    static public CourseNumberSelectionModel populateAll() {
        CourseNumberSelectionModel ret = new CourseNumberSelectionModel();
        ret.foundCourses = Course.findAll();
        return ret;
    }
    
    static public CourseNumberSelectionModel populateByOwner(String ownerID) {
        CourseNumberSelectionModel ret = new CourseNumberSelectionModel();
        ret.foundCourses = Course.findByOwner(ownerID);
        return ret;
    }

    public int getOptionCount() {
        return foundCourses.length;
    }

    public Object getOption(int index) {
        return foundCourses[index].getNumber();
    }

    public String getLabel(int index) {
        return foundCourses[index].getNumber() + " -- " +
                foundCourses[index].getName();
    }

    public String getValue(int index) {
        return foundCourses[index].getNumber();
    }

    public Object translateValue(String value) {
        return value;
    }

}
