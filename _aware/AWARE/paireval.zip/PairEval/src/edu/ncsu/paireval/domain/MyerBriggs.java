package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.*;

import edu.ncsu.paireval.database.DBConnection;

public class MyerBriggs implements Serializable{
    String EI, SI, TF, JP;
    int EIValue, SIValue, TFValue, JPValue;
    String user;

    public static MyerBriggs findByUser(String id) {
        MyerBriggs mb = new MyerBriggs();
        String sql = "select * from myers_briggs where user = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                mb.user = id;
                mb.EI = rst.getString("ei");
                mb.SI = rst.getString("si");
                mb.TF = rst.getString("tf");
                mb.JP = rst.getString("jp");
                mb.EIValue = rst.getInt("eiv");
                mb.SIValue = rst.getInt("siv");
                mb.TFValue = rst.getInt("tfv");
                mb.JPValue = rst.getInt("jpv");
            } else {
                mb = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return mb;
    }
    
    public static MyerBriggs createNew(String userID) {
        MyerBriggs mb = new MyerBriggs();
        mb.user = userID;
        String sql = "insert into myers_briggs (user) values (?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, userID);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            mb = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return mb;
    }
    
    public void save() {
        StringBuffer sql = new StringBuffer();
        sql.append("update myers_briggs set")
                .append(" ei = ?, eiv = ?,")
                .append(" si = ?, siv = ?,")
                .append(" tf = ?, tfv = ?,")
                .append(" jp = ?, jpv = ?")
                .append(" where user = ?;");
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql.toString());
        try {
            stmnt.setString(1, EI); stmnt.setInt(2, EIValue);
            stmnt.setString(3, SI); stmnt.setInt(4, SIValue);
            stmnt.setString(5, TF); stmnt.setInt(6, TFValue);
            stmnt.setString(7, JP); stmnt.setInt(8, JPValue);
            stmnt.setString(9, user);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
    
    public String getEI() {
        return EI;
    }
    
    public void setEI(String ei) {
        EI = ei;
    }
    
    public String getSI() {
        return SI;
    }
    
    public void setSI(String si) {
        SI = si;
    }
    
    public String getTF() {
        return TF;
    }
    
    public void setTF(String tf) {
        TF = tf;
    }
    
    public String getJP() {
        return JP;
    }
    
    public void setJP(String jp) {
        JP = jp;
    }

    public Integer getEIValue() {
        return new Integer(EIValue);
    }
    
    public void setEIValue(Integer value) {
        this.EIValue = value.intValue();
    }

    public Integer getSIValue() {
        return new Integer(SIValue);
    }
    
    public void setSIValue(Integer value) {
        this.SIValue = value.intValue();
    }

    public Integer getTFValue() {
        return new Integer(TFValue);
    }
    
    public void setTFValue(Integer value) {
        this.TFValue = value.intValue();
    }

    public Integer getJPValue() {
        return new Integer(JPValue);
    }
    
    public void setJPValue(Integer value) {
        this.JPValue = value.intValue();
    }

}
