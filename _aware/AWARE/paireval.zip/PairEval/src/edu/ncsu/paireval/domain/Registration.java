package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import edu.ncsu.paireval.database.DBConnection;

public class Registration implements Serializable{
    String userID, courseID, sectionName;
    
    public static Registration findOrCreate(
            String userID, String courseID, String sectionName) {
        Registration ret = find(userID, courseID, sectionName);
        if(ret == null) {
            ret = createNew(userID, courseID, sectionName);
        }
        return ret;
    }
    
    public static Registration createNew(
            String userID, String courseID, String sectionName) {
        Registration reg = new Registration();
        reg.userID = userID;
        reg.courseID = courseID;
        reg.sectionName = sectionName;
        String sql = "insert into registration (user, course, section_name)" +
                " values (?, ?, ?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, userID);
            stmnt.setString(2, courseID);
            stmnt.setString(3, sectionName);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            reg = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return reg;
    }
    
    public static Registration find(
            String userID, String courseID, String sectionName) {
        Registration reg = new Registration();
        String sql = "select * from registration where user = ?" +
                " and course = ? and section_name = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, userID);
            stmnt.setString(2, courseID);
            stmnt.setString(3, sectionName);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                reg.userID = userID;
                reg.sectionName = sectionName;
                reg.courseID = courseID;
            } else {
                reg = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return reg;
    }
    
    public static Section findSectionByStudent(String userID, String courseID) {
        Section section = new Section();
        String sql =
                "select * from registration where user = ? and course = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, userID);
            stmnt.setString(2, courseID);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                section.courseNumber = courseID;
                section.name = rst.getString("section_name");
            } else {
                section = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return section;
    }

    public static Registration[] findBySection(
            String courseID, String sectionName) {
        ArrayList ret = new ArrayList();
        String sql = "select * from registration where course = ?" +
                " and section_name = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, courseID);
            stmnt.setString(2, sectionName);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Registration reg = new Registration();
                reg.courseID = courseID;
                reg.sectionName = sectionName;
                reg.userID = rst.getString("user");
                ret.add(reg);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (Registration[])ret.toArray(new Registration[ret.size()]);
    }
    
    public static Registration[] findByStudent(String id) {
        ArrayList ret = new ArrayList();
        String sql = "select * from registration where user = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            rst = stmnt.executeQuery();
            while (rst.next()) {
                Registration reg = new Registration();
                reg.userID = id;
                reg.courseID = rst.getString("course");
                reg.sectionName = rst.getString("section_name");
                ret.add(reg);
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }        
        return (Registration[])ret.toArray(new Registration[ret.size()]);
    }
    
    public static int getSectionSize(String course, String section) {
        String sql =
                "select count(*) from registration" +
                " where course = ? and section_name = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, course);
            stmnt.setString(2, section);
            rst = stmnt.executeQuery();
            rst.next();
            return rst.getInt(1);
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            return 0;
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
    
    public void remove() {
        String sql = "delete from registration where user = ? and " +
                "course = ? and section_name = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, userID);
            stmnt.setString(2, courseID);
            stmnt.setString(3, sectionName);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
    
    public String getCourseID() {
        return courseID;
    }

    public String getSectionName() {
        return sectionName;
    }

    public String getUserID() {
        return userID;
    }
}
