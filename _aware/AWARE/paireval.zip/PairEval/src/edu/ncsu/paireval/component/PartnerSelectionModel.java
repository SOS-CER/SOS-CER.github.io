package edu.ncsu.paireval.component;

import org.apache.tapestry.form.IPropertySelectionModel;

import edu.ncsu.paireval.domain.User;

public class PartnerSelectionModel implements IPropertySelectionModel {
    User[] partners;
    
    public static PartnerSelectionModel populate(
            User user,
            String courseNumber,
            String assignment) {
        PartnerSelectionModel model = new PartnerSelectionModel();
        model.partners = user.getPartners(courseNumber, assignment);
        return model;
    }
    
    public int getOptionCount() {
        return partners.length;
    }

    public Object getOption(int index) {
        return partners[index];
    }

    public String getLabel(int index) {
        User p = (User)getOption(index);
        return p.getName();
    }

    public String getValue(int index) {
        User p = (User)getOption(index);
        return p.getID();
    }

    public Object translateValue(String value) {
        for (int i = 0; i < partners.length; i++) {
            User p = partners[i];
            if(p.getID().equals(value)) return p;
        }
        return null;
    }

}
