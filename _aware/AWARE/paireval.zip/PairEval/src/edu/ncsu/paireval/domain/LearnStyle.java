package edu.ncsu.paireval.domain;

import java.io.Serializable;
import java.sql.*;

import edu.ncsu.paireval.database.DBConnection;

public class LearnStyle implements Serializable{
    Integer ref, inte, vrb, glo;
    String userID;
    
    public static LearnStyle findByStudentID(String id) {
        LearnStyle ls = new LearnStyle();
        String sql = "select * from lstyles where user = ?;";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        ResultSet rst = null;
        try {
            stmnt.setString(1, id);
            rst = stmnt.executeQuery();
            if (rst.next()) {
                ls.userID = id;
                ls.ref = new Integer(rst.getInt("ref"));
                ls.inte = new Integer(rst.getInt("inte"));
                ls.vrb = new Integer(rst.getInt("verb"));
                ls.glo = new Integer(rst.getInt("glo"));
            } else {
                ls = null;
            }
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(rst != null) rst.close();
            } catch (SQLException ignored) {
            }
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return ls;
    }

    public static LearnStyle createWithStudentID(String id) {
        LearnStyle ls = new LearnStyle();
        ls.userID = id;
        String sql = "insert into lstyles (user) values (?);";
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql);
        try {
            stmnt.setString(1, id);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
            ls = null;
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
        return ls;
    }

    public String getUserID() {
        return userID;
    }
    
    public Integer getRef() {
        return ref;
    }
    
    public void setRef(Integer ref) {
        this.ref = ref;
    }

    public Integer getGlo() {
        return glo;
    }

    public void setGlo(Integer glo) {
        this.glo = glo;
    }
    
    public Integer getInte() {
        return inte;
    }
    
    public void setInte(Integer inte) {
        this.inte = inte;
    }
    
    public Integer getVrb() {
        return vrb;
    }
    
    public void setVrb(Integer vrb) {
        this.vrb = vrb;
    }

    public void save() {
        StringBuffer sql = new StringBuffer();
        sql.append("update lstyles set")
                .append(" ref = ?, inte = ?,")
                .append(" verb = ?, glo = ?")
                .append(" where user = ?;");
        DBConnection ctn = DBConnection.getInstance();
        PreparedStatement stmnt = ctn.getStatement(sql.toString());
        try {
            stmnt.setInt(1, ref.intValue());
            stmnt.setInt(2, inte.intValue());
            stmnt.setInt(3, vrb.intValue());
            stmnt.setInt(4, glo.intValue());
            stmnt.setString(5, userID);
            stmnt.execute();
        } catch(SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            try {
                if(stmnt != null) stmnt.close();
            } catch (SQLException ignored) {
            }
            ctn.release();
        }
    }
}
