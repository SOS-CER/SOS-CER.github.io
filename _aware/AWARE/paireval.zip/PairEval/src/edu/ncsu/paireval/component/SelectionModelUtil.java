package edu.ncsu.paireval.component;

import org.apache.tapestry.form.IPropertySelectionModel;
import org.apache.tapestry.form.StringPropertySelectionModel;

public class SelectionModelUtil {
    public static IPropertySelectionModel emptyModel() {
        return new StringPropertySelectionModel(new String[0]);
    }
}
