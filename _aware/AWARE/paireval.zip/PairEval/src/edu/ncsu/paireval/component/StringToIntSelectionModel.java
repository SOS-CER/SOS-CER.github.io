package edu.ncsu.paireval.component;

import org.apache.tapestry.form.IPropertySelectionModel;

public class StringToIntSelectionModel implements IPropertySelectionModel {
    String[] values;
    
    public static StringToIntSelectionModel newInstance(String[] values) {
        StringToIntSelectionModel model = new StringToIntSelectionModel();
        model.values = values;
        return model;
    }
    
    public int getOptionCount() {
        return values.length;
    }

    public Object getOption(int index) {
        return new Integer(index);
    }

    public String getLabel(int index) {
        return values[index];
    }

    public String getValue(int index) {
        return String.valueOf(index);
    }

    public Object translateValue(String value) {
        return Integer.valueOf(value);
    }

}
