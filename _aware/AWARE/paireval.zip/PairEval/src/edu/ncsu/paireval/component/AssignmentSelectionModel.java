package edu.ncsu.paireval.component;

import org.apache.tapestry.form.IPropertySelectionModel;

import edu.ncsu.paireval.domain.Assignment;

public class AssignmentSelectionModel implements IPropertySelectionModel {
    public static AssignmentSelectionModel populate(String courseNumber) {
        AssignmentSelectionModel model = new AssignmentSelectionModel();
        model.assignments = Assignment.findByCourse(courseNumber);
        return model;
    }
    
    Assignment[] assignments;

    public int getOptionCount() {
        return assignments.length;
    }

    public Object getOption(int index) {
        return assignments[index].getNumber();
    }

    public String getLabel(int index) {
        Assignment assignment = assignments[index];
        return assignment.getLabel();
    }

    public String getValue(int index) {
        return (String)getOption(index);
    }

    public Object translateValue(String value) {
        return value;
    }

}
